#include <iostream>
#include <string>
#include <set>
#include <vector>
#include <map>
#include <cstdio>
#include <fstream>

using namespace std;


#include <DBVariant.h>
#include <readcframe.h>
#include <tstemplate.h>
#include <UTCDateTime.h>
#include <Kinematic.h>
#include <Types.h>
#include <genrinexheader.h>
#include <Consts.h>

using namespace libgnss;

/**
 * @brief Возращает данные о параметрах программы
 * @return Пара: (Обязательные параметры, Необязательные параметры)
 *
 * Параметры задаются отображением: ключ параметра -> доп. информация
 */
map<string,string> arguments()
{
	map<string,string> result;
	result["-о"] = "(Шаблон имен выходных файлов, не включая расширение)";
	result["-runby"] = "(Название организации, до 20 символов)";
	result["-mrkname"] ="(Имя БИС, 4 символа - заглавные буквы и цифры)";
	result["-mrknum"] ="(Серийный номер БИС, до 20 символов)";
	result["-mrktype"] ="(GEODETIC|NON_GEODETIC|NON_PHYSICAL|SPACEBORNE\n"
			"|AIRBORNE|WATER_CRAFT|GROUND_CRAFT|FIXED_BUOY|FLOATING_BUOY|\n"
			"|FLOATING_ICE|GLACIER|BALLISTIC|ANIMAL|HUMAN)";
	result["-observer"] =
			"(Краткое название организации, собирающей данные, до 20 символов)";
	result["-agency"]=
			"(Полное название организации, собирающей данные, до 40 символов)";
	result["-recn"]="(Серийный номер приёмника, до 20 символов)";
	result["-rectype"]="(Название серии приёмников, до 20 символов)";
	result["-recver"]="(Версия прошивки приёмника, до 20 символов)";
	result["-antsn"] = "(Серийный номер антенны, до 20 символов)";
	result["-anttype"] = "(Тип антенны, до 20 символов)";
	result["-anth"] = "(Высота антенны над маркером, м.";
	result["-ante"] = "(Смещение антенны от маркера на восток, м";
	result["-antn"] = "(Смещение антенны от маркера на север, м";
	result["-robs"] = "(Добавляемый тип измерений ГЛОНАСС, согласно RINEX3)";
	result["-gobs"] = "(Добавляемый тип измерений GPS, согласно RINEX3)";
}

void displayHelp()
{

	map<string,string> args = arguments();

	cout<<"Командная строка вызова: "<<endl
			<<endl
			<<"cframe2rinex (Параметры) [-files file1 [file2 [...]]]: "<<endl
			<<endl;
	for (map<string,string>::iterator it=args.begin();it!=args.end();++it)
		cout<<it->first<<" "<<it->second<<endl;
	cout<<"-rogs и -gobs указываются по разу для каждого типа измерений."<<endl;
	cout<<"Если -files не указано, то имена файлов будут считываться со "<<endl
	   <<"стандартного входного потока."<<endl;
}

void parsecmdline(int argc, char ** argv, map<string,string> & params,
				  set<string> & gobs, set<string> & robs,
				  vector<string> & filenames)
{
	map<string,string> args = arguments();
	for (unsigned int i=1; i<argc; i++)
	{
		string curarg (argv[i]);
		if (curarg == "-h")
		{
			displayHelp();
			exit(0);
		}
		if ((curarg!="-files") && (args.find(curarg) == args.end()))
		{
			cout<<"Пропускаем неизвестный параметр: "<<curarg<<endl;
			continue;
		}
		i++;
		if (i>=argc)
		{
			cerr<<"После "<<curarg<<"ожидалось: "<<arguments()[curarg];
			exit(-1);
		}
		if (curarg == "-files")
		{
			//Все остальные аргументы - имена файлов
			while(i<argc)
			{
				filenames.push_back(string(argv[i]));
				i++;
			}
			return;
		}
		if (curarg == "-gobs")
		{
			gobs.insert(string(argv[i]));
			continue;
		}
		if (curarg == "-robs")
		{
			robs.insert(string(argv[i]));
			continue;
		}
		params[curarg] = string(argv[i]);
	}
}

class CFrameToRINEXConverter
{
private:
	VtoFuncs * vto;
	//Параметры работы программы
	const map<string,string> & params;
	const set<string> & gobs;
	const set<string> & robs;
	map<string,string> fn_replacements;
	UTCDateTime previous_dt;

	//Имя выводимых в данный момент файлов
	string curfilename;

	ofstream obsfile;
	ofstream navfile;
	ofstream meteofile;

	//Место в файле измерений, куда нужно будет записать координаты БИС
	int markerpos_fpos;

	//Усредненные координаты БИС
	kinematic<real,3,defaultNonInert> position;

	//По скольки моментам времени усреднение?
	int position_n;

	//Странная структура для vto.dll
	tblgpsutc_t utcGps;

	//Альманахи GPS и ГЛОНАСС
	tblAlmGps_t* almGps;
	tblAlmGlo_t* almGlo;

	//Внутренние структуры vto
	int* hprgnz;
	int* hcrdsat;
	int* hcrdpnt;


	// Записать недостающую информацию в выбранные позиции в файлах
	void finishCurrentFile()
	{

	}

	kinematic<real,3,defaultNonInert> solveForPosition(lsttblSat_t * lsat)
	{
		//Магические вызовы libvto
		unsigned int timevto;
		timevto=vto->get_TmVto(lsat);
		utcGps.gpsutc = 0;
		almGlo= (tblAlmGlo_t*) (vto->get_AlmGlo(hprgnz, lsat));
		almGps= (tblAlmGps_t*) (vto->get_AlmGps(hprgnz, lsat));
		lsttblCrdSat_t*lcrdsat=(lsttblCrdSat_t*)(vto->get_crdsat(hcrdsat,lsat,
											timevto,utcGps.gpsutc,0.0));
		vto->set_crdpnt_sys(hcrdpnt,0);
		tblCrdPnt_t*crdpnt_glo_gps=(tblCrdPnt_t *)
				(vto->get_crdpnt(hcrdpnt,lcrdsat));
		kinematic<real,3,defaultNonInert> result;
		result[0] = crdpnt_glo_gps->crd[0];
		result[1] = crdpnt_glo_gps->crd[1];
		result[2] = crdpnt_glo_gps->crd[2];
		return result;
	}

	//Записать заголовки новых файлов (пока с некоторыми полями пустыми)
	void newFile(const UTCDateTime & first_epoch)
	{
		//Сделать строковое представление первой эпохи
		//Часы в GPS
		string time_of_first_obs = fillTemplate(
				"  %YYYY    %MM    %MD    %HH    %mm    %SS.0000000     GPS",
						first_epoch);

		//Запись заголовка файла измерительных данных
		obsfile.open((curfilename+"o").c_str());
		string obshead = generateRINEXObsHeader(params,gobs,robs,
												time_of_first_obs,
												markerpos_fpos);
		obsfile<<obshead;

		//Запись аголовка файла навигационной информации
		navfile.open((curfilename+"p").c_str());
		string navhead = generateRINEXNavHeader(params);
		navfile<<navhead;
	}

	map<string, string> genObsDataString(const tblObs_t & obsdata)
	{
		static string empty("              ");
		map<string,string> result;

		if (obsdata.actual[0]) //1C
		{
			result["C1C"] = Variant((real)obsdata.psvd[0]).toString("%14.3f");
			result["L1C"] = Variant((real)obsdata.faze[0]).toString("%14.3f");
			result["D1C"] = Variant((real)obsdata.dop[0]).toString("%14.3f");
		}
		else
			result["C1C"]=result["L1C"]=result["D1C"]=empty;

		if (obsdata.actual[1]) //2C
		{
			result["C2C"] = Variant((real)obsdata.psvd[1]).toString("%14.3f");
			result["L2C"] = Variant((real)obsdata.faze[1]).toString("%14.3f");
			result["D2C"] = Variant((real)obsdata.dop[1]).toString("%14.3f");
		}
		else
			result["C2C"]=result["L2C"]=result["D2C"]=empty;

		if (obsdata.actual[2]) //1P
		{
			result["C1P"] = Variant((real)obsdata.psvd[2]).toString("%14.3f");
			result["L1P"] = Variant((real)obsdata.faze[2]).toString("%14.3f");
			result["D1P"] = Variant((real)obsdata.dop[2]).toString("%14.3f");
		}
		else
			result["C1P"]=result["L1P"]=result["D1P"]=empty;

		if (obsdata.actual[3]) //2P
		{
			result["C2P"] = Variant((real)obsdata.psvd[3]).toString("%14.3f");
			result["L2P"] = Variant((real)obsdata.faze[3]).toString("%14.3f");
			result["D2P"] = Variant((real)obsdata.dop[3]).toString("%14.3f");
		}
		else
			result["C2P"]=result["L2P"]=result["D2P"]=empty;
		return result;
	}

	//Записать эпоху измерительных данных
	void writeObsDataEpoch(lsttblSat_t * lsat, const UTCDateTime & dt)
	{
		int nsats = lsat->nglo + lsat->ngps;
		string epochrecord = fillTemplate(
			"> %YYYY %MM %MD %HH %mm %SS.0000000  0"
					+takeNChars(Variant(nsats).toString(),3), dt);
		obsfile<<epochrecord<<endl;

		//Записать измерения всех НКА GPS
		for (int i=0; i<lsat->ngps; i++)
		{
			obsfile<<"G"<<Variant(lsat->lstgps[i].hdr->num).toString("%2d");
			map<string,string> obsdata=genObsDataString(*(lsat->lstgps[i].obs));
			for(set<string>::const_iterator it = gobs.begin();
				it!=gobs.end(); ++it)
				obsfile<<obsdata[*it]<<"00";
			obsfile<<endl;
		}

		//Записать измерения всех НКА ГЛОНАСС
		for (int i=0; i<lsat->nglo; i++)
		{
			obsfile<<"R"<<Variant(lsat->lstglo[i].hdr->num).toString("%2d");
			map<string,string> obsdata=genObsDataString(*(lsat->lstglo[i].obs));
			for(set<string>::const_iterator it = robs.begin();
				it!=robs.end(); ++it)
				obsfile<<obsdata[*it]<<"00";
			obsfile<<endl;
		}
	}

	//Записать эпоху навигационной информации, если надо
	void writeNavDataEpoch(lsttblSat_t * lsat)
	{

	}

	string verifyObsTypes( const set<string> & obstypes)
	{
		string allowedtypes = "CLD";
		string allowedbands = "12";
		string allowedattrs = "PC";
		for (set<string>::const_iterator it = obstypes.begin();
			 it!=obstypes.end(); ++it)
		{
			const string & curobstype = *it;
			if ((allowedtypes.find_first_of(curobstype[0])==string::npos)
				||(allowedbands.find_first_of(curobstype[1])==string::npos)
					||(allowedattrs.find_first_of(curobstype[2])==string::npos))
				return curobstype;
		}
		return "";
	}

public:
	CFrameToRINEXConverter(VtoFuncs * vto, const map<string,string> & _params,
						   const set<string> & _gobs,
						   const set<string> & _robs)
		: params(_params), gobs(_gobs), robs(_robs)
	{
		string unsupported = verifyObsTypes(gobs);
		if (unsupported.size() > 0)
			throw StrException("CFrameToRINEXConverter",
							   "Неподдерживаемый тип измерительных данных GPS: "
							   +unsupported);
		unsupported = verifyObsTypes(gobs);
		if (unsupported.size() > 0)
			throw StrException("CFrameToRINEXConverter",
							   "Неподдерживаемый тип измерительных данных "
							   "ГЛОНАСС: "+unsupported);

		this->vto = vto;
		hprgnz = vto->prg_init();
		hcrdsat = vto->crds_init();
		hcrdpnt = vto->crdp_init();

		curfilename = "";
		fn_replacements["%MRKN"] = params.at("-mrkname");
		//Тогда GPS не было
		previous_dt = UTCDateTime::fromUTCDateTime(1900,1,1,0,0,0.0);
	}

	~CFrameToRINEXConverter()
	{
		vto->prg_finit(hprgnz);
		vto->crds_finit(hcrdsat);
		vto->crdp_finit(hcrdpnt);
		finishCurrentFile();
	}

	void convertEpoch(lsttblSat_t * lsat)
	{
		real tmvto;
		// Момент времени - выбрать наименьший среди всех НКА
		if (lsat->nglo>0)
			tmvto = lsat->lstglo[0].obs->tmVto;
		else if (lsat->ngps>0)
			tmvto = lsat->lstgps[0].obs->tmVto;
		else return;

		for (unsigned int i=0; i<lsat->nglo; i++)
			if (lsat->lstglo[i].obs->tmVto < tmvto)
				tmvto = lsat->lstglo[i].obs->tmVto;

		for (unsigned int i=0; i<lsat->ngps; i++)
			if (lsat->lstgps[i].obs->tmVto < tmvto)
				tmvto = lsat->lstgps[i].obs->tmVto;

		UTCDateTime dt =  UTCDateTime::fromUTCJ2000(tmvto - 15*3600);
		if (dt.getTAIJ2000()<=previous_dt.getTAIJ2000())
		{
			cerr<<"Эпоха: "<<dt.getUTCDateTimeString()<<" меньше предыдущей: "
			   <<previous_dt.getUTCDateTimeString()<<"C-кадр пропущен."<<endl;
			return;
		}

		//Имя файла
		string newfilename = fillTemplate(params.at("-o"), dt, fn_replacements);

		//Если необходимо, открыть новые файлы
		if (newfilename!=curfilename)
		{

			if (curfilename!="")
				finishCurrentFile();
			curfilename = newfilename;
			newFile(dt);
		}

		//Решить навигационную задачу
		if (position_n < 1e10)
		{
			kinematic<real,3,defaultNonInert> solnav = solveForPosition(lsat);
			if (solnav.length<0,2>() != 0)
			{
				position = position*((real)position_n/((real)position_n+1))
									 + solnav * (1.0l / (real)(position_n+1));
				position_n++;
			}
		}

		//Записать эпоху измерительных данных
		writeObsDataEpoch(lsat, dt);

	}
};

int main(int argc, char ** argv)
{
	map<string,string> params;
	set<string> gobs;
	set<string> robs;
	vector<string> filenames;
	parsecmdline(argc,argv,params,gobs,robs,filenames);
	VtoFuncs vto;
	if (vto.ok == false)
	{
		cout<<"Не удалось загрузить блоб vto.dll"<<endl;
		return -1;
	}

	CFrameToRINEXConverter converter(&vto, params, gobs, robs);

	int i = 0;
	while (true)
	{
		string nextfilename;
		if (filenames.size() > 0)
		{
			if (i>filenames.size())
				break;
			nextfilename = filenames[i];
			i++;
		}
		else
		{
			cout<<"Введите имя файла: ";
			if (cin.eof())
				break;
			getline(cin,nextfilename);
			if (nextfilename == "")
				continue;
		}
		//Пробуем открыть файл
		FILE*fpbin = fopen(nextfilename.c_str(), "rb");
		if (fpbin == 0)
		{
			cout<<"Пропускаем несуществующий файл: "<<nextfilename<<endl;
			continue;
		}
		int*hvto = vto.cinit();
		int*hprgnz = vto.prg_init();
		int*hcrdsat = vto.crds_init();
		int*hcrdpnt = vto.crdp_init();

		unsigned char data[4096];
		unsigned char typekrd[1];
		unsigned short int head[1];

		fseek(fpbin, 0, SEEK_END);
		fseek(fpbin, 0, SEEK_SET);
		while(!feof(fpbin))
		{
			// Иногда вместе с Цкадром записывается 25 кадр, который необходимо
			//пропустить
			if (fread(data,1,1,fpbin) < 1)
				break; //Выйти, если неожиданный конец файла

			if ((data[0]==0xA5) || (data[0]==0x25))
			{
				fseek(fpbin,57,SEEK_CUR);
				fread(data,1,1,fpbin);
				continue;
			}
			if ((data[0]!=0x0C) && (data[0]!=0x1C))
			{
				fclose(fpbin);
				throw WrongCFrameFormat("Неожиданный тип кадра: "+
										Variant((int)(data[0])).toString());
			}
			//Чтение C-кадра
			if (fread(&(data[1]),2,1,fpbin)<1)
				break; //Выйти, если неожиданный конец файла
			unsigned short int size = *((unsigned short int *)(&(data[1])));
			fread(&(data[3]),1,size-3,fpbin);
	//		fread(data,head[0],1,fpbin);

			// Передать один C-кадр конвертеру
			lsttblSat_t * lsat=(lsttblSat_t*) vto.cupx0c(hvto,data);
			converter.convertEpoch(lsat);
		}

		//Уничтожить все созданные временные объекты
		vto.cfinit(hvto);
		vto.prg_finit(hprgnz);
		vto.crds_finit(hcrdsat);
		vto.crdp_finit(hcrdpnt);
		fclose(fpbin);
	}

	return 0;
}

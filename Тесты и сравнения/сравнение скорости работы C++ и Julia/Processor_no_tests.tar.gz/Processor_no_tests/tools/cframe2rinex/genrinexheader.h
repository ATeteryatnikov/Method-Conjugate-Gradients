#ifndef GENRINEXHEADER_H_
#define GENRINEXHEADER_H_

#include <string>
#include <map>
#include <set>


/**
 * @brief Функция генерирует заголовок RINEX Obs 3.0
 * @param params Свойства БИС
 * @param gobs Набор записываемых измерений GPS
 * @param robs Набор записываемых измерений ГЛОНАСС
 * @param[out] time_of_first_obs_pos Позиция начальной метки времени
 * @param[out] time_of_last_obs_pos Позиция конечной метки времени
 * @param[out] approxposition_pos Позиция приблизительного положения БИС
 * @return Строка с заголовком
 *
 * Функция генерирует заголовок файла RINEX Obs 3.0, оставляя незаполненными
 * поля APPROX POSITION XYZ, TIME_OF_FIRST_OBS, TIME_OF_LAST_OBS и возвращая
 * их позицию в полученной строке заголовка.
 */
std::string generateRINEXObsHeader(
		std::map<std::string,std::string> params,
		std::set<std::string> gobs,
		std::set<std::string> robs,
		std::string time_of_first_obs,
		int & approxposition_pos
		);

std::string generateRINEXNavHeader(
		std::map<std::string,std::string> params
		);

#endif

#include <genrinexheader.h>
#include <sstream>
#include <tstemplate.h>
#include <DBError.h>
#include <DBVariant.h>


using namespace std;
using namespace libgnss;

std::string generateRINEXObsHeader(std::map<std::string,std::string> params,
		std::set<std::string> gobs,
		std::set<std::string> robs,
		string time_of_first_obs,
		int & approxposition_pos
		)
{
	static set<string> mrktypes;
	if (mrktypes.size() == 0)
	{
		mrktypes.insert("NON_GEODETIC");
		mrktypes.insert("NON_PHYSICAL");
		mrktypes.insert("SPACEBORNE");
		mrktypes.insert("AIRBORNE");
		mrktypes.insert("WATER_CRAFT");
		mrktypes.insert("GROUND_CRAFT");
		mrktypes.insert("FIXED_BUOY");
		mrktypes.insert("FLOATING_BUOY");
		mrktypes.insert("FLOATING_ICE");
		mrktypes.insert("GLACIER");
		mrktypes.insert("BALLISTIC");
		mrktypes.insert("ANIMAL");
		mrktypes.insert("HUMAN");
	}
	//Проверить тип маркера
	if (mrktypes.find(params["-mrktype"]) == mrktypes.end())
		throw StrException("generateRINEXObsHeader","Неизвестный тип маркера: '"
						   +params["-mrktype"]+"'");

	ostringstream hd;
	hd
		<<"     3.00           OBSERVATION DATA    M (MIXED)           RINEX VERSION / TYPE"<<endl
		<<"cframe2rinex        "
		<<takeNChars(params.at("-runby"),20)
		<<fillTemplate("%UYYYY%UMM%UMD %UHH%UmmUSS UTC ",UTCDateTime::now())
		<<"PGM / RUN BY / DATE "<<endl
		<<takeNChars(takeNChars(params.at("-mrkname"),4),60)
		<<takeNChars("MARKER NAME",20)<<endl
		<<takeNChars(params.at("-mrknum"),60)
		<<takeNChars("MARKER NUMBER",20)<<endl
		<<takeNChars(params.at("-observer"),20)
		<<takeNChars(params.at("-agency"),40)
		<<takeNChars("OBSERVER / AGENCY",20)<<endl
		<<takeNChars(params.at("-recn"),20)
		<<takeNChars(params.at("-rectype"),20)
		<<takeNChars(params.at("-recver"),20)
		<<takeNChars("REC # / TYPE / VERS", 20)<<endl
		<<takeNChars(params.at("-antsn"),20)
		<<takeNChars(takeNChars(params.at("-anttype"),20),40)
		<<takeNChars("ANT # / TYPE", 20)<<endl;

	//Запомнить положение APPROX_POSITION_XYZ
	approxposition_pos = hd.str().size();

	hd
		<<takeNChars("",60)<<takeNChars("APPROX POSITION XYZ",20)<<endl
		<<Variant::fromString(Variant::TYPE_DOUBLE, params.at("-anth")).toString("%14.4f")
		<<Variant::fromString(Variant::TYPE_DOUBLE, params.at("-ante")).toString("%14.4f")
		<<Variant::fromString(Variant::TYPE_DOUBLE, params.at("-antn")).toString("%14.4f")
		<<takeNChars("",18)<<takeNChars("ANTENNA: DELTA H/E/N",20)<<endl;

	//Типы измерений GPS
	int i=0;
	for (set<string>::iterator it = gobs.begin(); it!=gobs.end(); ++it, i++)
	{
		if (i==0)
			hd<<"G  "<<takeNChars(Variant((int)gobs.size()).toString(),3);
		else if (i%13==0)
			hd<<endl<<"      ";
		hd<<" "<<*it;
	}
	hd<<endl;

	//Типы измерений ГЛОНАСС
	i=0;
	for (set<string>::iterator it = robs.begin(); it!=robs.end(); ++it, i++)
	{
		if (i==0)
			hd<<"G  "<<takeNChars(Variant((int)robs.size()).toString(),3);
		else if (i%13==0)
			hd<<endl<<"      ";
		hd<<" "<<*it;
	}
	hd<<endl;

	hd
		<<takeNChars(time_of_first_obs,60)
		<<takeNChars("TIME OF FIRST OBS",20)<<endl
		<<takeNChars("",60)
		<<takeNChars("END OF HEADER",20)<<endl;

	return hd.str();
}

std::string generateRINEXNavHeader(
		std::map<std::string,std::string> params
		)
{
	ostringstream hd;
	hd
		<<"     3.00           NAVIGATION DATA     M (MIXED)           RINEX VERSION / TYPE"<<endl
		<<"cframe2rinex        "
		<<takeNChars(params.at("-runby"),20)
		<<fillTemplate("%UYYYY%UMM%UMD %UHH%UmmUSS UTC ",UTCDateTime::now())
		<<"PGM / RUN BY / DATE "<<endl
		<<takeNChars("",60)
		<<takeNChars("END OF HEADER",20)<<endl;
	return hd.str();

}

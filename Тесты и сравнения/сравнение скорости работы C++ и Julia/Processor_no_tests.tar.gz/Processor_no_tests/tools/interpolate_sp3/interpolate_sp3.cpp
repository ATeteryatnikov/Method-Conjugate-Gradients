#include <interpsp3.h>
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
	//Загрузить библиотеку
	InterpSP3Funcs interp;
	//Проверить, загружена ли библиотека
	if (interp.ok == false)
	{
		cout<<"SP3 interpolator library not loaded."<<endl;
		return -1;
	}

	// Сообщения об ошибке будут поступать в этот буфер в кодировке UTF8
	char errbuf[1000];

	cout<<"An error should occur..."<<endl;

	//Создать интерполятор
	void * interpolator = interp.createInterpolator_gpswd("non-existing.sp3",
														  1567, 1, 1567, 6,
														  "leap_seconds.dates",
														  "coordinates.tc",
														  0,
														  true,
														  true,
														  errbuf);
	if (interpolator == 0)
		cout<<errbuf<<endl;

	cout<<"Now no error should occur"<<endl;

	//Создать интерполятор
	interpolator = interp.createInterpolator_gpswd("igs%WWWW%D.sp3",
														  1567, 1, 1567, 6,
														  "leap_seconds.dates",
														  "coordinates.tc",
														  0,
														  true,
														  true, errbuf);
	if (interpolator == 0)
	{
		cerr<<errbuf<<endl;
		cerr<<"Test sp3 files not found"<<endl;
		return -1;
	}

	//Массив, куда будут возвращаться координаты, скорость и ускорение
	double ret[9];

	//Идентификатор системы координат WGS84
	int wgs84_id = interp.getFrameID(interpolator, "WGS84-G1150");

	int gpsweek = 1567;

	cout.precision(16);
	for (unsigned int gpsday = 1; gpsday<=6; gpsday++)
	{
		for (unsigned int hour = 0; hour<24; hour++)
			for (unsigned int minute = 0; minute<50; minute++)
			{
				interp.interpolateSP3_gpswdf(interpolator, 'G', 25,
								 gpsweek, //GPS неделя
								 gpsday,    //GPS сутки
								 (3600.0l * hour + 60.0l * minute) /86400.0l,  //Дробная часть суток
								 wgs84_id,
								 2,  //Координаты, скорость и ускорение
								 ret,
								 errbuf);
				if (isnan(ret[0]))
				{
					cerr<<errbuf<<endl;
					continue;
				}
				cout<<"week="<<gpsweek<<" day="<<gpsday<<" hour="<<hour
				   <<" minute="<<minute<<" position_wgs84=("<<ret[0]<<";"
				  <<ret[1]<<";"<<ret[2]<<") velocity_wgs84=("<<ret[3]<<";"
				 <<ret[4]<<";"<<ret[5]<<") acceleration_wgs84=("<<ret[6]<<";"
				<<ret[7]<<";"<<ret[8]<<")"<<endl;
			}
	}

	cout<<"week=1567 day=0 hour=0 minute=0 ";
	//Для этого момента времени траектория не загружена, поэтому будет ошибка
	interp.interpolateSP3_gpswdf(interpolator, 'G', 25,
								 1567, //GPS неделя
								 0,    //GPS сутки
								 0.0l,  //Дробная часть суток
								 wgs84_id,
								 2,
								 ret,
								 errbuf);
	cout<<errbuf<<endl;


	interp.destroyInterpolator(interpolator);
}

#ifndef INTERPSP3_H_
#define INTERPSP3_H_

#include <cstdio>

#include <gnssconfig.h>

#ifdef Win32
#include <windows.h>
#include <tchar.h>
#else
#include <dlfcn.h>
#endif

#include <iostream>

/*Функции инициализации интерполятора. Указать:
 *
 *
 * 1) tmpl - шаблон имени SP3-файла, т.е. строка, содержащая плейсхолдеры,
 * которые будут затем заполнены с помощью меток времени.
 *
 * Допустимые плейсхолдеры:
 *
 * %WWWW - неделя GPS (четырехзначное число)
 * %D - день недели GPS (одна цифра 0-6)
 * %[G|R|U]YYYY - год (четырехзначное число)
 * %[G|R|U]yy - год (двухзначное число)
 * %[G|R|U]YDD - день в году (трехзначное число)
 * %[G|R|U]MM - месяц (двухзначное число)
 * %[G|R|U]MD - день месяца (двухзначное число)
 * %[G|R|U]HH - час (двухзначное число)
 * %[G|R|U]mm - минута (двухзначное число)
 * %[G|R|U]SS - секунда (двухзначное число)
 * %[G|R|U]h - час (буква от a до x)
 *
 * Префиксы G, R или U обозначают шкалу G (GPS), R (Московское время) или
 * U (шкала UTC).
 *
 * Если при переводе в строку получается меньшее число цифр, то строка
 * дополняется нулями.
 *
 * 2) Временной интервал, для которого необходимо загрузить SP3-файлы.
 * Указывается разными способами (см. ниже).
 *
 * 3) leapsec - имя файла с датами введения секунд координации. Если leapsec == 0,
 * будут учитываться только секунды координации до 2015 года.
 *
 * 4) coordsys - имя файла с данными о системах координат. Если coordsys == 0, можно будет
 * интерполировать координаты только в той системе координат, в которой они приведены в
 * SP3-файле
 *
 * 5) ldfile - если нужно, загрузка каких-либо других данных во внутреннем формате библиотеки gnsscore
 * Если ничего не нужно, передать 0.
 *
 * 6) calc_velocity - если нужно считать скорость, она будет предпросчитана на этапе инициализации
 *
 * 7) calc_acceleration - если нужно считать ускорение НКА, оно будет предпросчитано
 *
 * 8) error - указатель на буфер, куда будет возвращено сообщение об ошибке.
 *
 * Сфункции createInterpolator_... возвращают либо указатель на объект
 * интерполятора, либо 0 при возникновении ошибки. Если возникла ошибка,
 * сообщение будет выведено в кодировке UTF8 в буфер error.
 *
 */


// from, until задаются датами UTC в виде строк в формате YYYY-MM-DD_hh:mm:ss.sss (длины полей - фиксированные!)
typedef void * (*createInterpolator_utc_)(const char* tmpl, const char * from,
						  const char * until,
						  const char * leapsec, const char * coordsys,
						  const char * ldfile,
						  bool calc_velocity,
                                                  bool calc_acceleration, char * error);

// Временной интервал задаётся в виде дат GPS: номеров недель и дней недели GPS
typedef void * (*createInterpolator_gpswd_)(const char* tmpl, int gpsw_from, int gpsd_from,
						  int gpsw_until, int gpsd_until,
						  const char * leapsec, const char * coordsys,
						  const char * ldfile,
						  bool calc_velocity,
                                                  bool calc_acceleration, char * error);

// Временной интервал задаётся величинами, передающимися в оперативной информации ГЛОНАСС:
//n4 - номер четырехлетнего интервала, nt - номер дня в четырехлетнем интервале, tb - номер секунд в пределах суток
//(см. ИКД)
typedef void * (*createInterpolator_glonavinf_)(const char* tmpl, int tb_from, int nt_from, int n4_from,
						  int tb_until, int nt_until, int n4_until,
						  const char * leapsec, const char * coordsys,
						  const char * ldfile,
						  bool calc_velocity,
                                                  bool calc_acceleration, char * error);

// ВременнОй интервал задаётся числом секунд (за исключением секунд координации !!!)
// от 5 января 1980 г. Московского декретного времени.
typedef void * (*createInterpolator_mdt1980_)(const char* tmpl, long long int mdt_from,
						  long long int mdt_until,
						  const char * leapsec, const char * coordsys,
						  const char * ldfile,
						  bool calc_velocity,
                                                  bool calc_acceleration, char * error);

/* Функции интерполяции interpolateSP3_... вычисляют координаты, скорость и
 * ускорение НКА. Они принимают:
 *
 * 1) interpolator - указатель на объект интерполятора, полученный от функции создания
 * интерполятора.
 *
 * 2) navsys - буква навигационной системы G - GPS, R - ГЛОНАСС
 *
 * 3) slot - слот для ГЛОНАСС и prn для GPS
 *
 * 4) Момент времени в каком-либо из форматов (см. ниже)
 *
 * 5) coordsys - номер системы координат (можно посмотреть в файле систем координат или
 * получить с помощью функции getFrameID() исходя из имени системы координат - опять же, они есть в файле)
 * Если файл с системами координат загружать не предполагается, то нужно писать 0 - идентификатор
 * системы координат, в которой SP3-файл.
 *
 * 6) nderivs: 0 - вычислять только положение, 1 - положение и скорость, 2 - ко всему ещё ускорение.
 * Для вычисления скоротей и ускорения нужно при создании интерполятора установить флаги calc_velocity и
 * calc_acceleration.
 *
 * 7) result - массив результата: 3 координаты, 3 компоненты скорости и 3 компоненты ускорения
 *
 * 8) error - указатель на буфер, куда будет возвращаена ошибка
 */

//Момент времени задаётся числом секунд (включая секунды координации) от 12:00 00.00.2000 TAI
typedef void (*interpolateSP3_tai_)(void * interpolator, char navsys, int slot,
                                    long long int tai, int coordsys, int nderivs,
                                    double * result, char * error);

//Момент времени задаётся числом секунд (не включая секунды координации) от 5 января 1980 г. Московского декретного времени
typedef void (*interpolateSP3_gln1980_)(void * interpolator, char navsys, int slot,
                long long int gln1980, int coordsys, int nderivs, double * result,
                                        char * error);

//Момент времени задаётся неделей, номером дня GPS и дробным числом суток frac (то есть frac=0 - начало суток, frac=1 - конец суток)
typedef void (*interpolateSP3_gpswdf_)(void * interpolator, char navsys, int slot, int gpsw, int gpsd,
                                double frac, int coordsys, int nderivs, double * result, char * error);

//Момент времени задаётся также, как эпоха эфемерид в оперативной информации ГЛОНАСС числами tb, nt, n4 (см. ИКД)
typedef void (*interpolateSP3_glonavinf_)(void * interpolator, char navsys, int slot, int tb, int nt,
                                        int n4, int coordsys, int nderivs, double * result, char * error);

// Момент времени задаётся датой UTC
typedef void (*interpolateSP3_utc_)(void * interpolator, char navsys, int slot, int YYYY, int MM, 
                                int DD, int hh, int mm, double sec, int coordsys, int nderivs,
                                double * result, char * error);

//Уничтожение объекта интерполятора
typedef void (*destroyInterpolator_)(void * interpolator);

//Получить идентификатор системы координат по её имени.
//Объект интерполятора загружает таблицу систем координат из файла; в файле
//указаны номера и имена систем координат. Лучше ориентироваться на имена,
//вроде ПЗ-90.02, ITRF00, и др., так как номера могут поменяться.
typedef int (*getFrameID_) (void * interpolator, const char * name);


struct InterpSP3Funcs
{
	bool ok;
#ifdef Win32
	HINSTANCE handle;
#else
	void * handle;
#endif
	createInterpolator_utc_ createInterpolator_utc;
	createInterpolator_gpswd_ createInterpolator_gpswd;
	createInterpolator_glonavinf_ createInterpolator_glonavinf;
	createInterpolator_mdt1980_ createInterpolator_mdt1980;
	interpolateSP3_tai_ interpolateSP3_tai;
	interpolateSP3_gln1980_ interpolateSP3_gln1980;
	interpolateSP3_gpswdf_ interpolateSP3_gpswdf;
	interpolateSP3_glonavinf_ interpolateSP3_glonavinf;
        interpolateSP3_utc_ interpolateSP3_utc;
	destroyInterpolator_ destroyInterpolator;
        getFrameID_ getFrameID;
	
	inline InterpSP3Funcs()
	{
		ok = false;
#ifdef Win32
                handle = LoadLibrary(TEXT("libinterpsp3.dll"));
		if (handle == NULL)
		{
			LPVOID lpMsgBuf;
			LPVOID lpDisplayBuf;
			DWORD dw = GetLastError();

			FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER |
				FORMAT_MESSAGE_FROM_SYSTEM |
				FORMAT_MESSAGE_IGNORE_INSERTS,
				NULL,
				dw,
				MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US),
				(LPTSTR) &lpMsgBuf,
				0, NULL );


			_tprintf( TEXT("%s\n"), lpMsgBuf );

			LocalFree(lpMsgBuf);
		}
		
                createInterpolator_utc=(createInterpolator_utc_)GetProcAddress(handle, "createInterpolator_utc");
                createInterpolator_gpswd=(createInterpolator_gpswd_)GetProcAddress(handle, "createInterpolator_gpswd");
                createInterpolator_glonavinf=(createInterpolator_glonavinf_)GetProcAddress(handle, "createInterpolator_glonavinf");
                createInterpolator_mdt1980=(createInterpolator_mdt1980_)GetProcAddress(handle, "createInterpolator_mdt1980");
                interpolateSP3_tai=(interpolateSP3_tai_)GetProcAddress(handle, "interpolateSP3_tai");
                interpolateSP3_gln1980=(interpolateSP3_gln1980_)GetProcAddress(handle, "interpolateSP3_gln1980");
                interpolateSP3_gpswdf=(interpolateSP3_gpswdf_)GetProcAddress(handle, "interpolateSP3_gpswdf");
                interpolateSP3_glonavinf=(interpolateSP3_glonavinf_)GetProcAddress(handle, "interpolateSP3_glonavinf");
                interpolateSP3_glonavinf=(interpolateSP3_glonavinf_)GetProcAddress(handle, "interpolateSP3_glonavinf");
                destroyInterpolator=(destroyInterpolator_)GetProcAddress(handle, "destroyInterpolator");
                getFrameID=(getFrameID_)GetProcAddress(handle, "getFrameID");

		
	#else

                handle = dlopen("./libinterpsp3.so", RTLD_LAZY);

                if (handle==0)
                        std::cerr<<dlerror()<<std::endl;
		
                createInterpolator_utc=(createInterpolator_utc_)dlsym(handle, "createInterpolator_utc");
                createInterpolator_gpswd=(createInterpolator_gpswd_)dlsym(handle, "createInterpolator_gpswd");
                createInterpolator_glonavinf=(createInterpolator_glonavinf_)dlsym(handle, "createInterpolator_glonavinf");
                createInterpolator_mdt1980=(createInterpolator_mdt1980_)dlsym(handle, "createInterpolator_mdt1980");
                interpolateSP3_tai=(interpolateSP3_tai_)dlsym(handle, "interpolateSP3_tai");
                interpolateSP3_gln1980=(interpolateSP3_gln1980_)dlsym(handle, "interpolateSP3_gln1980");
                interpolateSP3_gpswdf=(interpolateSP3_gpswdf_)dlsym(handle, "interpolateSP3_gpswdf");
                interpolateSP3_glonavinf=(interpolateSP3_glonavinf_)dlsym(handle, "interpolateSP3_glonavinf");
                interpolateSP3_glonavinf=(interpolateSP3_glonavinf_)dlsym(handle, "interpolateSP3_glonavinf");
                destroyInterpolator=(destroyInterpolator_)dlsym(handle, "destroyInterpolator");
                getFrameID=(getFrameID_)dlsym(handle, "getFrameID");
		
	#endif
		ok = true;
	}
	
	inline ~InterpSP3Funcs()
	{
	#ifdef Win32
		FreeLibrary(handle);
	#else
		dlclose(handle);
	#endif
	}
};

#endif

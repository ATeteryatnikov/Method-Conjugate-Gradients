#include <string>
#include <iostream>
#include <fstream>
#include <set>
#include <vector>

using namespace std;

#include <UTCDateTime.h>
#include <DBTableCollection.h>
#include <Settings.h>
#include <LeapSeconds.h>
#include <Frames.h>
#include <StdTables.h>
#include <ERPStorage.h>
#include <ParamTrajectory.h>
#include <readleapseconds.h>
#include <finals2000A.h>
#include <tstemplate.h>
#include <sp3.h>
#include <Acceleration.h>
#include <NumericAcceleration.h>

using namespace libgnss;

class SP3Interpolator
{
private:
	DBTableCollection * datacollection;
	Settings * sets;
	LeapSeconds * leaps;
	SatelliteHistory * history;
	Frames * frm;
	CoordinateTypes * ctypes;
	ParamTrajectory * traj;
	ITRFTranslation * itrftr;

	int src_frame_id;
	vector<int> coordinates;
	bool calc_accel;
	bool calc_velocity;

public:

	SP3Interpolator(const char * leapsec, const char * coordsys,
					const char * ldfile,
					bool calc_velocity,
					bool calc_acceleration
					)
	{
		this->calc_accel = calc_acceleration;
		this->calc_velocity = calc_velocity;
		//Создать коллекцию таблиц
		datacollection = new DBTableCollection();
		sets = new Settings(datacollection);
		leaps = new LeapSeconds(datacollection);
		history = new SatelliteHistory(datacollection);
		frm = new Frames(datacollection);
		ctypes = new CoordinateTypes(datacollection);
		traj = new ParamTrajectory(datacollection);
		itrftr = new ITRFTranslation(datacollection);

		//Загрузить файлы
		//Секунды координации
		if (leapsec == 0)
		{
			istringstream ss;
			readLeapSeconds(*leaps, ss);
		}
		else
		{
			ifstream leapseconds(leapsec);
			if (leapseconds.is_open())
				readLeapSeconds(*leaps,leapseconds);
			else
				throw StrException("SP3Interpolator", string(leapsec)+
								   ": file not found");
		}

		//Системы координат
		if (coordsys!=0)
		{
			ifstream coordsystem(coordsys);
			if (coordsystem.is_open())
				datacollection->readFromStream(coordsystem, cerr);
			else
				throw StrException("SP3Interpolator", string(coordsys)+
								   ": file not found");
		}

		//Дополнительный файл
		if (ldfile!=0)
		{
			ifstream auxfile(ldfile);
			if (auxfile.is_open())
				datacollection->readFromStream(auxfile,cerr);
			else
				throw StrException("SP3Interpolator", string(ldfile)+
								   ": file not found");
		}

		//Создать временную таблицу идентификаторов НКА
		for ( int i=1; i<=32; i++)
			history->insertRow(Tuple()<<'G'<<i<<i
						  <<UTCDateTime::fromUTCDateTime(1900,01,01,0,0,0.0l)
						  <<UTCDateTime::fromUTCDateTime(2100,01,01,0,0,0.0l));
		for ( int i=1; i<=24; i++)
			history->insertRow(Tuple()<<'R'<<i+700<<i
						  <<UTCDateTime::fromUTCDateTime(1900,01,01,0,0,0.0l)
						  <<UTCDateTime::fromUTCDateTime(2100,01,01,0,0,0.0l));


	}

	void loadSP3(const string & tmpl, const UTCDateTime & from,
						const UTCDateTime & until)
	{
		//Получить список SP3-файлов за весь интервал
		set<string> readsp3s = fillTemplate(tmpl, from, until);
		for (set<string>::iterator it=readsp3s.begin();it!=readsp3s.end(); ++it)
		{
			ifstream readsp3f(it->c_str());
			if (readsp3f.is_open())
			{
				try
				{
					readSP3(*datacollection, readsp3f);
				}
				catch (const FrameNotAvailableException & e)
				{
					//Если система координат неизвестна, добавить её и снова
					//перечитать SP3-файл, но тогда точно не будет работать
					//перевод в другую систему координат
					readsp3f.close();
					string newcs = e.coordSystem;
					int frame_id=frm->insertRow(Tuple()<<Frames::FT_ITRS
											   <<newcs);
					for (int i=0; i<9; i++)
						ctypes->insertRow(Tuple()<<frame_id<<i);
					readsp3f.open(it->c_str());
				}
			}
		}

		//В какой системе координат SP3-файл? Все данные траектории даны в одной
		//системе - можно найти номер СК по одной координате
		int coord1 = traj->const_begin().keyColumnValue(1).toInt();
		src_frame_id = ctypes->getCoordinateFrame(coord1); //ИД системы коорд.
		coordinates = frm->getFrameCoordinates(src_frame_id); //ИД координат

		//Проверить, что система координат поддерживает скорость и ускорение,
		//если нужно
		int numcoords_required = 3;
		if (calc_velocity)
			numcoords_required = 6;
		if (calc_accel)
			numcoords_required = 9;
		if (numcoords_required > coordinates.size())
		{
			for ( int i=coordinates.size(); i<numcoords_required; i++)
				ctypes->insertRow(Tuple()<<src_frame_id<<i);
			frm->clearCoordinatesCache();
			coordinates = frm->getFrameCoordinates(src_frame_id);
		}

		//Если требуется, вычислить скорость
		if (calc_velocity)
			traj->calcVelocity();

		//Если требуется, вычислить ускорение
		if (calc_accel)
		{
			//Вычислить ускорения численно
			NumericAcceleration accel(datacollection, src_frame_id,-1e-7l);

			//Скопировать ускорения в траекторию (при этом нужно правильно
			//указать номер координаты)
			for (DBTable::DBConstIterator it = accel.const_begin();
				 it!=accel.const_end(); ++it)
			{
				int sat_history_id = it.keyColumnValue(0).toInt();
				int coord0 = it.keyColumnValue(1).toInt();
				real tai = it.keyColumnValue(2).toDouble();
				int coord0_num = -1;
				for (int i=0; i<3; i++)
					if (coordinates[i] == coord0)
						coord0_num = i;
				if (coord0_num == -1)
					throw StrException("SP3Interpolator", "Internal error "
									   "(calculate acceleration)");
				traj->insertRow(Tuple()<<sat_history_id
								<<coordinates[coord0_num+6]
						<<tai, Tuple()<<it[0]);
			}
		}
	}

	//Найти идентификатор системы координат
	int getCoordSysID(const string & s)
	{
		return frm->getCoordinateFrameID(s);
	}

	//Интерполировать координаты, скорость и ускорение в заданный момент времени
	vector<real> interpolate(
			real tai, char navsys, int prn, int coordsys, int nderivs)
	{
		//DBTable::DBConstIterator it = frm->find(coordsys);
		int sat_history_id = history->getSatHistoryID(navsys, prn, tai);
		kinematic<real,9,defaultNonInert> pos_src;

		for (int i=0; i<3*(nderivs+1); i++)
			pos_src[i] = traj->getParameterValue(Tuple()<<sat_history_id
												 <<coordinates[i],tai);

		//Если нужно, перевести в другую систему координат
		if (coordsys!=src_frame_id)
		{
			if (nderivs == 0)
				pos_src = itrftr->translateITRF(pos_src.subset<0,2>(),
												src_frame_id,
												coordsys, tai).
						concat(kinematic<real,6,defaultNonInert>());

			if (nderivs == 1)
				pos_src = itrftr->translateITRF(pos_src.subset<0,5>(),
												src_frame_id,
												coordsys, tai).
						concat(kinematic<real,3,defaultNonInert>());

			if (nderivs == 2)
				pos_src = itrftr->translateITRF(pos_src,
												src_frame_id,
												coordsys, tai);
		}
		vector<real> result;
		for (int i=0; i<3*(nderivs+1); i++)
			result.push_back(pos_src[i]) ;

		return result;
	}

	//Деструктор интерполятора
	~SP3Interpolator()
	{
		delete itrftr;
		delete traj;
		delete ctypes;
		delete frm;
		delete history;
		delete leaps;
		delete sets;
		delete datacollection;
	}

};

//Библиотечные функции
extern "C" {

void * createInterpolator_utc(const char* tmpl, const char * from,
						  const char * until,
						  const char * leapsec, const char * coordsys,
						  const char * ldfile,
						  bool calc_velocity,
						  bool calc_acceleration,
						  char * error)
{
	SP3Interpolator*result;
	try
	{
		result=(new SP3Interpolator(leapsec, coordsys,
														ldfile,
														calc_velocity,
														calc_acceleration));
		result->loadSP3(tmpl,UTCDateTime::fromUTCDateTimeString(from),
					UTCDateTime::fromUTCDateTimeString(until));
	}
	catch (const StrException & e)
	{
		delete result;
		sprintf(error, e.what());
		return 0;
	}

	return (void*)result;
}

void * createInterpolator_gpswd(const char* tmpl, int gpsw_from, int gpsd_from,
						  int gpsw_until, int gpsd_until,
						  const char * leapsec, const char * coordsys,
						  const char * ldfile,
						  bool calc_velocity,
						  bool calc_acceleration,
						  char * error)
{
	SP3Interpolator*result;
	try
	{
		result=(new SP3Interpolator(leapsec, coordsys,
														ldfile,
														calc_velocity,
														calc_acceleration));
		result->loadSP3(string(tmpl),
				UTCDateTime::fromGPSWeekDayFrac(gpsw_from,gpsd_from, 0.0),
				UTCDateTime::fromGPSWeekDayFrac(gpsw_until,gpsd_until, 0.0));
	}
	catch (const StrException & e)
	{
		delete result;
		sprintf(error, e.what());
		return 0;
	}

	return (void*)result;
}

void * createInterpolator_glonavinf(const char* tmpl, int tb_from, int nt_from, int n4_from,
						  int tb_until, int nt_until, int n4_until,
						  const char * leapsec, const char * coordsys,
						  const char * ldfile,
						  bool calc_velocity,
						  bool calc_acceleration,
						  char * error)
{
	SP3Interpolator*result;
	try
	{
		result=(new SP3Interpolator(leapsec, coordsys,
														ldfile,
														calc_velocity,
														calc_acceleration));
		result->loadSP3(string(tmpl),
				UTCDateTime::fromGLONASSNavData(tb_from, nt_from, n4_from),
				UTCDateTime::fromGLONASSNavData(tb_until, nt_until, n4_until));
	}
	catch (const StrException & e)
	{
		delete result;
		sprintf(error, e.what());
		return 0;
	}
	return (void*)result;
}

void * createInterpolator_mdt1980(const char* tmpl, long long int mdt_from,
						  long long int mdt_until,
						  const char * leapsec, const char * coordsys,
						  const char * ldfile,
						  bool calc_velocity,
						  bool calc_acceleration,
						  char * error)
{
	SP3Interpolator*result;
	try
	{
		result=(new SP3Interpolator(leapsec, coordsys,
														ldfile,
														calc_velocity,
														calc_acceleration));
		result->loadSP3(string(tmpl),
				UTCDateTime::fromGLN6jan1980((real)mdt_from),
				UTCDateTime::fromGLN6jan1980((real)mdt_until));
	}
	catch (const StrException & e)
	{
		delete result;
		sprintf(error, e.what());
		return 0;
	}
	return (void*)result;
}

void interpolateSP3_tai_d(void * interpolator, char navsys, int slot, real tai,
						  int coordsys, int nderivs, double * result,
						  char * error)
{
	try
	{
		vector<real> result1 = ((SP3Interpolator*)(interpolator))->interpolate(tai, navsys, slot, coordsys, nderivs);
		for (int i=0; i<3*(nderivs+1); i++)
			 result[i] = result1[i];
	}
	catch (const StrException & e)
	{
		sprintf(error, e.what());
		for (unsigned int i=0; i<3*(nderivs+1); i++)
			result[i] = numeric_limits<double>::quiet_NaN();
	}
}

void interpolateSP3_tai(void * interpolator, char navsys, int slot,
						long long int tai, int coordsys, int nderivs,
						double * result, char * error)
{
	interpolateSP3_tai_d(interpolator, navsys, slot, (real)tai, coordsys,
						 nderivs, result, error);
}

void interpolateSP3_gln1980(void * interpolator, char navsys, int slot,
							long long int gln1980, int coordsys, int nderivs,
							double * result, char * error)
{
	interpolateSP3_tai_d(interpolator, navsys, slot,
					UTCDateTime::fromGLN6jan1980((real)gln1980).getTAIJ2000(),
						 coordsys, nderivs, result, error);
}

void interpolateSP3_gpswdf(void * interpolator, char navsys, int slot, int gpsw,
						   int gpsd, double frac, int coordsys, int nderivs,
						   double * result, char * error)
{
	interpolateSP3_tai_d(interpolator, navsys, slot,
				UTCDateTime::fromGPSWeekDayFrac(gpsw,gpsd,frac).getTAIJ2000(),
						 coordsys, nderivs, result, error);
}

void interpolateSP3_glonavinf(void * interpolator, char navsys, int slot,
							  int tb, int nt, int n4, int coordsys, int nderivs,
							  double * result, char * error)
{
	interpolateSP3_tai_d(interpolator, navsys, slot,
					UTCDateTime::fromGLONASSNavData(tb, nt, n4).getTAIJ2000(),
						 coordsys, nderivs, result, error);
}

void interpolateSP3_utc(void * interpolator, char navsys, int slot, int YYYY,
						int MM, int DD, int hh, int mm, double sec,
						int coordsys, int nderivs, double * result,
						char * error)
{
	interpolateSP3_tai_d(interpolator, navsys, slot,
		UTCDateTime::fromUTCDateTime(YYYY, MM, DD, hh, mm, sec).getTAIJ2000(),
						 coordsys, nderivs, result, error);
}

int getFrameID(void * interpolator, const char * name)
{
	return ((SP3Interpolator*)(interpolator))->getCoordSysID(name);
}

void destroyInterpolator(void * interpolator)
{
	delete (SP3Interpolator*)(interpolator);
}

}

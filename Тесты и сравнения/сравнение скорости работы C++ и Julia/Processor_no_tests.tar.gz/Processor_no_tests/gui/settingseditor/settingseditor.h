#ifndef SETTINGSEDITOR_H_
#define SETTINGSEDITOR_H_

#include <QWidget>
#include <QString>
#include <QList>
#include <DBVariant.h>
#include <QTabWidget>

class SettingsEditor : public QTabWidget
{
	Q_OBJECT
private:
	struct SetKey
	{
		QString group;
		QString module;
		QString key;
		libgnss::Variant::Type type;
		libgnss::Variant defaultValue;
	};
	QList<QPair<SetKey, QWidget*> > editwidgets;
private:
	SettingsEditor(){};
public:
	SettingsEditor(QWidget * parent);
	QString optionsStr();
};

#endif

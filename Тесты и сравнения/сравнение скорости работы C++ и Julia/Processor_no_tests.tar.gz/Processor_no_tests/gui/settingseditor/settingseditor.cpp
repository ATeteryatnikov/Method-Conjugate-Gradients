#include <settingseditor.h>
#include <StdTables.h>
#include <DBTable.h>
#include <QTabWidget>
#include <QGroupBox>
#include <QBoxLayout>
#include <QGridLayout>
#include <QScrollArea>
#include <QRegExpCheckEdit.h>
#include <QDateTimeEdit>
#include <QComboBox>
#include <string>
#include <map>
#include <QLabel>
#include <QFrame>

using namespace std;

using namespace libgnss;

SettingsEditor::SettingsEditor(QWidget *parent)
	: QTabWidget(parent)
{
	DBTable * enumerator = Settings::Enumerator::enumerator();



	//Цикл по группам
	for (DBTable::DBConstIterator it = enumerator->const_begin();
		 !it.isEnd(); it.inc(0))
	{
		QWidget * thispage = new QWidget(this);
		QVBoxLayout * thisgrouplay = new QVBoxLayout();
		thispage->setLayout(thisgrouplay);
		string thispagename = it.keyColumnValue(0).toString();

		//Цикл по модулям
		for (DBTable::DBConstIterator it1 = it; !it1.isEnd(); it1.subinc(1,0))
		{
			string thisgroupname = it1.keyColumnValue(1).toString();
			QGroupBox * gb = new QGroupBox(
						QString::fromUtf8(thisgroupname.data()), this);
			thisgrouplay->addWidget(gb);
			QGridLayout * lay = new QGridLayout();
			gb->setLayout(lay);

			int r = 0;
			//Цикл по ключам
			for (DBTable::DBConstIterator it2 = it1; !it2.isEnd();
				 it2.subinc(2,1))
			{
				if (r>0)
				{
					QFrame * hline = new QFrame(this);
					hline->setFrameStyle(QFrame::HLine | QFrame::Sunken);
					lay->addWidget(hline,r,0,1,2);
					r++;
				}
				SetKey newsetkey;
				string keyname = it2.keyColumnValue(2).toString();
				string hint = it2.values()[1].toString();
				newsetkey.group = QString::fromUtf8(thispagename.data());
				newsetkey.module = QString::fromUtf8(thisgroupname.data());
				newsetkey.key = QString::fromUtf8(keyname.data());
				newsetkey.defaultValue = it2.values()[2];
				newsetkey.type = CType::getCType(it2[0].toString());
				string defvalstr = newsetkey.defaultValue.toString();
				QString defval = QString::fromUtf8(defvalstr.data());

				//Создать виджет для редактирования настройки
				QWidget * cureditor;
				CTypeSelect*selecttype;
				if (newsetkey.type == Variant::TYPE_INT)
					cureditor = new QRegExpCheckEdit("$[-\\+][0-9]+^", defval);
				else if (newsetkey.type == Variant::TYPE_DOUBLE)
					cureditor = new QRegExpCheckEdit
						("^[-\\+][0-9]+(.[0-9]+)?([eE][-\\+][0-9]+)?$", defval);
				else if (newsetkey.type == Variant::TYPE_CHAR)
				{
					QLineEdit * cureditor_ = new QLineEdit(defval,this);
					cureditor_->setMaxLength(1);
					cureditor = cureditor_;
				}
				else if (newsetkey.type == Variant::TYPE_DATETIME)
				{
					UTCDateTime dt = Variant::fromString(Variant::TYPE_DATETIME,
											defvalstr).toUTCDateTime();
					QDateTimeEdit * cureditor_ = new QDateTimeEdit(this);
					int Y,M,D,h,m; real sec;
					dt.getUTCDateTime(Y,M,D,h,m,sec);
					cureditor_->setDate(QDate(Y,M,D));
					cureditor_->setTime(QTime(h,m,sec));
					cureditor = cureditor_;
				}
				else if ((selecttype=
						  dynamic_cast<CTypeSelect*>(newsetkey.type))!=NULL)
				{
					QComboBox * selbox = new QComboBox(this);
					map<int,string> opts = selecttype->getOptionsRev();
					map<string,int> opts_ = selecttype->getOptions();
					for (map<int,string>::iterator it3 = opts.begin();
						 it3!=opts.end(); ++it3)
					{
						string curoption = it3->second;
						selbox->addItem(QString::fromUtf8(curoption.data()));
					}
					cureditor = selbox;
					selbox->setCurrentIndex(opts_[defvalstr]);
				}
				else
					cureditor = new QLineEdit(defval,this);

				//Вставить виджеты
				lay->addWidget(new QLabel(QString::fromUtf8(hint.c_str()),this),
							   r,0,1,2);
				r++;
				lay->addWidget(new QLabel(QString::fromUtf8(keyname.c_str()),this),
							   r,0);
				lay->addWidget(cureditor,r,1);
				r++;
			}
		}
		QScrollArea * thispagescroll = new QScrollArea(this);
		thispagescroll->setWidget(thispage);
		addTab(thispagescroll,QString::fromUtf8(thispagename.data()));
	}
}

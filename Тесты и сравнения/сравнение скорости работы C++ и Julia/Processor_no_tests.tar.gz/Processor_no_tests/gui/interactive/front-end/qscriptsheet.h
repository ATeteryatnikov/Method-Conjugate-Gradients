#ifndef QSCRIPTSHEET_H
#define QSCRIPTSHEET_H

//! @file

#include <exception>

#include <QWidget>
#include <QTextEdit>
#include <QVector>
#include <QVBoxLayout>
#include <QAction>
#include <QPushButton>
#include <QKeyEvent>
#include <QScrollArea>
#include <QSyntaxHighlighter>
#include <QKeySequence>
#include <QMutex>
#include <QThread>
#include <QLabel>
#include <QProcess>

class QScriptSheet;

class ResultCell : public QTextEdit
{
	Q_OBJECT
private:
	qreal lastsize;
public:
	ResultCell(QWidget * parent);
public slots:
	void textChange();

};

class EditCell;

class BackEnd : public QObject
{
	Q_OBJECT
private:

	//Процесс выполнения скрипта
	QProcess * backend;

	//Текущая ячейка для возврата результата
	ResultCell * currentResult;

	//Текущая ячейка с кодом
	EditCell * codeCell;

	//Блок, не позволяющий запускать слишком одновременно несколько команд
	QMutex block;

	//Имя исполняемого файла интерпретатора
	QString command;

	//true - если интерпретатор уже начал возвращать результат вычислений
	//false - если интерпретатор возвращает промежуточный вывод
	bool returnresult;
public:

	//Запуск интерпретатора
	BackEnd(const QString & cmd);

	//Остановка интерпретатора
	~BackEnd();

	//Перезапуск интерпретатора
	void reset();

	//Попытка выполнить код
	void evaluate(const QString & program, ResultCell * resc, EditCell * cell);

	inline const QString & getCommand() const
	{
		return command;
	}

signals:

	//Когда никакой код не выполняется, весь посторонний вывод
	//перенаправляется с помощью этого сигнала
	void receiveOutputLine(const QString & str);
public slots:

	//Приём текстовых данных от процесса
	void readReady();

	//Приём сообщения об ошибке от процесса
	void errorReady();

	//Сигнал о том, что процесс остановился из-за ошибки
	void finished ( int exitCode, QProcess::ExitStatus exitStatus );

	void changeBackEnd (const QString & cmd);
};


class EditCell : public QTextEdit
{
	friend class BackEnd;
	friend class QScriptSheetEditor;
Q_OBJECT
private:
	QScriptSheet * base;
	int digitscount;
	int position;
	qreal lastSize;
	QSyntaxHighlighter * hilight;
	int fontwidth;
	QAction * evaluate;
	QAction * insertcodeblockafter;
	QAction * insertcodeblockbefore;
	QAction * delblock;
	QLabel * linenumbers;
public:
	EditCell (QScriptSheet * parent, int position);
	void setPosition(int position);
public slots:
	void insertCodeBlockAfter();
	void insertCodeBlockBefore();
	void deleteBlock();
	//Изменён текст внутри ячейки
	void textChanged ();
	//Изменено расположение текста ячейки (текст мог не поменяться)
	void textViewChanged ();
	void keyPressEvent ( QKeyEvent * e );
	void followCursor();
	void showContextMenu(const QPoint &pt);
	void doEvaluate();
protected slots:
	virtual void resizeEvent ( QResizeEvent * e );
};

class Splitter : public QWidget
{
Q_OBJECT
private:
	QScriptSheet * base;
	int position;
	QAction * cblock;
public:
	Splitter(QWidget *parent, QScriptSheet * base, int position);
public slots:
	virtual void mouseReleaseEvent ( QMouseEvent * event );
	void insertCodeBlock();
	void setPosition(int position);
};

class QScriptSheetEditor;

class QScriptSheet : public QWidget
{
	Q_OBJECT
	friend class QScriptSheetEditor;
	friend class EditCell;
private:
	QVBoxLayout * blayout;
	QScriptSheetEditor * editor;

public:

	explicit QScriptSheet(QWidget *parent = 0);
	void insertCodeCell(int position);

signals:
	
public slots:
	void checkLast(int position);
	void deleteCell(int position);
	void renumerateCells ();

};


class QScriptSheetEditor : public QScrollArea
{
	Q_OBJECT
	friend class ScriptSheet;
private:
	BackEnd * eng;
	QScriptSheet * sheet;
	ResultCell * pendingResult;
	static QKeySequence saveAs;
	static QKeySequence delCell;
	static QKeySequence evaluateCell;
	static QKeySequence saveSheet;
	static QKeySequence codeBlockAfter;
	static QKeySequence codeBlockBefore;

	QMutex evaluation;
	QString filename;
	void stdinit();
	EditCell * activecell;
public:

	bool isempty;

	QString getFilename()
	{
		return filename;
	}

	virtual void setFocus();

	inline void setActiveCell ( EditCell * c)
	{
		activecell = c;
	}

	QAction * abortEvaluation;

	inline QMutex & getEvaluation()
	{
		return evaluation;
	}

	inline ResultCell * getPendingResult()
	{
		return pendingResult;
	}

	void setPendingResult(ResultCell*cell);
	void evaluate(ResultCell * result, EditCell *cell);
	static QKeySequence & delCellKeySequence();
	static QKeySequence & evaluateCellSequence();
	static QKeySequence & saveSheetSequence();
	static QKeySequence & codeBlockAfterKeySequence();
	static QKeySequence & codeBlockBeforeKeySequence();
	static QKeySequence & saveAsKeySequence();
	QScriptSheetEditor(BackEnd * eng, QWidget * parent);
	QScriptSheetEditor(BackEnd *eng, const QString & filename, QWidget *parent);
public slots:
	void abort();
	void saveDocument ();
	void saveDocumentAs();
};

//-------ПОДСВЕТКА---------------------------------------//
class Highlighter : public QSyntaxHighlighter
{
	Q_OBJECT
public:
	Highlighter(QTextDocument *parent = 0);
	void SetRule(QString name,QString pattern,QTextCharFormat format);
protected:
	void highlightBlock(const QString &text);
	struct HighlightingRule
	{
		HighlightingRule() {}
		HighlightingRule(QRegExp _pattern,QTextCharFormat _format)
		{
			pattern = _pattern;
			format = _format;
		}
		QRegExp pattern;
		QTextCharFormat format;
	};
	QMap<QString,HighlightingRule> highlightingRules;
};

class MultiLineCommentHighlighter : public Highlighter
{
	Q_OBJECT
public:
	MultiLineCommentHighlighter(QTextDocument *parent = 0);
protected:
	void highlightBlock(const QString &text);
	QRegExp commentStartExpression;
	QRegExp commentEndExpression;
	QTextCharFormat multiLineCommentFormat;
};

class JSHighlighter : public MultiLineCommentHighlighter {
	Q_OBJECT
public:
	JSHighlighter(QTextDocument *parent = 0);
};

#endif // QSCRIPTSHEET_H

#ifndef FRONTEND_H_
#define FRONTEND_H_

//! @file

#include <QMainWindow>
#include <QString>
#include <QDockWidget>
#include <QLabel>
#include <QVector>
#include <QDialog>
#include <QListWidget>
#include <qscriptsheet.h>
#include <QSpinBox>
#include <QComboBox>

class InteractiveFrontEnd : public QMainWindow
{
	Q_OBJECT
private:
	QScriptSheetEditor * document;

	//Меню Файл
	QAction * newdocument;
	QAction * opendocument;
	QAction * save;
	QAction * saveas;
	QAction * changebackend;
	QAction * evaluate;
	QAction * restart;
	QAction * history;
	BackEnd * backend;
	QAction * helpme;
	void buildGui(QScriptSheetEditor * toAdd);
public:
	InteractiveFrontEnd ();
	InteractiveFrontEnd (const QString filename);
	~InteractiveFrontEnd();

public slots:
	void newDocument();
	void changeBackEnd();
	void openDocument();
	void evaluateCell();
	void helpMe();
	void resetName();
	void saveDocument();
	void saveDocumentAs();
	void showHistory();
	virtual void closeEvent(QCloseEvent *event);
};

class ScriptOutputConsole : public QDockWidget
{
Q_OBJECT
private:
	QScrollArea * scroll;
	QVector < QLabel * > lines;
	int maxlc;
	int curline;
	QWidget * inside;
	QVBoxLayout * inlay;
public:
	ScriptOutputConsole (int maxlines, QWidget * parent);
public slots:
	void receiveLine ( const QString & line );
};

class RecentFiles : public QDialog
{
	Q_OBJECT
private:
	QListWidget * recentfiles;
	QSpinBox * nmaxfiles;
public:
	RecentFiles(QWidget * parent);
	static void showRecent();
public slots:
	void dblClick(QListWidgetItem * item);
	void spboxChange (int N);


};

class ChooseInterpreter : public QDialog
{
	Q_OBJECT
private:
	QComboBox * interps;
	QPushButton * cancel;
	QPushButton * ok;
	QPushButton * del;
public:
	ChooseInterpreter(QWidget * parent);
	static QString chooseInterpreter();
public slots:
	void OK();
	void Cancel();
	void Del();
};

#endif

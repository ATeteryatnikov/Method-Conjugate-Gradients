//! @file

#include <frontend.h>

#include <QMessageBox>
#include <QToolBar>
#include <QFileDialog>
#include <QScrollBar>
#include <QSettings>
#include <QGridLayout>

void InteractiveFrontEnd::buildGui(QScriptSheetEditor * toAdd)
{
	document = toAdd;
	setCentralWidget(document);

	QToolBar*tb = addToolBar(QString::fromUtf8("Интерактивная обработка"));
	tb->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
	newdocument = tb->addAction(QIcon(":/menuicons/document-new.png"),
								QString::fromUtf8("Создать"),
								this, SLOT(newDocument()));
	opendocument = tb->addAction(QIcon(":/menuicons/document-open.png"),
								QString::fromUtf8("Открыть сценарий"),
								this, SLOT(openDocument()));
	history = tb->addAction(QIcon(":/menuicons/history.png"),
							QString::fromUtf8("История"),
							this,SLOT(showHistory()));
	history->setToolTip(QString::fromUtf8("Просмотреть последние файлы"));
	save = tb->addAction(QIcon(":/menuicons/document-save.png"),
								QString::fromUtf8("Сохранить"),
								this, SLOT(saveDocument()));
	saveas = tb->addAction(QIcon(":/menuicons/document-save-as.png"),
								QString::fromUtf8("Сохранить как"),
								this, SLOT(saveDocumentAs()));
	tb->addSeparator();
//	evaluate = tb->addAction(QIcon(":/menuicons/evaluate.png"),
//							 QString::fromUtf8("Выполнить"),
//							 this, SLOT(evaluateCell()));
	changebackend = tb->addAction(QIcon(":/menuicons/backend.png"),
								  QString::fromUtf8("Выбрать интерпретатор"),
								  this, SLOT(changeBackEnd()));
	changebackend->setToolTip(
				QString::fromUtf8("Выбрать команду запуска интерпретатора,\n"
								  "исполняющего сценарий"));
	restart = tb->addAction(QIcon(":/menuicons/reset.png"),
						   QString::fromUtf8("Сброс"),
						   document, SLOT(abort()));
	restart->setToolTip(QString::fromUtf8("Перезапустить интерпретатор"));
	tb->addSeparator();
	helpme = tb->addAction(QIcon(":/menuicons/help.png"),
						   QString::fromUtf8("Руководство"),
						   this, SLOT(helpMe()));
	document->setFocus();
	setMinimumHeight(250);
	ScriptOutputConsole * con = new ScriptOutputConsole(100,this);
	addDockWidget(Qt::BottomDockWidgetArea, con);
	connect(backend, SIGNAL(receiveOutputLine(QString)), con,
											SLOT(receiveLine(QString)));
	setWindowIcon(QIcon(":/menuicons/windowicon.png"));
	resetName();
}

BackEnd * newBackEnd(bool select = false)
{
	QString cmd = ChooseInterpreter :: chooseInterpreter();
	if (cmd=="")
		return 0;
	return new BackEnd(cmd);
}

InteractiveFrontEnd::~InteractiveFrontEnd()
{
//	delete backend;
}

InteractiveFrontEnd::InteractiveFrontEnd ()
{
	backend = newBackEnd();
	if (backend == 0)
	{
		deleteLater();
		return;
	}
	QScriptSheetEditor * edt = new QScriptSheetEditor(backend,this);
	buildGui(edt);
}

InteractiveFrontEnd::InteractiveFrontEnd (const QString filename)
{
	backend = newBackEnd();
	if (backend == 0)
	{
		deleteLater();
		return;
	}

	QScriptSheetEditor * edt = new QScriptSheetEditor(backend,filename,this);
	buildGui(edt);
}

void InteractiveFrontEnd::resetName()
{

	QString filename = document->getFilename();
	if (filename!="")
	{
		QSettings settings;
		bool OK;
		int MaxRecentFiles = settings.value("maxRecentFiles").toInt(&OK);
		if (OK==false)
			MaxRecentFiles = 10;
		QStringList files = settings.value("recentFileList").toStringList();
		files.removeAll(filename);
		files.prepend(filename);
		while (files.size() > MaxRecentFiles)
			files.removeLast();
		settings.setValue("recentFileList", files);
	}

	int lslash = filename.lastIndexOf("/");
	int lbslash = filename.lastIndexOf("\\");
	int lsl = qMax(lbslash,lslash);
	QString nameonly = document->getFilename().mid(lsl+1);
	setWindowTitle("["+nameonly+QString::fromUtf8("] Интерактивная обработка"));
}

void InteractiveFrontEnd::newDocument()
{
	if (document->isempty)
		return;
	InteractiveFrontEnd * newfe = new InteractiveFrontEnd();
	newfe->show();
}

void InteractiveFrontEnd::showHistory()
{
	RecentFiles::showRecent();
}

void InteractiveFrontEnd::changeBackEnd()
{
	QString newinterp = ChooseInterpreter::chooseInterpreter();
	if (newinterp == "")
		return;
	if (newinterp!=backend->getCommand())
		if (QMessageBox::warning(this,
			QString::fromUtf8("Сменить интерпретатор"),
			QString::fromUtf8("Вы уверены, что хотите сменить интерпретатор?"),
			QMessageBox::Yes,QMessageBox::No) == QMessageBox::No)
			return;
	backend->changeBackEnd(newinterp);
}

void InteractiveFrontEnd::openDocument()
{
	QString filename = QFileDialog::getOpenFileName(this,
												QString::fromUtf8("Открыть"));
	if (filename=="")
		return;
	InteractiveFrontEnd * newfe = new InteractiveFrontEnd(filename);
	newfe->show();
	if (document->isempty)
	{
		close();
		deleteLater();
	}
}

void InteractiveFrontEnd::evaluateCell()
{

}

void InteractiveFrontEnd::helpMe()
{

}

void InteractiveFrontEnd::saveDocument()
{
	document->saveDocument();
	resetName();
}

void InteractiveFrontEnd::saveDocumentAs()
{
	document->saveDocumentAs();
	resetName();
}

void InteractiveFrontEnd::closeEvent(QCloseEvent *event)
{
	delete backend;
	QMainWindow::closeEvent(event);
}

ScriptOutputConsole::ScriptOutputConsole (int maxlines, QWidget * parent)
{



	this->maxlc = maxlines;


	scroll = new QScrollArea (this);
	scroll->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
	scroll->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
	inside = new QWidget(scroll);
	inlay=new QVBoxLayout(inside);
	//inside->setFixedSize(100,100);
	scroll->setWidget(inside);
	QPalette pal = inside->palette();
	pal.setColor(QPalette::Background, QColor(255,255,255));
	inside->show();
	scroll->setWidgetResizable(true);
	inlay->addWidget(new QLabel(QString::fromUtf8("Вывод сценария")));
	inlay->addStretch();
	inlay->setSpacing(0);
	setWidget(scroll);

}


void ScriptOutputConsole::receiveLine ( const QString & line )
{
	if (line.trimmed()=="")
		return;;
	QLabel * lbl = new QLabel(line, inside);
	//lbl->setFrameShape(QFrame::Box);
	QFont thisfont = lbl->font();
	thisfont.setFamily("Monospace");
	thisfont.setStyleHint(QFont::Courier);
	lbl->setFont(thisfont);
	if (inlay->count() > maxlc)
	{
		QWidget * elem = inlay->itemAt(0)->widget();
		inlay->takeAt(0);
		delete elem;
	}
	inlay->insertWidget(inlay->count()-1,lbl);
	scroll->verticalScrollBar()->setSliderPosition(scroll->verticalScrollBar()->maximum());
}


RecentFiles::RecentFiles(QWidget *parent)
	: QDialog(parent)
{
	QGridLayout * lay = new QGridLayout(this);
	QLabel * nmfileslbl = new QLabel (QString::fromUtf8("Длина истории"));
	recentfiles = new QListWidget (this);
	nmaxfiles = new QSpinBox(this);
	lay->addWidget(nmfileslbl,0,0);
	lay->addWidget(nmaxfiles,0,1);
	lay->addWidget(recentfiles,1,0,2,2);
	QSettings settings;
	bool OK;
	int MaxRecentFiles = settings.value("maxRecentFiles").toInt(&OK);
	if (OK==false)
		MaxRecentFiles = 10;
	nmaxfiles->setValue(MaxRecentFiles);
	QStringList files = settings.value("recentFileList").toStringList();
	recentfiles->addItems(files);
	connect(recentfiles, SIGNAL(itemDoubleClicked(QListWidgetItem*)),
			this,SLOT(dblClick(QListWidgetItem*)));
	connect(nmaxfiles, SIGNAL(valueChanged(int)), this,SLOT(spboxChange(int)));
	setWindowTitle(QString::fromUtf8("Последние файлы"));
	setWindowIcon(QIcon(":/menuicons/windowicon.png"));
}

void RecentFiles::dblClick(QListWidgetItem *item)
{
	InteractiveFrontEnd * n = new InteractiveFrontEnd(item->text());
	this->close();
	n->show();
}

void RecentFiles::spboxChange(int N)
{
	QSettings settings;
	QVariant v(N);
	settings.setValue("maxRecentFiles", v);
	if (recentfiles->count()>N)
	{
		QSettings settings;
		QStringList files = settings.value("recentFileList").toStringList();
		while (files.count()>N)
			files.removeLast();
		settings.setValue("recentFileList",files);
		while (recentfiles->count()>N)
			recentfiles->removeItemWidget(recentfiles->item(recentfiles->count()-1));
	}
}

void RecentFiles::showRecent()
{
	RecentFiles * rec = new RecentFiles(0);
	rec->exec();
}

ChooseInterpreter::ChooseInterpreter(QWidget *parent)
{
	interps = new QComboBox (this);
	QSettings sets;
	QStringList ilist = sets.value("interpretersHistory").toStringList();
	interps->setEditable(true);
	interps->addItems(ilist);
	ok = new QPushButton(QString::fromUtf8("OK"),this);
	cancel = new QPushButton(QString::fromUtf8("Отмена"),this);
	del = new QPushButton(QIcon(":/menuicons/edit-delete.png"),QString());
	del->setIconSize(QSize(16,16));
	del->setFixedSize(QSize(24,24));
	QGridLayout * lay = new QGridLayout(this);
	lay->addWidget(interps,0,0,1,3);
	lay->addWidget(ok,1,0);
	lay->addWidget(cancel,1,1);
	lay->addWidget(del,0,3);
	lay->setColumnStretch(2,1);
	connect(ok,SIGNAL(clicked()), this,SLOT(OK()));
	connect(cancel,SIGNAL(clicked()),this,SLOT(Cancel()));
	connect(del,SIGNAL(clicked()),this,SLOT(Del()));
	setWindowIcon(QIcon(":/menuicons/windowicon.png"));
	setWindowTitle(QString::fromUtf8("Выберете командную строку интерпретатора"));
	setMinimumWidth(400);
}

void ChooseInterpreter::OK()
{
	QSettings sets;
	QStringList ilist = sets.value("interpretersHistory").toStringList();
	ilist.removeAll(interps->currentText());
	ilist.prepend(interps->currentText());
	sets.setValue("interpretersHistory", ilist);
	done(0);
}

void ChooseInterpreter::Cancel()
{
	done(1);
}

QString ChooseInterpreter::chooseInterpreter()
{
	ChooseInterpreter * choose = new ChooseInterpreter(0);
	int r = choose->exec();
	QString result = choose->interps->currentText();
	if (r==1)
		result="";
	delete choose;
	return result;
}

void ChooseInterpreter::Del()
{
	QString itemat = interps->currentText();
	QSettings sets;
	QStringList ilist = sets.value("interpretersHistory").toStringList();
	ilist.removeAll(itemat);
	sets.setValue("interpretersHistory", ilist);
	interps->clear();
	interps->addItems(ilist);
}

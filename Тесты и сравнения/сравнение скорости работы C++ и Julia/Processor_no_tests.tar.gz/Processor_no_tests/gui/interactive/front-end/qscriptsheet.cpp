//! @file

#include <vector>
#include <string>

#include <qscriptsheet.h>
#include <QMouseEvent>
#include <QMenu>
#include <QSpacerItem>
#include <QSyntaxHighlighter>
#include <QTextCharFormat>
#include <QTextDocument>
#include <QKeySequence>
#include <QThread>
#include <QDomDocument>
#include <QDomText>
#include <QFileDialog>
#include <QTextStream>
#include <QFile>
#include <QDebug>
#include <QMessageBox>
#include <QPainter>
#include <QDebug>
#include <QTextLayout>

BackEnd::BackEnd(const QString & cmd)
	: QObject(0)
{
	this->command = cmd;
	backend = new QProcess(0);
	backend->start(cmd);
	currentResult = 0;
	returnresult = false;
	connect(backend,SIGNAL(finished(int,QProcess::ExitStatus)),this,
			SLOT(finished(int,QProcess::ExitStatus)));
	connect(backend,SIGNAL(readyReadStandardOutput()),this,SLOT(readReady()));
	connect(backend,SIGNAL(readyReadStandardError()),this,SLOT(errorReady()));
}

BackEnd::~BackEnd()
{
	disconnect(backend,SIGNAL(finished(int,QProcess::ExitStatus)),this,
			   SLOT(finished(int,QProcess::ExitStatus)));
	backend->close();
	delete backend;
}

void BackEnd::changeBackEnd(const QString &cmd)
{
	if (this->command==cmd)
		return;
	command = cmd;
	reset();
}

void BackEnd::evaluate(const QString&program, ResultCell*resc, EditCell*cell)
{
	//Если
	if (!(block.tryLock()))
	{
		resc->setText(QString::fromUtf8(
	"Необходимо дождаться окончания выполнения предыдущей запущенной процедуры."
						  ));
		return;
	}
	resc->setText("");
	std::string program_std (program.toUtf8().data());
	backend->write(program_std.data());
	backend->waitForBytesWritten(-1);
	QString end="\n-end-\n";
	currentResult = resc;
	codeCell = cell;
	returnresult = false;
	backend->write(end.toLatin1());
	backend->waitForBytesWritten(-1);
}

void BackEnd::readReady()
{
	QByteArray result = backend->readAllStandardOutput();
	QString res = QString::fromUtf8(result);
	QStringList reslines = res.split("\n");
	for (unsigned int i=0; i<reslines.count(); i++)
	{
		if (reslines[i].trimmed() == "-begin-")
		{
			returnresult = true;
			continue;
		}
		if (returnresult)
		{
			if(reslines[i].trimmed()=="-end-")
			{
				QPalette pal = codeCell->linenumbers->palette();
				pal.setColor(QPalette::Background, QColor(192,255,192));
				codeCell->linenumbers->setPalette(pal);
				returnresult = false;
				currentResult = 0;
				block.unlock();
				continue;
			}
			QString prev = currentResult->toPlainText();
			if (prev!="")
				prev+="\n";
			prev+=reslines[i];
			currentResult->setText(prev);
		}
		else
		{
			receiveOutputLine(reslines[i]);
		}
	}
}

void BackEnd::errorReady()
{
	QByteArray result = backend->readAllStandardError();
	QString res = QString::fromUtf8(result);
	QStringList reslines = res.split("\n");
	for (unsigned int i=0; i<reslines.count(); i++)
		receiveOutputLine(reslines[i]);
}

void BackEnd::reset()
{
	disconnect(backend,SIGNAL(finished(int,QProcess::ExitStatus)),this,
			   SLOT(finished(int,QProcess::ExitStatus)));
	disconnect(backend,SIGNAL(readyReadStandardOutput()),this,
			   SLOT(readReady()));
	block.unlock();
	backend->close();
	delete backend;
	backend=new QProcess(0);
	backend->start(command);
	connect(backend,SIGNAL(finished(int,QProcess::ExitStatus)),this,
			SLOT(finished(int,QProcess::ExitStatus)));
	connect(backend,SIGNAL(readyReadStandardOutput()),this,SLOT(readReady()));
}

void BackEnd::finished ( int exitCode, QProcess::ExitStatus exitStatus )
{
	readReady();
	errorReady();
	QMessageBox::critical(0,QString::fromUtf8("Ошибка"),QString::fromUtf8(
			"Выполнение команды привело к завершеную работы интерпретатора.\n"
							"Интерпретатор будет перезапущен."));
	reset();
}

ResultCell::ResultCell(QWidget *parent)
	: QTextEdit(parent)
{
	connect(this,SIGNAL(textChanged()),SLOT(textChange()));
	setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
	setFixedHeight(0);
	setReadOnly(true);
	setFrameShape(QFrame::Box);
	setFrameShadow(QFrame::Plain);
	lastsize = 0;
}

void ResultCell::textChange()
{

	qreal newSize =(toPlainText()=="")?0:document()->size().height();
	if (newSize!=lastsize)
	{
		setFixedHeight((newSize==0)?0:(int(newSize)+3));
		lastsize = newSize;
	}
}

Splitter::Splitter(QWidget *parent, QScriptSheet *base, int position)
	: QWidget(parent)
{
	//setBackgroundRole(QPalette::Text);
	this->base = base;
	this->position = position;
	cblock = new QAction (QString::fromUtf8("Вставить блок кода"),this);
	connect(cblock,SIGNAL(triggered()),SLOT(insertCodeBlock()));
	setMinimumHeight(5);
	setMaximumHeight(5);
	setVisible(true);
	setPalette(QColor(0,0,0));
}

void Splitter::mouseReleaseEvent ( QMouseEvent * event )
{
	if (event->button() == Qt::RightButton)
	{
		QMenu insertBlock (this);
		insertBlock.addAction(cblock);
		insertBlock.exec(event->globalPos());
	}
}

void Splitter::insertCodeBlock()
{
	base->insertCodeCell(position);
}

void Splitter::setPosition(int position)
{
	this->position = position;
}

EditCell::EditCell (QScriptSheet * parent, int position)
	: QTextEdit(parent)
{
	base = parent;
	this->position = position;
	setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
	setFrameShape(QFrame::Box);
	setFrameShadow(QFrame::Plain);
	setAcceptRichText(false);
	QFont thisfont = font();
	thisfont.setFamily("Monospace");
	thisfont.setStyleHint(QFont::Courier);
	//thisfont.setPointSize(9);
	setFont(thisfont);
	QFontMetrics metrics(thisfont);
	lastSize = document()->size().height();
	setFixedHeight(lastSize+3);
	fontwidth = metrics.width(' ');
	setTabStopWidth(4 * fontwidth);
	hilight = new JSHighlighter(document());
	connect(this,SIGNAL(textChanged()),SLOT(textChanged()));
	setViewportMargins(fontwidth*1,0,0,0);
	digitscount = 1;
	linenumbers = new QLabel("1",this);
	//linenumbers->setScaledContents(true);
	linenumbers->setFont(font());
	linenumbers->setGeometry(1, 1, fontwidth*digitscount+3, lastSize+1);
	linenumbers->setAutoFillBackground(true);
	QPalette pal (linenumbers->palette());
	pal.setColor(QPalette::Background,QColor(192,192,192));
	linenumbers->setPalette(pal);
	setContextMenuPolicy(Qt::CustomContextMenu);
	evaluate = new QAction (QIcon(":/menuicons/evaluate.png"),
							QString::fromUtf8("Выполнить..."),this);
	insertcodeblockbefore = new QAction (
			QString::fromUtf8("Вставить блок кода выше"),this);
	insertcodeblockafter = new QAction (
			QString::fromUtf8("Вставить блок кода ниже"),this);
	delblock = new QAction (
				QString::fromUtf8("Удалить блок"),this);
	delblock->setShortcut(QScriptSheetEditor::delCellKeySequence());
	evaluate->setShortcut(QScriptSheetEditor::evaluateCellSequence());
	insertcodeblockafter->
			setShortcut(QScriptSheetEditor::codeBlockAfterKeySequence());
	insertcodeblockbefore->setShortcut(
				QScriptSheetEditor::codeBlockBeforeKeySequence());

	connect(evaluate,SIGNAL(triggered()),this,SLOT(doEvaluate()));
	connect(insertcodeblockafter,SIGNAL(triggered()),this,
								SLOT(insertCodeBlockAfter()));
	connect(insertcodeblockbefore,SIGNAL(triggered()),this,
								SLOT(insertCodeBlockBefore()));
	connect(delblock,SIGNAL(triggered()),this,SLOT(deleteBlock()));
	connect(this,SIGNAL(customContextMenuRequested(QPoint)),
			this,SLOT(showContextMenu(QPoint)));
}

void EditCell::deleteBlock()
{
	base->deleteCell(position);
}

void EditCell::insertCodeBlockAfter()
{
	if (position < base->layout()->count()-2)
	{
		Splitter*spl=(Splitter *)(base->layout()->itemAt(position+2)->widget());
		spl->insertCodeBlock();
	}
}

void EditCell::insertCodeBlockBefore()
{
	if (position > 1)
	{
		Splitter*spl=(Splitter *)(base->layout()->itemAt(position-1)->widget());
		spl->insertCodeBlock();
	}
}

void EditCell::doEvaluate()
{
	if (position < base->layout()->count()-2)
	{
		QPalette pal (linenumbers->palette());
		pal.setColor(QPalette::Background,QColor(255,192,192));
		linenumbers->setPalette(pal);

		base->editor->evaluate((ResultCell*)(base->layout()->
									itemAt(position+1)->widget()),this);
	}
}

void EditCell::showContextMenu(const QPoint &pt)
{
	QMenu *menu = new QMenu();
	QAction * undo = menu->addAction(QIcon(":/menuicons/edit-undo.png"),
								QString::fromUtf8("Отмена"),this,SLOT(undo()));
	QAction * redo = menu->addAction(QIcon(":/menuicons/edit-redo.png"),
								QString::fromUtf8("Повтор"),this,SLOT(redo()));
	menu->addSeparator();
	QAction * cut = menu->addAction(QIcon(":/menuicons/edit-cut.png"),
								QString::fromUtf8("Вырезать"),this,SLOT(cut()));
	QAction * copy = menu->addAction(QIcon(":/menuicons/edit-copy.png"),
							QString::fromUtf8("Копировать"),this,SLOT(copy()));
	QAction * paste = menu->addAction(QIcon(":/menuicons/edit-paste.png"),
							QString::fromUtf8("Вставить"),this,SLOT(paste()));
	QAction * del = menu->addAction(QIcon(":/menuicons/edit-delete.png"),
							QString::fromUtf8("Удалить"),this,SLOT(clear()));
	menu->addSeparator();
	QAction * selectall = menu->addAction(QIcon(":/menuicons/edit-undo.png"),
					QString::fromUtf8("Выделить всё"),this,SLOT(selectAll()));
	undo->setShortcut(QKeySequence(Qt::CTRL+Qt::Key_Z));
	redo->setShortcut(QKeySequence(Qt::CTRL+Qt::SHIFT+Qt::Key_Z));
	cut->setShortcut(QKeySequence(Qt::CTRL+Qt::Key_X));
	copy->setShortcut(QKeySequence(Qt::CTRL+Qt::Key_C));
	paste->setShortcut(QKeySequence(Qt::CTRL+Qt::Key_V));
	selectall->setShortcut(QKeySequence(Qt::CTRL+Qt::Key_A));
	menu->addSeparator();
	menu->addAction(evaluate);
	menu->addAction(base->editor->abortEvaluation);
	menu->addSeparator();
	menu->addAction(this->insertcodeblockafter);
	menu->addAction(this->insertcodeblockbefore);
	menu->addAction(this->delblock);
	menu->exec(mapToGlobal(pt));
	delete menu;
}

void EditCell::setPosition(int position)
{
	this->position = position;
}

void EditCell::resizeEvent(QResizeEvent *e)
{
	QTextEdit::resizeEvent(e);
	if (position<base->layout()->count()-2)
		textViewChanged();
}

void EditCell::textViewChanged()
{

	QString str = document()->toPlainText();
	qreal newSize = document()->size().height();
	if (newSize!=lastSize)
	{
		setMaximumHeight(int(newSize)+3);
		setMinimumHeight(int(newSize)+3);
		lastSize = newSize;
//		linenumbersvalid = false;
		digitscount = 1;
		int blockscount = this->document()->blockCount();
		if (blockscount == 0)
			blockscount = 1;
		while (blockscount >= 10)
		{
			blockscount /= 10;
			++digitscount;
		}
		setViewportMargins(fontwidth*digitscount,0,0,0);
		QString labeltext = "";
		int blockCount = 0;
		for (QTextBlock blk = document()->firstBlock(); blk.isValid();
			 blk = blk.next())
		{
			blockCount++;
			QString nm = QString::number(blockCount);
			for (unsigned int i=0; i<digitscount-nm.length(); i++)
				labeltext+=" ";
			labeltext+=nm;
			int lc = blk.layout()->lineCount();
			for ( int i=0; i<lc-1; i++)
				labeltext+="\n";
			if (blockCount!=document()->blockCount())
				labeltext+="\n";
		}
		linenumbers->setTextFormat(Qt::PlainText);
		linenumbers->setText(labeltext);
		linenumbers->setGeometry(1,1,fontwidth*(digitscount)+3,int(newSize)+1);
	}
}

void EditCell::textChanged()
{
	base->checkLast(position);
	QPalette pal (linenumbers->palette());
	pal.setColor(QPalette::Background,QColor(192,192,192));
	linenumbers->setPalette(pal);
	textViewChanged();
}

void EditCell::keyPressEvent ( QKeyEvent * e )
{
//	if (e==)
	QKeySequence qs(e->modifiers()+e->key());
	//Удалить данную ячайку
	if (qs==base->editor->delCellKeySequence())
		this->deleteBlock();
	if (qs==base->editor->saveSheetSequence())
		base->editor->saveDocument();
	if (qs==base->editor->codeBlockAfterKeySequence())
		insertCodeBlockAfter();;
	if (qs==base->editor->codeBlockBeforeKeySequence())
		insertCodeBlockBefore();
	if (qs==base->editor->saveAsKeySequence())
		base->editor->saveDocumentAs();
	base->editor->isempty = false;
	if (qs==base->editor->evaluateCellSequence())
	{
		doEvaluate();
		return;
	}
	if ((e->key() == Qt::Key_Down)&&(e->modifiers()==Qt::NoModifier))
	{
		if (position<base->layout()->count()-3)
			if (textCursor().blockNumber() == document()->blockCount()-1)
			{
				base->layout()->itemAt(position+3)->widget()->setFocus();

				((EditCell*)(base->layout()->itemAt(position+3)->widget()))->
																followCursor();
				return;
			}
	}
	if ((e->key() == Qt::Key_Up)&&(e->modifiers()==Qt::NoModifier))
	{
		if (position>0)
			if (textCursor().blockNumber() == 0)
			{
				base->layout()->itemAt(position-3)->widget()->setFocus();
				((EditCell*)(base->layout()->itemAt(position-3)->widget()))->
																followCursor();

				return;
			}
	}
	QString indent = "";
	if ((e->key() == Qt::Key_Return)&&(e->modifiers()==Qt::NoModifier))
	{
		QString curline = textCursor().block().text();
		for (unsigned int i=0; i<curline.size(); ++i)
		{
			if (curline[i]==QChar('\t'))
			{
				indent+="\t";
				continue;
			}
			if (curline[i]==QChar(' '))
			{
				indent+=" ";
				continue;
			}
			break;
		}

	}
	QTextEdit::keyPressEvent(e);
	if ((e->key() == Qt::Key_Return)&&(e->modifiers()==Qt::NoModifier))

		textCursor().insertText(indent);
	followCursor();


}

void EditCell::followCursor()
{
	QPoint editcoord = base->layout()->itemAt(position)->geometry().topLeft();
	QPoint cursorcoord = cursorRect().topLeft();
	QPoint cv = editcoord+cursorcoord;
	base->editor->ensureVisible(cv.x(), cv.y(),20,20);
}

QScriptSheet::QScriptSheet(QWidget *parent) :
	QWidget(parent)
{
	setPalette(QColor(255,255,255));
	EditCell * newcell = new EditCell(this,0);
	blayout = new QVBoxLayout;
	blayout->setSpacing(0);
	blayout->addWidget(newcell);
	blayout->addStretch();
	setLayout(blayout);
	editor = (QScriptSheetEditor *)parent;
	newcell->setFocus();
}


void QScriptSheet::checkLast(int position)
{
	//Нужно ли вставить ещё одну ячейку?
	if (position== blayout->count() - 2)
	{
		int com1 = blayout->count() - 1;
		ResultCell * resultcell = new ResultCell(this);
		Splitter * newsplitter = new Splitter(this,this,blayout->count());
		EditCell * newcell = new EditCell(this,blayout->count()+1);
		blayout->insertWidget(com1,resultcell);
		blayout->insertWidget(com1+1,newsplitter);
		blayout->insertWidget(com1+2,newcell);
		blayout->update();
	}
}

void QScriptSheet::renumerateCells()
{
	for (unsigned int i=0; i<layout()->count(); ++i)
	{
		if (i%3==0)//Ячейка ввода
		{
			EditCell* cell = (EditCell*)(layout()->itemAt(i)->widget());
			cell->setPosition(i);
		}
		if (i%3==2)//Ячейка результата
		{
			Splitter* split = (Splitter*)(layout()->itemAt(i)->widget());
			split->setPosition(i);
		}
	}
}

void QScriptSheet::insertCodeCell(int position)
{
	EditCell * edit = new EditCell(this,0);
	ResultCell * result = new ResultCell(this);
	Splitter * split = new Splitter(this,this,0);
	blayout->insertWidget(position,result);
	blayout->insertWidget(position,edit);
	blayout->insertWidget(position,split);
	renumerateCells();
}

void QScriptSheet::deleteCell(int position)
{
	int co = blayout->count();
	if (position==co-2)
		return;
	QWidget*editcell = layout()->itemAt(position)->widget();
	QWidget*resultcell = layout()->itemAt(position+1)->widget();
	QWidget*splitter = layout()->itemAt(position+2)->widget();

	if (!(editor->getEvaluation().tryLock()))
	{
		//Не удалять ячейку, пока идёт выполнение
		if (editor->getPendingResult() == resultcell)
			return;
	}
	else
	{
		editor->getEvaluation().unlock();
	}

	layout()->removeWidget(editcell);
	layout()->removeWidget(resultcell);
	layout()->removeWidget(splitter);

	renumerateCells();

	editcell->deleteLater();
	resultcell->deleteLater();
	splitter->deleteLater();

	layout()->itemAt(position)->widget()->setFocus();

}

void QScriptSheetEditor::abort()
{
	if (QMessageBox::warning(this,QString::fromUtf8("Перезапуск"),
	QString::fromUtf8("Вы действительно хотите перезапустить интерпретатор?"),
	QMessageBox::Yes,QMessageBox::No) == QMessageBox::Yes)
	{
		eng->reset();
		for (int i=0; i<sheet->blayout->count(); i++)
		{
			EditCell * cell = qobject_cast<EditCell *>
					(sheet->blayout->itemAt(i)->widget());
			if (cell == 0)
				continue;
			QPalette pal = cell->linenumbers->palette();
			pal.setColor(QPalette::Background, QColor(192,192,192));
			cell->linenumbers->setPalette(pal);
		}

	}
}

void QScriptSheetEditor::stdinit()
{
	delCell = QKeySequence(Qt::CTRL+Qt::Key_Delete);
	evaluateCell = QKeySequence(Qt::SHIFT+Qt::Key_Return);
	saveSheet = QKeySequence(Qt::CTRL+Qt::Key_S);
	codeBlockAfter = QKeySequence(Qt::CTRL+Qt::ALT+Qt::Key_C);
	codeBlockBefore = QKeySequence(Qt::CTRL+Qt::SHIFT+Qt::Key_C);
	saveAs = QKeySequence(Qt::CTRL+Qt::SHIFT+Qt::Key_S);

	abortEvaluation = new QAction(QString::fromUtf8("Перезапустить..."),this);
	connect(abortEvaluation,SIGNAL(triggered()),this,SLOT(abort()));
	sheet = new QScriptSheet(this);
	setWidgetResizable(true);
	setWidget(sheet);
}

void QScriptSheetEditor::setFocus()
{
	sheet->layout()->itemAt(0)->widget()->setFocus();
}

QScriptSheetEditor::QScriptSheetEditor(BackEnd *eng, QWidget *parent)
	: QScrollArea( parent )
{
	filename = "";
	this->eng=eng;
	stdinit();
	isempty = true;
}

QScriptSheetEditor::QScriptSheetEditor(BackEnd *eng, const QString &filename,
									   QWidget *parent)
	: QScrollArea(parent)
{
	this->filename = filename;
	this->eng=eng;
	stdinit();
	QFile f(filename);
	f.open(QIODevice::ReadOnly);
	QDomDocument dd;
	dd.setContent(&f);
	f.close();
	QDomNodeList l = dd.childNodes();
	QString roottag = l.at(0).toElement().tagName();
	if ((l.count() != 1)||(roottag != "ecma"))
	{
		qDebug()<<"Wrong format!";
		return;
	}
	QDomNodeList cells = l.at(0).childNodes();
	for (unsigned int i = 0; i<cells.count(); i++)
	{
		QDomElement cell = cells.at(i).toElement();
		QString code =
		cell.childNodes().at(0).toElement().childNodes().at(0).toText().data();
		QString result =
		cell.childNodes().at(1).toElement().childNodes().at(0).toText().data();
		int co = sheet->layout()->count()-2;
		EditCell*c = ((EditCell*)(sheet->layout()->itemAt(co)->widget()));
		c->setText(code);
		c->document()->adjustSize();
		c->textChanged();
		ResultCell*r = ((ResultCell*)(sheet->layout()->itemAt(co+1)->widget()));
		r->setText(result);
		r->document()->adjustSize();
		r->textChange();
	}
	isempty = false;
}

void QScriptSheetEditor::saveDocument()
{
	QString nfilename = filename;
	if (filename == "")
		nfilename = QFileDialog::getSaveFileName(this,
		QString::fromUtf8("Сохранить"),QString(),
		QString::fromUtf8("Файлы ECMA script (*.ecma)"));
	if (nfilename == "")
		return;
	if ((filename.length()<5)||(filename.right(5)!=".ecma"))
		filename = filename + ".ecma";
	filename = nfilename;
	QDomDocument doc;
	QDomElement root = doc.createElement("ecma");
	doc.appendChild(root);
	for (unsigned int i=0; i<sheet->layout()->count()-2; i+=3)
	{
		EditCell*code=(EditCell*)(sheet->layout()->itemAt(i)->widget());
		ResultCell*result=(ResultCell*)(sheet->layout()->itemAt(i+1)->widget());
		QDomElement cell = doc.createElement("cell");
		QDomElement codenode = doc.createElement("code");
		QDomElement resultnode = doc.createElement("result");
		QDomText codetext = doc.createTextNode(code->toPlainText());
		QDomText resulttext = doc.createTextNode(result->toPlainText());
		root.appendChild(cell);
		cell.appendChild(codenode);
		cell.appendChild(resultnode);
		codenode.appendChild(codetext);
		resultnode.appendChild(resulttext);
	}
	QFile f(filename);
	QString s = doc.toString(4);
	f.open(QIODevice::WriteOnly);
	f.write(s.toUtf8());
	f.close();
}

void QScriptSheetEditor::saveDocumentAs()
{
	QString savefilename = filename;
	filename = "";
	saveDocument();
	if (filename=="")
		filename = savefilename;
}

void QScriptSheetEditor::setPendingResult(ResultCell *cell)
{
	pendingResult = cell;
}

void QScriptSheetEditor::evaluate(ResultCell *result, EditCell *cell)
{
	QString code = cell->toPlainText();
	eng->evaluate(code, result, cell);
}

//-------ПОДСВЕТКА СИНТАКСИСА------------------------------------------------//

Highlighter::Highlighter(QTextDocument *parent) : QSyntaxHighlighter(parent)
{

}

void Highlighter::SetRule(QString name,QString pattern,QTextCharFormat format)
{
	if (pattern != "")
		highlightingRules.insert(name,
								 HighlightingRule(QRegExp(pattern),format));
	else
		highlightingRules.remove(name);
	rehighlight();
}

void Highlighter::highlightBlock(const QString &text)
{
	foreach (const HighlightingRule &rule, highlightingRules)
	{
		QRegExp expression(rule.pattern);
		int index = expression.indexIn(text);
		while (index >= 0)
		{
			int length = expression.matchedLength();
			setFormat(index, length, rule.format);
			index = expression.indexIn(text, index + length);
		}
	}
	setCurrentBlockState(0);
}

MultiLineCommentHighlighter::MultiLineCommentHighlighter(QTextDocument *parent)
	: Highlighter(parent)
{
	multiLineCommentFormat.setForeground(Qt::red);
	commentStartExpression = QRegExp("/\\*");
	commentEndExpression = QRegExp("\\*/");
}

void MultiLineCommentHighlighter::highlightBlock(const QString &text)
{
	Highlighter::highlightBlock(text);
	int startIndex = 0;
	if (previousBlockState() != 1)
		startIndex = commentStartExpression.indexIn(text);
	while (startIndex >= 0)
	{
		int endIndex = commentEndExpression.indexIn(text, startIndex);
		int commentLength;
		if (endIndex == -1)
		{
			setCurrentBlockState(1);
			commentLength = text.length() - startIndex;
		}
		else
		{
			commentLength = endIndex - startIndex
					+ commentEndExpression.matchedLength();
		}
		setFormat(startIndex, commentLength, multiLineCommentFormat);
		startIndex = commentStartExpression.indexIn(text,
												startIndex + commentLength);
	}
}

JSHighlighter::JSHighlighter(QTextDocument *parent)
	: MultiLineCommentHighlighter(parent)
{
	QTextCharFormat keywordFormat;
	keywordFormat.setForeground(Qt::black);
	keywordFormat.setFontWeight(QFont::Bold);
	QStringList keywordPatterns;
	keywordPatterns << "\\bvar\\b" << "\\bArray\\b" << "\\bfunction\\b"
					<< "\\breturn\\b" << "\\barguments\\b" << "\\bif\\b"
					<< "\\belse\\b" << "\\bfor\\b" << "\\bswitch\\b"
					<< "\\bcase\\b" << "\\bbreak\\b" << "\\bwhile\\b"
					<< "\\bnew\\b";
	int i = 0;
	foreach (const QString &pattern, keywordPatterns)
	{
		SetRule(QString("00_KeyWord_%1").arg(i),pattern,keywordFormat);
		++i;
	}
	// Values
	QTextCharFormat valueFormat;
	valueFormat.setForeground(Qt::blue);
	SetRule("03_Values","\\btrue\\b|\\bfalse\\b|\\b[0-9]+\\b",valueFormat);
	QTextCharFormat functionFormat;
	//functionFormat.setFontItalic(false);
	functionFormat.setForeground(Qt::darkBlue);
	SetRule("04_Functions","\\b[A-Za-z0-9_]+(?=\\()",functionFormat);
	// Qt Classes
	QTextCharFormat classFormat;
	classFormat.setFontWeight(QFont::Bold);
	classFormat.setForeground(Qt::darkMagenta);
	SetRule("06_QtClasses","\\bQ[A-Z]+[A-Za-z]+\\b",classFormat);
	// Quotation
	QTextCharFormat quotationFormat;
	quotationFormat.setForeground(Qt::blue);
	SetRule("z1_Quotations","\"[^\"]*\"",quotationFormat);
	// Single Line Comments
	QTextCharFormat singleLineCommentFormat;
	singleLineCommentFormat.setForeground(Qt::darkGreen);
	SetRule("z2_SingleLineComments","//[^\n]*",singleLineCommentFormat);
}

QKeySequence QScriptSheetEditor::delCell;
QKeySequence QScriptSheetEditor::evaluateCell;
QKeySequence QScriptSheetEditor::codeBlockAfter;
QKeySequence QScriptSheetEditor::codeBlockBefore;
QKeySequence QScriptSheetEditor::saveSheet;
QKeySequence QScriptSheetEditor::saveAs;

QKeySequence & QScriptSheetEditor::saveSheetSequence()
{
	return saveSheet;
}

QKeySequence & QScriptSheetEditor::saveAsKeySequence()
{
	return saveAs;
}

QKeySequence & QScriptSheetEditor::delCellKeySequence()
{
	return delCell;
}

QKeySequence & QScriptSheetEditor::evaluateCellSequence()
{
	return evaluateCell;
}

QKeySequence & QScriptSheetEditor::codeBlockAfterKeySequence()
{
	return codeBlockAfter;
}

QKeySequence & QScriptSheetEditor::codeBlockBeforeKeySequence()
{
	return codeBlockBefore;
}

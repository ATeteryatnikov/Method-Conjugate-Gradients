//! @file

#include <QApplication>
#include <qscriptsheet.h>
#include <QScrollArea>
#include <QScriptEngine>
#include <unistd.h>
#include <QFileDialog>
#include <exception>
#include <frontend.h>


int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	//a.setStyle("Plastique");
	a.setOrganizationName("SFU");
	a.setApplicationName("Interactive Processing");

	InteractiveFrontEnd * fe = new InteractiveFrontEnd;
	fe->show();

	return a.exec();
}

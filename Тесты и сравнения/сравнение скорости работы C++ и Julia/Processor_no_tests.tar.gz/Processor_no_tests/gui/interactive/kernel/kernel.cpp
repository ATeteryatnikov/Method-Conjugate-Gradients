#include <string>
#include <iostream>
#include <sstream>
#include <unistd.h>
#include <fstream>
#include <exception>

using namespace std;

//! @file

#include <gnssconfig.h>
#ifdef UseMPI
#include <mpi.h>
#endif

#include <DBTableCollection.h>
#include <readAntEx.h>
#include <PhaseCentre.h>
#include <readrinex21obs.h>
#include <sinex.h>
#include <RINEXClock.h>
#include <Pseudorange.h>
#include <StdTables.h>
#include <ERPStorage.h>
#include <ParamTrajectory.h>
#include <sp3.h>
#include <finals2000A.h>
#include <Troposphere.h>
#include <dcb.h>
#include <YawAttitude.h>
#include <Frames.h>
#include <sparsematrix.hpp>
#include <Integrate.h>
#include <RadPressureBerne.h>
#include <GravityPotential.h>
#include <LoadEGM08.h>
#include <ClockVariance.h>
#include <Frames.h>
#include <SiteDisplacement.h>
#include <TimeShift.h>
#include <PhaseAmbiguity.h>

using namespace libgnss;

#include <QDebug>
#include <QCoreApplication>
#include <QScriptEngine>
#include <QString>
#include <QFile>
#include <QScriptValueIterator>
#include <QDomElement>
#include <QStringList>
#include <QTextCodec>

#include <ScriptShell.h>

class Session : public DBTableCollection
{
private:
	Settings*sets;
	LeapSeconds*leaps;
	SatelliteHistory*history;
	AntennaModels*antmods;
	ReceivingAntennas*recants;
	SVAntennas*svants;
	Frames*frames;
	CoordinateTypes*ctypes;
	PhaseCentreOffsetFrequency*phcof;
	PhaseCentreVariationGrid*phcvg;
	SVPhaseCentreModels*svphcm;
	ReceivingAntennaPhaseCentreModels*recantmods;
	Markers*markers;
	GravityPotential*grav;
	LongperiodSolidTides*lst;
	DiurnalSolidTides*dst;
	SemidiurnalSolidTides*sst;
	OceanTides*ot;
	OceanPoleTides*opt;
	ParameterRadPressureBerne*berne;
	Receivers*recs;
	ObservableTypes*obst;
	ObservationSource*obssrc;
	Observables*obs;
	NavigationSystem*navsys;
	GLONASSFrequencySlots*gloslots;
	ERPStorage*erp;
	ParamTrajectory*traj;
	MarkerEccentricity*ecc;
	MarkerPosition*mpos;
	ITRFTranslation*trans;
	ClockBias*clkbias;
	ParamTroposphere*trop;
	ParamDCB*dcb;
	ParamPhaseAmbiguity*ambig;
	ClockVarBinomial*clkbin;
	ClockLinearResidue*clklin;
	CelestialBodies * cb;
	ReferenceFrames * rfr;
public:
	Session(QScriptEngine * eng)
	{
		sets = new Settings(this);
		leaps = new LeapSeconds(this);
		history = new SatelliteHistory(this);
		antmods = new AntennaModels(this);
		recants = new ReceivingAntennas(this);
		svants = new SVAntennas(this);
		frames = new Frames(this);
		ctypes = new CoordinateTypes(this);
		phcof = new PhaseCentreOffsetFrequency(this);
		phcvg = new PhaseCentreVariationGrid (this);
		svphcm = new SVPhaseCentreModels(this);
		recantmods = new ReceivingAntennaPhaseCentreModels(this);
		markers = new Markers(this);
		grav = new GravityPotential(this);
		lst = new LongperiodSolidTides(this);
		dst = new DiurnalSolidTides(this);
		sst = new SemidiurnalSolidTides(this);
		ot = new OceanTides(this);
		opt = new OceanPoleTides(this);
		berne = new ParameterRadPressureBerne(this);
		recs = new Receivers(this);
		obst = new ObservableTypes (this);
		obssrc = new ObservationSource(this);
		obs = new Observables(this);
		navsys = new NavigationSystem(this);
		gloslots= new GLONASSFrequencySlots(this);
		erp = new ERPStorage(this);
		traj = new ParamTrajectory(this);
		ecc = new MarkerEccentricity(this);
		mpos = new MarkerPosition(this);
		trans = new ITRFTranslation(this);
		clkbias = new ClockBias(this);
		trop = new ParamTroposphere(this);
		dcb = new ParamDCB(this);
		ambig = new ParamPhaseAmbiguity(this);
		clkbin = new ClockVarBinomial(this);
		clklin = new ClockLinearResidue(this);
		cb = new CelestialBodies (this);
		rfr = new ReferenceFrames (this);
		cb->loadDefaultValues();
		LoadEGM08(*this, 20);
		for (map<string, DBTable*>::const_iterator it = begin();
			 it!=end(); ++it)
			it->second->setEngine(eng);
	}

	~Session()
	{
		delete cb;
		delete sets;
		delete leaps;
		delete history;
		delete antmods;
		delete recants;
		delete svants;
		delete frames;
		delete ctypes;
		delete phcof;
		delete phcvg;
		delete svphcm;
		delete recantmods;
		delete markers;
		delete grav;
		delete lst;
		delete dst;
		delete sst;
		delete ot;
		delete opt;
		delete berne;
		delete recs;
		delete obst;
		delete obssrc;
		delete obs;
		delete navsys;
		delete gloslots;
		delete erp;
		delete traj;
		delete ecc;
		delete mpos;
		delete trans;
		delete clkbias;
		delete trop;
		delete dcb;
		delete ambig;
		delete clkbin;
		delete clklin;
		//delete cb;
	}
};

QScriptValue createSession (QScriptContext*ctx, QScriptEngine * eng)
{
	Session * s = new Session(eng);
	return eng->newQObject(s, QScriptEngine::ScriptOwnership);
}

BuiltIn createsess("newSession",0,createSession);

void wrongCommandLine(string err)
{

	cout<<string("Неверные параметры командной строки: ")<<err<<endl<<endl<<endl;
	cout<<string("./scriptkernel [параметр1 [параметр2 ...]]")<<endl<<endl;
	cout<<string("Каждый параметр имеет формат -(k) (аргумент)")<<endl;
	cout<<string("-(k) - один из следующих ключей.")<<endl;
	cout<<"-f    Тогда (аргумент) - имя файла скрипта для исполнения"<<endl
	   <<"-v    Тогда (аргумент) имеет вид (имя_переменной)=(значение),"<<endl
		<<"и переменной (имя_переменной) присваивается значение (значение)"
		  <<endl;
	cout<<"-i    Тогда (аргумент) пустой, и интерпретатор запускается в "<<endl
	   <<"интерактивном режиме."<<endl;

	exit(0);
}

int main(int argc, char *argv[])
{

#ifdef UseMPI
	MPI_Init(&argc,&argv);
#endif

	QCoreApplication a(argc, argv);
	a.addLibraryPath(".");

	ScriptShell shell;

	if (argc == 1)
		wrongCommandLine("без аргументов не работает.");

	QStringList commandsdesc;
	QStringList commands;

	for (int i = 1; i<argc; i++)
	{
		string s = string(argv[i]);
		if (s=="-i")
		{
			if ((i > 1) || (argc > 2))
				wrongCommandLine("Параметр -i не может сопровождаться другими "
								 "параметрами");
			//Запустить интерактивный режим
			while(true)
			{
				stringstream cmd;
				while(true)
				{
					string addcmd;
					if (cin.eof())
						break;
					getline(cin,addcmd);
					//cout<<addcmd<<endl;
					if (addcmd.compare("-end-")==0)
					{
						break;
					}
					if (addcmd=="")
						continue;
					cmd<<addcmd<<'\n';
					if (cmd.gcount()>65536)
						return -1;
				}
				if (cin.eof())
					break;
				string cmdstr = cmd.str();
				if (cmdstr=="")
					break;
				QScriptValue val0;
				val0=shell.evaluate(QString::fromUtf8(cmdstr.c_str()));

				shell.engine->collectGarbage();
				QString val0qstr = val0.toString();
				string result = val0qstr.toUtf8().data();
				cout<<endl<<"-begin-"<<endl;
				cout<<result<<endl;
				cout<<"-end-"<<endl;
			}
			return 0;
		}
		// Присвоить значение переменной
		if (s == "-v")
		{
			i++;
			if (i>=argc)
				wrongCommandLine("После -v ожидалось присваивание.");
			QString assignment = QString::fromAscii(argv[i]);
			QStringList ass_list = assignment.split(QChar('='));
			// Проверить идентификатор
			if (!(QRegExp("^[^\\d]\\w+$").exactMatch(ass_list[0])))
				wrongCommandLine("Строка '"+ass_list[0].toStdString()+
								 "' не является корректным идентификатором.");
			//Либо присваиваемое выражение является числом
			QString numre("^[-\\+]?[0-9]*(.[0-9]+([eE][-\\+][0-9]+)?)?$");
			//Либо строкой в кавычках, не содержащее кавычек внутри
			QString strre("^\"[^\"]+\"$");
			//Либо строкой без кавычек, тогда нужно добавить кавычки по бокам
			if (!(QRegExp(numre).exactMatch(ass_list[1])
					|| QRegExp(strre).exactMatch(ass_list[1])))
			{
				if (QRegExp("^[^\"]+$").exactMatch(ass_list[1]))
					ass_list[1] = "\""+ass_list[1]+"\"";
				else
					wrongCommandLine("Строка "+ass_list[1].toStdString()+
									 " не является константой.");
			}
			QString command = ass_list[0]+"="+ass_list[1];
			commandsdesc.push_back(command);
			commands.push_back(command);
		}
		if (s == "-f")
		{
			i++;
			if (i>=argc)
				wrongCommandLine("После -f ожидалось имя файла со скриптом.");
			QString filename = QFile::decodeName(argv[i]);
			QFile progfile(filename);
			if (!(progfile.open(QIODevice::ReadOnly)))
				wrongCommandLine("Указанный после -f файл не удалось открыть.");
			QDomDocument dd;
			dd.setContent(&progfile);
			progfile.close();
			QDomNodeList l = dd.childNodes();
			QString roottag = l.at(0).toElement().tagName();
			if ((l.count() != 1)||(roottag != "ecma"))
				wrongCommandLine("Файл не является корректным "
					  "скриптом интерактивного обработчика");
			QDomNodeList cells = l.at(0).childNodes();
			for (unsigned int i = 0; i<cells.count(); i++)
			{
				QDomElement cell = cells.at(i).toElement();
				QString code =
						cell.childNodes().at(0).toElement()
									.childNodes().at(0).toText().data();
				commandsdesc.push_back(filename+QString::fromUtf8(" блок ")+
											QString::number(i));
				commands.push_back(code);
			}
		}
	}

	//Выполнение команд
	for (int i=0; i<commands.size(); i++)
	{
		cout<<"Выполнение: "<<commandsdesc[i].toUtf8().data()<<endl;
		QScriptValue result = shell.evaluate(commands[i]+";undefined;");
		if (!(result.isUndefined()))
		{
			cout<<"Выполнение завершилось ошибкой: "<<endl
				  <<result.toString().toUtf8().data()<<endl;
			break;
		}
	}


#ifdef UseMPI
	MPI_Finalize();
#endif
}

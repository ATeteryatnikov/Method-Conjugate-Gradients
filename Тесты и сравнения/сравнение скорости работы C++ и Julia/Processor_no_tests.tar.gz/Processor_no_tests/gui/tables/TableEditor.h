#ifndef TABLEEDITOR_H_
#define TABLEEDITOR_H_

#include <QString>
#include <QWidget>
#include <QScrollArea>
#include <QToolButton>
#include <QVector>
#include <QLabel>
#include <QComboBox>
#include <QGridLayout>

#include <DBVariant.h>
#include <DBTable.h>
#include <DBTableCollection.h>

class TableEditor;

class KnowYourPlaceLabel : public QLabel
{
	Q_OBJECT
private:
	int colnumber;
	int rownumber;
public:
	KnowYourPlaceLabel (const QString & text, int colnumber, int rownumber,
						TableEditor * parent);

protected:
	void mouseDoubleClickEvent(QMouseEvent * e);

signals:
	void dblClick(int colnumber, int rownumber);
};

class KnowYourRowButton : public QToolButton
{
	Q_OBJECT
private:
	int rownumber;
public:
	KnowYourRowButton (int rownumber, TableEditor * parent);
protected slots:
	void clickme();
signals:
	void clickBtn(int rownumber);
};

/**
 * @brief Редактор таблиц из коллекции
 *
 * Позволяет редактировать таблицы из коллекции.
 *
 * Каждый элемент таблицы можно редактировать разными способами: с помощью
 * простого текстового окна, с помощью текстового окна-счетчика, с помощью
 * текстового окна для ввода дробных чисел, с помощью редактора даты и времени.
 *
 * При редактировании ключевого поля открывается дополнительное окно для
 * редактирования сразу всех ключевых полей. При редактировании поля данных
 * изменения вносятся немедленно.
 *
 */
class TableEditor : public QWidget
{
	friend class RowEditor;
	Q_OBJECT


public:
	enum EditWith
	{
		EW_Default = 0,
		EW_TextBox = 1,
		EW_MultLineEdit = 2,
		EW_SpinBox = 3,
		EW_DateTime = 4
	};

private:

	libgnss::OperatorPushableVector < EditWith > edit_with;

	/**
	 * @brief Преобразование состояния редактора поля в значение Variant
	 * @param editortype Тип редактора поля
	 * @param editor Виджет-редактор
	 * @param desiredtype Требуемый тип Variant
	 * @return Значение нужного типа, полученное от редактора
	 */
	static libgnss::Variant fromEditor (EditWith editortype, QWidget * editor,
							   libgnss::Variant::Type desiredtype);

	/**
	 * @brief Создание редактора для редактирования поля типа Variant
	 * @param editortype Желаемый тип редактора
	 * @param v Значение, которое нужно отредактировать
	 * @return Созданный для редактирования виджет
	 */
	static QWidget * toEditor (EditWith editortype, const libgnss::Variant & v,
							   QWidget * parent);

	/**
	 * @brief Получить желаемое строковое представление для объекта Variant
	 * @param v Преобразуемый объект
	 * @param editwith Тип редактора, для которого требуется представление
	 * @return Строковое представление
	 */
	static QString strRepresentation(const libgnss::Variant & v,
									 EditWith & editwith);

	libgnss::DBTable * table;
	libgnss::OperatorPushableVector <EditWith> keyeditors;
	libgnss::OperatorPushableVector <EditWith> valueeditors;

	QToolButton * previousPage;
	QToolButton * nextPage;
	QComboBox * linesOnPage;
	QLabel * rowscount;
	QScrollArea * tableview;
	QWidget * insideWidget;
	QGridLayout * lay;

	QVector < QWidget * > pageWidgets;

	libgnss::DBTable::DBConstIterator first, last;
	int lastline;

	void clearPage();
	void showPage();

public:
	TableEditor (libgnss::DBTableCollection * base, const QString & tablename,
				const libgnss::OperatorPushableVector <EditWith> & keyeditors,
				const libgnss::OperatorPushableVector <EditWith> & valueeditors,
				 QWidget * parent
				 );
public slots:

	void dblClick(int colnumber, int rownumber);
	void delClick(int rownumber);
	void addNewRow();
	void insertRow(const libgnss::Tuple & key, const libgnss::Tuple & value);
	void deleteRow(const libgnss::Tuple & key);
	void updateCell(const libgnss::Tuple & key, int colnumber,
					const libgnss::Variant & newvalue);
	void goPreviousPage();
	void goNextPage();

};


#endif

#include <TableEditor.h>
#include <QMouseEvent>
#include <QDialog>
#include <QLineEdit>
#include <QPlainTextEdit>
#include <QSpinBox>
#include <QDateTimeEdit>
#include <climits>
#include <cfloat>
#include <cmath>
#include <QPushButton>
#include <QMessageBox>

using namespace libgnss;

void TableEditor::updateCell(const Tuple &key, int colnumber,
								const Variant &newvalue)
{

}

void TableEditor::deleteRow(const Tuple &key)
{

}

void TableEditor::insertRow(const Tuple &key, const Tuple &value)
{

}

TableEditor::TableEditor(DBTableCollection *base, const QString &tablename,
						 const OperatorPushableVector<EditWith> &keyeditors,
						 const OperatorPushableVector<EditWith> &valueeditors,
						 QWidget *parent)
	: QWidget(parent)
{
	lastline = -1;
	table = base->getTable(tablename.toStdString());
	this->keyeditors = keyeditors;
	this->valueeditors = valueeditors;

	previousPage = new QToolButton(this);
	previousPage->setIcon(QIcon(":/toolbuttons/arrow-left.png"));
	previousPage->setFixedSize(24,24);
	connect(previousPage,SIGNAL(clicked()),this,SLOT(goPreviousPage()));
	nextPage = new QToolButton (this);
	nextPage->setIcon(QIcon(":/toolbuttons/arrow-right.png"));
	nextPage->setFixedSize(24,24);
	connect(nextPage,SIGNAL(clicked()),this,SLOT(goNextPage()));
	linesOnPage = new QComboBox(this);
	linesOnPage->addItem("10");
	linesOnPage->addItem("100");
	linesOnPage->addItem("1000");
	linesOnPage->addItem("10000");
	linesOnPage->setCurrentIndex(0);
	rowscount = new QLabel(this);
	tableview = new QScrollArea(this);
	tableview->setWidgetResizable(true);
	insideWidget = new QWidget;
	insideWidget->setVisible(true);
	tableview->setWidget(insideWidget);
	tableview->setBackgroundRole(QPalette::Light);
	QGridLayout * outer = new QGridLayout(this);
	outer->setContentsMargins(0,0,0,0);
	outer->setSpacing(0);
	outer->addWidget(previousPage,0,0);
	outer->addWidget(new QLabel(QString::fromUtf8("Строк на странице"),this),0,1);
	outer->addWidget(linesOnPage,0,2);
	outer->addWidget(rowscount,0,4);
	outer->addWidget(nextPage,0,5);
	outer->addWidget(tableview,1,0,1,6);
	lay = new QGridLayout;
	lay->setContentsMargins(0,0,0,0);
	lay->setSpacing(0);
	insideWidget->setLayout(lay);
	//tableview->setWidget(new QLabel("Загружено"));
	//lay->addWidget(new QLabel("Загружено"),0,0);


	first = table->const_begin();
	showPage();

}

QString TableEditor::strRepresentation(const Variant &v, EditWith &editwith)
{
	if (v.getType() == Variant::TYPE_INT)
	{
		if (editwith == EW_DateTime)
			return QString::fromStdString(
				UTCDateTime::fromTAIJ2000(v.toInt()).getUTCDateTimeString());
	}
	if (v.getType() == Variant::TYPE_DOUBLE)
	{
		if (editwith == EW_DateTime)
			return QString::fromStdString(
				UTCDateTime::fromTAIJ2000(v.toDouble()).getUTCDateTimeString());
	}
	return QString::fromStdString(v.toString());
}

KnowYourPlaceLabel::KnowYourPlaceLabel(const QString &text, int colnumber,
									   int rownumber, TableEditor *parent)
	: QLabel(text,parent)
{
	this->colnumber = colnumber;
	this->rownumber = rownumber;
}

void KnowYourPlaceLabel::mouseDoubleClickEvent(QMouseEvent *e)
{
	e->accept();
	dblClick(colnumber, rownumber);
}

KnowYourRowButton::KnowYourRowButton (int rownumber, TableEditor * parent)
	: QToolButton(parent)
{
	this->rownumber = rownumber;
	connect(this,SIGNAL(clicked()),this,SLOT(clickme()));
}

void KnowYourRowButton::clickme()
{
	clickBtn(rownumber);
}

void TableEditor::clearPage()
{
	for (unsigned int i=0; i<pageWidgets.size(); i++)
		delete pageWidgets[i];
	pageWidgets.resize(0);
}

void TableEditor::showPage()
{
	clearPage();
	int linesonpage = linesOnPage->currentText().toInt();
	DBMap::DBConstIterator it = first;
	lastline = 0;
	for (unsigned int i=0; i<linesonpage; i++)
	{
		if (it==table->const_end())
			break;

		//Добавить кнопку удаления
		KnowYourRowButton * newbtn = new KnowYourRowButton(i,this);
		pageWidgets.push_back(newbtn);
		newbtn->setIcon(QIcon(":/toolbuttons/edit-delete.png"));
		newbtn->setContentsMargins(0,0,0,0);
		newbtn->setFixedSize(18,18);
		connect(newbtn, SIGNAL(clickBtn(int)),this,SLOT(delClick(int)));

		lay->addWidget(newbtn,i,0);
		//lay->addWidget(new QToolButton(this),i,0);

		//Добавить отображение ключевых полей
		int kkc = table->getKeyColumnsCount();
		for (unsigned int j = 0; j<kkc; j++)
		{
			KnowYourPlaceLabel * nlab = new KnowYourPlaceLabel(
						strRepresentation(it.keyColumnValue(j),
										  keyeditors[j]), j,i,this);
			lay->addWidget(nlab,i,j+1);
			pageWidgets.push_back(nlab);
		}

		//Добавить отображение полей значений
		for (unsigned int j = 0; j<table->getValueColumnsCount(); j++)
		{
			KnowYourPlaceLabel * nlab =new KnowYourPlaceLabel(
						strRepresentation(it[j],valueeditors[j]),j+kkc,i,
						this);
			lay->addWidget(nlab,i,j+1+kkc);
			pageWidgets.push_back(nlab);
		}

		it++;
		lastline = i+1;
	}

	if (it == table->const_end())
	{
		QLabel * tableend = new QLabel(QString::fromUtf8("(Конец)"),this);
		tableend->setAlignment(Qt::AlignLeft | Qt::AlignTop);
		lay->addWidget(tableend,lastline,1,2,1);
		pageWidgets.push_back(tableend);
	}

	QToolButton * addline = new QToolButton(this);
	pageWidgets.push_back(addline);
	addline->setIcon(QIcon(":/toolbuttons/list-add.png"));
	addline->setFixedSize(18,18);
	lay->addWidget(addline,lastline,0);
	lay->addWidget(new QWidget(this),lastline+1,0);
	connect(addline,SIGNAL(clicked()),this,SLOT(addNewRow()));
	rowscount->setText(QString::fromUtf8("Число строк: ")+
					   QString::number(table->count()));

	//Запомнить итератор последней строки
	last = it;
	previousPage->setEnabled(first!=table->const_begin());
	nextPage->setEnabled(last!=table->const_end());

}

void TableEditor::goNextPage()
{
	first = last;
	showPage();
}

void TableEditor::goPreviousPage()
{
	int linesonpage = linesOnPage->currentText().toInt();
	for (unsigned int i=0; i<linesonpage; i++)
		if (first!=table->const_begin())
			first.dec(table->getKeyColumnsCount()-1);
	showPage();
}

void TableEditor::dblClick(int colnumber, int rownumber)
{

}

void TableEditor::delClick(int rownumber)
{
	bool theend = false;
	Tuple newfirstkey;
	DBTable::DBConstIterator newfirstiterator = first;
	if (rownumber == 0)
		newfirstiterator++;
	if (newfirstiterator!=table->const_end())
	{
		theend = true;
		newfirstkey = newfirstiterator.subkey();
	}

	DBTable::DBConstIterator it0 = first;
	it0.inc(table->getKeyColumnsCount()-1,rownumber);
	Tuple toDel = it0.subkey();
	table->deleteRows(toDel);

	if (!theend)
		newfirstiterator = table->find(newfirstkey);

	first = newfirstiterator;


	showPage();
}

QWidget * TableEditor::toEditor (EditWith editortype, const Variant & v,
								 QWidget * parent)
{
	if (editortype == EW_TextBox)
	{
		QLineEdit * result = new QLineEdit(parent);
		result->setText(strRepresentation(v,editortype));
		return result;
	}

	if (editortype == EW_MultLineEdit)
	{
		QPlainTextEdit  * result = new QPlainTextEdit(parent);
		result->document()->setPlainText(strRepresentation(v, editortype));
		return result;
	}

	if (editortype == EW_SpinBox)
	{
		QSpinBox * result = new QSpinBox(parent);
		result->setMinimum(INT_MIN);
		result->setMaximum(INT_MAX);
		result->setValue(v.toInt());
		return result;
	}

	if (editortype == EW_DateTime)
	{
		QDateTimeEdit * result = new QDateTimeEdit(parent);
		UTCDateTime dt;
		if (v.getType() == Variant::TYPE_DATETIME)
			dt = v.toUTCDateTime();
		if ((v.getType() == Variant::TYPE_DOUBLE)||
				(v.getType() == Variant::TYPE_INT))
			dt = UTCDateTime::fromTAIJ2000(v.toDouble());
		if (v.getType() == Variant::TYPE_STRING)
			dt = UTCDateTime::fromUTCDateTimeString(v.toString());
		if ((v.getType()!=Variant::TYPE_INT)
				&&(v.getType()!=Variant::TYPE_DOUBLE)
				&&(v.getType()!=Variant::TYPE_DATETIME)
				&&(v.getType()!=Variant::TYPE_STRING))
			throw StrException("TableEditor::toEditor",
							   "Невозможно отредактировать переменную типа " +
							   v.getTypeName()+" как дату и время");
		int Y,M,D,h,m,isec,imsec;
		real sec;
		dt.getUTCDateTime(Y,M,D,h,m,sec);
		isec = floor(sec);
		imsec = floor((sec - isec)*1000);
		result->setDate(QDate(Y, M, D));
		result->setTime(QTime(h, m, isec, imsec));
		return result;
	}

	if (editortype == EW_Default)
	{
		if (v.getType() == Variant::TYPE_DATETIME)
			return toEditor(EW_DateTime,v,parent);
		if (v.getType() == Variant::TYPE_INT)
			return toEditor(EW_SpinBox,v,parent);
		if (v.getType() == Variant::TYPE_STRING)
			if (v.toString().find_first_of('\n')!=string::npos)
				return toEditor(EW_MultLineEdit,v,parent);
		return toEditor(EW_TextBox,v,parent);
	}

}

Variant TableEditor::fromEditor(EditWith editortype, QWidget *editor,
								Variant::Type desiredtype)
{
	if (editortype == EW_TextBox)
		return Variant::fromString(desiredtype,
								   ((QLineEdit*)editor)->text().toStdString());
	if (editortype == EW_MultLineEdit)
		return Variant::fromString(desiredtype,
			((QPlainTextEdit*)editor)->document()->toPlainText().toStdString());
	if (editortype == EW_SpinBox)
	{
		int value = ((QSpinBox*)editor)->value();
		if (desiredtype == Variant::TYPE_CHAR)
			return Variant(char(value));
		if (desiredtype == Variant::TYPE_INT)
			return Variant(value);
		if (desiredtype == Variant::TYPE_DOUBLE)
			return Variant(real(value));
		if (desiredtype == Variant::TYPE_STRING)
			return Variant(Variant(value).toString());
		return Variant();
	}
	if (editortype == EW_DateTime)
	{
		QDateTimeEdit * edt = static_cast<QDateTimeEdit*>(editor);
		UTCDateTime res;
		res = UTCDateTime::fromUTCDateTime(edt->date().year(),
										   edt->date().month(),
										   edt->date().day(),
										   edt->time().hour(),
										   edt->time().minute(),
										   edt->time().second()+
										   0.001*edt->time().msec());
		if (desiredtype == Variant::TYPE_DOUBLE)
			return Variant(res.getTAIJ2000());
		if (desiredtype == Variant::TYPE_INT)
			return Variant(floor(res.getTAIJ2000()));
		if (desiredtype == Variant::TYPE_DATETIME)
			return Variant(res);
		return Variant();

	}
	if (editortype == EW_Default)
	{
		if (editor->inherits("QDateTimeEdit"))
			return fromEditor(EW_DateTime,editor,desiredtype);
		if (editor->inherits("QSpinBox"))
			return fromEditor(EW_SpinBox,editor,desiredtype);
		if (editor->inherits("QLineEdit"))
			return fromEditor(EW_TextBox,editor,desiredtype);
		return fromEditor(EW_MultLineEdit,editor,desiredtype);

	}
}

void TableEditor::addNewRow()
{
	QDialog * newrow = new QDialog;
	QGridLayout * dialay = new QGridLayout(newrow);
	Tuple newkey;
	Tuple newvalue;
	newkey.resize(table->getKeyColumnsCount());
	newvalue.resize(table->getValueColumnsCount());
	int kkc = table->getKeyColumnsCount();
	for (unsigned int i=0; i<kkc; i++)
	{
		newkey[i] = ((Variant::Type)
					 (table->getKeyColumns()[i].first))->defaultValue();
		dialay->addWidget(new QLabel(table->getKeyColumnName(i),newrow),i,0);
		dialay->addWidget(toEditor(keyeditors[i], newkey[i] ,newrow),i,1);
	}

	for (unsigned int i=0; i<table->getValueColumnsCount(); i++)
	{
		newvalue[i] = ((Variant::Type)
					   (table->getValueColumns()[i].first))->defaultValue();
		dialay->addWidget(new QLabel(table->getValueColumnName(i),newrow),
						  kkc+i,0);
		dialay->addWidget(toEditor(valueeditors[i],newvalue[i],newrow),kkc+i,1);
	}

	QWidget * buttongroup = new QWidget(newrow);
	dialay->addWidget(buttongroup,table->getKeyColumnsCount()+kkc+1,0,1,2);
	QHBoxLayout * buttonlayout = new QHBoxLayout(buttongroup);
	QPushButton * ok = new QPushButton(QString::fromUtf8("OK"),newrow);
	connect(ok,SIGNAL(clicked()),newrow, SLOT(accept()));
	QPushButton * cancel = new QPushButton(QString::fromUtf8("Отмена"),newrow);
	connect(cancel,SIGNAL(clicked()),newrow,SLOT(reject()));
	buttonlayout->addWidget(ok);
	buttonlayout->addWidget(cancel);
	buttonlayout->addStretch();
	newrow->exec();
	int result = newrow->result();
	//Попробовать вставить выбранную строку
	if (result==QDialog::Accepted)
	{
		for (unsigned int i=0; i<kkc; i++)
			newkey[i] = fromEditor(keyeditors[i],dialay->itemAtPosition(i,1)->widget(),table->getKeyColumns()[i].first);
		for (unsigned int i=0; i<table->getValueColumnsCount(); i++)
			newvalue[i] = fromEditor(valueeditors[i],dialay->itemAtPosition(i+kkc,1)->widget(),table->getValueColumns()[i].first);
		delete newrow;
		try
		{
			table->insertRow(newkey,newvalue);
		}
		catch (StrException e)
		{
			QMessageBox::critical(this,QString::fromUtf8("Ошибка добавления записи"),
								  QString::fromUtf8("Строка: \n(")+QString::fromStdString(newkey.join(","))
								  +","+QString::fromStdString(newvalue.join(","))+")\n не может быть добавлена. Детали:"
								  +QString::fromStdString(e.what()));
		}
		return;
	}
	delete newrow;
}

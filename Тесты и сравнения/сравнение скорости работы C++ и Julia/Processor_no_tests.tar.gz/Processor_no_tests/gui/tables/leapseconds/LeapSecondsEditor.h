#ifndef LEAPSECONDSEDITOR_H_
#define LEAPSECONDSEDITOR_H_

#include <QWidget>
#include <QScrollArea>

#include <DBTableCollection.h>
#include <StdTables.h>

class LeapSecondsEditor : public QWidget
{
	Q_OBJECT
private:
	QScrollArea * mainarea;
	QWidget * inside;

public:
	LeapSecondsEditor(libgnss::DBTableCollection * base, QWidget * parent);

};

#endif

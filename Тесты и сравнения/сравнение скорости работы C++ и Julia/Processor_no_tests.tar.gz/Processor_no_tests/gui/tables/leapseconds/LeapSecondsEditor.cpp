#include <LeapSecondsEditor.h>

using namespace libgnss;

LeapSecondsEditor::LeapSecondsEditor(DBTableCollection *base, QWidget *parent)
	: QWidget(parent)
{

}

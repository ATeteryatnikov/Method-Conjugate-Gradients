#include <cmath>

#include <view3d.h>
#include <Consts.h>

View3D::View3D(DBTableCollection *base, const QGLFormat &format,
	       QWidget *parent, const QGLWidget *shareWidget,
	       Qt::WindowFlags f)
	: QGLWidget (format,parent,shareWidget,f)
{
	this->base.push_back(base);
	focus_id = -1;
	earthTex = convertToGLFormat(QImage(":/textures/earth2048x1024.png"));

	// Проверка наличия необходимых таблиц

	//Выбрать момент времени
	curT = 0;

	//Камера смотрит со стороны наконечника оси X.
	angleXY = 0;
	angleXZ = 0;
	camR = 1.0e+04;
	halfViewAngle = Pi/4;
}


void View3D::addData (DBTableCollection * addBase)
{
	base.push_back(addBase);
}


void View3D::setTime ( timeMoment t )
{
	curT = t;
}

void View3D::setFocusID ( int focusID )
{
	focus_id = focusID;
}


void View3D::initializeGL()
{
	glClearColor(0.0,0.0,0.0,0.0);
	bindTexture(earthTex);

	//Фильтриация текстуры
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);

	//Повтор текстуры при больших значениях текстурных координат
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_R, GL_REPEAT );
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_R, GL_REPEAT );
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_REPEAT );
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_REPEAT );
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

}

void View3D::resizeGL(int w, int h)
{
	int side = qMin(width, height);
	glViewport((width - side) / 2, (height - side) / 2, side, side);
}




void View3D::paintGL()
{
	//Сделать так, чтобы камера смотрела строго вдоль оси X
	//Все координаты будут преобразованы в соответствии с этим.
	//Задать параметры буфера глубины в зависимости от расстояния
	//от центра вида до камеры.
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum(-1.0, +1.0, -1.0, 1.0, camR/1000, camR*10);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//Очистить буфер глубины
	glClear(GL_DEPTH_BUFFER);


	QMatrix4x4 m;

	//Установить координату КА
	QVector3D camcenter = getCamCenter();
	QVector3D campos = camcenter + QVector3D(
				camR * cos(angleXY) * cos (angleXZ),
				camR * sin(angleXY) * cos (angleXZ),
				camR * sin(angleXZ)
				);

	m.lookAt(campos, camcenter, QVector3D(0.0,0.0,1.0));

	//Матрица transform будет применяться для ручного преобразования
	//всех координат, заданных в double, чтобы избежать потери точности
	//при использовании float в opengl.
	QMatrix4x4 transform = m.inverted();

	drawEarthMoonSun(transform);
}

void View3D::drawEarthMoonSun(const QMatrix4x4 &transform)
{
	bindTexture(earthTex);

	if (focus_id == -1) // Центр - Земля
	{
		//Угловая ширина видимой поверхности Земли
		double angleWidth;
		//Определить видимые пределы поверхности Земли
		double ratio1 = sin(halfViewAngle) * camR / 6300;
		if (fabs(ratio1)>1)
			angleWidth = Pi/2;
		else
		{
			if (camR < 6300)
				angleWidth = 0;
			else
				angleWidth = asin(ratio1) - halfViewAngle;
		}

	}
}

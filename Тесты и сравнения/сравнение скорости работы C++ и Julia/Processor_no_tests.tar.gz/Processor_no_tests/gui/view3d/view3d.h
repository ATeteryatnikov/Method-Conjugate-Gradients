#ifndef VIEW3D_H_
#define VIEW3D_H_

#include <QImage>
#include <QMutex>
#include <QVector>
#include <QGLWidget>
#include <DBTableCollection.h>

#include <Types.h>
#include <ParamTrajectory.h>

class View3D : public QGLWidget
{
private:
	timeMoment curT;

	QMutex access;

	QVector < DBTableCollection * > base;

	QImage earthTex;

	int focus_id;

	//Углы ориентации камеры
	double angleXY;
	double angleXZ;

	//Расстояние от центра до камеры
	double camR;

	QVector3D getCamCenter();

	void drawEarthMoonSun( const QMatrix4x4 & transform );

	void drawTrajectories( const QMatrix4x4 & transform );

	void drawStations ( const QMatrix4x4 & transform );

	double halfViewAngle;

public:
	View3D (DBTableCollection * base, const QGLFormat & format,
		QWidget * parent = 0, const QGLWidget * shareWidget = 0,
		Qt::WindowFlags f = 0);

	void addData (DBTableCollection * addBase);

	//! Указать момент времени, на который требуется отображение
	void setTime ( timeMoment t );

	/** @brief Установить на каком объекте центрирована камера.
	  *
	  * Если focusID=-1, камера указывает на Землю.
	  * В противном случае, камера указывает на КА, идентификатор которого
	  * равен focusID.
	  *
	  * @param focusID Номер объекта
	  */
	void setFocusID ( int focusID );



protected:
	void initializeGL();
	void resizeGL(int w, int h);
	void paintGL();

};


#endif

#ifndef PREPROCESS_H_
#define PREPROCESS_H_

#include <set>
#include <string>

using namespace std;

#include <observables.h>
#include <readcframe.h>
#include <TimeShift.h>
#include <DBError.h>
#include <readRINEXNavGLO.h>

class PPPObservablesParser;


/**
 * @brief Предобработка измерительных данных при чтении
 *
 * Единственное отличие от всем устраивающего базового класса - метод
 * прореживания псевдодальностей @ref cutObservables(), который на лету
 * подгружает RINEX Clock-файлы и отмечает для удаления те измерения, для
 * которых нет измерительных данных.
 */
class PPPObservablesParser_ : public libgnss::ObservablesLoader
{
	friend class PPPObservablesParser;
private:
	libgnss::Tuple chkclk_sat;
	libgnss::Tuple chkclk_rec;
	libgnss::ClockBias * bias;
	string clktemplate;
	string stationname;
	bool stationclockcut;
	set<int> sat_ids;
	PPPObservablesParser * parent;
	set<int> obs_ids;//Разрешенные типы измерительных данных

public:

	/**
	 * @brief Конструктор предобработчика измерительных данных
	 * @param tcol Коллекция, в которую нужно записать данные
	 * @param obs_src_id Идентификатор БИС
	 * @param clkfilenametemplate Шаблон имён Clock-файлов
	 * @param glophase Режим чтения фазы ГЛОНАСС
	 * @param gpsphase Режим чтения фазы GPS
	 * @param glorange Режим чтения псевдодальности ГЛОНАСС
	 * @param gpsrange Режим чтения псевдодальности GPS
	 */
	PPPObservablesParser_(libgnss::DBTableCollection * col,
						 const string & clkfilenametemplate,
						 bool stationclockcut, const set<int> & sat_ids,
						 int obs_src_id, char int_criterion, char navsys,
						 PPPObservablesParser * parent,
						 string p1denotement, string p2denotement,
						 string l1denotement, string l2denotement);

private:

	/**
	 * @brief Подгружает RINEX-Clock-файл на данную эпоху
	 * @param t Момент времени, секунды TAI от 1 янв. 2000
	 * @return true, если пришлось загружать файл, false, если уже был загружен
	 */
	bool loadClockFile(libgnss::real t);

protected:

	/**
	  * Цель перегрузки - убрать моменты времени, в которые нет ухода часов НКА
	 */
	virtual bool cutObservables(int sat_history_id, libgnss::real t,
								int obstype);

	//! @brief Цель перегрузки - ограничить загрузку по идентификатору НКА
	virtual void loadObservables (int sat_history_id, libgnss::real t,
								  const map < int , libgnss::real > & data,
								  const map < int, int> & flags);

	//! @brief Цель перегрузки - взять новое имя БИС для заполнения шаблона
	virtual void setNewObsSrcID(int new_obs_src_id);

	/**
	 * Цель перегрузки - записывать список дуг измерительных данных.
	 */
	virtual int nextInterval (int sat_history_id, int & i, int & count,
							  libgnss::real & length, vector < bool > & cut);

	/**
	  * Цель перегрузки - помечать в списке дуг измерительнгых данных те,
	  * которые использованы для обработки (те, которые переданы в данную
	  * функцию).
	 */
	void loadObservablesArc(int sat_history_id, int begin, int end,
							const vector < bool > & cut);

	/**
	  * Цель перегрузки - убрать лишние типы измерений
	 */
	virtual void loadObservable (int sat_history_id, int obstype,
								 libgnss::real t,
								 libgnss::real obs, int flag);
};

void chooseObsDenotement(string & r1, string & r2, string & l1,
						 string & l2, int phasemode, int rangemode,
						 int rinexver);

class PPPObservablesParser
{
	friend class PPPObservablesParser_;
private:
	PPPObservablesParser_ * gloparser;
	PPPObservablesParser_ * gpsparser;
	libgnss::GLONASSNavDataReader * glofrs;
	libgnss::DBTable * intervals;

public:
	set<pair<int,int> > loadeddays;
	set<string> loadedclk;

	/**
	 * @brief Загрузчик измерительных данных GPS/ГЛОНАСС
	 * @param tcol Коллекция таблиц
	 * @param obs_src_id Идекнтификатор БИС
	 * @param clkfilenametemplate Шаблон имен Clock-файлов
	 * @param glophasemode Выбор точности фазы ГЛОНАСС
	 * @param glorangemode Выбор пары типов измерений ГЛОНАСС
	 * @param gpsphasemode Выбор точности фазы GPS
	 * @param gpsrangemode Выбор пары типов измерений GPS
	 * @param stationclockcut Флаг: нужно ли удалять измерения без часов БИС
	 * @param sat_ids Допустимые идентификаторы НКА
	 * @param intervals Таблица интервалов непрерывности фазы
	 * @param smallarc Критерий коротких дуг
	 * @param rinexver Версия RINEX: 2 или 3
	 *
	 * Выбор точности фазы: 0 - обычная, 1 - повышенная точность.
	 *
	 * Выбор пар типов измерений - по паре каких измерений будет вычислена
	 * ионосферно-свободная линейная комбинация измерений:
	 * 0=C1P2, 1=P1P2, 2=C1C2, 3=P1C2
	 *
	 * От версии RINEX зависят обозначения типов измерений.
	 */
	PPPObservablesParser(libgnss::DBTableCollection * tcol, int obs_src_id,
						 const string & clkfilenametemplate,
						 int glophasemode, int glorangemode,
						 int gpsphasemode, int gpsrangemode,
						 bool stationclockcut,
						 const set<int> & sat_ids,
						 libgnss::DBTable * intervals,
						 char smallarc,
						 int rinexver);

	~PPPObservablesParser();

	inline PPPObservablesParser_ * GLONASSParser()
	{
		return gloparser;
	}

	inline PPPObservablesParser_ * GPSParser()
	{
		return gpsparser;
	}

};



#endif

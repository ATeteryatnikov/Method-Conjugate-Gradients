#ifndef PPPPOSTPROCESS_H
#define PPPPOSTPROCESS_H

#include <vector>
#include <string>
#include <set>
#include <map>

#include <Types.h>


typedef std::map <
			std::pair<libgnss::real, libgnss::real>, //Интервалы
			std::map <
				std::string, //БИСы
				std::map <
					std::string, //НКА
					std::set<std::string> > > >
	ResidualFilesList;

/**
 * @brief Создает текстовые файлы графиков аномалий
 * @param resfilenames Подготовленные файлы невязок
 * @param gradation Градация невязок по величине
 * @param norm Норма: 0 - равномерная; 1 - СКО
 * @return Для каждого интервала градации - список подготовленных файлов
 *
 * Функция проходит переданный ей список файлов, содержащих невязки
 * моделирования измерительных данных, находит в нём невязки
 */
ResidualFilesList sortResidualFiles(const std::vector<std::string>&resfilenames,
		const std::set<libgnss::real> &gradation, int norm,
									libgnss::real maxzenith);

#endif // PPPPOSTPROCESS_H

#include <gnssconfig.h>
#include <pppoptions.h>
#include <iostream>
#include <cmath>
#include <DBVariant.h>
#include <cstdlib>
#include <fstream>

using namespace libgnss;

PPPOptions::PPPOptions()
{
	smallarcs = 'C';
	cmdline = "";
	onlycheck = false;
	showgui = false;
	stname = "";
	glophase=0;
	glorange=0;
	gpsphase=0;
	gpsrange=0;
	igsdir="";
	antex = "";
	fileidx = -1;
	clktemplate="";
	sp3template="";
	snxtemplate="";
	trotemplate="";
	resample = 0; //0 обозначает отказ от разделения на два этапа
	stexactcoord=false;
	sinexexact=false;
	finalsfile = "";
	stexactcoord=false;
	sinexexact=false;
	st_x=numeric_limits<real>::quiet_NaN();
	st_y=numeric_limits<real>::quiet_NaN();
	st_z=numeric_limits<real>::quiet_NaN();
	crdframe="";
	stcrdstep=numeric_limits<real>::quiet_NaN();
	mapfunc="";
	tromodel="";
	tropogradient=true;
	usesinextropo=false;
	tropostep = numeric_limits<real>::quiet_NaN();
	strinexclock=false;
	precsatclockimit = false;
	allowsatclockinterp=false;
	usenavorbit=false;
	allowrecclockinterp=false;
	outputdir="";
	phasetxt=false;
	rangetxt=false;
	phasepng=false;
	rangepng=false;
	urretxt=false;
	uraetxt=false;
	urrepng=false;
	uraepng=false;
	phtxttempl="";
	rtxttempl="";
	urretmpl="";
	uraetmpl="";
	errmode_stddev=0;//Размер ошибки считается по равномерной норме
	satcount=false;
	satcounttemplate="";
	overview=false;
	adjdump = false;
	loaddump = false;
	urranumpoints = 6;
	urraorder = 2;
	stage = 0;
	pltvis = "./gnuplot/visibility.gnuplot";
	pltres = "./gnuplot/residuals.gnuplot";
	plturr = "./gnuplot/urre.gnuplot";
	pltura = "./gnuplot/urae.gnuplot";
	maxzenith_imit = 90;
	maxzenith_ls = 85;
	since_iter = 2;
	still_draw = true;

	settings["Parsers"]["finals2000A"]["Bulletin"] = "B";
	settings["Parsers"]["SINEX"]["SINEX_TRS"] = "IGS08";
	settings["Observables"]["Editor"]["usegfdetector"] = "Yes";
	settings["Observables"]["Editor"]["usemwdetector"] = "Yes";
	settings["Observables"]["Editor"]["usempdetector"] = "Yes";
	settings["Least_Squares"]["Pseudorange"]["maxZenith"]="90";
	settings["Least_Squares"]["Pseudorange"]["TSToAdj"]="Receiver";
	settings["Least_Squares"]["Pseudorange"]["rms_p"]="1.0";
	settings["Least_Squares"]["Pseudorange"]["rms_l"]="0.1";
	settings["Observables"]["Editor"]["minArcLength"]="900";
	settings["Observables"]["Editor"]["minObsCount"]="4";
	settings["Observables"]["Editor"]["MPThreshold"]="10.0";
	settings["Observables"]["Editor"]["WBThreshold"]="10.0";
	settings["Observables"]["Editor"]["GFThreshold"]="3e-5";
	settings["Observables"]["Editor"]["GFNumOfPoints"]="60";
	settings["Observables"]["Editor"]["GFOrder"]="3";
	settings["Observables"]["Editor"]["Interval"]="60";
	settings["Least_Squares"]["Pseudorange"]["RMSAccountZenith"]="No";
	settings["Least_Squares"]["Pseudorange"]["maxZenith"]="90";
	settings["Parameters_settings"]["trajectory"]["extrlim"]="60";
	settings["Parameters_settings"]["trajectory"]["maxstep"]="3600";
}

int getStrArgument(int argc, char**argv, int&i, const string&argstr,
						  string & result, bool once = true)
{
	if ((result != "") && once)
	{
		cerr<<"Повторное задание параметра "<<argstr<<endl;
		return -10;
	}
	i++;
	if (i>=argc)
	{
		cerr<<"После "<<argstr<<" ожидался ещё один аргумент"<<endl;
		return -11;
	}
	result = string(argv[i]);
	return 0;
}

int getRealArgument(int argc, char ** argv, int & i,
						   const string & argstr, real & result,
					bool once = true)
{
	if ((!(isnan(result))) && once)
	{
		cerr<<"Повторное задание параметра "<<argstr<<endl;
		return -10;
	}
	i++;
	if (i>=argc)
	{
		cerr<<"После "<<argstr<<" ожидался ещё один аргумент"<<endl;
		return -11;
	}
	real result1;
	try
	{
		result1 = Variant::fromString(Variant::TYPE_DOUBLE,
									  string(argv[i])).toDouble();
	}
	catch(...)
	{
		cerr<<"Возникла ошибка разбора действительного числа после аргумента "
			  <<argstr<<endl;
		return -12;
	}
	result = result1;
	return 0;
}

int getIntArgument(int argc, char ** argv, int & i,
						   const string & argstr, int & result, bool once=true)
{
	real realarg = numeric_limits<real>::quiet_NaN();
	int rescode = getRealArgument(argc,argv,i,argstr,realarg);
	if (rescode != 0)
		return rescode;
	if (floor(realarg)!=realarg)
	{
		cerr<<"Возникла ошибка разбора целого числа после аргумента "
			  <<argstr<<endl;
		return -13;
	}
	result = (int)(realarg);
	return 0;
}


bool isGPSGLOSatelliteName(string satname)
{
	char navsys = satname[0];
	if ((navsys!='R')&&(navsys!='G'))
		return false;
	char * after;
	long prn = strtol(&(satname[1]),&after,10);
	if (navsys == 'G')
		if ((prn<1)||(prn>32))
			return false;
	if (navsys == 'R')
		if ((prn<1)||(prn>24))
			return false;
	return true;
}

int parseCMDLine (int argc, char ** argv, PPPOptions & r)
{
	int result= 0;
	int rescode;
	//Если аргументов нет, в любом случае показать GUI
	if (argc == 1)
		r.showgui = true;
	else
	{
		for (int i=1; i<argc; i++)
		{
			if (r.cmdline != "")
				r.cmdline += " ";
			r.cmdline += string(argv[i]);
		}

		//Разобрать параметры командной строки
		for (int i=1; i<argc; i++)
		{
			string cmdarg (argv[i]);
			//Показать графический интерфейс, даже если опций достаточно
			if (cmdarg == ShowGUI)
				r.showgui = true;
			else if (cmdarg == OnlyCheck)
				r.onlycheck = true;
			else if (cmdarg == PltVis)
			{
				string newpltvis;
				if((rescode=getStrArgument(argc,argv,i,PltVis,newpltvis))!=0)
					return rescode;
				r.pltvis = newpltvis;
			}
			else if (cmdarg == PltRes)
			{
				string newpltres;
				if((rescode=getStrArgument(argc,argv,i,PltRes,newpltres))!=0)
					return rescode;
				r.pltres = newpltres;
			}
			else if (cmdarg == PltURR)
			{
				string newplturr;
				if((rescode=getStrArgument(argc,argv,i,PltURR,newplturr))!=0)
					return rescode;
				r.plturr = newplturr;
			}
			else if (cmdarg == PltURA)
			{
				string newpltura;
				if((rescode=getStrArgument(argc,argv,i,PltURA,newpltura))!=0)
					return rescode;
				r.pltura = newpltura;
			}
			else if (cmdarg == Stage)
			{
				if((rescode=getIntArgument(argc,argv,i,Stage,r.stage))!=0)
					return rescode;
			}
			else if (cmdarg == Resample)
			{
				if((rescode=getIntArgument(argc,argv,i,Resample,r.resample))!=0)
					return rescode;
			}
			else if (cmdarg == GPSPhase)
			{
				if((rescode=getIntArgument(argc,argv,i,GPSPhase,r.gpsphase))!=0)
					return rescode;
			}
			else if (cmdarg == GPSRange)
			{
				if((rescode=getIntArgument(argc,argv,i,GPSRange,r.gpsrange))!=0)
					return rescode;
			}
			else if (cmdarg == GLOPhase)
			{
				if((rescode=getIntArgument(argc,argv,i,GLOPhase,r.glophase))!=0)
					return rescode;
			}
			else if (cmdarg == GLORange)
			{
				if((rescode=getIntArgument(argc,argv,i,GLORange,r.glorange))!=0)
					return rescode;
			}
			else if (cmdarg == FileIDX)
			{
				if((rescode=getIntArgument(argc,argv,i,FileIDX,r.fileidx))!=0)
					return rescode;
			}
			else if (cmdarg == Antex)
			{
				if ((rescode=getStrArgument(argc,argv,i,Antex,r.antex))!=0)
					return rescode;
			}
			else if (cmdarg == ERPFinals)
			{
				if((rescode=getStrArgument(argc,argv,i,ERPFinals,r.finalsfile))
						!=0)
					return rescode;
			}
			else if (cmdarg == TropoStep)
			{
				if((rescode=getRealArgument(argc,argv,i,TropoStep,r.tropostep))
						!=0)
					return rescode;
			}
			else if (cmdarg == ChooseSats)
			{
				string satlist_s = "";
				rescode=getStrArgument(argc,argv,i,ChooseSats,satlist_s);
				vector < string > satlist_list = split(satlist_s,',');
				for (unsigned int i=0; i<satlist_list.size(); i++)
					if (isGPSGLOSatelliteName(satlist_list[i]))
						r.adj_satnames.push_back(satlist_list[i]);
					else
					{
						cerr<<"Строка "<<satlist_list[i]<<" не задаёт "
							  "корректное название НКА GPS или ГЛОНАСС"<<endl;
						return -13;
					}
			}
			else if (cmdarg == ChooseImitSats)
			{
				string satlist_s = "";
				rescode=getStrArgument(argc,argv,i,ChooseSats,satlist_s);
				vector < string > satlist_list = split(satlist_s,',');
				for (unsigned int i=0; i<satlist_list.size(); i++)
					if (isGPSGLOSatelliteName(satlist_list[i]))
						r.imit_satnames.push_back(satlist_list[i]);
					else
					{
						cerr<<"Строка "<<satlist_list[i]<<" не задаёт "
							  "корректное название НКА GPS или ГЛОНАСС"<<endl;
						return -13;
					}
			}
			else if (cmdarg == SatClkImit)
			{
				r.precsatclockimit = true;
			}
			else if (cmdarg == AllowSClkInt)
			{
				r.allowsatclockinterp = true;
			}
			else if (cmdarg == AllowRClkInt)
			{
				r.allowrecclockinterp = true;
			}
			else if (cmdarg == UseNavOrbit)
				r.usenavorbit = true;
			else if (cmdarg == RClockStation)
			{
				r.strinexclock = true;
			}
			else if (cmdarg==URRNumPoints)
			{
				if ((rescode=getIntArgument(argc,argv,i,URRNumPoints,
											 r.urranumpoints))!=0)
					return rescode;
			}
			else if (cmdarg==URROrder)
			{
				if ((rescode=getIntArgument(argc,argv,i,URROrder,
											 r.urraorder))!=0)
					return rescode;
			}
			//Имя БИС
			else if (cmdarg == StationName)
			{
				if ((rescode=getStrArgument(argc,argv,i,StationName,r.stname))
						!=0)
					return rescode;
			}
			//Имя RINEX-файла
			else if (cmdarg == RinexNames)
			{
				string rinexname = "";
				rescode = getStrArgument(argc,argv,i,RinexNames,rinexname);
				if (rescode!=0)
					return rescode;
				r.rinexnames.push_back(rinexname);
			}
			//Имя файла с C-кадрами
			else if (cmdarg == CFrameNames)
			{
				string cframename = "";
				rescode = getStrArgument(argc,argv,i,CFrameNames,cframename);
				if (rescode!=0)
					return rescode;
				//Проверить, откроется ли файл
				ifstream checkme(cframename.c_str());
				if (checkme.is_open())
					r.cframenames.push_back(cframename);
				else
				{
					cerr<<"Файл не найден: "<<cframename<<endl;
					if (r.showgui==false)
						return -20;
				}
				//Проверить, доступна ли вспомогательная библиотека
				if (checkBlob() == false)
				{
					cerr<<"Отсутствует блоб vto для данной платформы."<<endl;
					if (r.showgui==false)
						return -22;
				}
			}
			//Пусть к продуктам IGS
			else if (cmdarg == IGSDir)
			{
				if ((rescode=getStrArgument(argc,argv,i,IGSDir,r.igsdir))!=0)
					return rescode;
			}
			else if (cmdarg == ClkTmpl)
			{
				if ((rescode=getStrArgument(argc,argv,i,ClkTmpl,r.clktemplate))
						!=0)
					return rescode;
			}
			else if (cmdarg == SP3Tmpl)
			{
				if ((rescode=getStrArgument(argc,argv,i,SP3Tmpl,r.sp3template))
						!=0)
					return rescode;
			}
			else if (cmdarg == SNXTmpl)
			{
				if ((rescode=getStrArgument(argc,argv,i,SNXTmpl,r.snxtemplate))
						!=0)
					return rescode;
			}
			else if (cmdarg == TroTmpl)
			{
				if ((rescode=getStrArgument(argc,argv,i,TroTmpl,r.trotemplate))
						!=0)
					return rescode;
			}
			else if (cmdarg == StCrdStep)
			{
				if ((rescode=getRealArgument(argc,argv,i,StCrdStep,r.stcrdstep))
						!=0)
					return rescode;
			}
			//Задать точные координаты БИС
			else if (cmdarg == ExactCoords)
			{
				r.stexactcoord = true;
				if ((rescode=getRealArgument(argc,argv,i,ExactCoords,r.st_x))
						!=0)
					return rescode;
				if ((rescode=getRealArgument(argc,argv,i,ExactCoords,r.st_y))
						!=0)
					return rescode;
				if ((rescode=getRealArgument(argc,argv,i,ExactCoords,r.st_z))
						!=0)
					return rescode;
				if ((rescode=getStrArgument(argc,argv,i,ExactCoords,r.crdframe))
						!=0)
					return rescode;
			}
			else if (cmdarg == SNXCoords)
				r.sinexexact = true;
			//Модель тропосферы
			else if (cmdarg == MapFunc)
			{
				if ((rescode=getStrArgument(argc,argv,i,MapFunc,r.mapfunc))!=0)
					return rescode;
			}
			else if (cmdarg == TroModel)
			{
				if ((rescode=getStrArgument(argc,argv,i,TroModel,r.tromodel))
						!=0)
					return rescode;
			}
			else if (cmdarg == TropoGradient)
				r.tropogradient = true;
			else if (cmdarg == SinexTropo)
				r.usesinextropo = true;
			//Параметры генерации отчета
			else if (cmdarg == OutputDir)
			{
				if ((rescode=getStrArgument(argc,argv,i,OutputDir,r.outputdir))
						!=0)
					return rescode;
			}
			//Вывод невязок измерительных данных
			else if (cmdarg == PhaseRes)
			{
				r.phasetxt = true;
				if ((rescode=getStrArgument(argc,argv,i,PhaseRes,r.phtxttempl))
						!=0)
					return rescode;
			}
			else if (cmdarg == RangeRes)
			{
				r.rangetxt = true;
				if ((rescode=getStrArgument(argc,argv,i,RangeRes,r.rtxttempl))
						!=0)
					return rescode;
			}
			else if (cmdarg == URRERes)
			{
				r.urretxt = true;
				if ((rescode=getStrArgument(argc,argv,i,URRERes,r.urretmpl))
						!=0)
					return rescode;
			}
			else if (cmdarg == URAERes)
			{
				r.uraetxt = true;
				if ((rescode=getStrArgument(argc,argv,i,URAERes,r.uraetmpl))
						!=0)
					return rescode;
			}
			//Генерировать графики невязок
			else if (cmdarg == PhasePNG)
				r.phasepng = true;
			else if (cmdarg == RangePNG)
				r.rangepng = true;
			else if (cmdarg == URREPng)
				r.urrepng = true;
			else if (cmdarg == URAEPng)
				r.uraepng = true;
			//Генерировать файл с числом НКА
			else if (cmdarg == SatCount)
			{
				r.satcount = true;
				if ((rescode=getStrArgument(argc,argv,i,SatCount,
											r.satcounttemplate))!=0)
					return rescode;
			}
			//Критерий коротких дуг
			else if (cmdarg == smallArcs)
			{
				string crit;
				if ((rescode=getStrArgument(argc,argv,i,smallArcs,
											crit))!=0)
					return rescode;
				r.smallarcs = crit[0];
			}
			else if (cmdarg == Overview)
			{
				if((rescode=getStrArgument(argc,argv,i,Overview,r.overviewname))
						!=0)
					return rescode;
				r.overview = true;
			}
			else if (cmdarg == ErrGradMode)
				r.errmode_stddev=true;
			else if (cmdarg == ErrorGradationPhase)
			{
				real errgrd = numeric_limits<real>::quiet_NaN();
				if ((rescode=getRealArgument(argc,argv,i,ErrorGradationPhase,
											 errgrd))!=0)
					return rescode;
				r.phaseerrdivision.insert(errgrd);
			}
			else if (cmdarg == ErrorGradationRange)
			{
				real errgrd = numeric_limits<real>::quiet_NaN();
				if ((rescode=getRealArgument(argc,argv,i,ErrorGradationRange,
											 errgrd))!=0)
					return rescode;
				r.rangeerrdivision.insert(errgrd);
			}
			else if (cmdarg == ErrorGradationURRE)
			{
				real errgrd = numeric_limits<real>::quiet_NaN();
				if((rescode=getRealArgument(argc,argv,i,ErrorGradationURRE,
											errgrd))!=0)
					return rescode;
				r.urredivision.insert(errgrd);
			}
			else if (cmdarg == ErrorGradationURAE)
			{
				real errgrd = numeric_limits<real>::quiet_NaN();
				if((rescode=getRealArgument(argc,argv,i,ErrorGradationURAE,
											errgrd))!=0)
					return rescode;
				r.uraedivision.insert(errgrd);
			}
			else if (cmdarg == LoadDump)
				r.loaddump = true;
			else if (cmdarg == AdjustDump)
				r.adjdump = true;
			else if (cmdarg == SetSettings)
			{
				string group,module,key,val;
				if((rescode=getStrArgument(argc,argv,i,SetSettings,group))!=0)
					return rescode;
				if((rescode=getStrArgument(argc,argv,i,SetSettings,module))!=0)
					return rescode;
				if((rescode=getStrArgument(argc,argv,i,SetSettings,key))!=0)
					return rescode;
				if((rescode=getStrArgument(argc,argv,i,SetSettings,val))!=0)
					return rescode;
				r.settings[group][module][key] = val;
			}
			else if (cmdarg == ZenithLS)
			{
				if((rescode=getIntArgument(argc,argv,i,ZenithLS,
											r.maxzenith_ls))!=0)
					return rescode;
				if((rescode=getIntArgument(argc,argv,i,ZenithLS,
										   r.since_iter))!=0)
					return rescode;
			}
			else if (cmdarg == ZenithImit)
			{
				if((rescode=getIntArgument(argc,argv,i,ZenithImit,
											r.maxzenith_imit))!=0)
					return rescode;
				string stdr;
				if((rescode=getStrArgument(argc,argv,i,ZenithImit,stdr))!=0)
					return rescode;
				if (stdr=="Yes")
					r.still_draw = true;
				else if (stdr=="No")
					r.still_draw = false;
				else
				{
					cerr<<"После "<<ZenithImit<<" ожидалось (Число) (Yes|No)"
					   <<endl;
					return -1;
				}
			}
			else
			{
				cerr<<"Предупреждение: параметр командной строки не "
				   "распознан: "<<cmdarg<<endl;
			}
		}

		if (r.precsatclockimit == false)
			r.allowsatclockinterp = true;

		if ((r.precsatclockimit == false) || (r.usenavorbit==true))
		{
			if ((r.cframenames.size() == 0) && (r.rinexnames.size() > 0))
			{
				cerr<<"Выбрано вводить измерительные данные из RINEX-файла. В "
					  "этом случае невозможно прочитать оперативную информацию "
					  "из C-кадра"<<endl;
				return -21;
			}
		}

		//Проверить, нет ли нестыковок
		if ((r.rinexnames.size()>0) && (r.cframenames.size()>0))
		{
			cerr<<"Противоречивые настройки: указаны для обработки и C-кадры и "
				  "RINEX-файлы, что не поддерживается."<<endl;
			return -14;
		}
		if ((r.stexactcoord) && (r.sinexexact))
		{
			cerr<<"Противоречивые настройки: координаты БИС можно либо "
				  "уточнить, либо взять из SINEX-файла, либо задать через "
				  "командную строку, однако указано одновременно две опции"
			   <<endl;
			return -15;
		}
		if (!(r.phasetxt))
		{
			if (r.phasepng)
			{
				cerr<<"Противоречивые настройки: указано не создавать "
					"текстовых файлов невязок, но без них невозможно построить"
					  " графики невязок."<<endl;
				return -16;
			}
		}
		if (!(r.rangetxt))
		{
			if (r.rangepng)
			{
				cerr<<"Противоречивые настройки: указано не создавать текстовых"
				" файлов невязок, но без них невозможно построить графики "
					  "невязок."<<endl;
				return -17;
			}
		}
		if (!(r.urretxt))
		{
			if (r.urrepng)
			{
				cerr<<"Противоречивые настройки: указано не создавать текстовых"
				" файлов невязок, но без них невозможно построить графики "
					  "невязок."<<endl;
				return -17;
			}
		}
		if (!(r.uraetxt))
		{
			if (r.uraepng)
			{
				cerr<<"Противоречивые настройки: указано не создавать текстовых"
				" файлов невязок, но без них невозможно построить графики "
					  "невязок."<<endl;
				return -17;
			}
		}

		if ((r.satcount) &&
				((r.satcounttemplate.find("%SNN")!=string::npos)
				 ||(r.satcounttemplate.find("%N")==string::npos)))
		{
			cerr<<"Файл с графиком видимости НКА должен иметь имя, зависящее "
				  "от навигационной системы (использовать %N), но не от "
				  "номера НКА (нельзя использовать %SNN)"<<endl;
			return -18;
		}
		if ((r.phasetxt) && (r.phtxttempl.find("%SNN")==string::npos))
		{
			cerr<<"Текстовый файл с невязками моделирования фазы должен иметь "
				  "имя, зависящее от имени НКА (в шаблоне используйте %SNN)"
			   <<endl;
			return -19;
		}
		if ((r.rangetxt) && (r.rtxttempl.find("%SNN")==string::npos))
		{
			cerr<<"Текстовый файл с невязками моделирования псевдодальности "
				  "должен иметь имя, зависящее от имени НКА (в шаблоне "
				  "используйте %SNN)"<<endl;
			return -19;
		}
		if ((r.urretxt) && (r.urretmpl.find("%SNN")==string::npos))
		{
			cerr<<"Текстовый файл с невязками моделирования User Range Rate "
				  "должен иметь имя, зависящее от имени НКА (в шаблоне "
				  "используйте %SNN)"<<endl;
			return -19;
		}
		if ((r.uraetxt) && (r.uraetmpl.find("%SNN")==string::npos))
		{
			cerr<<"Текстовый файл с невязками моделирования User Range "
				  " Acceleration должен иметь имя, зависящее от имени НКА (в "
				  "шаблоне используйте %SNN)"<<endl;
			return -19;
		}

		//Если не заданы все необходимые параметры, открыть окно GUI
		if ((r.cframenames.size() == 0) && (r.rinexnames.size() == 0)
				&& (r.stage == 0))
		{
			cerr<<"Необходимо указать хотя бы один файл измерительных данных"
			   <<endl;
			result |= 1;
		}
		if (r.igsdir == "")
		{
			cerr<<"Необходимо указать директорию с продуктами IGS"<<endl;
			result |= 2;
		}
		if (r.clktemplate == "")
		{
			cerr<<"Необходимо указать шаблон имён Clock-файлов"<<endl;
			result |= 4;
		}
		if (r.sp3template == "")
		{
			cerr<<"Необходимо указать шаблон имён SP3-файлов"<<endl;
			result |= 8;
		}
		if ((r.usesinextropo) && (r.trotemplate == ""))
		{
			cerr<<"Чтобы взять параметры тропосферной задержки из "
				  <<"SINEX-Tropo-файлов, необходимо указать шаблон их имён."
				 <<endl;
			result |= 16;
		}
		if ((r.sinexexact) && (r.snxtemplate == ""))
		{
			cerr<<"Чтобы взять точные координаты БИС из SINEX-файлов, "
				  "необходимо "<<"указать шаблон их имён"<<endl;
			result |= 32;
		}
		if (r.finalsfile == "")
		{
			cerr<<"Необходимо указать имя файла с ПВЗ"<<endl;
			result |= 64;
		}
		if (r.outputdir == "")
		{
			cerr<<"Необходимо указать имя директории для вывода отчета"<<endl;
			result |= 128;
		}
		if (r.antex == "")
		{
			cerr<<"Необходимо указать имя ANTEX-файла"<<endl;
			result |= 256;
		}
		if ((r.cframenames.size()>0) && (r.stname == ""))
		{
			cerr<<"При работе с C-кадрами необходимо указать имя БИС"<<endl;
			result |= 512;
		}
	}

	//проверить существование выбранных файлов gnuplot
	ifstream gnuplotscript(r.pltvis.c_str());
	if (!(gnuplotscript.is_open()))
	{
		cerr<<"Файл скрипта gnuplot '"<<r.pltvis<<"'' не найден."<<endl;
		return -22;
	}
	gnuplotscript.close();
	gnuplotscript.open(r.pltres.c_str());
	if (!(gnuplotscript.is_open()))
	{
		cerr<<"Файл скрипта gnuplot '"<<r.pltvis<<"'' не найден."<<endl;
		return -22;
	}

	//Данные, которых может не хватать, но которые можно заполнить самим.
	if (r.mapfunc == "")
		r.mapfunc = "GMF";
	if (r.tromodel == "")
		r.tromodel = "DryAndWet";

	if (r.adj_satnames.size() == 0)
	{
		for (int i=1; i<=32; i++)
		{
			string sn = Variant(i).toString();
			if (i<10)
				sn = "0"+sn;
			if (i<=24)
				r.adj_satnames.push_back(string(1,'R')+sn);
			r.adj_satnames.push_back(string(1,'G')+sn);
		}
	}
	if (r.imit_satnames.size() == 0)
	{
		for (int i=1; i<=32; i++)
		{
			string sn = Variant(i).toString();
			if (i<10)
				sn = "0"+sn;
			if (i<=24)
				r.imit_satnames.push_back(string(1,'R')+sn);
			r.imit_satnames.push_back(string(1,'G')+sn);
		}
	}

	//Дополнить таблицу настроек
	r.settings["Delay_models"]["Tropospheric_delay"]["Model"]=r.tromodel;
	r.settings["Delay_models"]["Tropospheric_delay"]["tropo_mf"]=r.mapfunc;
	if (r.tropogradient == false)
		r.settings["Delay_models"]["Tropospheric_delay"]["tropo_gradients"]
				="No";
	real tropodens = 1/r.tropostep;
	r.settings["Parameters_settings"]["troposphere"]["Sampling_density"]=
			Variant(tropodens).toString();
	if (!(isnan(r.stcrdstep)))
	{
		real stcrddens = 1/r.stcrdstep;
		r.settings["Parameters_settings"]["marker_position"]["Sampling_density"]
				=Variant(stcrddens).toString();
	}
	if (r.cframenames.size()>0)
	{
		if(r.settings["Obsevables"]["Editor"]["GFNumOfPoints"] == "")
			r.settings["Obsevables"]["Editor"]["GFNumOfPoints"]="60";
		if(r.settings["Obsevables"]["Editor"]["GFOrder"] == "")
			r.settings["Obsevables"]["Editor"]["GFOrder"]="3";
	}

	return result;

}

string PPPOptions::getSettingsTable() const
{
	string result;
	for (map<string,map<string,map<string,string> > >::const_iterator
		 it = settings.begin(); it!=settings.end(); ++it)
		for (map<string,map<string,string> >::const_iterator
			 it1=it->second.begin(); it1!=it->second.end(); ++it1)
			for (map<string,string>::const_iterator
				 it2 = it1->second.begin(); it2!=it1->second.end(); ++it2)
				result+=("settings\t"+it->first+"\t"+it1->first+"\t"
						 +it2->first+"\t"+it2->second+"\n");
	return result;
}

#include <QMutex>
#include <pppmultithread.h>
#include <outputviewer.h>
#include <QMessageBox>
#include <QApplication>
#include <pppoptions.h>



PPPThread::PPPThread(const QString & command, const QStringList & arglist,
					 QMutex * lockidxlist, QVector<int> * idxlist,
					 OutputViewer  * parent)
	: QObject(parent)
{
	myview = parent;
	curidx = -1;
	cmd = command;
	args = arglist;
	locker = lockidxlist;
	idx = idxlist;
	dobrief = false;
}

void PPPThread::startNewJob()
{
	if (dobrief == true)
	{
		finishedRunning();
		return;
	}

	QStringList newargs = args;
	locker->lock();
//	cout<<"Запрос задачи из портфеля..."<<endl;
	if ((curidx >= 0) && (curidx < idx->size()))
		(*idx)[curidx] = 2;
	bool alldone = true;
	curidx = -1;
	for (int i=0; i<idx->size(); i++)
	{
		if (idx->at(i) != 2)
			alldone = false;
		if (idx->at(i) == 0)
		{
			curidx = i;
			(*idx)[i] = 1;
			break;
		}
	}
	if( alldone)
	{
		//Данный процесс будет делать краткий отчет
		for (unsigned int i=0; i<idx->size(); i++)
			(*idx)[i] = 3;
		dobrief = true;
		curidx = idx->size();
	}
	locker->unlock();
	if ((curidx == -1) && (alldone == false))
	{
		deleteLater();
		return;
	}
	newargs<<QString::fromStdString(FileIDX)<<QString::number(curidx);
	myview->startCMD(cmd,newargs);
}

PPPMultithread::PPPMultithread(const QStringList & l, int filescount,
							   int nthreads)
	:QTabWidget(0)
{
	setAttribute(Qt::WA_DeleteOnClose);
	isRunning = true;
	blocker = new QMutex;
	idxlist.resize(filescount);
	this->setWindowTitle(QString::fromUtf8("Многопоточная обработка"));
	QString execname=qApp->arguments()[0];
	for (unsigned int i=0; i<nthreads; i++)
	{
		OutputViewer * nv = new OutputViewer("cmd",false);
		v.push_back(nv);
		PPPThread * nt = new PPPThread(execname,l,blocker,&idxlist,nv);
		threads.push_back(nt);
		addTab(nv,QString::fromUtf8("Поток №")+QString::number(i));
		connect (nv,SIGNAL(CMDfinish()), nt, SLOT(startNewJob()));
		connect(nt,SIGNAL(finishedRunning()), this, SLOT(finishedRunning()));
		nt->startNewJob();
	}
	setMinimumHeight(550);
	setMinimumWidth(700);
}


void PPPMultithread::closeEvent ( QCloseEvent * event )
{
	if (isRunning)
	{
		if (QMessageBox::question(this,QString::fromUtf8("Подтверждение"),
				QString::fromUtf8("Программа ещё выполняется. Прервать её?"),
					QMessageBox::Yes, QMessageBox::No) == QMessageBox::No)
		{
			event->ignore();
			return;
		}
		for (unsigned int i=0; i<threads.size(); i++)
		{
			disconnect(v[i],SIGNAL(CMDfinish()),threads[i],SLOT(startNewJob()));
			v[i]->killApp();
		}
	}
	closeWnd();
	event->accept();
}

void PPPMultithread::finishedRunning()
{
	QMessageBox::information(0,QString::fromUtf8("Многопоточная обработка"),
		QString::fromUtf8("Процесс обработки завершен. Теперь все окна "
						  "процессов можно закрыть."));
	isRunning = false;
}

PPPMultithread::~PPPMultithread()
{
	for (unsigned int i=0; i<v.size(); i++)
	{
		delete v[i];
		//delete threads[i];
	}
}

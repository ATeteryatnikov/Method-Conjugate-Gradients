#include <cstdio>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <dirent.h>
#include <algorithm>
#include <igstempledit.h>
#ifdef Win32
#include <io.h>
#else
#include <sys/stat.h>
#endif

using namespace std;
using namespace libgnss;

#include <readleapseconds.h>
#include <StdTables.h>
#include <ppp.h>
#include <testcommon.h>
#include <DBTableCollection.h>
#include <readAntEx.h>
#include <PhaseCentre.h>
#include <readrinex21obs.h>
#include <sinex.h>
#include <RINEXClock.h>
#include <Pseudorange.h>
#include <StdTables.h>
#include <ERPStorage.h>
#include <ParamTrajectory.h>
#include <sp3.h>
#include <finals2000A.h>
#include <Troposphere.h>
#include <dcb.h>
#include <YawAttitude.h>
#include <Frames.h>
#include <sparsematrix.hpp>
#include <preprocess.h>
#include <readcframe.h>
#include <testcommon.h>
#include <pppimitator.h>
#include<ppppostprocess.h>
#include <base64.hpp>


Settings::Enumerator obssrcid_s("temporary","ppp","obs_src_id",
								Variant::TYPE_INT,
								"Идентификатор БИС",0);

vector<string> stationsList(const DBTableCollection * base)
{
	DBTable * obs = base->getTable("observables");
	DBTable * obssrc = base->getTable("observation_source");
	DBTable * markers = base->getTable("markers");
	vector<string> result;
	set<string> checkresult;
	for (DBTable::DBConstIterator it = obs->const_begin();
		 it!=obs->const_end(); it.inc(0))
	{
		int obs_src_id = it.keyColumnValue(0).toInt();
		int marker_id = obssrc->read(obs_src_id)[0].toInt();
		string markername = markers->read(marker_id)[0].toString();
		if (checkresult.find(markername) == checkresult.end())
		{
			result.push_back(markername);
			checkresult.insert(markername);
		}
	}
	return result;
}

vector<string> satnamelist(char navsys)
{
	if ((navsys!='R') && (navsys!='G'))
		return vector<string>();

	vector<string> result;
	for (unsigned int i=1; i<=32; i++)
	{
		if ((navsys == 'R') && (i > 24))
			break;
		string satname = Variant((int)i).toString();
		if (satname.size() == 1)
			satname = "0"+satname;
		satname = string(1,navsys)+satname;
		result.push_back(satname);
	}
	return result;
}

vector<string> filenamesList(const string & fntemplate,
							 real t0, real t1,
							 const vector<string> & stationsList,
							 char navsys, FileNamesListSortOrder sortorder,
							 vector<string> *nonexisting)
{
	vector<string> * nonexisting_ = 0;
	set<string> checkresult; //Для проверки повторений
	map<int,string> result_; //Дерево сортировки имен файлов

	//Определить отсортированный список БИС
	vector<string> sortedstlist = stationsList;
	if (sortedstlist.size() == 0)
		sortedstlist.push_back("%MRKN"); //Список пустой -- не заменять имя БИС
	sort(sortedstlist.begin(), sortedstlist.end());
	int stcount = stationsList.size();

	//Определить отсортированный список НКА
	vector<string> satlist;
	if (navsys == '0')
		satlist.push_back("%SNN");
	else if (navsys == 'A')
	{
		vector<string> GLOsats = satnamelist('R');
		vector<string> GPSsats = satnamelist('G');
		satlist.insert(satlist.end(),GLOsats.begin(), GLOsats.end());
		satlist.insert(satlist.end(),GPSsats.begin(), GPSsats.end());
	}
	else
		satlist = satnamelist(navsys);
	int satcount = satlist.size();

	//Вычислить неделю GPS начала и конца
	int weekt0, dayt0; real fract0;
	int weekt1, dayt1; real fract1;
	UTCDateTime::fromTAIJ2000(t0).getGPSWeekDayFrac(weekt0,dayt0,fract0);
	UTCDateTime::fromTAIJ2000(t1).getGPSWeekDayFrac(weekt1,dayt1,fract1);
	int daysor0 = weekt0*7 + dayt0;
	int daysor1 = weekt1*7 + dayt1;
	int dayscount = daysor1-daysor0+1;
	for (unsigned int i=daysor0; i<=daysor1; i++)
	{
		int dayt = i % 7;
		int weekt = (i - dayt)/7;
		for (unsigned int ns=0; ns<2; ns++)
		{
			for (unsigned int st =0; st<stcount; st++)
			{
				for (unsigned int sat=0; sat<satcount; sat++)
				{

					int code;
					int day = i-daysor0;
					if (sortorder == FNSO_NavSysStationTime)
						code = day + st * dayscount + ns * dayscount * stcount;
					else if (sortorder == FNSO_NavSysTimeStation)
						code = st + stcount * day + ns * stcount * dayscount;
					else if (sortorder == FNSO_StationNavSysTime)
						code = day + ns * day + st * 2 * dayscount;
					else if (sortorder == FNSO_StationTimeNavSys)
						code = ns + 2 * day + st * 2 * dayscount;
					else if (sortorder == FNSO_TimeNavSysStation)
						code = st + stcount * ns + day * 2 * stcount;
					else if (sortorder == FNSO_TimeStationNavSys)
						code = ns + 2 * st + day * 2 * stcount;

					code = sat + satcount * code;
					string filename =  IGSfilenameFromTemplate(fntemplate,
															   sortedstlist[st],
															   satlist[sat],
															   weekt,dayt,0.0l);
					if (checkresult.find(filename) == checkresult.end())
					{
						checkresult.insert(filename);
						result_[code] = filename;
					}
				}
			}
		}
	}
	vector<string> result;
	for (map<int,string>::iterator it = result_.begin();
		 it!=result_.end(); ++it)
	{
		ifstream check(it->second.c_str());
		if (check.is_open())
			result.push_back(it->second);
		else
		{
			if (nonexisting!=0)
				nonexisting->push_back(it->second);
		}
	}
	return result;
}


/**
 * @brief Структура объекта, выполняющего анализ невязок для одного файла
 */
struct PPP
{
	//int obs_src_id; //Идентификатор БИС в случае приёмника МРК
//	set<int> adj_sat_ids; //Идентификаторы НКА, участвующих в МНК
//	set<int> imit_sat_ids; //Идентификаторы НКА, участвующих в МНК
	PPPOptions options;
	DBTableCollection * datacollection;
	Settings * sets;
	LeapSeconds * leaps;
	SatelliteHistory * history;
	AntennaModels * antmods;
	ReceivingAntennas * recants;
	ReceivingAntennaPhaseCentreModels * recphc;
	SVAntennas * svants;
	Frames * frames;
	CoordinateTypes * ctypes;
	PhaseCentreOffsetFrequency * pcofreq;
	PhaseCentreVariationGrid * pcgrid;
	SVPhaseCentreModels * svphc;
	Markers * markers;
	Receivers * recievers;
	ObservableTypes * obstypes;
	ObservationSource * obssrc;
	Observables * obs;
	NavigationSystem * sys;
	GLONASSFrequencySlots * gfs;
	ERPStorage * erp;
	ParamTrajectory * traj;
	MarkerEccentricity * ecc;
	MarkerPosition * mpos;
	ITRFTranslation * itrftr;
	ClockBias * tshift;
	ParamTroposphere * atm;
	ParamDCB * dcb;
	DBTable * paramslist;
	ParamPhaseAmbiguity * phsambig;
	DBTable * intervals; //Интервалы непрерывности фазы
	int fileid;
	string currentfile;

	class MyAntExReader : public AntExReader
	{
	public:
		virtual void unsupportedFrequency(const string &freq)
		{
			cerr<<"Частота в ANTEX-файле не соответствует стандарту ANTEX: "
			   <<freq<<endl;
		}

		virtual int insertNewGrid(const
				vector < pair < real, vector < pair < real, real > > > > & grid)
		{
			return -1;
		}

	};

	/**
	 * Цель перегрузки - вычислять норму правой части матрицы и сохранять
	 * матрицу и правую часть системы в файл.
	 */
	class MyObservablesLeastSquaresProblem:public ObservablesLeastSquaresProblem
	{
	private:
		real * myrhsnorm;
		string outputdirectory;
		string curfilename;
		int iteration;
	protected:
		virtual void processReadyMatrix(RowWiseSparseMatrix <real> & lhs,
										vector<real> & rhs,
										const vector<Tuple> *rowidx)
		{
			if (this->getParametersSet().find("troposphere")
					!=this->getParametersSet().end())
				regulariseTroposphereParameters(*this, lhs,rhs);
			//Посчитать норму правой части
			*myrhsnorm = 0;
			for (unsigned int i=0; i<rhs.size(); i++)
				*myrhsnorm += (rhs[i] * rhs[i]);
			*myrhsnorm = sqrt(*myrhsnorm);

			//Вывести матрицу и правую часть в файлы
			vector<string> fileparts = split(curfilename,'/');
			string dirname = outputdirectory;
			checkDirectoryExists(dirname);
			string curmatrixfilename = dirname + "/matrix."+
					Variant(iteration).toString()+ ".txt";
			ofstream m(curmatrixfilename.c_str());
			m.precision(20);
			for (unsigned int i=0; i<lhs.size(); i++)
			{
				for (unsigned int j=0; j<lhs[i].size(); j++)
					m<<"("<<lhs[i][j].first<<","<<lhs[i][j].second<<")";
				m<<"(RHS,"<<rhs[i]<<")"<<endl;
			}
			m.close();
		}

		virtual void processSolution(const RowWiseSparseMatrix < real > & lhs,
									 const vector<real> & rhs,
									 vector<real> & solution)
		{
			string cursolutionfilename = outputdirectory + "/solution."+
					Variant(iteration).toString()+ ".txt";
			ofstream soltxt(cursolutionfilename.c_str());
			soltxt.precision(20);
			for (set<string>::iterator it1 = getParametersSet().begin();
				 it1!=getParametersSet().end(); ++it1)
			{
				string paramname = *it1;
				DBTable * tbl = getBase()->getTable(paramname);
				for (DBTable::DBConstIterator it2 =
					getColumnsIndex(paramname)->const_begin();
					!(it2.isEnd()); ++it2)
					soltxt<<paramname<<'\t'
					<<tbl->tuplePrettyPrint(it2.subkey(),Tuple())
					<<"\tDelta="<<solution[it2[0].toInt()]<<endl;
			}
			soltxt.close();
		}

	public:
		MyObservablesLeastSquaresProblem(DBTableCollection * tcol,
										 string outputdir,
										 string curobsfile,
										 real * normaddress)
			: ObservablesLeastSquaresProblem(tcol)
		{
			myrhsnorm = normaddress;
			outputdirectory = outputdir;
			curfilename = curobsfile;
		}

		void setIterationNumber(int i)
		{
			iteration = i;
		}
	};

	class MyCFrameParser : public CFramesParser
	{
	private:
		ExceptionsLog l;
	public:
		virtual void loadObservables(tblObs_t *obs, tblHdr_t *hdr,
							 tblAddInf_t *add, tblOprGlo_t *oprglo)
		{
			try
			{
				CFramesParser::loadObservables(obs,hdr,add,oprglo);
			}
			catch (const StrException & e)
			{
				l.logException(e);
			}
		}

		void printExceptionLog(ostream & s)
		{
			l.outputLog(s);
		}

		MyCFrameParser(ObservablesLoader * gloobsparser,
					  ObservablesLoader * gpsobsparser,
					  GLONASSNavDataLoader * glonavdataparser,
					  CFrameGPSNavDataParser * gpsnavdataparser,
					  MeteoDataLoader * meteoldr)
			: CFramesParser(gloobsparser,gpsobsparser,glonavdataparser,
							gpsnavdataparser,meteoldr)
		{

		}

	};

	string getOutputDirectory(const string & initial, string & fname,
							  int fileid, int filescount)
	{
		if (filescount == 1)
			return initial;
		for (unsigned int i=0; i<fname.size(); i++)
			if (fname[i] == '\\')
				fname[i] = '/';
		vector<string> fileparts = split(fname,'/');
		string dirname = initial+"/"
				+fileparts[fileparts.size()-1]
				+"_file"+Variant(fileid).toString();
		checkDirectoryExists(dirname);
		return dirname;
	}

//	MyObservablesLeastSquaresProblem * ls;

	PPP(const PPPOptions & opts, int fileid)
	{
		this->fileid = fileid;
		options = opts;
		datacollection = new DBTableCollection ();
		sets = new Settings(datacollection);
		leaps = new LeapSeconds(datacollection);
		history = new SatelliteHistory(datacollection);
		antmods = new AntennaModels(datacollection);
		recants = new ReceivingAntennas(datacollection);
		recphc = new ReceivingAntennaPhaseCentreModels(datacollection);
		svants = new SVAntennas(datacollection);
		frames = new Frames(datacollection);
		ctypes = new CoordinateTypes(datacollection);
		pcofreq = new PhaseCentreOffsetFrequency(datacollection);
		pcgrid = new PhaseCentreVariationGrid(datacollection);
		svphc = new SVPhaseCentreModels(datacollection);
		markers = new Markers(datacollection);
		recievers = new Receivers(datacollection);
		obstypes = new ObservableTypes(datacollection);
		obssrc = new ObservationSource(datacollection);
		obs = new Observables(datacollection);
		sys = new NavigationSystem(datacollection);
		gfs = new GLONASSFrequencySlots(datacollection);
		erp = new ERPStorage(datacollection);
		traj = new ParamTrajectory(datacollection);
		ecc = new MarkerEccentricity(datacollection);
		mpos = new MarkerPosition(datacollection);
		itrftr = new ITRFTranslation(datacollection);
		tshift = new ClockBias(datacollection);
		atm = new ParamTroposphere(datacollection);
		dcb = new ParamDCB(datacollection);
		phsambig = new ParamPhaseAmbiguity(datacollection);
		paramslist = new DBTable(Columns()
								 <<Column(Variant::TYPE_STRING, "param_name"),
								 Columns());
		intervals = new DBTable(Columns()
								<<Column(Variant::TYPE_INT, "obs_src_id")
								<<Column(Variant::TYPE_INT, "sat_history_id")
								<<Column(Variant::TYPE_DOUBLE, "begin"),
								Columns()
								<<Column(Variant::TYPE_DOUBLE, "end")
								<<Column(Variant::TYPE_INT, "status"));
		datacollection->addTable("continuity_intervals",intervals);
		datacollection->addTable("adjustable_parameters", paramslist);
		//Имя загружаемого файла
		if (options.cframenames.size()+options.rinexnames.size()>fileid)
		{
			if (options.cframenames.size()>0)
				currentfile = options.cframenames[fileid];
			else
				currentfile = options.rinexnames[fileid];
			//Заменить все обратные косые на прямые (как в unix)
			for (unsigned int i=0; i<currentfile.size(); i++)
				if (currentfile[i] == '\\')
					currentfile[i] = '/';
			//Если несколько файлов, писать результат каждого файла в отдельный
			//каталог.
			options.outputdir = getOutputDirectory(options.outputdir,
					currentfile, fileid, options.rinexnames.size()
												   +options.cframenames.size());
		}
	}

	~PPP()
	{
		delete intervals;
		delete phsambig;
		delete dcb;
		delete atm;
		delete tshift;
		delete itrftr;
		delete mpos;
		delete ecc;
		delete traj;
		delete erp;
		delete gfs;
		delete sys;
		delete obs;
		delete obssrc;
		delete obstypes;
		delete recievers;
		delete markers;
		delete svphc;
		delete pcgrid;
		delete pcofreq;
		delete ctypes;
		delete frames;
		delete svants;
		delete recphc;
		delete recants;
		delete antmods;
		delete history;
		delete leaps;
		delete sets;
		delete datacollection;
	}

	void loadReferenceTables()
	{
		try
		{
			ifstream leapsecs("leap_seconds.dates");
			if (leapsecs.is_open() == false)
				throw FileNotFoundException("leap_seconds.dates");
			readLeapSeconds(*leaps,leapsecs);
			leapsecs.close();
			datacollection->readFromFile("coordinates.tc");

			//Файл слотов ГЛОНАСС необходим только при обработке RINEX-
			//файлов; для C-кадров он не является необходимым (хотя полезен)
			try
			{
				datacollection->readFromFile("glonass_frequency_slots.tc");
			}
			catch (const FileNotFoundException & e)
			{
				if (options.rinexnames.size() > 0)
					throw e;
			}

			istringstream navsystems(
							"navigation_systems	G	GPS	USDoD\n"
							"navigation_systems	R	ГЛОНАСС	РосКосмос\n");
			datacollection->readFromStream(navsystems,cout);
		}
		catch (...)
		{
			string errmsg="В текущей директории не найдены файлы справочников: "
				"\nleap_seconds.dates\ncoordinates.tc\n"
				"Убедитесь, что Вы запускаете программу из папки дистрибутива.";
			throw StrException("ppp", errmsg);
		}
	}

	void loadANTEX()
	{
		ifstream atx(options.antex.c_str());
		if (atx.is_open())
		{
			MyAntExReader().read(*datacollection, atx);
			//datacollection->readFromStream(atx,cout);
			atx.close();
		}
		else
			throw FileNotFoundException(options.antex);
//		//Создание списка НКА для МНК
//		set<string> adj_satlist_set;
//		for (int i=0; i<options.adj_satnames.size(); i++)
//			adj_satlist_set.insert(options.adj_satnames[i]);
//		for (DBTable::DBConstIterator it = history->const_begin();
//			 it!=history->const_end(); ++it)
//		{
//			int sat_history_id = it.keyColumnValue(0).toInt();
//			string satname = history->getShortSatName(sat_history_id);
//			if (adj_satlist_set.find(satname)!=adj_satlist_set.end())
//				adj_sat_ids.insert(sat_history_id);
//		}
//		//Создание списка НКА для имитации
//		set<string> imit_satlist_set;
//		for (int i=0; i<options.imit_satnames.size(); i++)
//			imit_satlist_set.insert(options.imit_satnames[i]);
//		for (DBTable::DBConstIterator it = history->const_begin();
//			 it!=history->const_end(); ++it)
//		{
//			int sat_history_id = it.keyColumnValue(0).toInt();
//			string satname = history->getShortSatName(sat_history_id);
//			if (imit_satlist_set.find(satname)!=imit_satlist_set.end())
//				imit_sat_ids.insert(sat_history_id);
//		}

	}

	void loadSettings()
	{
		istringstream settingstable(options.getSettingsTable());
		cout<<"Настройки сгенерированы. Сохранение в файл..."<<endl;
		datacollection->readFromStream(settingstable,cout);
		string setdumpfn = options.outputdir+"/settingsloaded.tc";
		ofstream dumpfile(setdumpfn.c_str());
		datacollection->dump(dumpfile);
		dumpfile.close();
		cout<<"Сохранение параметров командной строки..."<<endl;
		string savecmdlinename = options.outputdir+"/cmdline.txt";
		ofstream savecmdline(savecmdlinename.c_str());
		savecmdline<<options.cmdline<<endl;
		savecmdline.close();
	}

	void loadReceiverInfo()
	{
		string stationname = options.stname;
		int recantmod = antmods->insertRow(Tuple()<<stationname<<1
										  <<"Антенна приёмника МРК");
		int recant_id = recants->insertRow(Tuple()<<stationname
										  <<"Антенна приёмника МРК"
									   <<recantmod);

		kinematic < real, 3, defaultNonInert > approxpos_geoc;
		kinematic < real, 3, defaultGeodetic > approxpos_geod;

		//Взять либо нули, либо записать данные из опций
		kinematic < real, 3, defaultNonInert > approxpos_geoc_;
		approxpos_geoc_[0] = options.st_x;
		approxpos_geoc_[1] = options.st_y;
		approxpos_geoc_[2] = options.st_z;
		if (!(isnan(approxpos_geoc_.length<0,2>())))
		{
			int srccrdframe = frames->getCoordinateFrameID(options.crdframe);
			if (srccrdframe == 0xffffffff)
				throw StrException("PPP", "Система координат "+
								   options.crdframe+" не определена.");

			approxpos_geoc = itrftr->translateITRF(approxpos_geoc_,srccrdframe,
								  frames->defaultNonInertFrame(),
									UTCDateTime::now().getTAIJ2000());
			approxpos_geod = geocentricToGeodetic(approxpos_geoc);
		}

		int marker_id = markers->insertRow(
					Tuple()<<stationname<<"МРК"<<"Маркер приёмника МРК"
					<<Markers::MT_GEODETIC<<approxpos_geoc[0]<<approxpos_geoc[1]
					<<approxpos_geoc[2]<<approxpos_geod[0]<<approxpos_geod[1]
					<<approxpos_geod[2]);

		int receiver_id = recievers->insertRow(Tuple()<<stationname
											<<"Приёмник МРК"<<"МРК");

		int obs_src_id = obssrc->insertRow(Tuple()<<marker_id<<receiver_id
										  <<recant_id);
		Tuple obsidkey;
		obsidkey<<"temporary"<<"ppp"<<"obs_src_id";
		if (sets->find(obsidkey).isEnd())
			sets->insertRow(Tuple()<<"temporary"<<"ppp"<<"obs_src_id",
							Tuple()<<obs_src_id);
		else
			sets->updateCell(obsidkey,0,obs_src_id);

		//Добавить информацию о смещении фазового центра ARP-APC
		DBTable::DBConstIterator itpcfr = pcofreq->const_end();
		itpcfr--;
		int phase_centre_model_id = itpcfr.keyColumnValue(0).toInt()+1;
		int freql1g = obstypes->getFrequencyFromAntex("G01");
		int freql2g = obstypes->getFrequencyFromAntex("G02");
		int freql1r = obstypes->getFrequencyFromAntex("R01");
		int freql2r = obstypes->getFrequencyFromAntex("R02");

		pcofreq->insertRow(Tuple()<<phase_centre_model_id<<freql1g,
						  Tuple()
						  <<real(0) //North
						  <<real(0) //East
						  <<real(0) //Up
						  <<-1 //Сетка поправок не используется
						  );
		pcofreq->insertRow(Tuple()<<phase_centre_model_id<<freql2g,
						  Tuple()
						  <<real(0) //North
						  <<real(0) //East
						  <<real(0) //Up
						  <<-1 //Сетка поправок не используется
						  );
		pcofreq->insertRow(Tuple()<<phase_centre_model_id<<freql1r,
						  Tuple()
						  <<real(0) //North
						  <<real(0) //East
						  <<real(0) //Up
						  <<-1 //Сетка поправок не используется
						  );
		pcofreq->insertRow(Tuple()<<phase_centre_model_id<<freql2r,
						  Tuple()
						  <<real(0) //North
						  <<real(0) //East
						  <<real(0) //Up
						  <<-1 //Сетка поправок не используется
						  );

		recphc->insertRow(Tuple()<<recantmod<<recant_id<<-real(1e50),
						 Tuple()<<phase_centre_model_id<<real(1e50));
	}

	void loadObservables()
	{
		//Создание списка НКА для МНК
		set<int> adj_sat_ids; //Идентификаторы НКА, участвующих в МНК
		set<string> adj_satlist_set;
		for (int i=0; i<options.adj_satnames.size(); i++)
			adj_satlist_set.insert(options.adj_satnames[i]);
		for (DBTable::DBConstIterator it = history->const_begin();
			 it!=history->const_end(); ++it)
		{
			int sat_history_id = it.keyColumnValue(0).toInt();
			string satname = history->getShortSatName(sat_history_id);
			if (adj_satlist_set.find(satname)!=adj_satlist_set.end())
				adj_sat_ids.insert(sat_history_id);
		}

		int obs_src_id =
				sets->getSettings("temporary","ppp","obs_src_id").toInt();


		PPPObservablesParser myparser(
					datacollection,obs_src_id,options.igsdir+"/"
					+options.clktemplate, options.glophase,options.glorange,
					options.gpsphase,options.gpsrange,
					options.strinexclock,adj_sat_ids,intervals,
					options.smallarcs,(options.rinexnames.size()>0)?2:3);

		if (options.cframenames.size()>0)
		{
			cout<<"Чтение и предобработка C-кадров из файла "<<currentfile
				  <<endl;
			MyCFrameParser p(myparser.GLONASSParser(),
							 myparser.GPSParser(),
							 0,0,0);
			p.read(currentfile);
			string readcframelog_fn = options.outputdir + "/read_cframe.log";
			ofstream readcframelog(readcframelog_fn.c_str());
			p.printExceptionLog(readcframelog);
			readcframelog.close();
		}
		else
		{
			cout<<"Чтение и предобработка RINEX-файла "<<currentfile<<endl;
			map<char,ObservablesLoader*> ldrs;
			ldrs['G'] = myparser.GPSParser();
			ldrs['R'] = myparser.GLONASSParser();
			ifstream ldrinex(currentfile.c_str());
			if (!(ldrinex.is_open()))
				throw FileNotFoundException(currentfile);
			parseRINEXObsData(ldrs,NavSys_GPS | NavSys_GLONASS
							  | ObsFreq_L1 | ObsFreq_L2
							  | ObsType_Phase|ObsType_StdPseudorange
							  | ObsType_HighPrecPseudorange, ldrinex);
			ldrinex.close();
		}

		cout<<"Измерительные данные загружены. Отобрано "<<obs->count()
			  <<" измерений."<<endl;

		//Забрать "застрявшие" измерения
		myparser.GLONASSParser()->finish();
		myparser.GPSParser()->finish();

		cout<<"Удаление линейной части задержки сигнала в ионосфере..."<<endl;
		obs->deleteIonosphere(
					'R',OperatorPushableVector<string>()
					<<myparser.GLONASSParser()->getL1Denotement()
					<<myparser.GLONASSParser()->getL2Denotement(), "L12");
		obs->deleteIonosphere(
					'R',OperatorPushableVector<string>()
					<<myparser.GLONASSParser()->getR1Denotement()
					<<myparser.GLONASSParser()->getR2Denotement(), "P12");
		obs->deleteIonosphere(
					'G',OperatorPushableVector<string>()
					<<myparser.GPSParser()->getL1Denotement()
					<<myparser.GPSParser()->getL2Denotement(), "L12");
		obs->deleteIonosphere(
					'G',OperatorPushableVector<string>()
					<<myparser.GPSParser()->getR1Denotement()
					<<myparser.GPSParser()->getR2Denotement(), "P12");

		cout<<"Осталось "<<obs->count()
			  <<" измерений."<<endl;

//		string dumpintname = options.outputdir+"/intervals.tc";
//		ofstream dumpintervals(dumpintname.c_str());
//		if (dumpintervals.is_open()==false)
//		{
//			cerr<<"Не удалось записать таблицу интервалов видимости НКА"<<endl;

//		}
//		else
//		{
//			intervals->dump(dumpintervals,"intervals");
//			dumpintervals.close();
//		}
	}

	void loadMiscProducts()
	{
		vector<string> stlist = stationsList(datacollection);
		real T0 = obs->getMinTime(), T1 = obs->getMaximalTime();
		vector<string> nonexistsp3;
		vector<string> sp3files = filenamesList(options.igsdir + "/" +
					options.sp3template,T0,T1,stlist,'A',FNSO_NavSysStationTime,
					&nonexistsp3);

		vector<string> nonexistsnx;
		vector<string> sinexfiles;
		if (options.sinexexact)
			sinexfiles = filenamesList(options.igsdir+"/"+
									   options.snxtemplate,T0,T1,stlist,'A',
									   FNSO_NavSysStationTime, &nonexistsnx);

		vector<string> nonexisttro;
		vector<string> trofiles;
		if (options.usesinextropo)
			trofiles = filenamesList(options.igsdir+"/"+
									 options.trotemplate,T0,T1,stlist,'A',
									 FNSO_NavSysStationTime, &nonexisttro);

		vector<string> nonexist;
		nonexist.insert(nonexist.end(),nonexistsp3.begin(),nonexistsp3.end());
		nonexist.insert(nonexist.end(),nonexistsnx.begin(),nonexistsnx.end());
		nonexist.insert(nonexist.end(),nonexisttro.begin(),nonexisttro.end());

		if (nonexist.size() > 0)
		{
			cout<<"Не найдены следующие файлы:"<<endl;
			for (unsigned int i=0; i<nonexist.size(); i++)
				cout<<nonexist[i]<<endl;
			cout<<"Измерительные данные в соответствующие моменты времени "
			   "будут отброшены."<<endl;
		}

		//Список файлов составлен и проверен, загрузить их
		for (unsigned int i=0; i<sp3files.size(); i++)
		{
			ifstream cursp3(sp3files[i].c_str());
			try
			{
				readSP3(*datacollection,cursp3);
			}
			catch (const StrException & e)
			{
				cerr<<"Ошибка чтения файла "<<sp3files[i]<<". Измерительные "
					  "данные за соответствующий период времени невозможно "
					  "будет моделировать. "<<e.what()<<endl;
			}
			cursp3.close();
		}
		for (unsigned int i=0; i<sinexfiles.size(); i++)
		{

			ifstream cursnx(sinexfiles[i].c_str());
			try
			{
				readSINEX(datacollection,cursnx);
			}
			catch (const StrException & e)
			{
				cerr<<"Ошибка чтения файла "<<sinexfiles[i]<<". Положение БИС "
					 "в соответствующие моменты времени будут интерполирвоаны. "
				   <<e.what()<<endl;
			}
			cursnx.close();
		}
		for (unsigned int i=0; i<trofiles.size(); i++)
		{
			ifstream curtro(trofiles[i].c_str());
			try
			{
				readTropoSINEX(datacollection,curtro);
			}
			catch (const StrException & e)
			{
				cerr<<"Ошибка чтения файла "<<trofiles[i]<<". Параметры "
					  "тропосферы в соответствующие моменты времени будут "
					  "недоступны. "<<e.what()<<endl;
			}
			curtro.close();
		}

		cout<<"Чтение ПВЗ"<<endl;
		ifstream finalsfile(options.finalsfile.c_str());
		if (finalsfile.is_open())
		{
			try
			{
				readFinals2000A(datacollection,finalsfile);
			}
			catch (const StrException & e)
			{
				cerr<<"Ошибка чтения файла ПВЗ: "<<options.finalsfile<<". "
					<<"ПВЗ будет недоступно на моменты времени после "
					<<"возникновения ошибки, что приведёт к погрешности в"
					<<" ориентации НКА"<<endl;
			}

			finalsfile.close();
		}
		else
			throw FileNotFoundException(options.finalsfile);

		traj->toInertial();
		cout<<"Вычисление скоростей НКА..."<<endl;
		traj->calcVelocity();
		cout<<"Вычисление ориентации НКА..."<<endl;
		calcOrientation(*datacollection,false); //Вычислять ту ориентацию,
												//которую сможем.
		cout<<"Генерация поправок к положению фазовых центров "
		   <<"для ионосферно-свободных комбинаций измерений..."<<endl;
		ionFreePhaseCentre(datacollection);

	}

	void zeroEccentricity()
	{
		for (DBTable::DBConstIterator it = obs->const_begin();
			 it!=obs->const_end(); it.inc(0))
		{
			int obs_src_id = it.keyColumnValue(0).toInt();
			int marker_id = obssrc->read(obs_src_id)[0].toInt();
			ecc->insertRow(Tuple()<<marker_id<<-real(1e50),
						  Tuple()<<0<<real(0)<<real(0)<<real(0)<<real(1e50));
		}
	}

	void loadData()
	{
		clock_t t0 = clock();
		cout<<"Чтение справочных таблиц..."<<endl;
		loadReferenceTables();
		cout<<"Заняло: "<< ((double)(clock()-t0))/CLOCKS_PER_SEC <<endl;
		t0 = clock();


		cout<<"Генерация таблицы настроек..."<<endl;
		loadSettings();
		cout<<"Заняло: "<< ((double)(clock()-t0))/CLOCKS_PER_SEC <<endl;
		t0 = clock();

		cout<<"Чтение ANTEX-файла..."<<endl;
		loadANTEX();
		cout<<"Заняло: "<< ((double)(clock()-t0))/CLOCKS_PER_SEC <<endl;
		t0 = clock();

		if (options.cframenames.size()>0)
		{
			cout<<"Генерация информации о БИС..."<<endl;
			loadReceiverInfo();
		}
		else
		{
			int obs_src_id = 0;
			Tuple obsidkey;
			obsidkey<<"temporary"<<"ppp"<<"obs_src_id";
			if (sets->find(obsidkey).isEnd())
				sets->insertRow(Tuple()<<"temporary"<<"ppp"<<"obs_src_id",
								Tuple()<<obs_src_id);
			else
				sets->updateCell(obsidkey,0,obs_src_id);

		}

		cout<<"Чтение измерительных данных..."<<endl;
		if (options.rinexnames.size()>0)
			loadRINEX21ObservationCodes(*datacollection);
		else
			loadRINEX3ObservationCodes(*datacollection);

		loadIonosphereFreeObservableCodes(*datacollection);

		loadObservables();
		if (obs->count()==0)
			return;
		cout<<"Заняло: "<< ((double)(clock()-t0))/CLOCKS_PER_SEC <<endl;
		t0 = clock();

		//Необходимо также заполнить для всех маркеров Eccentricity.
		//Если SINEX-файлы не читаются, то занесем нулевой эксцентриситет
		if (options.sinexexact == false)
			zeroEccentricity();

		cout<<"Чтение прочих продуктов..."<<endl;
		loadMiscProducts();
		cout<<"Заняло: "<< ((double)(clock()-t0))/CLOCKS_PER_SEC <<endl;
	}

	void process()
	{
		DBTable savefullobs(obs->getKeyColumns(), obs->getValueColumns());
		DBTable savetimeshift(tshift->getKeyColumns(),
							  tshift->getValueColumns());
		real T0 = obs->getMinTime(), T1 = obs->getMaximalTime();
		if (options.resample!=0)
		{
			//Перед первым этапом обработки проредить измерения
			savefullobs.copyFrom(obs->const_begin(), obs->const_end());
			//Сохранить уход часов НКА (он будет прорежен при прореживании
			//измерений)
			savetimeshift.copyFrom(tshift->find(Tuple()<<1),
								   tshift->const_end());
			obs->resampleDown(T0,options.resample);
			obs->deleteSmallArcs(options.smallarcs);
            cout<<"Для МНК будет использоваться "<<obs->count()<<" строк."<<endl;
		}

		real currentnorm;
		MyObservablesLeastSquaresProblem * ls
			 = new MyObservablesLeastSquaresProblem(datacollection,
												  options.outputdir,
												  currentfile,
												  &currentnorm);
		cout<<"Подготовка параметров фазовой неоднозначности..."<<endl;

		phsambig->resample(T0,T1);
		ls->addAdjustableParameter("phase_ambiguity");
		if (!(options.sinexexact || options.stexactcoord))
		{
			cout<<"Подготовка параметров положения БИС..."<<endl;
			mpos->resample(T0,T1);
			ls->addAdjustableParameter("marker_position");
		}
		//Если положение БИС берётся из SINEX, запретить экстраполировать
		//положение БИС более чем на сутки вперёд или назад.
		if (options.sinexexact)
			mpos->setExtrapolationLimit(Tuple(),86400);

		if (!options.usesinextropo)
		{
			cout<<"Подготовка параметров задержки сигнала в тропосфере..."
			   <<endl;
			atm->resample(T0,T1);
			ls->addAdjustableParameter("troposphere");
		}
		else
			//Если параметры тропосферы берутся из SINEX, запретить их
			//экстраполировать больше, чем на 4 часа вперёд или назад
			atm->setExtrapolationLimit(Tuple(),4*3600);
		if (!options.strinexclock)
		{
			cout<<"Подготовка параметров ухода часов БИС..."<<endl;
			ls->addAdjustableParameter("time_shift");
			tshift->resample(T1,T1);
		}
		//! @bug Не повредит ли это в нормальном режиме работы?
		tshift->setInterpolateOrder(Tuple(),2);
		ls->createColumnsList();
		real prevnorm = numeric_limits<real>::infinity();
		int iteration = 0;

		//Сохранить на будущее список уточняемых параметров
		for (set<string>::iterator it = ls->getParametersSet().begin();
			 it!=ls->getParametersSet().end(); ++it)
			paramslist->insertRow(Tuple()<<*it,Tuple());
		while (true)
		{
			iteration ++;
			cout<<"Итерация "<<iteration<<endl;
			ls->setIterationNumber(iteration);
			int itlim = 20000;
			clock_t t0 = clock();
			//Установить отсечение по зенитному углу
			//Если итерация ещё не подошла, убрать любые ограничения
			if (iteration<=options.since_iter)
				ls->setMaxZenith(Pi);
			else
				ls->setMaxZenith(options.maxzenith_ls * Pi/180.0l);

			ls->adjust(itlim);
			ofstream errlog;
			string errlogfname = options.outputdir+"/least_squares.log."+
					Variant(iteration).toString();
			errlog.open(errlogfname.c_str());
			if (errlog.is_open())
			{
				ls->printLastExceptionLog(errlog);
				errlog.close();
			}
			else
				cout<<"Не удалось открыть файл "<<errlogfname<<" для записи в "
				   <<"него журнала ошибок одной итерации МНК"<<endl;

			cout<<"Итерация заняла: "<< ((double)(clock()-t0))/CLOCKS_PER_SEC
				  <<" сек."<<endl;
			//Условие выхода: когда сходимость закончилась
			if (currentnorm >= (1.0l-1e-14l) * prevnorm)
				break;
			if (iteration>15)
			{
				cerr<<"За 15 итераций МНК не сходится."<<endl;
				break;
			}
			prevnorm = currentnorm;
		}

		if (options.resample==0)
			return;

		//После того, как посчитаны координаты и тропосферные параметры БИС,
		//вернуть псевдодальности в исходном разрешении и вычислить уход часов
		//БИС
		obs->deleteRows(Tuple());
		obs->copyFrom(savefullobs.const_begin(),savefullobs.const_end());

		//Вернуть уход часов НКА
		tshift->deleteRows(Tuple());
		tshift->copyFrom(savetimeshift.const_begin(),
						 savetimeshift.const_end());

		tshift->resample(T0,T1);
		phsambig->deleteRows(Tuple());
		phsambig->resample(T0,T1);
		MyObservablesLeastSquaresProblem * ls1 =
		   new MyObservablesLeastSquaresProblem(datacollection,
												  options.outputdir,
												  currentfile,
												  &currentnorm);
		ls1->addAdjustableParameter("time_shift");
		ls1->addAdjustableParameter("phase_ambiguity");
		iteration ++;
		cout<<"Итерация "<<iteration<<" (уход часов БИС)"<<endl;
		ls1->setIterationNumber(iteration);
		int itlim = 20000;
		clock_t t0 = clock();
		ls1->adjust(itlim);
		ofstream errlog;
		string errlogfname = options.outputdir+"/least_squares.log."+
				Variant(iteration).toString();
		errlog.open(errlogfname.c_str());
		if (errlog.is_open())
		{
			ls1->printLastExceptionLog(errlog);
			errlog.close();
		}
		else
			cout<<"Не удалось открыть файл "<<errlogfname<<" для записи в "
			   <<"него журнала ошибок одной итерации МНК"<<endl;

		cout<<"Итерация заняла: "<< ((double)(clock()-t0))/CLOCKS_PER_SEC
			  <<" сек."<<endl;
		delete ls1;
	}

	void imitate()
	{
		//Создание списка НКА для имитации
		set<int> imit_sat_ids; //Идентификаторы НКА, участвующих в МНК
		set<string> imit_satlist_set;
		for (int i=0; i<options.imit_satnames.size(); i++)
			imit_satlist_set.insert(options.imit_satnames[i]);
		for (DBTable::DBConstIterator it = history->const_begin();
			 it!=history->const_end(); ++it)
		{
			int sat_history_id = it.keyColumnValue(0).toInt();
			string satname = history->getShortSatName(sat_history_id);
			if (imit_satlist_set.find(satname)!=imit_satlist_set.end())
				imit_sat_ids.insert(sat_history_id);
		}
		cout<<"Имитация..."<<endl;
		int obs_src_id =
				sets->getSettings("temporary","ppp","obs_src_id").toInt();

		ImitationUsingNavData * ndi = new ImitationUsingNavData(datacollection,
																intervals,
																obs_src_id,
																options,
																imit_sat_ids);
		cout<<"Имитатор создан."<<endl;
		if (options.cframenames.size()>0)
		{
			currentfile = options.cframenames[fileid];

			MyCFrameParser p(ndi->GLONASSLoader(),
							 ndi->GPSLoader(),ndi->GLONavDataLoader(),
							 ndi->GPSNavDataLoader(),0);

			p.read(currentfile);

			string readcframelog_fn = options.outputdir + "/imitate_cframe.log";
			ofstream readcframelog(readcframelog_fn.c_str());
			p.printExceptionLog(readcframelog);
			readcframelog.close();

		}
		else
		{
			cout<<"Чтение и предобработка RINEX-файла "<<currentfile<<endl;
			currentfile = options.rinexnames[fileid];
			map<char,ObservablesLoader*> ldrs;
			ldrs['G'] = ndi->GPSLoader();
			ldrs['R'] = ndi->GLONASSLoader();
			ifstream ldrinex(currentfile.c_str());
			if (!(ldrinex.is_open()))
				throw FileNotFoundException(currentfile);
			parseRINEXObsData(ldrs,NavSys_GPS | NavSys_GLONASS
							  | ObsFreq_L1 | ObsFreq_L2
							  | ObsType_Phase|ObsType_StdPseudorange
							  | ObsType_HighPrecPseudorange, ldrinex);
			ldrinex.close();
		}
		delete ndi;
	}

	void dumpTxtFiles()
	{
		cout<<"Файлы с окончательными значениями уточняемых параметров: "<<endl;
		for (DBTable::DBConstIterator it = paramslist->const_begin();
			 it!=paramslist->const_end();++it)
		{
			string paramname = it.keyColumnValue(0).toString();
			string paramfilename = options.outputdir+"/"
					+paramname+".tc";
			cout<<paramfilename<<endl;
			ofstream paramfile(paramfilename.c_str());
			datacollection->getTable(paramname)->dump(paramfile,paramname);
			paramfile.close();
		}
		//delete ls;
	}

	void mkResidualPlots()
	{
		vector<string>  filenames;
		real T0 = obs->getMinTime(), T1 = obs->getMaximalTime();
		if (options.rangepng)
		{
			vector<string> rangefnames = filenamesList(options.outputdir+"/"
				+options.rtxttempl, T0,T1,stationsList(datacollection),'A',
													   FNSO_NavSysStationTime);
			filenames.insert(filenames.end(),rangefnames.begin(),
							  rangefnames.end());
		}
		if (options.phasepng)
		{
			vector<string> phasefnames = filenamesList(options.outputdir+"/"
				+options.phtxttempl, T0,T1,stationsList(datacollection),'A',
													   FNSO_NavSysStationTime);
			filenames.insert(filenames.end(),phasefnames.begin(),
							  phasefnames.end());
		}

		for (unsigned int i=0; i<filenames.size(); i++)
		{
			string gnuplotoptions=string("-e \"filename='")+filenames[i]
						+string("';set terminal png size 1000,400;set output '")
						+filenames[i]+".png'\" ";
			string gnuplotcmd = string(
		#ifdef Win32
					"gnuplot.exe "
		#else
					"gnuplot "
		#endif
					) + gnuplotoptions +" "
					+options.pltres;
			system(gnuplotcmd.c_str());
		}

		if (options.urrepng)
		{
			vector<string> urrefnames = filenamesList(options.outputdir+"/"
				+options.urretmpl, T0,T1,stationsList(datacollection),'A',
													   FNSO_NavSysStationTime);
			for (unsigned int i=0; i<urrefnames.size(); i++)
			{
				string gnuplotoptions=string("-e \"filename='")+urrefnames[i]
							+string("';set terminal png size 1000,400;set output '")
							+urrefnames[i]+".png'\" ";
				string gnuplotcmd = string(
			#ifdef Win32
						"gnuplot.exe "
			#else
						"gnuplot "
			#endif
						) + gnuplotoptions +" "
						+options.plturr;
				system(gnuplotcmd.c_str());
			}
		}
		if (options.uraepng)
		{
			vector<string> uraefnames = filenamesList(options.outputdir+"/"
				+options.uraetmpl, T0,T1,stationsList(datacollection),'A',
													   FNSO_NavSysStationTime);
			for (unsigned int i=0; i<uraefnames.size(); i++)
			{
				string gnuplotoptions=string("-e \"filename='")+uraefnames[i]
							+string("';set terminal png size 1000,400;set output '")
							+uraefnames[i]+".png'\" ";
				string gnuplotcmd = string(
			#ifdef Win32
						"gnuplot.exe "
			#else
						"gnuplot "
			#endif
						) + gnuplotoptions +" "
						+options.pltura;
				system(gnuplotcmd.c_str());
			}
		}
	}

	//Возвращает список имён текстовых файлов видимости НКА.
	//Отображение: Имя БИС->Пара(список для G, список для R).
	map<string,pair< vector<string>, vector<string> > > visibilityFilenames(
			real T0, real T1, const vector<string> & stnames,
			const string & root)
	{
		map<string,pair< vector<string>, vector<string> > > result;
		if (options.satcount)
		{
			for (unsigned int i=0; i<stnames.size(); i++)
			{
				vector<string> onestation(1,stnames[i]);
				result[stnames[i]].first = filenamesList(
							root+"/"+options.satcounttemplate,
							T0,T1,onestation,'G',FNSO_NavSysStationTime);
				result[stnames[i]].second = filenamesList(
							root+"/"+options.satcounttemplate,
							T0,T1,onestation,'R',FNSO_NavSysStationTime);
			}
		}
		return result;
	}

	void mkVisibilityPlots()
	{
		if (options.satcount)
		{
			real T0 = obs->getMinTime(), T1 = obs->getMaximalTime();
			vector<string> stnames = stationsList(datacollection);
			map<string,pair< vector<string>, vector<string> > > fnl =
					visibilityFilenames(T0,T1,stnames,options.outputdir);
			for (map<string,pair< vector<string>, vector<string> > >::iterator
				 it1 = fnl.begin(); it1!=fnl.end(); ++it1)
			{
				for (unsigned int i=0; i<it1->second.first.size();i++)
				{
					string curtxtfile = it1->second.first[i];
					string gnuplotoptions=string("-e \"filename='")+curtxtfile
						+string("';ns='G';set terminal png size 800,600;")
						+string("set output '")
						+curtxtfile+".png';set title 'БИС:"
						+it1->first+". График видимость НКА GPS'\" ";
					string gnuplotcmd = string(
				#ifdef Win32
							"gnuplot.exe "
				#else
							"gnuplot "
				#endif
							) + gnuplotoptions +" "+
							options.pltvis;
					system(gnuplotcmd.c_str());


				}

				for (unsigned int i=0; i<it1->second.second.size();i++)
				{
					string curtxtfile = it1->second.second[i];
					string gnuplotoptions=string("-e \"filename='")+curtxtfile
						+string("';ns='R';set terminal png size 800,600;")
						+string("set output '")
						+curtxtfile+".png';set title 'БИС:"
						+it1->first+". График видимость НКА ГЛОНАСС'\"";

					string gnuplotcmd = string(
				#ifdef Win32
							"gnuplot.exe "
				#else
							"gnuplot "
				#endif
							) + gnuplotoptions +" "+
							options.pltvis;
					system(gnuplotcmd.c_str());
				}

			}
		}
	}

	void mkBriefReport()
	{
		string artname = (options.errmode_stddev)?"СКО невязки"
												:"Максимальная невязка";
		real gt0=numeric_limits<real>::infinity(),
				gt1=-gt0;
		vector<string> & fnames = (options.rinexnames.size()>0)?
					options.rinexnames:options.cframenames;
		//Создавать список файлов с артефактами
		//Структура с файлами артефактов фазы
		ResidualFilesList phase;
		//Структура с файлами артефактов кода
		ResidualFilesList range;
		//Структура с файлами артефактов скорости
		ResidualFilesList rate;
		//Структура с файлами артефактов ускорения
		ResidualFilesList accel;
		//Файлы видимости НКА
		map<string,pair<vector<string>,vector<string> > > visfnames;
		for (unsigned int i=0; i<fnames.size(); i++)
		{
			string thisdir=getOutputDirectory(options.outputdir,fnames[i],i,
											  fnames.size());
			string thisstlist = thisdir+"/session.info";
			ifstream thisstlistfile(thisstlist.c_str());
			if(!(thisstlistfile.is_open()))
			{
				cerr<<"Файл session.info не найден - файл "
				   <<fnames[i]<<" не обработан. Пропускаем." <<endl;
				continue;
			}
			real T0,T1;
			string line0;
			getline(thisstlistfile,line0);
			T0 = Variant(line0).toDouble();
			getline(thisstlistfile,line0);
			T1 = Variant(line0).toDouble();
			if(T0<gt0)
				gt0=T0;
			if(T1>gt1)
				gt1=T1;
			set<string> stationsset;
			while (!(thisstlistfile.eof()))
			{
				string line;
				getline(thisstlistfile,line);
				if (line!="")
					stationsset.insert(line);
			}
			thisstlistfile.close();
			vector<string> stationslist;
			stationslist.insert(stationslist.end(),stationsset.begin(),
								stationsset.end());

			//Собрать список артефактов фазы
			ResidualFilesList thisphase;
			if ((options.phasetxt)&&(options.phaseerrdivision.size() > 0))
			{
				vector<string> filenames = filenamesList(thisdir+"/"+
							options.phtxttempl,T0,T1,stationslist,
							'A', FNSO_NavSysStationTime);
				thisphase=sortResidualFiles(filenames,
											options.phaseerrdivision,
											options.errmode_stddev?1:0,
											options.maxzenith_imit);
				//Цикл по интервалам невязки
				for (ResidualFilesList::iterator it=thisphase.begin();
					 it!=thisphase.end(); ++it)
					//Цикл по БИСам
					for (std::map<std::string,std::map<std::string,
						std::set<std::string> > >::iterator
						 it1=it->second.begin();
						 it1!=it->second.end(); ++it1)
						//Цикл по НКА
						for (std::map<std::string,std::set<std::string> >
							 ::iterator it2=it1->second.begin();
							 it2!=it1->second.end(); ++it2)
						{
							set<string> & dest =
								phase[it->first][it1->first][it2->first];
							set<string> & src = it2->second;
							dest.insert(src.begin(), src.end());
						}

			}


			ResidualFilesList thisrange;
			//Собрать список артефактов кода
			if ((options.rangetxt)&&(options.rangeerrdivision.size() > 0))
			{
				vector<string> filenames = filenamesList(thisdir+"/"+
							options.rtxttempl,T0,T1,stationslist,
							'A', FNSO_NavSysStationTime);
				thisrange=sortResidualFiles(filenames,options.rangeerrdivision,
											options.errmode_stddev?1:0,
											options.maxzenith_imit);
				//Цикл по интервалам невязки
				for (ResidualFilesList::iterator it=thisrange.begin();
					 it!=thisrange.end(); ++it)
					//Цикл по БИСам
					for (std::map<std::string,std::map<std::string,
						std::set<std::string> > >::iterator
						 it1=it->second.begin();
						 it1!=it->second.end(); ++it1)
						//Цикл по НКА
						for (std::map<std::string,std::set<std::string> >
							 ::iterator it2=it1->second.begin();
							 it2!=it1->second.end(); ++it2)
						{
							set<string> & dest =
									range[it->first][it1->first][it2->first];
							set<string> & src = it2->second;
							dest.insert(src.begin(), src.end());
						}
			}


			ResidualFilesList thisurr;
			//Собрать список артефактов скорости псевдодальности
			if ((options.urretxt)&&(options.urredivision.size() > 0))
			{
				vector<string> filenames = filenamesList(thisdir+"/"+
							options.urretmpl,T0,T1,stationslist,
							'A', FNSO_NavSysStationTime);
				thisurr=sortResidualFiles(filenames,options.urredivision,
											options.errmode_stddev?1:0,
											options.maxzenith_imit);
				//Цикл по интервалам невязки
				for (ResidualFilesList::iterator it=thisurr.begin();
					 it!=thisurr.end(); ++it)
					//Цикл по БИСам
					for (std::map<std::string,std::map<std::string,
						std::set<std::string> > >::iterator
						 it1=it->second.begin();
						 it1!=it->second.end(); ++it1)
						//Цикл по НКА
						for (std::map<std::string,std::set<std::string> >
							 ::iterator it2=it1->second.begin();
							 it2!=it1->second.end(); ++it2)
						{
							set<string> & dest =
									rate[it->first][it1->first][it2->first];
							set<string> & src = it2->second;
							dest.insert(src.begin(), src.end());
						}
			}

			ResidualFilesList thisura;
			//Собрать список артефактов ускорения псевдодальности
			if ((options.uraetxt)&&(options.uraedivision.size() > 0))
			{
				vector<string> filenames = filenamesList(thisdir+"/"+
							options.uraetmpl,T0,T1,stationslist,
							'A', FNSO_NavSysStationTime);
				thisura=sortResidualFiles(filenames,options.uraedivision,
											options.errmode_stddev?1:0,
											options.maxzenith_imit);
				//Цикл по интервалам невязки
				for (ResidualFilesList::iterator it=thisura.begin();
					 it!=thisura.end(); ++it)
					//Цикл по БИСам
					for (std::map<std::string,std::map<std::string,
						std::set<std::string> > >::iterator
						 it1=it->second.begin();
						 it1!=it->second.end(); ++it1)
						//Цикл по НКА
						for (std::map<std::string,std::set<std::string> >
							 ::iterator it2=it1->second.begin();
							 it2!=it1->second.end(); ++it2)
						{
							set<string> & dest =
									accel[it->first][it1->first][it2->first];
							set<string> & src = it2->second;
							dest.insert(src.begin(), src.end());
						}
			}

			//Список имен файлов с видимость НКА
			map<string,pair<vector<string>,vector<string> > > thisvisfnames=
					visibilityFilenames(T0,T1,stationslist,thisdir);
			for (map<string,pair<vector<string>,vector<string> > >
				 ::iterator it = thisvisfnames.begin();
				 it!=thisvisfnames.end(); ++it)
			{
				vector<string> & dest1 = visfnames[it->first].first;
				vector<string> & dest2 = visfnames[it->first].second;
				vector<string> & src1 = it->second.first;
				vector<string> & src2 = it->second.second;
				dest1.insert(dest1.end(),src1.begin(),src1.end());
				dest2.insert(dest2.end(),src2.begin(),src2.end());
			}
		}//Цикл по файлам с измерительными данными
		//Собрать список имён файлов видимость НКА

		if (isinf(gt0))
		{
			cout<<"Нет данных для краткого отчета."<<endl;
			return;
		}


		//Формирование текста отчета
		//Заголовок файла
		string briefname=options.outputdir+"/"+options.overviewname+".html";
		ofstream brief(briefname.c_str());
		brief<<"<html>"
			   "<head><meta content=\"text/html; charset=utf-8\""
			   "http-equiv=\"Content-Type\">"
			   "<title>Изучение невязок IGS на интервале с "
			   <<UTCDateTime::fromTAIJ2000(gt0).getUTCDateTimeString()
			  <<" по "<<UTCDateTime::fromTAIJ2000(gt1).getUTCDateTimeString()
				<<"</title></head><body>";

		if (options.satcount == true)
		{
			//Графики видимости НКА
			brief<<"<h1>Видимость НКА</h1>";
			for (map<string,pair<vector<string>,vector<string> > >::iterator
				 it1=visfnames.begin(); it1!=visfnames.end(); ++it1)
			{
				string stname=it1->first;
				brief<<"<h2>БИС "<<stname<<"</h2>";
				for (int i=0; i<it1->second.first.size(); i++)
					brief<<"<img src=\"data:image/png;base64,"
						   <<base64OfFile(it1->second.first[i]+".png")
							 <<"\" />";
				for (int i=0; i<it1->second.second.size(); i++)
					brief<<"<img src=\"data:image/png;base64,"
						   <<base64OfFile(it1->second.second[i]+".png")
							 <<"\" />";
			}
		}

		if ((phase.size()>0) && (options.phasepng))
		{
			brief<<"<h1>Артефакты фазы</h1>";
			for (ResidualFilesList::iterator it=phase.begin();
				 it!=phase.end();++it)
			{
				brief<<"<h2>"<<artname<<" фазы от "<<(double)(it->first.first)
					<<" до "<<(double)(it->first.second)<<"км</h2>";
				//Цикл по БИСам
				for (std::map<std::string,std::map<std::string,
					std::set<std::string> > >::iterator
					 it1=it->second.begin();
					 it1!=it->second.end(); ++it1)
				{
					brief<<"<h3>БИС "<<it1->first<<"</h3>";
					//Цикл по НКА
					for (std::map<std::string,std::set<std::string> >
						 ::iterator it2=it1->second.begin();
						 it2!=it1->second.end(); ++it2)
					{
						brief<<"<h3>НКА "<<it2->first<<"</h3>";
						for (set<string>::iterator it3=it2->second.begin();
							 it3!=it2->second.end(); ++it3)
							brief<<"<img src=\"data:image/png;base64,"
								   <<base64OfFile(*it3 + ".png")
									 <<"\" />";
					}
				}
			}
		}

		if ((range.size()>0) && (options.rangepng))
		{
			brief<<"<h1>Артефакты псевдодальности</h1>";
			for (ResidualFilesList::iterator it=range.begin();
				 it!=range.end();++it)
			{
				brief<<"<h2>"<<artname<<" псевдодальности от "
					<<(double)(it->first.first)<<" до "
				   <<(double)(it->first.second)
				   <<"км</h2>";
				//Цикл по БИСам
				for (std::map<std::string,std::map<std::string,
					std::set<std::string> > >::iterator
					 it1=it->second.begin();
					 it1!=it->second.end(); ++it1)
				{
					brief<<"<h3>БИС "<<it1->first<<"</h3>";
					//Цикл по НКА
					for (std::map<std::string,std::set<std::string> >
						 ::iterator it2=it1->second.begin();
						 it2!=it1->second.end(); ++it2)
					{
						brief<<"<h3>НКА "<<it2->first<<"</h3>";
						for (set<string>::iterator it3=it2->second.begin();
							 it3!=it2->second.end(); ++it3)
							brief<<"<img src=\"data:image/png;base64,"
								   <<base64OfFile(*it3 + ".png")
									 <<"\" />";
					}
				}
			}
		}

		if ((rate.size()>0) && (options.urrepng))
		{
			brief<<"<h1>Артефакты скорости изменения псевдодальности</h1>";
			for (ResidualFilesList::iterator it=rate.begin();
				 it!=rate.end();++it)
			{
				brief<<"<h2>"<<artname
					<<" скорости изменения псевдодальности от "
					<<(double)(it->first.first)<<" до "
				   <<(double)(it->first.second)
				   <<"км/c</h2>";
				//Цикл по БИСам
				for (std::map<std::string,std::map<std::string,
					std::set<std::string> > >::iterator
					 it1=it->second.begin();
					 it1!=it->second.end(); ++it1)
				{
					brief<<"<h3>БИС "<<it1->first<<"</h3>";
					//Цикл по НКА
					for (std::map<std::string,std::set<std::string> >
						 ::iterator it2=it1->second.begin();
						 it2!=it1->second.end(); ++it2)
					{
						brief<<"<h3>НКА "<<it2->first<<"</h3>";
						for (set<string>::iterator it3=it2->second.begin();
							 it3!=it2->second.end(); ++it3)
							brief<<"<img src=\"data:image/png;base64,"
								   <<base64OfFile(*it3 + ".png")
									 <<"\" />";
					}
				}
			}
		}

		if ((accel.size()>0) && (options.uraepng))
		{
			brief<<"<h1>Артефакты ускорения изменения псевдодальности</h1>";
			for (ResidualFilesList::iterator it=rate.begin();
				 it!=rate.end();++it)
			{
				brief<<"<h2>"<<artname
					<<" ускорения изменения псевдодальности от "
					<<(double)(it->first.first)<<" до "
				   <<(double)(it->first.second)
				   <<"км/c^2</h2>";
				//Цикл по БИСам
				for (std::map<std::string,std::map<std::string,
					std::set<std::string> > >::iterator
					 it1=it->second.begin();
					 it1!=it->second.end(); ++it1)
				{
					brief<<"<h3>БИС "<<it1->first<<"</h3>";
					//Цикл по НКА
					for (std::map<std::string,std::set<std::string> >
						 ::iterator it2=it1->second.begin();
						 it2!=it1->second.end(); ++it2)
					{
						brief<<"<h3>НКА "<<it2->first<<"</h3>";
						for (set<string>::iterator it3=it2->second.begin();
							 it3!=it2->second.end(); ++it3)
							brief<<"<img src=\"data:image/png;base64,"
								   <<base64OfFile(*it3 + ".png")
									 <<"\" />";
					}
				}
			}
		}


		brief.close();
	}

};



void runPPP(const PPPOptions & options, int fileidx)
{
	PPP app(options,fileidx);

	int nfiles = max(options.rinexnames.size(), options.cframenames.size());
	if (fileidx<nfiles)
	{
		vector<string> fnames = (options.rinexnames.size()>0)?
					options.rinexnames:options.cframenames;
		string thisdir=app.getOutputDirectory(options.outputdir,fnames[fileidx],
										  fileidx, fnames.size());
		cout<<"Выходная директория для файла "<<fnames[fileidx]
			  <<":"<<thisdir<<endl;
		if (options.stage==0)
		{
			app.loadData();
			if (app.obs->count() == 0)
			{
				cerr<<"Измерения не загружены."<<endl;
				return;
			}
			if (options.loaddump)
			{
				cout<<"Создание резервной копии базы..."<<endl;
				string dumpname = app.options.outputdir+"/loaddump.tc";
				ofstream ldmp(dumpname.c_str());
				ldmp.precision(25);
				app.datacollection->dump(ldmp);
				ldmp.close();
			}
		}
		if (options.stage==1)
		{
			string dumpname = app.options.outputdir+"/loaddump.tc";
			cout<<"Восстановление сеанса из файла:"<<endl
			   <<dumpname<<endl;
			ifstream ldmp(dumpname.c_str());
			if (ldmp.is_open()==false)
			{
				cerr<<"Файл не найден."<<endl;
				return;
			}
			ldmp.precision(25);
			clock_t t0 = clock();
			app.datacollection->readFromStream(ldmp,cout);
			ldmp.close();
			cout<<"Заняло: "<<((double)(clock()-t0))/CLOCKS_PER_SEC<<endl;
		}

		if (options.stage<2)
		{
			app.process();
			if (options.adjdump)
			{
				cout<<"Создание резервной копии базы..."<<endl;
				string dumpname = app.options.outputdir+"/adjdump.tc";
				ofstream ldmp(dumpname.c_str());
				app.datacollection->dump(ldmp);
				ldmp.close();
			}
		}
		else
		{
			string dumpname = app.options.outputdir+"/adjdump.tc";
			cout<<"Восстановление сеанса из файла:"<<endl
			   <<dumpname<<endl;
			ifstream ldmp(dumpname.c_str());
			if (ldmp.is_open()==0)
			{
				cerr<<"Файл не найден."<<endl;
				return;
			}
			clock_t t0 = clock();
			app.datacollection->readFromStream(ldmp,cout);
			ldmp.close();
			cout<<"Заняло: "<<((double)(clock()-t0))/CLOCKS_PER_SEC<<endl;
		}

		if (options.stage<3)
		{
			clock_t t0 = clock();
			DBTable saveclock(app.tshift->getKeyColumns(),
							  app.tshift->getValueColumns());
			saveclock.copyFrom(app.tshift->const_begin(),
							   app.tshift->const_end());
			app.imitate();
			app.tshift->deleteRows(Tuple());
			app.tshift->copyFrom(saveclock.const_begin(),
								 saveclock.const_end());
			saveclock.deleteRows(Tuple());
			cout<<"Имитация заняла: "<<((double)(clock()-t0))/CLOCKS_PER_SEC <<endl;
		}

		app.dumpTxtFiles();
		cout<<"Построение графиков..."<<endl;
		app.mkResidualPlots();
		app.mkVisibilityPlots();
		//Сохранить временнОй интервал и список БИС
		string sessinfoname = thisdir+"/session.info";
		ofstream sessinfo (sessinfoname.c_str());
		sessinfo.precision(20);
		real T0 = app.obs->getMinTime(), T1 = app.obs->getMaximalTime();
		sessinfo<<(double)T0<<endl<<(double)T1<<endl;
		vector<string> stlist = stationsList(app.datacollection);
		for (unsigned int i=0; i<stlist.size(); i++)
			sessinfo<<stlist[i]<<endl;
		sessinfo.close();
	}
	else
	{
		cout<<"Формирование краткого отчета..."<<endl;
		app.mkBriefReport();
	}
}


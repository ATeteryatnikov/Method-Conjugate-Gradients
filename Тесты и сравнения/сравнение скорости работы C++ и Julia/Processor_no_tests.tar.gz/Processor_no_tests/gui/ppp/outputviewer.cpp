#include <outputviewer.h>
#include <QMessageBox>
#include <DBError.h>

using namespace libgnss;

OutputViewer::OutputViewer(const QString &title, bool closeOnFinish)
	: QTextBrowser(0)
{
	setWindowTitle(title);
	CloseOnFinish = closeOnFinish;
	setAttribute(Qt::WA_DeleteOnClose);
	setMinimumSize(640,480);
	running = false;
    app=0;
}

void OutputViewer::startCMD(const QString &appname, const QStringList &appargs)
{
	if (running == true)
		throw StrException("OutputViewer::startCMD",
						   "Команда уже запущена.");
	running = true;
	app = new QProcess(0);
	setReadOnly(true);
	setAcceptRichText(true);
	connect(app,SIGNAL(readyReadStandardOutput()),
			this,SLOT(readReady()));
	connect(app,SIGNAL(readyReadStandardError()),
			this,SLOT(errorReady()));
	connect(app,SIGNAL(finished(int,QProcess::ExitStatus)),
			this,SLOT(finished(int,QProcess::ExitStatus)));
	app->start(appname,appargs,QProcess::ReadOnly);
}

void OutputViewer::readReady()
{
	QString readlines = QString::fromUtf8(app->readAllStandardOutput());
	QStringList lines = readlines.split(QChar('\n'));
	for (int i=0; i<lines.size(); i++)
		if (lines[i].trimmed()!="")
			append(QString::fromUtf8(
			"<div style=\"color:black;font-family:'Courier New',monospace\">")+
				lines[i]+QString::fromUtf8("</div>"));
}

void OutputViewer::errorReady()
{
	QString readlines = QString::fromUtf8(app->readAllStandardError());
	QStringList lines = readlines.split(QChar('\n'));
	for (int i=0; i<lines.size(); i++)
		if (lines[i].trimmed()!="")
			append(QString::fromUtf8(
			"<div style=\"color:red;font-family:'Courier New',monospace\">")+
				lines[i]+QString::fromUtf8("</div>"));
}

void OutputViewer::finished(int exitCode, QProcess::ExitStatus exitStatus)
{
	running = false;
	app->deleteLater();
    app = 0;
	if (CloseOnFinish)
		close();
	else
		append(QString::fromUtf8(
			"<div style=\"color:blue;font-family:'Courier New',monospace\">"
				   "Программа завершила работу с кодом ")+
		QString::number(exitCode)+QString::fromUtf8(". Окно можно закрыть"
													"</div>"));
	CMDfinish();
}

void OutputViewer::killApp()
{
	app->kill();
	app->waitForFinished();
	app->deleteLater();
	app = 0;
}

void OutputViewer::closeEvent(QCloseEvent *event)
{
    bool running = true;
    if (app == 0)
        running = false;
    else
        if (app->state()!=QProcess::Running)
            running = false;

    if (running)
	{
		if (QMessageBox::question(this,QString::fromUtf8("Подтверждение"),
				QString::fromUtf8("Программа ещё выполняется. Прервать её?"),
					QMessageBox::Yes, QMessageBox::No) == QMessageBox::No)
		{
			event->ignore();
			return;
		}
		else
		{
			killApp();
		}
	}
	closeWnd();
	event->accept();
}

void OutputViewer::waitForFinish()
{
	app->waitForFinished();
}

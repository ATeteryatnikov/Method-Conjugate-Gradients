#include "ppphelp.h"
#include <QDockWidget>
#include <QToolBar>


MyHelpBrowser::MyHelpBrowser(QHelpEngine *eng, QWidget *parent)
	: QTextBrowser(parent)
{
	this->eng = eng;
	setFontFamily("Times");

}

QVariant MyHelpBrowser::loadResource(int type, const QUrl &name)
{
	QByteArray result;
	QUrl url(name);
	if (name.isRelative())
		url = source().resolved(url);
	result = eng->fileData(name);
	if (result.size() > 0)
		return result;
	else return QVariant();
}

PPPHelp::PPPHelp(QWidget *parent) :
	QMainWindow(parent)
{
	setWindowTitle(QString::fromUtf8("Изучение невязок IGS - справка"));
	helpengine = new QHelpEngine("ppphelp.qhc",this);
	helpengine->setupData();
	QDockWidget * helpcontent = new QDockWidget(this);
	helpcontent->setMinimumWidth(300);
	helpcontent->setFeatures(QDockWidget::DockWidgetFloatable
							 |QDockWidget::DockWidgetMovable);
	addDockWidget(Qt::LeftDockWidgetArea,helpcontent);
	helpcontent->setWidget(helpengine->contentWidget());
	helpengine->contentWidget()->setModel(helpengine->contentModel());
	helpbrowser = new MyHelpBrowser(helpengine, this);
	helpbrowser->setMinimumSize(600,400);
	setCentralWidget(helpbrowser);
	connect(helpengine->contentWidget(),SIGNAL(linkActivated(QUrl)),
			helpbrowser,SLOT(setSource(QUrl)));
//	connect(helpengine->contentWidget(),SIGNAL(linkActivated(QUrl)),
//			this,SLOT(openURL(QUrl)));
//	helpbrowser->setOpenLinks(false);
	//connect(helpbrowser,SIGNAL(anchorClicked(QUrl)),this,SLOT(openURL(QUrl)));
	setAttribute(Qt::WA_DeleteOnClose);
	QToolBar * tb = addToolBar(QString::fromUtf8("Просмотр документации"));
	tb->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
	prev = new QAction(QIcon(":/menuicons/go-previous.png"),
					   QString::fromUtf8("Назад"),this);
	next = new QAction(QIcon(":/menuicons/go-next.png"),
					   QString::fromUtf8("Вперёд"),this);
	prev->setEnabled(false);
	next->setEnabled(false);
	connect(prev,SIGNAL(triggered()),helpbrowser,SLOT(backward()));
	connect(next,SIGNAL(triggered()),helpbrowser,SLOT(forward()));
	tb->addAction(prev);
	tb->addAction(next);
	tb->addAction(QIcon(":/menuicons/zoom-in.png"),
			QString::fromUtf8("Приблизить"),helpbrowser,SLOT(zoomIn()))->
			setShortcut(Qt::CTRL+Qt::Key_Plus);
	tb->addAction(QIcon(":/menuicons/zoom-out.png"),
				  QString::fromUtf8("Отдалить"),helpbrowser,SLOT(zoomOut()))->
			setShortcut(Qt::CTRL+Qt::Key_Minus);
	prev->setShortcut(Qt::ALT+Qt::Key_Left);
	next->setShortcut(Qt::ALT+Qt::Key_Right);
	connect(helpbrowser,SIGNAL(backwardAvailable(bool)),prev,SLOT(setEnabled(bool)));
	connect(helpbrowser,SIGNAL(forwardAvailable(bool)),next,SLOT(setEnabled(bool)));
	helpbrowser->setSource(QUrl("qthelp://ru.sfu-kras.gnss.ppp/PPP/intro.html"));
}

void PPPHelp::openURL(const QUrl &url)
{
	QByteArray data = helpengine->fileData(url);
	QString helpdata = QString::fromUtf8(data);
	helpbrowser->setText(helpdata);
}


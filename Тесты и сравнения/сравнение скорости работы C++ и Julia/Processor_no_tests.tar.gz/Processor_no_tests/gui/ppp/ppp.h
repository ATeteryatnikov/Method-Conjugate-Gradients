#ifndef PPP_H_
#define PPP_H_

#include <vector>
#include <string>
#include <pppoptions.h>
#include <DBTableCollection.h>
#include <Types.h>



void runPPP(const PPPOptions & options, int fileidx);

/**
 * @brief Генерирует список всех БИС
 * @param base Коллекция таблиц
 *
 * Функция обходит таблицу observables, составляет список всех БИС, которые
 * в ней используются.
 *
 * @return Вектор имен маркеров БИС
 */
vector<string> stationsList(const libgnss::DBTableCollection * base);

/**
 * @brief Возвращает список имен НКА
 * @param navsys Буква навигационной системы (R - НКА ГЛОНАСС, G - НКА GPS)
 * @return Вектор имен НКА вида SNN, где S - буква, NN - слот/prn.
 */
vector<string> satnamelist(char navsys);

enum FileNamesListSortOrder
{
	FNSO_NavSysStationTime = 0,
	FNSO_NavSysTimeStation = 1,
	FNSO_StationNavSysTime = 2,
	FNSO_StationTimeNavSys = 3,
	FNSO_TimeStationNavSys = 4,
	FNSO_TimeNavSysStation = 5
};

/**
 * @brief Генерирует список имён всех файлов, получаемых из шаблона
 * @param fntemplate Шаблон имён файлов (см. @ref IGSfilenameFromTemplate() )
 * @param t0 Начальный момент времени, секунды от 12:00 01.01.2000 TAI
 * @param t1 Конечный момент времени, секунды от 12:00 01.01.2000 TAI
 * @param stationsList Список БИС
 * @param navsys Навигационные системы (G, R)
 * @param sortorder Порядок сортировки
 * @param[out] nonexisting Массив, куда пишутся имена не найденных файлов
 * @return Список имен файлов
 *
 * Для каждого дня в указанном временном интервале от t0 до t1, для каждого БИС
 * из переданного списка и для каждого НКА данной навигационной системы
 * генерируется список имен файлов по шаблону. Если данный файл существует,
 * то он включается в возвращаемый список. Число всех файлов, которые получились
 * по шаблону, но не существуют, возвращается через аргумент nonexisting.
 *
 *
 * Если шаблон не зависит от имени БИС, то список БИС можно не передавать;
 * если шаблон зависит от имени БИС, а список БИС пуст, то имя БИС заменяться
 * не будет.
 *
 * Если navsys = 'G', 'R', то будут браться все НКА только этих навигационных
 * систем. Если navsys = 'A', будут браться НКА и ГЛОНАСС и GPS. Если
 * navsys = '0', то подстановка осуществляться не будет.
 */
vector<string> filenamesList(const string & fntemplate,
							 libgnss::real t0, libgnss::real t1,
							 const vector<string> & stationsList,
							 char navsys,
							 FileNamesListSortOrder sortorder,
							 vector<string>* nonexisting = 0);



#endif

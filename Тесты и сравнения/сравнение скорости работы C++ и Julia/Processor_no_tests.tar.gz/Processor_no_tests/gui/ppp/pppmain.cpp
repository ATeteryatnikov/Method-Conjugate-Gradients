#include <string>
#include <vector>
#include <iostream>
#include <limits>
#include <fstream>

using namespace std;

#include <ppp.h>
//#include <igstempledit.h>
#include <QIcon>
#include <QApplication>
#include <pppoptionswindow.h>
#include <DBTableCollection.h>
#include <StdTables.h>
#include <QTranslator>
#include <readleapseconds.h>

using namespace libgnss;

int main(int argc, char ** argv)
{
	DBTableCollection tcol;
	LeapSeconds leaps(&tcol);
	ifstream ls("leap_seconds.dates");
	if (ls.is_open() == false)
	{
		cerr<<"Необходимый файл дистрибутива leap_seconds.dates не найден."
		   <<endl;
		return -1;
	}
	readLeapSeconds(leaps,ls);
	ls.close();

	//tcol.readFromString(leapseconds0);

	PPPOptions options;
	int parse = parseCMDLine(argc,argv, options);
	if (parse < 0)
		return parse;
	if (options.onlycheck)
		return parse;
	if (options.showgui)
	{
		QApplication a(argc,argv);
		a.setWindowIcon(QIcon(":/menuicons/browser.png"));
#ifndef Win32
//		a.setStyle("Plastique");
#endif
		a.setOrganizationName("SFU");
		a.setApplicationName("PPP");
		PPPOptionsWindow * wnd = new PPPOptionsWindow(options);
		wnd->show();
		return a.exec();
	}
	if (parse!=0)
		return parse;

	int NFiles = max(options.cframenames.size(), options.rinexnames.size());
	if (options.fileidx == -1)
		for (unsigned int i=0; i<=NFiles; i++)
			runPPP(options,i);
	else
		runPPP(options,options.fileidx);
}

#ifndef PPPMULTITHREAD_H_
#define PPPMULTITHREAD_H_

#include <QWidget>
#include <QString>
#include <QVector>
#include <QCloseEvent>
#include <QStringList>
#include <QTabWidget>

class OutputViewer;
class QMutex;

class PPPThread : public QObject
{
	Q_OBJECT
private:
	int curidx;
	OutputViewer * myview;
	QString cmd;
	QStringList args;
	QMutex * locker;
	QVector<int> * idx; //0 - файл нужно обрабатывать
	//1 - файл обрабатывается
	//2 - файл обработан
	//3 - файл передан для краткого отчета
	bool dobrief;
public:
	PPPThread(const QString & command, const QStringList & arglist,
			  QMutex * lockidxlist, QVector<int> *idxlist,
			  OutputViewer *parent);
public slots:
	void startNewJob();
signals:
	void finishedRunning();
};

class PPPMultithread : public QTabWidget
{
	Q_OBJECT
private:
	QVector<OutputViewer *>v;
	QVector<PPPThread*> threads;
	QMutex * blocker;
	QVector<int> idxlist;
	bool isRunning;
protected slots:
	void closeEvent ( QCloseEvent * event );
	void finishedRunning();
signals:
	void closeWnd();
public:
	PPPMultithread(const QStringList & l, int filescount, int nthreads);
	~PPPMultithread();
};

#endif

#ifndef OUTPUTVIEWER_H_
#define OUTPUTVIEWER_H_

#include <QTextBrowser>
#include <QString>
#include <QStringList>
#include <QCloseEvent>
#include <QProcess>


/**
 * @brief Позволяет просматривать вывод выводимого приложением текста
 */
class OutputViewer : public QTextBrowser
{
	Q_OBJECT
private:
	bool running;
	QProcess * app;
	bool CloseOnFinish;
public:
	OutputViewer (const QString & title, bool closeOnFinish);
public slots:
	void startCMD(const QString & appname, const QStringList & appargs);
	void killApp();
protected slots:
	void closeEvent ( QCloseEvent * event );
	void readReady();
	void errorReady();
	void finished ( int exitCode, QProcess::ExitStatus exitStatus );
	void waitForFinish();
signals:
	void CMDfinish();
	void closeWnd();
};


#endif

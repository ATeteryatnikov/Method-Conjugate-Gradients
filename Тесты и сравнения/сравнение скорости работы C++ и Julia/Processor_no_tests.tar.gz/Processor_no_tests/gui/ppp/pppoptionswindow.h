#ifndef PPPOPTIONSWINDOW_H_
#define PPPOPTIONSWINDOW_H_

#include <vector>
#include <string>

#include <QWidget>
#include <QString>
#include <ppp.h>
#include <QVector>
#include <pppoptions.h>
#include <QProcess>
#include <igsdirectoryprofile.h>
#include <QRegExpCheckEdit.h>

class QLineEdit;
class QCheckBox;
class QComboBox;
class QProcess;
class QSpinBox;
class QListWidget;
class QRadioButton;

class SatsList:public QWidget
{
	Q_OBJECT
private:
	QVector < QCheckBox* > procsatellites;
public:
	SatsList(QWidget * parent = 0);
	QString satsliststr();
	void setChecked(const std::vector < std::string > & sl);
public slots:
	void invertAllSatellites();
	void invertGLONASSSatellites();
	void invertGPSSatellites();
	void deselectGPS();
	void deselectGLONASS();
};

class PPPOptionsWindow : public QWidget
{
	Q_OBJECT
private:

	static QString rememberoutput;

	//Вкладка входных данных
	QRadioButton * chooserinex;
	QRadioButton * choosecframe;
	QLineEdit * stationname;
	QListWidget * filenames;
	QString obsfiletype;
	QComboBox * fitphaseGPS;
	QComboBox * fitphaseGLO;
	QComboBox * fitRangeGPS;
	QComboBox * fitRangeGLO;
	libgnss::IGSDirectoryProfile * igs;
	QLineEdit * finals;
	QComboBox * fbull;

	//Вкладка параметров предобработки
	QCheckBox * usegf;
	QSpinBox * gfnumpoints;
	QSpinBox * gforder;
	libgnss::QRegExpCheckEdit * gfthreshold;
	QCheckBox * usemw;
	libgnss::QRegExpCheckEdit * mwthreshold;
	QCheckBox * usemp;
	libgnss::QRegExpCheckEdit * mpthreshold;
	libgnss::QRegExpCheckEdit * minterval;
	QCheckBox * accountzenith;
	libgnss::QRegExpCheckEdit * rms_l;
	libgnss::QRegExpCheckEdit * rms_p;
	libgnss::QRegExpCheckEdit * maxtrajstep;
	libgnss::QRegExpCheckEdit * maxtrajextr;
	QSpinBox * minarccount;
	libgnss::QRegExpCheckEdit * minarclen;
	QCheckBox * count_arc;
	QCheckBox * count_len;

	//Вкладка уточнения параметров
	QCheckBox * doresample;
	libgnss::QRegExpCheckEdit * resample;
	QRadioButton * sinexcoords;
	QRadioButton * exactcoords;
	QRadioButton * adjustcoords;
	libgnss::QRegExpCheckEdit * stcoordstep;
	libgnss::QRegExpCheckEdit * stx;
	libgnss::QRegExpCheckEdit * sty;
	libgnss::QRegExpCheckEdit * stz;
	QComboBox * stcoordsys;
	QComboBox * mappingfunction;
	QComboBox * tropomodel;
	QCheckBox * tropogradient;
	QRadioButton * sinextropo;
	QRadioButton * adjusttropo;
	libgnss::QRegExpCheckEdit * tropostep;
	QCheckBox * rinexclockstation;
	SatsList * adj_slist;

	//Вкладка имитации
	QRadioButton * SatClkIGS;
	QRadioButton * SatClkCFr;
	QRadioButton * SatOrbSP3;
	QRadioButton * SatOrbCFr;
	QCheckBox * allowSatClockInterp;
	QCheckBox * allowRecClockInterp;
	SatsList * imit_slist;
	QSpinBox * urrenumpoints;
	QSpinBox * urreorder;

	//Вкладка выходной директории
	QLineEdit * outputDirectory;
	QComboBox * outputprofile;
	QCheckBox * PhaseTxt;
	QCheckBox * RangeTxt;
	QCheckBox * PhaseGr;
	QCheckBox * RangeGr;
	QCheckBox * URREGr;
	QCheckBox * URAEGr;
	QCheckBox * URRETxt;
	QCheckBox * URAETxt;
	QLineEdit * URRETxtTemplate;
	QLineEdit * URAETxtTemplate;
	QLineEdit * PhaseTxtTemplate;
	QLineEdit * RangeTxtTemplate;
	QCheckBox * SatCountGr;
	QLineEdit * SatCountTemplate;
	QCheckBox * CreateBrief;
	QLineEdit * BriefName;
	QComboBox * ErrorMeas;

	//Прочее
	libgnss::QRegExpCheckEdit * phaseErrDivision;
	libgnss::QRegExpCheckEdit * rangeErrDivision;
	libgnss::QRegExpCheckEdit * URREErrDivision;
	libgnss::QRegExpCheckEdit * URAEErrDivision;

//	QRegExpCheckEdit * errorNeighbourhood;
	QStringList generateArgumentsList(int threadid=-1);
	QString processoutput;
	QProcess * runningprocess;

	//Контрольные точки
	QCheckBox * mkLoadDump;
	QCheckBox * mkAdjustDump;
	QComboBox * resumeFrom;

	//Скрипты gnuplot
	QLineEdit * gnuplotvis;
	QLineEdit * gnuplotres;
	QLineEdit * gnuploturr;
	QLineEdit * gnuplotura;

	//Отсечение по зенитному углу
	QSpinBox * max_zenith_ls;
	QSpinBox * max_zenith_imit;
	QSpinBox * max_zenith_since_iter;
	QCheckBox * max_zenith_imit_only_stat;

	void displayCurrentOptions ( const PPPOptions & opts);

public:
	PPPOptionsWindow (const PPPOptions & opts);
protected slots:
	void chooseGNUPLOTVis();
	void chooseGNUPLOTRes();
	void chooseGNUPLOTURR();
	void chooseGNUPLOTURA();
	void addFile();
	void removeFile();
	void rinexToggled(bool checked);
	void cframeToggled(bool checked);
	void adjustStationCoordsToggled(bool checked);
	void exactStationCoordsToggled(bool checked);
	void sinexStationCoordsToggled(bool checked);
	void adjustTropoToggled(bool checked);
	void sinexTropoToggled(bool checked);
	void changeFinalsFile();
	void changeOutputDirectory();
	void saveOutputDirProfile();
	void loadOutputDirProfile(const QString & profilename);
	void forgetOutputDirProfile();
	void onDestroy();
	void generateCMDLine();
	void execute();
	void executeMultithreaded1();
	void showhelp();
	void setMaximalDegree(int N);
	//Чтение процесса обработчика
	void readReady();
	void errorReady();
	void processFinished( int exitCode, QProcess::ExitStatus exitStatus );
};


#endif

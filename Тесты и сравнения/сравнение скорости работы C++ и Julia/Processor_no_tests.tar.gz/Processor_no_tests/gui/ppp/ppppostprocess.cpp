#include <ppppostprocess.h>
#include <map>
#include <string>
#include <fstream>
#include <DBVariant.h>
#include <set>
#include <limits>
#include <cstdio>
#include <base64.hpp>
#include <Consts.h>

using namespace std;

using namespace libgnss;

struct ArtifactNorm
{
	real Max; //!< Максимальное по норме значение
	real Sq; //!< Сумма квадратов
	int N; //!< Число элементов

	ArtifactNorm()
	{
		Max = 0.0l;
		Sq = 0.0l;
		N = 0;
	}
};

ResidualFilesList sortResidualFiles(const vector<string> & resfilenames,
									const std::set<real> & gradation, int norm,
									real maxzenith)
{
	ResidualFilesList result;
	real minartifact = *(gradation.begin());

	//Для каждого файла найти норму невязки
	//Отображение: Имя БИС->Имя НКА->Имя файла->Данные для вычисления нормы
	map<string,map<string,map<string,ArtifactNorm> > > maxartifact;

	for (unsigned int i=0; i<resfilenames.size(); i++)
	{
		ifstream res(resfilenames[i].c_str());
		if (!(res.is_open())) //Пропускать отсутствующие файлы
			continue;
		while (!(res.eof()))
		{
			string line;
			getline (res,line);
			if (line.size() == 0)
				continue;
			vector<string> elems = split(line,'\t');
			string recname = elems[0];
			string satname = elems[1];
			real t = Variant(elems[2]).toDouble();
			real residual = fabs(Variant(elems[3]).toDouble());
			if (elems.size()>=7)
			{
				real zenith = Variant(elems[6]).toDouble() * 180.0l/Pi;
				if (zenith > maxzenith)
					continue;
			}
			ArtifactNorm & curartifact = maxartifact[recname][satname]
					[resfilenames[i]];
			if (residual > curartifact.Max)
				curartifact.Max = residual;
			curartifact.Sq += (residual*residual);
			curartifact.N++;
		}
		res.close();
	}

	//Для каждого файла теперь известен максимальный артифакт
	//Выбрать те, которые вписываются в градацию
	for (map<string,map<string,map<string,ArtifactNorm> > >::iterator
		 it = maxartifact.begin(); it!=maxartifact.end(); ++it)
		for (map<string,map<string,ArtifactNorm> >::iterator it1 =
			 it->second.begin(); it1!=it->second.end(); ++it1)
			for (map<string,ArtifactNorm>::iterator it2 = it1->second.begin();
				 it2!=it1->second.end(); ++it2)
			{
				string recname = it->first;
				string satname = it1->first;
				string curfilename = it2->first;
				ArtifactNorm & normdata = it2->second;
				real artifact;// = it2->second;
				if (norm == 0)
					artifact = normdata.Max;
				else
					artifact = sqrt(normdata.Sq/normdata.N);
				if (artifact < minartifact)
					continue;
				set<real>::iterator grit = gradation.begin();
				real low = *grit;
				while (grit!=gradation.end())
				{
					grit++;
					real high = (grit == gradation.end())?
								numeric_limits<real>::infinity():*grit;
					if ((artifact>=low) && (artifact<high))
						result[pair<real,real>(low,high)][recname]
								[satname].insert(curfilename);
					low = high;
				}
			}
	return result;
}

#ifndef PPPOPTIONS_H_
#define PPPOPTIONS_H_

//! @file

#include <string>
#include <vector>
#include <limits>
#include <set>
#include <map>
#include <Types.h>
#include <readcframe.h>

struct PPPOptions
{
	std::string cmdline;
	bool onlycheck; //!< Только проверить введённые параметры
	bool showgui; //!< Показать GUI
	std::string stname; //!< Имя БИС

	//Имена входных файлов
	int fileidx; //!< номер обрабатываемого файла (-1 - все файлы,
				//!< fileidx=числу файлов => формировать краткий отчет
	std::vector < std::string > cframenames; //!< Вектор имен файлов с C-кадрами
	std::vector < std::string > rinexnames; //!< Имена RINEX-файлов
	int gpsphase; //!< Выбор фазы GPS: 0=Civil,1=Precise
	int gpsrange; //!< Выбор кода GPS: 0=C1P2, 1=P1P2, 2=C1C2, 3=P1C2
	int glophase; //!< Выбор фазы ГЛОНАСС: 0=СТ,1=ВТ
	int glorange; //!< Выбор кода ГЛОНАСС: 0=C1P2, 1=P1P2, 2=C1C2, 3=P1C2
	std::string igsdir; //!< Директория с продуктами IGS
	std::string antex; //!< Имя Antex-файла
	std::string clktemplate; //!< Шаблон формирования имен RINEX-Clock-файлов
	std::string sp3template; //!< Шаблон формирования имен SP3-файлов
	std::string snxtemplate; //!< Шаблон формирования имен SINEX-файлов
	std::string trotemplate; //!< Шаблон формирования имен SINEX-Tropo-файлов
	std::string finalsfile; //!< Файл с ПВЗ

	//Настройки уточняемых параметров
	int resample; //!< Шаг прореживания псевдодальности на первом этапе МНК
	//Координаты БИС
	bool stexactcoord; //!< Признак того, что заданы точные координаты БИС
	bool sinexexact; //!< Признак того, что точные координаты БИС берутся из SINEX-файла
	libgnss::real stcrdstep; //!< Шаг уточнения координат БИС
	libgnss::real st_x, st_y, st_z; //!< Точные координаты БИС (если установлен признак)
	std::string crdframe; //!< Система координат для точных координат БИС
	//Задержка сигнала в тропосфере
	std::string mapfunc; //!< Отображающая функция тропосферы
	std::string tromodel; //!< Модель тропосферной задержки
	bool tropogradient; //!< Включить градиенты зенитной задержки
	bool usesinextropo; //!< Брать тропосферный параметр из SINEX-файлов
	libgnss::real tropostep; //!< Шаг уточнения параметров тропосферы
	//Уход часов БИС
	bool strinexclock; //!< Не уточнять уход часов БИС (брать из RINEX-Clock)
	//Список НКА
	std::vector < std::string > adj_satnames; //!< Какие НКА задействовать при уточнении?
	//Параметры имитации
	bool precsatclockimit; //!< Использовать точные часы НКА при имитации
	bool allowsatclockinterp; //!< Интерполировать по времени ухода часов НКА
	bool usenavorbit; //!< Использовать орбиты НКА и оперативной информации
	//!< при имитации
	bool allowrecclockinterp; //!< Вычислять уход часов БИС в промежуточные
	std::vector < std::string > imit_satnames; //!< Какие НКА задействовать при имитации?
	int urranumpoints; //!< Число точек для численного дифференцирования при вычислении URR и URA
	int urraorder; //!< Порядок численного дифференцирования для вычисления URR и URA.

	//Параметры генерации отчета
	std::string outputdir; //!< Директория для вывода отчета
	bool phasetxt; //!< Выводить невязку моделирования фазы в текстовые файлы
	bool rangetxt; //!< Выводить невязку псевдодальностей в текстовый файл
	bool urretxt; //!< Выводить в текстовый файл User Range Rate Arror
	bool uraetxt; //!< Выводить в текстовый файл User Range Acceleration Arror
	bool phasepng; //!<Строить графики невязки фазы
	bool rangepng; //!< Строить графики невязки псевдодальности
	bool urrepng; //!< Строить графики User Range Rate Arror
	bool uraepng; //!< Строить графики User Range Acceleration Arror
	std::string phtxttempl; //!< Формат названия текстовых файлов для фазы
	std::string rtxttempl; //!< Формат названия текстовых файлов для псевдодальности
	std::string urretmpl;//!< Шаблон имени файла для вывода URRE
	std::string uraetmpl;//!< Шаблон имени файла для вывода URAE
	bool satcount; //!< Текстовый файл с числом видимых НКА
	std::string satcounttemplate; //!< Шаблон имени файла графика видимости

	bool overview; //!< Создать краткий отчет
	std::string overviewname; //!< Имя краткого отчета относительно папки вывода
	bool errmode_stddev; //!< Определять ошибку по СКО
	std::set<libgnss::real> phaseerrdivision; //!< Границы интервалов градации величины ошибки фазы
	std::set<libgnss::real> rangeerrdivision; //!< Границы интервалов градации величины ошибки псевдодальности
	std::set<libgnss::real> urredivision; //!< Границы интервалов градации величины URRE
	std::set<libgnss::real> uraedivision;//!< Границы интервалов градации величины URAE

	//Дампы/восстановление из дампа
	bool loaddump; //!< Создать дамп базы после загрузки
	bool adjdump; //!< Создать дамп базы после уточнения параметров
	int stage; //!< Стадия начала работы: 0) загрузка 1) уточнение 2) имитация 3) генерация краткого отчета
	std::string pltvis; //!< Имя скрипта GNUPLOT для видимости НКА
	std::string pltres; //!< Имя скрипта GNUPLOT для невязок
	std::string plturr; //!< Имя скрипта GNUPLOT для URRE
	std::string pltura;//!< Имя скрипта GNUPLOT для URRA

	//Удаление коротких дуг
	char smallarcs;

	//Отброс по зенитному углу
	int maxzenith_ls;
	int since_iter;
	int maxzenith_imit;
	bool still_draw;

	//Изменённые глобальные настройки обработчика (Settings)
	std::map<std::string,std::map<std::string,std::map<std::string, std::string> > > settings;

	PPPOptions();

	std::string getSettingsTable() const;
};

const std::string OnlyCheck = "-check"; //Проверить введённые параметры
const std::string ShowGUI = "-gui"; //Показать графический интерфейс в любом случае
const std::string RinexNames = "-rnx"; //Считать файл RINEX
const std::string StationName = "-name"; //Имя БИС из C-кадра
const std::string CFrameNames = "-cfr";//Считать файл с C-кадрами
const std::string FileIDX = "-idx";//Номер обрабатываемого файла
const std::string GPSPhase = "-gph"; //Режим фазы GPS
const std::string GPSRange = "-grn"; //Режим псевдодальности GPS
const std::string GLOPhase = "-rph"; //Режим фазы ГЛОНАСС
const std::string GLORange = "-rrn"; //Режим псевдодальности ГЛОНАСС
const std::string IGSDir = "-igs";//Задать директорию с продуктами IGS
const std::string Antex = "-atx"; //Имя Antex-файла
const std::string ClkTmpl = "-clk";//Шаблон имен RINEX-Clock-файлов
const std::string SP3Tmpl = "-sp3";//Шаблон имен SP3-файлов
const std::string SNXTmpl = "-snx";//Шаблон имен SInEx-файлов
const std::string TroTmpl = "-tro";//Шаблон имен SInEx-Tropo-файлов
const std::string ERPFinals = "-erp";//Имя файла finals.2000A
const std::string Resample = "-rsm"; //Шаг прореживания измерений для 1-го этапа МНК
const std::string StCrdStep = "-sst"; //Шаг уточнения координат БИС
const std::string ExactCoords = "-crd";//Задать точные координаты БИС
const std::string SNXCoords = "-scrd";//Брать точные координаты БИС из SInEx-файлов
const std::string MapFunc = "-mf";//Отображающая функция тропосферы
const std::string TroModel = "-tmd";//Тип модели тропосферы
const std::string TropoGradient = "-tgr";//Использовать градиент тропосферы
const std::string SinexTropo = "-stro";//Брать тропосферный параметр из SInEx-файлов
const std::string TropoStep = "-trs"; //Шаг уточнения параметров тропосферы
const std::string RClockStation = "-rсlk"; //Не уточнять уход часов БИС
const std::string ChooseSats = "-svs"; //Какие НКА задействовать при уточнении
const std::string SatClkImit = "-sclk"; //Использовать точный уход часов НКА при имитации
const std::string UseNavOrbit = "-nav"; //Использовать орбиты НКА из опер. инф-и при имитации
const std::string AllowSClkInt = "-scint"; //Интерполировать уход часов НКА
const std::string AllowRClkInt = "-scint"; //Интерполировать уход часов НКА
const std::string ChooseImitSats = "-isvs"; //Какие НКА задействовать при имитации
const std::string URRNumPoints = "-unp"; //Число узлов для численного дифференцирования дальности
const std::string URROrder = "-uord"; // Порядок дифференцирования дальности
const std::string OutputDir = "-out"; //Директория для вывода
const std::string PhaseRes = "-phr"; //Выводить в текстовые файлы невязки фазы
const std::string RangeRes = "-prr"; //Выводить в текстовые файлы невязки псевдодальности
const std::string URRERes = "-urr"; //Выводить в текстовые файлы URRE
const std::string URAERes = "-ura"; //Выводить в текстовые файлы URAE
const std::string PhasePNG = "-phpng"; //Генерировать графики невязок фазы
const std::string RangePNG = "-prpng"; //Генерировать графики невязок псевдодальности
const std::string URREPng = "-urrpng";// Строить графики URRE
const std::string URAEPng = "-urapng"; //Строить графики URAE
const std::string SatCount = "-vis"; //Генерировать файл с числом видимых НКА
const std::string Overview = "-ovr"; // Генерировать краткий отчет
const std::string ErrGradMode = "-esdev"; //Режим определение размера ошибок по СКО
									//(по умолчанию, по равномерной норме)
const std::string ErrorGradationPhase = "-phe"; //Добавить границу градации ошибок
const std::string ErrorGradationRange = "-pre"; //Добавить границу градации ошибок
const std::string ErrorGradationURRE = "-urrg"; //Добавить границу градации ошибок
const std::string ErrorGradationURAE = "-urag"; //Добавить границу градации ошибок

const std::string ErrorNeighbourhood = "-enh"; //Ширина по времени графика вокруг аномалии
const std::string LoadDump = "-ldmp"; //Сделать дамп после загрузки
const std::string AdjustDump = "-admp"; //Сделать дамп после уточнения
const std::string Stage = "-stg"; //Загрузиться из дампа
const std::string SetSettings = "-set"; //Изменить глобальную настройку обработчика

const std::string PltVis = "-pltvis"; //Имя скрипта GNUPLOT для видимости НКА
const std::string PltRes = "-pltres"; //Имя скрипта GNUPLOT для невязок
const std::string PltURR = "-plturr"; //Имя скрипта GNUPLOT для URRE
const std::string PltURA = "-pltura"; //Имя скрипта GNUPLOT для URAE

const std::string smallArcs = "-sma"; //Критерий коротких дуг

const std::string ZenithLS = "-zenls"; //Отброс по зенитному углу при решении МНК
const std::string ZenithImit = "-zenim"; //Отброс по зенитному углу при имитации

int parseCMDLine (int argc, char ** argv, PPPOptions & r);

#endif

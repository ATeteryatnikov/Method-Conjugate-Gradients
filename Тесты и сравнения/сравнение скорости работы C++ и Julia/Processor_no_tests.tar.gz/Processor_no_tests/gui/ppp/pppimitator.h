#ifndef PPPIMITATOR_H_
#define PPPIMITATOR_H_

#include <map>
#include <filespool.hpp>
#include <fstream>
#include <DBTableCollection.h>
#include <observables.h>
#include <readcframe.h>
#include <pppoptions.h>
#include <Kinematic.h>
#include <vto.h>
#include <StdTables.h>
#include <ParamTrajectory.h>
#include <TimeShift.h>
#include <Pseudorange.h>
#include <PhaseAmbiguity.h>
#include <readRINEXNavGLO.h>

class FilesPool;

/**
 * @brief Имитатор, использующий навигационную информацию из C-кадров
 *
 *
 * Имитатор принимает измерительные данные и оперативную информацию из C-кадра и
 * выполняет с ними следующие действия:
 *
 * 1) Пишет информацию в файл видимости НКА в зависимости от ситуации:
 * а) Если измерение совпадает по времени с разрывом фазы
 * б) Если измерение находится внутри интервала непрерывности фазы
 * в) Если измерение лежит вне отрезков непрерывности фазы (было отбраковано).
 *
 * 2) Отбрасывает измерения, для которых нет ухода часов. Если уход часок НКА
 * берётся из оперативной информации, то он интерполируется; если уход часов НКА
 * берётся из Clock-файлов, то он интерполируется только при наличии галочки
 * "Интерполировать уход часов НКА". Уход часов БИС всегда есть только на те
 * моменты времени, на которые был уход часов НКА в Clock-файлах. Если
 * стоит галочка "Вычислять уход часов БИС в промежуточные моменты времени",
 * то уход часов БИС будет уход часов БИС будет найден с использованием всех
 * измерений данной эпохи.
 *
 * 3) Если уход часов БИС вычислен при обработке или интерполирован, то
 * выполняется имитация фазовых измерений и выводится в файл.
 *
 * 4) Производится имитация псевдодальности и выводится в файл.
 *
 * 5) Для каждого НКА создаётся список моментов времени, в которые невязка
 * оказалась в пределах градации. !!!
 */
class ImitationUsingNavData
{
private:
	string imitlogfn;
	libgnss::ExceptionsLog l;

	class ImitationObservationParser : public libgnss::ObservablesLoader
	{
		friend class ImitationUsingNavData;
	private:
		int r1t, r2t, l1t, l2t;
		ImitationUsingNavData * parent;
		ImitationObservationParser(ImitationUsingNavData * parent,
								   char navsys, int obs_src_id,
								   const string & p1,
								   const string & p2,
								   const string & l1,
								   const string & l2);

		/**
		 * Убирает ионосферу и передаёт данные методу
		 * @ref ImitationUsingNavData::acceptObsData().
		 */
		virtual void loadObservables(int sat_history_id, libgnss::real t,
									 const map < int , libgnss::real > & data,
									 const map < int, int> & flags);

		/**
		 * @brief Присваивает новое значение obs_src_id имитатору
		 * @param new_obs_src_id Новый идентификатор БИС
		 */
		virtual void setNewObsSrcID (int new_obs_src_id);
	};

	class ImitationGLONavDataParser : public libgnss::GLONASSNavDataLoader
	{
		friend class ImitationUsingNavData;
		ImitationUsingNavData * parent;

		ImitationGLONavDataParser(ImitationUsingNavData * parent);

		virtual void loadNavData(int orb_slot, libgnss::real t,
						libgnss::real delta_tau,
						libgnss::real gamma_n, libgnss::real tau_n,
						libgnss::real x, libgnss::real y, libgnss::real z,
						libgnss::real vx, libgnss::real vy, libgnss::real vz,
						libgnss::real ax, libgnss::real ay, libgnss::real az,
						int freq_n, bool BN, int E, int m, libgnss::real Ft);
	};

	class ImitationGPSNavDataParser : public libgnss::CFrameGPSNavDataParser
	{
		friend class ImitationUsingNavData;
		ImitationUsingNavData * parent;

		ImitationGPSNavDataParser(ImitationUsingNavData * parent);
		virtual void operator() (tblHdr_t*hdr, tblTmPrmGps_t*tmprm,
								tblOprGps_t*oper );
	};

	std::set<int> satlist;

	ImitationObservationParser * gloobsparser;
	ImitationObservationParser * gpsobsparser;
	ImitationGLONavDataParser * glonavparser;
	ImitationGPSNavDataParser * gpsnavparser;
	libgnss::ObservablesLeastSquaresProblem * lsp;
	int obs_src_id;
	libgnss::DBTableCollection * tcol;
	libgnss::GLONASSFrequencySlots * gslots;
	libgnss::ParamPhaseAmbiguity * phambig;
	libgnss::ITRFTranslation * itrft;
	libgnss::DBTable * intervals;
	libgnss::Frames * frm;
	libgnss::SatelliteHistory * history;
	libgnss::ParamTrajectory * traj;
	libgnss::ClockBias * clkbias;
	libgnss::ObservableTypes * obstypes;
	PPPOptions options;
	libgnss::ObservationSource * obssrc;
	libgnss::Markers * markers;
	int pz90_idx;
	int wgs84_idx;
	vector<int> gcrscoords;
	string markername;
	int lglo, rglo, lgps, rgps;

	//Неделя GPS, с которой начинаются измерительные данные
	int begingpsw;

	struct CyclicWindow
	{
		int npoints;
		vector<libgnss::real> arguments;
		vector<libgnss::real> values;
	};

	//! Для каждого НКА: окно для аппроксимации SISRE для нахождения URE и URA
	map<int, CyclicWindow> ura;

	//! Отображение: Номер НКА -> момент времени нав. информации для ГЛОНАСС
	map<int,libgnss::real> navdatat0_glo;

	map<int,pair<libgnss::real,libgnss::real> > navdatat0_gps;

	//! Отображение: Номер НКА-> межчастотная задержка L1-L2
	map<int,libgnss::real> l1_l2;

	//! Отображение: Номер НКА -> Пара (кодовое измерение, измерение фазы)
	map<int, pair < libgnss::real, libgnss::real > > obsdata;

	//! Сымитированные значения, аналогичные obsdata
	map<int, pair < libgnss::real, libgnss::real > > imitdata;

	//! Момент времени, на которую запоминаются измерительные даныне
	libgnss::real curobst;

	FilesPool * filespool;

	void imitateEpoch();

public:

	/**
	 * @brief Указывает новый идентификатор БИС
	 * @param newobssrcid Новый идентификатор БИС
	 *
	 * При получении нового идентификатора БИС необходимо выбрать новое имя
	 * маркера для именования выходных файлов.
	 */
	void setNewObsSrcID(int newobssrcid);

	/**
	 * @brief ImitationUsingNavData Конструктор имитатора
	 * @param tcol Коллекция таблиц
	 * @param glophasemode Канал фазы ГЛОНАСС: стандартной или высокой точности
	 * @param glorangemode Режим псевдодальности ГЛОНАСС: C1P2, P1P2, C1C2, P1C2
	 * @param gpsphasemode Канал фазы GPS: стандартной или высокой точности
	 * @param gpsrangemode Режим псевдодальности GPS: C1P2, P1P2, C1C2, P1C2
	 * @param allowstaclkinterp Допускать интерполяцию ухода часов БИС
	 * @param allowsatclkinterp Допускать интерполяцию ухода часов НКА
	 * @param usenavorbit Использовать орбиты НКА из оперативной информации
	 * @param useprecsatclk Использовать уход часов НКА из таблицы time_shift
	 */
	ImitationUsingNavData(libgnss::DBTableCollection *tcol,
						  libgnss::DBTable * intervals,
						  int obs_src_id,
						  const PPPOptions & options,
						  const set<int> & satlist);

	~ImitationUsingNavData();

	/**
	 * @brief Принимает и запоминает измерительную информацию.
	 * @param t Момент времени, секунды TAI от 1 янв. 2000
	 * @param sat_his_id Идентификатор НКА
	 * @param obsdata Пара (кодовое измерение, измерение фазы)
	 *
	 * Когда эпоха прочитана из C-кадра до конца (т.е. появляется новое значение
	 * момента времени t), выполняется имитация измерительных данных, вывод их
	 * в файлы, и т.д.
	 */
	void acceptObsData(libgnss::real t, int sat_his_id,
					   const pair<libgnss::real,libgnss::real> & obsdata);

	/**
	 * @brief Принимает и размножает оперативную информацию из C-кадра
	 * @param hdr Заголовок C-кадра
	 * @param tmprm Информация о моменте времени
	 * @param oper Оперативная информация
	 */
	void acceptGPSNavData(tblHdr_t*hdr, tblTmPrmGps_t*tmprm,
						  tblOprGps_t*oper);

	/**
	* @brief Принимает и размножает оперативную информацию из C-кадра
	* @param hdr Заголовок C-кадра
	* @param tmprm Информация о моменте времени
	* @param oper Оперативная информация
	*/
	void acceptGLONavData(int orb_slot, libgnss::real t,libgnss::real delta_tau,
						  libgnss::real gamma_n, libgnss::real tau_n,
						  libgnss::real x, libgnss::real y, libgnss::real z,
						  libgnss::real vx, libgnss::real vy, libgnss::real vz,
						  libgnss::real ax, libgnss::real ay, libgnss::real az,
								  int freq_n, bool BN, int E);

	inline libgnss::ObservablesLoader * GLONASSLoader()
	{
		return gloobsparser;
	}

	inline libgnss::ObservablesLoader * GPSLoader()
	{
		return gpsobsparser;
	}

	inline libgnss::GLONASSNavDataLoader * GLONavDataLoader()
	{
		return glonavparser;
	}

	inline libgnss::CFrameGPSNavDataParser * GPSNavDataLoader()
	{
		return gpsnavparser;
	}
};

#endif

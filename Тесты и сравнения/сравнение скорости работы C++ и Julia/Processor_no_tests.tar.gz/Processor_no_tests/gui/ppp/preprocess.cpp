#include <preprocess.h>
#include <ppp.h>
#include <fstream>
#include <RINEXClock.h>
#include <testcommon.h>
#include <igstempledit.h>

using namespace libgnss;

PPPObservablesParser_::PPPObservablesParser_(DBTableCollection *col, const string &clkfilenametemplate,
		bool stationclockcut, const set<int> &sat_ids, int obs_src_id,
		char int_criterion, char navsys, PPPObservablesParser *parent,
		string p1denotement, string p2denotement, string l1denotement,
		string l2denotement)
	: ObservablesLoader(col,obs_src_id,int_criterion,navsys,p1denotement,
						p2denotement,l1denotement,l2denotement)
{
	this->parent = parent;
	this->sat_ids = sat_ids;
	clktemplate = clkfilenametemplate;
	chkclk_sat<<1<<0<<0<<(real)1.0l;
	chkclk_rec<<0<<obs_src_id<<0<<(real)1.0l;
	this->stationclockcut = stationclockcut;
	bias = (ClockBias*)(tcol->getTable("time_shift"));
	ObservableTypes * otypes = (ObservableTypes*)
			(col->getTable("observable_types"));
	obs_ids.insert(otypes->getObservableTypeID(navsys, p1denotement));
	obs_ids.insert(otypes->getObservableTypeID(navsys, p2denotement));
	obs_ids.insert(otypes->getObservableTypeID(navsys, l1denotement));
	obs_ids.insert(otypes->getObservableTypeID(navsys, l2denotement));
}

bool PPPObservablesParser_::loadClockFile(real t)
{
	int weekt0, dayt0; real fract0;
	UTCDateTime::fromTAIJ2000(t).getGPSWeekDayFrac(weekt0,dayt0,fract0);
	//Если этот день уже загружен, то другой clk-файл грузить не надо.
	if (parent->loadeddays.find(pair<int,int>(weekt0,dayt0))!=
			parent->loadeddays.end())
		return false;

	//Получить имя Clock-файла
	string clkfilename_t = IGSfilenameFromTemplate(clktemplate,
					stationname, "%SNN", weekt0, dayt0,fract0);
	//Проверить ещё раз, вдруг имя Clock-файла нестандартно
	if (parent->loadedclk.find(clkfilename_t) !=
			parent->loadedclk.end())
		return false;
	//Загрузить clk-файл
	ifstream clkfile (clkfilename_t.c_str());
	if (!(clkfile.is_open()))
	{
		cout<<"Предупреждение: clock-файл "<<clkfilename_t
		   <<" не найден. Все измерительные данные за соответствующий период "
		  <<"будут отброшены."<<endl;
	}
	else
	{

		//Попробовать загрузить clock-файл
		cout<<"Чтение clock-файла: "<<clkfilename_t<<endl;
		try
		{
			readRINEXClock((bias->getBase()),clkfile);
			cout<<"clock-файл прочитан. Продолжение загрузки измерительных "
				  <<"данных"<<endl;
		}
		catch (const exception & e)
		{
			cout<<"Предупреждение: clock-файл "<<clkfilename_t<<
			" не удалось прочитать. Все измерительные данные за соответствующий "
			   <<"период будут отброшены."<<endl
			  <<"Причина: "<<e.what()<<endl;
		}
		clkfile.close();

	}
	//Запомнить, что мы загрузили Clock-файл
	parent->loadeddays.insert(pair<int,int>(weekt0,dayt0));
	parent->loadedclk.insert(clkfilename_t);
	return true;
}


bool PPPObservablesParser_::cutObservables(int sat_history_id, real t,
											   int obstype)
{
	chkclk_sat[1] = sat_history_id;
	chkclk_sat[3] = t;
	if (stationclockcut)
		chkclk_rec[3] = t;
	//Проверить, существует ли уход часов НКА
	bool hasclock = true;
	if (bias->find(chkclk_sat,t*1e-15).isEnd())
		hasclock = false;
	if (stationclockcut && bias->find(chkclk_rec,t*1e-15).isEnd())
		hasclock = false;
	if (hasclock == false)
	{
		//Попробовать загрузить clock-файл
		if (loadClockFile(t) == false)
			return true;
		//Попробовать снова найти уход часов
		hasclock = true;
		if (bias->find(chkclk_sat).isEnd())
			hasclock = false;
		if (stationclockcut && bias->find(chkclk_rec).isEnd())
			hasclock = false;
		if (hasclock == false)
			return true;
	}
	return false;
}

void PPPObservablesParser_::loadObservables(int sat_history_id,
				real t, const map<int, real> &data, const map<int, int> &flags)
{
	if (sat_ids.find(sat_history_id) == sat_ids.end())
		return;
	else
		ObservablesLoader::loadObservables(sat_history_id,t,
												 data,flags);
}

void PPPObservablesParser_::setNewObsSrcID(int new_obs_src_id)
{
	ObservablesLoader::setNewObsSrcID(new_obs_src_id);
	ObservationSource * obssrc = (ObservationSource*)
			(tcol->getTable("observation_source"));
	Markers * mrk = (Markers*)(tcol->getTable("markers"));
	try
	{
		int mrkid = (*obssrc)[new_obs_src_id][0].toInt();
		stationname = mrk->read(mrkid)[0].toString();
	}
	catch(const KeyNotFoundException & e)
	{
		stationname = "%MRKN";
	}
}

int PPPObservablesParser_::nextInterval (int sat_history_id, int & i,
						int & count, real & length, vector < bool > & cut)
{
	int result = ObservablesLoader::nextInterval(sat_history_id,i,count,
													   length,cut);
	if (result==-1)
		return -1;
	real tbegin = getEpoch(sat_history_id,result);
	real tend = getEpoch(sat_history_id, i);
	parent->intervals->insertRow(Tuple()<<this->getObsSrcID()
								 <<sat_history_id<<tbegin,
								 Tuple()<<tend<<2);
	return result;
}


void PPPObservablesParser_::loadObservablesArc(int sat_history_id, int begin,
											   int end, const vector<bool> &cut)
{
	parent->intervals->updateCell(Tuple()<<getObsSrcID()
								 <<sat_history_id
								 <<getEpoch(sat_history_id,begin),
								 1,0);
	ObservablesLoader::loadObservablesArc(sat_history_id,begin,end,cut);
}

void PPPObservablesParser_::loadObservable(int sat_history_id,
										   int obstype, real t, real obs,
										   int flag)
{
	if (obs_ids.find(obstype)!=obs_ids.end())
		ObservablesLoader::loadObservable(sat_history_id,obstype,t,obs,
										  flag);
}

void chooseObsDenotement(string & r1, string & r2, string & l1,
						 string & l2, int phasemode, int rangemode,
						 int rinexver)
{
	if (rinexver == 2)
	{
		l1 = "L1";
		l2 = "L2";
		if (rangemode == 0)
		{
			r1 = "C1";
			r2 = "P2";
		}
		else if (rangemode == 1)
		{
			r1 = "P1";
			r2 = "P2";
		}
		else if (rangemode == 2)
		{
			r1 = "C1";
			r2 = "C2";
		}
		else if (rangemode == 3)
		{
			r1 = "P1";
			r2 = "C2";
		}
	}
	else if (rinexver == 3)
	{
		if (phasemode == 0)
		{
			l1 = "L1C";
			l2 = "L2C";
		}
		else
		{
			l1 = "L1P";
			l2 = "L2P";
		}
		if (rangemode == 0)
		{
			r1 = "C1C";
			r2 = "C2P";
		}
		else if (rangemode == 1)
		{
			r1 = "C1P";
			r2 = "C2P";
		}
		else if (rangemode == 2)
		{
			r1 = "C1C";
			r2 = "C2C";
		}
		else if (rangemode == 3)
		{
			r1 = "C1P";
			r2 = "C2C";
		}
	}
	else
		throw NotImplementedException("Стандарт именования типов измерительных "
							"данных RINEX v."+Variant(rinexver).toInt());
}

PPPObservablesParser::PPPObservablesParser(DBTableCollection *tcol,
										   int obs_src_id,
										   const string &clkfilenametemplate,
										   int glophasemode,
										   int glorangemode,
										   int gpsphasemode,
										   int gpsrangemode,
										   bool stationclockcut,
										   const set<int> &sat_ids,
										   DBTable *intervals,
										   char smallarc,
										   int rinexver)
{
	this->intervals = intervals;
	string r1glo;
	string r2glo;
	string l1glo;
	string l2glo;

	string r1gps;
	string r2gps;
	string l1gps;
	string l2gps;
	chooseObsDenotement(r1glo,r2glo,l1glo,l2glo,glophasemode,glorangemode,
						rinexver);
	chooseObsDenotement(r1gps,r2gps,l1gps,l2gps,gpsphasemode,gpsrangemode,
						rinexver);
	gloparser = new PPPObservablesParser_(tcol,clkfilenametemplate,
										  stationclockcut,sat_ids,obs_src_id,
										  smallarc,'R',this,r1glo,r2glo,
										  l1glo,l2glo);
	gpsparser = new PPPObservablesParser_(tcol,clkfilenametemplate,
										  stationclockcut,sat_ids,obs_src_id,
										  smallarc,'G',this,r1glo,r2glo,
										  l1glo,l2glo);
	glofrs = new GLONASSNavDataReader(tcol,false,false,true);
}

PPPObservablesParser::~PPPObservablesParser()
{
	delete gloparser;
	delete gpsparser;
	delete glofrs;
}

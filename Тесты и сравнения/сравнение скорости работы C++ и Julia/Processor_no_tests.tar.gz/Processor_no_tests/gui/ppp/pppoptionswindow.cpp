#include <pppoptionswindow.h>
#include <outputviewer.h>
#include <ppphelp.h>
#include <Frames.h>
#include <pppmultithread.h>

#include <QPalette>
#include <QCheckBox>
#include <QGroupBox>
#include <QToolButton>
#include <pppoptions.h>
#include <QBoxLayout>
#include <QTabWidget>
#include <QGridLayout>
#include <QPushButton>
#include <QLabel>
#include <igstempledit.h>
#include <QFileDialog>
#include <QSettings>
#include <QCryptographicHash>
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QDebug>
#include <QMenu>
#include <QInputDialog>
#include <QApplication>
#include <QProcess>
#include <QTextEdit>
#include <cmath>
#include <QSet>
#include <QMutex>
#include <QThread>
#include <QSpinBox>
#include <QListWidget>
#include <QRadioButton>
#include <QRegExpCheckEdit.h>
#include <QComboBox>

using namespace libgnss;

SatsList::SatsList(QWidget * parent)
	: QWidget(parent)
{
	QGridLayout * satlistlay = new QGridLayout();
	setLayout(satlistlay);
	satlistlay->setVerticalSpacing(1);
	QStringList satnames;
	for (unsigned int i=1; i<=24; i++)
	{
		QString satnumber = QString::number(i);
		if (satnumber.length() == 1)
			satnumber = "0"+satnumber;
		satnames.push_back("R"+satnumber);
	}
	for (unsigned int i=1; i<=32; i++)
	{
		QString satnumber = QString::number(i);
		if (satnumber.length() == 1)
			satnumber = "0"+satnumber;
		satnames.push_back("G"+satnumber);
	}
	for (unsigned int i=0; i<satnames.size(); i++)
	{
		int Y = i % 4;
		int X = (i-Y)/4;
		QCheckBox * satchkbox = new QCheckBox(satnames[i],this);
		satchkbox->setChecked(true);
		satlistlay->addWidget(satchkbox,Y,X);
		procsatellites.push_back(satchkbox);
	}
	QHBoxLayout * satinvbuttons = new QHBoxLayout();
	QPushButton * invall = new QPushButton(
				QString::fromUtf8("Инвертировать выделение"),this);
	QPushButton * invglo = new QPushButton(
				QString::fromUtf8("Инвертировать выделение НКА ГЛОНАСС"),this);
	QPushButton * invgps = new QPushButton(
				QString::fromUtf8("Инвертировать выделение НКА GPS"),this);
	QPushButton * dsG=new QPushButton(QString::fromUtf8("Убрать GPS"),this);
	QPushButton * dsR=new QPushButton(QString::fromUtf8("Убрать ГЛОНАСС"),this);
	connect(invall,SIGNAL(clicked()),this,SLOT(invertAllSatellites()));
	connect(invgps,SIGNAL(clicked()),this,SLOT(invertGPSSatellites()));
	connect(invglo,SIGNAL(clicked()),this,SLOT(invertGLONASSSatellites()));
	connect(dsG,SIGNAL(clicked()),this,SLOT(deselectGPS()));
	connect(dsR,SIGNAL(clicked()),this,SLOT(deselectGLONASS()));
	satinvbuttons->addWidget(invall);
	satinvbuttons->addWidget(invglo);
	satinvbuttons->addWidget(invgps);
	satinvbuttons->addWidget(dsG);
	satinvbuttons->addWidget(dsR);
	satinvbuttons->addStretch();
	satlistlay->addLayout(satinvbuttons,4,0,1,14);
}

QString SatsList::satsliststr()
{
	QStringList satnames_l;
	for (int i=0; i<procsatellites.size(); i++)
		if (procsatellites[i]->isChecked())
			satnames_l.push_back(procsatellites[i]->text());
	return satnames_l.join(",");
}

void SatsList::setChecked(const std::vector < std::string > & sl)
{
	QSet < QString>  satnames_set;
	for (unsigned int i=0; i<sl.size(); i++)
		satnames_set.insert(QString::fromLocal8Bit(sl[i].data()));
	for (int i=0; i<procsatellites.size(); i++)
		procsatellites[i]->setChecked(
					satnames_set.contains(procsatellites[i]->text()));

}

void SatsList::invertAllSatellites()
{
	for (int i=0; i<procsatellites.size(); i++)
		procsatellites[i]->setChecked(!(procsatellites[i]->isChecked()));
}

void SatsList::invertGPSSatellites()
{
	for (int i=0; i<procsatellites.size(); i++)
		if (procsatellites[i]->text().at(0) == QChar('G'))
			procsatellites[i]->setChecked(!(procsatellites[i]->isChecked()));
}

void SatsList::invertGLONASSSatellites()
{
	for (int i=0; i<procsatellites.size(); i++)
		if (procsatellites[i]->text().at(0) == QChar('R'))
			procsatellites[i]->setChecked(!(procsatellites[i]->isChecked()));

}

void SatsList::deselectGLONASS()
{
	for (int i=0; i<procsatellites.size(); i++)
		if (procsatellites[i]->text().at(0) == QChar('R'))
			procsatellites[i]->setChecked(false);
}

void SatsList::deselectGPS()
{
	for (int i=0; i<procsatellites.size(); i++)
		if (procsatellites[i]->text().at(0) == QChar('G'))
			procsatellites[i]->setChecked(false);
}


QString PPPOptionsWindow::rememberoutput=QString::fromUtf8(
			"Выберите ранее сохраненный профиль отчета");

PPPOptionsWindow::PPPOptionsWindow(const PPPOptions &opts)
	:QWidget()
{
	//Считать список систем координат
	DBTableCollection col1;
	Frames frm(&col1);
	try
	{
		col1.readFromFile("coordinates.tc");
	}
	catch (exception & e)
	{
		QMessageBox::critical(this,QString::fromUtf8("Ошибка"),
						QString::fromUtf8("Файл не найден: coordinates.tc"));
		deleteLater();
	}

	QStringList coordsystemslist;
	for(DBTable::DBConstIterator it=frm.const_begin();
		it!=frm.const_end(); ++it)
		if (it[0].toInt()==Frames::FT_ITRS)
			coordsystemslist.push_back(
						QString::fromUtf8(it[1].toString().c_str()));

	obsfiletype = QString::fromStdString(CFrameNames);
	setWindowTitle(QString::fromUtf8("Изучение невязок IGS"));
	QString numre = "^[0-9]+(.[0-9]+)?([eE][-\\+][0-9]+)?$";
	QString numlistre = "^[0-9]+(\\.[0-9]+)?([eE][-\\+][0-9]+)?"
			"(,[0-9]+(\\.[0-9]+)?([eE][-\\+][0-9]+)?)*$";
	connect(this,SIGNAL(destroyed()),this,SLOT(onDestroy()));
	QTabWidget * pages = new QTabWidget(this);
	QWidget * intro = new QWidget(this);
	QWidget * input = new QWidget(this);
	QWidget * ls = new QWidget(this);
	QWidget * imit = new QWidget(this);
	QWidget * report = new QWidget(this);
	QWidget * miscopt = new QWidget(this);
	pages->addTab(intro,QString::fromUtf8("Введение"));
	pages->addTab(input,QString::fromUtf8("Входные данные"));
	pages->addTab(ls,QString::fromUtf8("Оценка уточняемых параметров"));
	pages->addTab(imit,QString::fromUtf8("Моделирование измерений"));
	pages->addTab(report,QString::fromUtf8("Генерация отчета"));
	pages->addTab(miscopt,QString::fromUtf8("Прочие параметры"));
	QVBoxLayout * vblay = new QVBoxLayout();
	vblay->addWidget(pages,1);
	setLayout(vblay);
	QGridLayout * introlayout = new QGridLayout();
	intro->setLayout(introlayout);
	QFile introhtml(":/txtfiles/intro.html");
	introhtml.open(QIODevice::ReadOnly);
	QString helptxt = QString::fromUtf8(introhtml.readAll());
	introhtml.close();
	introlayout->addWidget(new QLabel(helptxt,this),
						   0,0,1,2);
	QPushButton * showhelpbtn = new QPushButton(QIcon(":/menuicons/help.png"),
											 QString::fromUtf8("Подробнее"),
											 this);
	connect(showhelpbtn,SIGNAL(clicked()),this,SLOT(showhelp()));
	introlayout->addWidget(showhelpbtn,1,1);
	introlayout->setColumnStretch(0,1);
	introlayout->setColumnStretch(1,0);

	//Вкладка входных данных
	QVBoxLayout * inputlay = new QVBoxLayout();
	input->setLayout(inputlay);

	//Измерительные данные
	QGroupBox * chooseobs = new QGroupBox(
				QString::fromUtf8("Выбор измерительных данных"),this);
	inputlay->addWidget(chooseobs);
	QGridLayout * chooseobslay = new QGridLayout();
	chooseobslay->setVerticalSpacing(1);
	chooseobslay->setColumnStretch(1,1);
	chooseobs->setLayout(chooseobslay);
	chooserinex = new QRadioButton (QString::fromUtf8("RINEX"),
												   this);
	choosecframe = new QRadioButton(QString::fromUtf8("C-кадр"),
													this);
	stationname = new QLineEdit(this);
	QPushButton * addobs = new QPushButton(QString::fromUtf8("Добавить..."),
										   this);
	QPushButton * remobs = new QPushButton(QString::fromUtf8("Удалить"),
										   this);
	filenames = new QListWidget(this);
	connect(addobs,SIGNAL(clicked()),this,SLOT(addFile()));
	connect(remobs,SIGNAL(clicked()),this,SLOT(removeFile()));
	chooseobslay->addWidget(chooserinex,0,0);
	chooseobslay->addWidget(choosecframe,0,2);
	chooseobslay->addWidget(new QLabel(QString::fromUtf8("Имя БИС:"),this),
							0,3);
	chooseobslay->addWidget(stationname,0,4);
	chooseobslay->addWidget(addobs,1,0);
	chooseobslay->addWidget(remobs,2,0);
	chooseobslay->addWidget(filenames,1,1,3,4);

	QHBoxLayout * obstypeslay = new QHBoxLayout();
	chooseobslay->addLayout(obstypeslay,4,0,1,5);
	fitphaseGLO=new QComboBox(this);
	fitphaseGLO->addItem(QString::fromUtf8("СТ"));
	fitphaseGLO->addItem(QString::fromUtf8("ВТ"));
	fitRangeGLO = new QComboBox(this);
	fitRangeGLO->addItem(QString::fromUtf8("C1P2"));
	fitRangeGLO->addItem(QString::fromUtf8("P1P2"));
	fitRangeGLO->addItem(QString::fromUtf8("C1C2"));
	fitRangeGLO->addItem(QString::fromUtf8("P1C2"));
	fitphaseGPS = new QComboBox(this);
	fitphaseGPS->addItem(QString::fromUtf8("C"));
	fitphaseGPS->addItem(QString::fromUtf8("P"));
	fitRangeGPS = new QComboBox(this);
	fitRangeGPS->addItem(QString::fromUtf8("C1P2"));
	fitRangeGPS->addItem(QString::fromUtf8("P1P2"));
	fitRangeGPS->addItem(QString::fromUtf8("C1C2"));
	fitRangeGPS->addItem(QString::fromUtf8("P1C2"));
	obstypeslay->setSpacing(5);
	obstypeslay->addWidget(new QLabel(
		QString::fromUtf8("Выбор измерений ГЛОНАСС:   "), this));
	obstypeslay->addWidget(new QLabel(
		QString::fromUtf8("Фаза:"), this));
	obstypeslay->addWidget(fitphaseGLO);
	obstypeslay->addWidget(new QLabel(
		QString::fromUtf8("Код:"), this));
	obstypeslay->addWidget(fitRangeGLO);
	obstypeslay->addStretch(1);

	obstypeslay->addWidget(new QLabel(
		QString::fromUtf8("Выбор измерений GPS:   "), this));
	obstypeslay->addWidget(new QLabel(
		QString::fromUtf8("Фаза:"), this));
	obstypeslay->addWidget(fitphaseGPS);
	obstypeslay->addWidget(new QLabel(
		QString::fromUtf8("Код:"), this));
	obstypeslay->addWidget(fitRangeGPS);
	obstypeslay->addStretch(1);

	//Продукты IGS
	QGroupBox * chooseigs = new QGroupBox(QString::fromUtf8("Продукты IGS"),
										  this);
	inputlay->addWidget(chooseigs);
	QGridLayout * chooseigslay = new QGridLayout();
	chooseigslay->setContentsMargins(0,0,0,0);
	chooseigs->setLayout(chooseigslay);
	igs = new IGSDirectoryProfile("SFU","PPP",stationname,coordsystemslist,
								  this);
	chooseigslay->addWidget(igs,0,0);
	QHBoxLayout * finalslay = new QHBoxLayout();
	finalslay->addWidget(new QLabel(
			QString::fromUtf8("Файл с параметрами вращения Земли finals2000A:"),
									this));
	finals = new QLineEdit(this);
	QSettings sets;
	QVariant try_finals = sets.value("LastFinalsFile");
	finalslay->addWidget(finals);
	if (try_finals!=QVariant())
	{
		QString tryfin =try_finals.toString();
		finals->setText(tryfin);
	}
	fbull = new QComboBox(this);
	fbull->addItem("B");
	fbull->addItem("A");
	QToolButton * changeFinals = new QToolButton(this);
	changeFinals->setText("...");
	connect(changeFinals,SIGNAL(clicked()),this,SLOT(changeFinalsFile()));
	finalslay->addWidget(changeFinals);
	finalslay->addWidget(new QLabel(QString::fromUtf8("Бюллетень:"),this));
	finalslay->addWidget(fbull);
	inputlay->addLayout(finalslay);
	inputlay->addStretch();

	//Прочие параметры
	QGridLayout * miscoptlay = new QGridLayout;
	miscoptlay->setVerticalSpacing(1);
	miscopt->setLayout(miscoptlay);
	//Параметры GF-фильтра
	QGroupBox * gf = new QGroupBox(QString::fromUtf8("Поиск разрывов с помощью "
						"геометрически свободной комбинации (GF)"), this);
	miscoptlay->addWidget(gf,0,0,2,1);
	QGridLayout * gfgrid = new QGridLayout();
	gfgrid->setVerticalSpacing(1);
	gf->setLayout(gfgrid);
	usegf = new QCheckBox(QString::fromUtf8("Использовать.  Порог выброса:"),
						  this);
	gfthreshold = new QRegExpCheckEdit(numre, "3e-5", this);
	gfgrid->addWidget(usegf,0,0);
	gfgrid->addWidget(gfthreshold,0,1);
	gfgrid->addWidget(new QLabel(QString::fromUtf8("км."),this),0,2);
	gfgrid->addWidget(new QLabel(QString::fromUtf8("Число узлов для "
					"аппроксимирующего полинома"),this),1,0);
	gfnumpoints = new QSpinBox(this);
	gfnumpoints->setMinimum(3);
	gfnumpoints->setMaximum(100);
	gfgrid->addWidget(gfnumpoints,1,1,1,2);
	connect(gfnumpoints,SIGNAL(valueChanged(int)),this,
				SLOT(setMaximalDegree(int)));
	gforder = new QSpinBox(this);
	gforder->setMinimum(2);
	setMaximalDegree(100);
	gfgrid->addWidget(new QLabel(QString::fromUtf8("Степень аппроксимирующего "
						"полинома"),this),2,0);
	gfgrid->addWidget(gforder,2,1,1,2);
	//Параметры MW-фильтра
	QGroupBox * mw = new QGroupBox(QString::fromUtf8("Поиск разрывов с помощью"
							"линейной комбинации Melbourne-Wubbena"),this);
	miscoptlay->addWidget(mw,0,1,1,3);
	QHBoxLayout * mwlay = new QHBoxLayout;
	mw->setLayout(mwlay);
	usemw = new QCheckBox(QString::fromUtf8("Использовать.  Порог выброса: "),
						  this);
	mwlay->addWidget(usemw);
	mwthreshold = new QRegExpCheckEdit(numre,"4");
	mwlay->addWidget(mwthreshold);
	mwlay->addWidget(new QLabel(QString::fromUtf8("*sigma"),this));
	//Параметры MP-фильтра
	QGroupBox * mp = new QGroupBox(QString::fromUtf8("Поиск разрывов с помощью"
							"многолучевой линейной комбинации"),this);
	miscoptlay->addWidget(mp,1,1,1,3);
	QHBoxLayout * mplay = new QHBoxLayout;
	mp->setLayout(mplay);
	usemp = new QCheckBox(QString::fromUtf8("Использовать.  Порог выброса: "),
						  this);
	mplay->addWidget(usemp);
	mpthreshold = new QRegExpCheckEdit(numre,"4");
	mplay->addWidget(mpthreshold);
	mplay->addWidget(new QLabel(QString::fromUtf8("*sigma"),this));
	minterval = new QRegExpCheckEdit(numre,"60.0",this);
	miscoptlay->addWidget(new QLabel(QString::fromUtf8("Максимальный "
			"пропуск измерений без выброса:"),this),2,1);
	miscoptlay->addWidget(minterval,2,2);
	miscoptlay->addWidget(new QLabel(QString::fromUtf8("сек."),this),2,3);
	usegf->setChecked(true);
	usemp->setChecked(true);
	usemw->setChecked(true);
	//Эти строки перенесены сюда, поскольку эти методы требуют уже
	//созданных usegf, usemp, usemw.
	connect(chooserinex,SIGNAL(toggled(bool)),this,SLOT(rinexToggled(bool)));
	connect(choosecframe,SIGNAL(toggled(bool)),this,SLOT(cframeToggled(bool)));
	choosecframe->setChecked(true);
	//Параметры формирования матрицы МНК
	QGroupBox * weight = new QGroupBox(QString::fromUtf8("Параметры весов "
					"строк МНК"), this);
	miscoptlay->addWidget(weight,2,0,3,1);
	QGridLayout * weightlay = new QGridLayout();
	weightlay->setVerticalSpacing(1);
	weight->setLayout(weightlay);
	accountzenith = new QCheckBox(
		QString::fromUtf8("Домножать строки на косинус зенитного угла"),this);
	weightlay->addWidget(accountzenith,0,0,1,2);
	weightlay->addWidget(new QLabel(QString::fromUtf8(
							 "Предполагаемое СКО погрешности фазы, км"),this),
						 1,0);
	rms_l = new QRegExpCheckEdit(numre,"5e-5",this);
	weightlay->addWidget(rms_l,1,1);
	weightlay->addWidget(new QLabel(QString::fromUtf8(
							"Предполагаемое СКО псевдодальности, км"),this),
						 2,0);
	rms_p = new QRegExpCheckEdit(numre,"1e-3",this);
	weightlay->addWidget(rms_p,2,1);
	//Параметры аппроксимации траектории
	QGroupBox * trajapprox = new QGroupBox(QString::fromUtf8(
					"Параметры аппроксимации траектории НКА"),this);
	miscoptlay->addWidget(trajapprox,4,1,1,3);
	QGridLayout * trajapproxlay = new QGridLayout();
	trajapproxlay->setVerticalSpacing(1);
	trajapprox->setLayout(trajapproxlay);
	trajapproxlay->addWidget(new QLabel(QString::fromUtf8(
			"Максимальный шаг между узлами аппроксимации, сек.: "),this),0,0);
	maxtrajstep = new QRegExpCheckEdit(numre,"1800",this);
	trajapproxlay->addWidget(maxtrajstep,0,1);
	trajapproxlay->addWidget(new QLabel(QString::fromUtf8(
			"Максимальный выход целевого момента времени за \n"
			"пределы множества узлов аппроксимации, сек"),this),1,0);
	maxtrajextr = new QRegExpCheckEdit(numre,"60",this);
	trajapproxlay->addWidget(maxtrajextr,1,1);

	//Контрольные точки
	QGroupBox * entrypoints = new QGroupBox(
				QString::fromUtf8("Создание точек восстановления"),this);
	miscoptlay->addWidget(entrypoints,5,1,2,1);
	QVBoxLayout * entrypointslay = new QVBoxLayout();
	entrypointslay->setSpacing(1);
	entrypoints->setLayout(entrypointslay);
	mkLoadDump = new QCheckBox(
		QString::fromUtf8("Перед уточнением неизвестных параметров"),this);
	mkAdjustDump = new QCheckBox(
		QString::fromUtf8("Перед моделированием измерений"),this);
	entrypointslay->addWidget(mkLoadDump);
	entrypointslay->addWidget(mkAdjustDump);
	//Критерий коротких дуг
	QGroupBox * smallarcs = new QGroupBox(
				QString::fromUtf8("Какие дуги измерительных данных считать "
								  "короткими"),
										  this);
	miscoptlay->addWidget(smallarcs,5,0);
	QHBoxLayout * smallarcs_lay = new QHBoxLayout();
	smallarcs->setLayout(smallarcs_lay);
	count_arc = new QCheckBox(QString::fromUtf8("Менее"),this);
	count_len = new QCheckBox(QString::fromUtf8("Короче"),this);
	minarccount = new QSpinBox(this);
	minarccount->setValue(4);
	minarclen = new QRegExpCheckEdit(numre, "900", this);
	smallarcs_lay->addWidget(count_arc);
	smallarcs_lay->addWidget(minarccount);
	smallarcs_lay->addWidget(new QLabel(QString::fromUtf8("измерений  "),this));
	smallarcs_lay->addWidget(count_len);
	smallarcs_lay->addWidget(minarclen);
	smallarcs_lay->addWidget(new QLabel(QString::fromUtf8("сек."),this));


	QGroupBox * gnuplotoptions = new QGroupBox(
				QString::fromUtf8("Скрипты gnuplot для построения графиков"),
				this);
	miscoptlay->addWidget(gnuplotoptions,6,0,2,1);
	QGridLayout * gnuplotlay = new QGridLayout();
	gnuplotoptions->setLayout(gnuplotlay);
	gnuplotlay->addWidget(new QLabel
			(QString::fromUtf8("Видимость НКА:"),this),
						  0,0);
	gnuplotlay->addWidget(new QLabel
			(QString::fromUtf8("Невязок приближения:"),this),
						  1,0);
	gnuplotlay->addWidget(new QLabel
			(QString::fromUtf8("Ошибки скорости псевдодальности:"),this),
						  2,0);
	gnuplotlay->addWidget(new QLabel
			(QString::fromUtf8("Ошибки ускорения псевдодальности:"),this),
						  3,0);
	gnuplotvis = new QLineEdit(this);
	gnuplotres = new QLineEdit(this);
	gnuploturr = new QLineEdit(this);
	gnuplotura = new QLineEdit(this);
	QToolButton * chGnuplotVis = new QToolButton(this);
	chGnuplotVis->setText("...");
	QToolButton * chGnuplotRes = new QToolButton(this);
	chGnuplotRes->setText("...");
	QToolButton * chGnuplotURR = new QToolButton(this);
	chGnuplotURR->setText("...");
	QToolButton * chGnuplotURA = new QToolButton(this);
	chGnuplotURA->setText("...");

	gnuplotlay->setSpacing(1);

	gnuplotlay->addWidget(gnuplotvis,0,1);
	gnuplotlay->addWidget(chGnuplotVis,0,2);
	gnuplotlay->addWidget(gnuplotres,1,1);
	gnuplotlay->addWidget(chGnuplotRes,1,2);
	gnuplotlay->addWidget(gnuploturr,2,1);
	gnuplotlay->addWidget(chGnuplotURR,2,2);
	gnuplotlay->addWidget(gnuplotura,3,1);
	gnuplotlay->addWidget(chGnuplotURA,3,2);

	connect(chGnuplotVis,SIGNAL(clicked()),this,SLOT(chooseGNUPLOTVis()));
	connect(chGnuplotRes,SIGNAL(clicked()),this,SLOT(chooseGNUPLOTRes()));
	connect(chGnuplotURR,SIGNAL(clicked()),this,SLOT(chooseGNUPLOTURR()));
	connect(chGnuplotURA,SIGNAL(clicked()),this,SLOT(chooseGNUPLOTURA()));

	miscoptlay->setRowStretch(8,2);

	QGroupBox * max_zenith = new QGroupBox(
		QString::fromUtf8("Отбрасывать измерения при превышении зенитного угла"),
		this);
	miscoptlay->addWidget(max_zenith,7,1,1,3);
	QGridLayout * max_zenith_lay = new QGridLayout();
	max_zenith->setLayout(max_zenith_lay);
	max_zenith_lay->addWidget(new QLabel(
			QString::fromUtf8("При решении задачи МНК:"),
								  this),0,0);
	max_zenith_lay->addWidget(new QLabel(
			QString::fromUtf8("При моделировании:"),
								  this),1,0);
	max_zenith_ls = new QSpinBox(this);
	max_zenith_ls->setMinimum(0);
	max_zenith_ls->setMaximum(90);
	max_zenith_imit = new QSpinBox(this);
	max_zenith_imit->setMinimum(0);
	max_zenith_imit->setMaximum(90);
	max_zenith_lay->addWidget(max_zenith_ls,0,1);
	max_zenith_lay->addWidget(max_zenith_imit,1,1);
	max_zenith_lay->addWidget(new QLabel(
			QString::fromUtf8("начиная с итерации"),this),0,2);
	max_zenith_since_iter = new QSpinBox(this);
	max_zenith_since_iter->setMinimum(0);
	max_zenith_since_iter->setMaximum(10);
	max_zenith_lay->addWidget(max_zenith_since_iter,0,3);
	max_zenith_imit_only_stat=new QCheckBox(
		QString::fromUtf8("только при вычислении нормы"));
	max_zenith_lay->addWidget(max_zenith_imit_only_stat,1,2,1,2);

	//Вкладка параметров обработки
	QVBoxLayout * procParamsLay = new QVBoxLayout();
	ls->setLayout(procParamsLay);

	//Настройки параметра "Координаты БИС"
	QGroupBox * stcoordgroup = new QGroupBox(
				QString::fromUtf8("Координаты БИС"), this);
	procParamsLay->addWidget(stcoordgroup);
	QGridLayout * stcoordlay = new QGridLayout();
	stcoordgroup->setLayout(stcoordlay);
	stcoordlay->setVerticalSpacing(1);
	sinexcoords = new QRadioButton(QString::fromUtf8("Взять из SINEX"),this);
	exactcoords = new QRadioButton(QString::fromUtf8("Ввести вручную (в км.):"),
								   this);
	adjustcoords=new QRadioButton(QString::fromUtf8("Вычислить с шагом"),this);
	connect(sinexcoords,SIGNAL(toggled(bool)),this,
			SLOT(sinexStationCoordsToggled(bool)));
	connect(exactcoords,SIGNAL(toggled(bool)),this,
			SLOT(exactStationCoordsToggled(bool)));
	connect(adjustcoords,SIGNAL(toggled(bool)),this,
			SLOT(adjustStationCoordsToggled(bool)));
	stcoordstep = new QRegExpCheckEdit(numre,"86400.0",this);
	stx = new QRegExpCheckEdit(numre,"0", this);
	sty = new QRegExpCheckEdit(numre,"0", this);
	stz = new QRegExpCheckEdit(numre,"0", this);
	QVariant previousCoords = sets.value("StationCoords");
	if (previousCoords != QVariant())
	{
		QStringList stcoords = previousCoords.toStringList();
		if (stcoords.length() == 3)
		{
			bool okx, oky, okz;
			double st_x = (stcoords[0].toDouble(&okx)),
					st_y = (stcoords[1].toDouble(&oky)),
					st_z = (stcoords[2].toDouble(&okz));
			if (okx && oky && okz)
			{
				stx->setNumber(okx);
				sty->setNumber(oky);
				stz->setNumber(okz);
			}
		}
	}
	stcoordsys = new QComboBox(this);
	stcoordsys->setEditable(true);
	stcoordsys->addItems(coordsystemslist);
	stcoordsys->setCurrentIndex(coordsystemslist.size()-1);\
//	stcoordsys->addItem(QString::fromUtf8("IGb08"));
//	stcoordsys->addItem(QString::fromUtf8("ITRF08"));
//	stcoordsys->addItem(QString::fromUtf8("IGS05"));
//	stcoordsys->addItem(QString::fromUtf8("ITRF05"));
//	stcoordsys->addItem(QString::fromUtf8("ITRF00"));
//	stcoordsys->addItem(QString::fromUtf8("WGS-05"));
//	stcoordsys->addItem(QString::fromUtf8("WGS84"));
//	stcoordsys->addItem(QString::fromUtf8("ПЗ-90"));
//	stcoordsys->addItem(QString::fromUtf8("ПЗ-90.02"));
//	stcoordsys->addItem(QString::fromUtf8("ПЗ-90.11"));

	QHBoxLayout * adjstcoords = new QHBoxLayout();
	adjstcoords->addWidget(stcoordstep);
	adjstcoords->addWidget(new QLabel(QString::fromUtf8("сек."),this));
	stcoordlay->addWidget(adjustcoords, 0,0);
	stcoordlay->addLayout(adjstcoords, 0, 1);

	QHBoxLayout * exactcoordslay = new QHBoxLayout();
	exactcoordslay->addWidget(new QLabel(
								  QString::fromUtf8("X:"), this),0);
	exactcoordslay->addWidget(stx,1);
	exactcoordslay->addWidget(new QLabel(
								  QString::fromUtf8("Y:"), this),0);
	exactcoordslay->addWidget(sty,1);
	exactcoordslay->addWidget(new QLabel(
								  QString::fromUtf8("Z:"), this),0);
	exactcoordslay->addWidget(stz,1);
	exactcoordslay->addWidget(new QLabel(
							QString::fromUtf8("Система координат:"),this));
	exactcoordslay->addWidget(stcoordsys);
	exactcoordslay->setSpacing(3);
	stcoordlay->addWidget(exactcoords, 1,0);
	stcoordlay->addLayout(exactcoordslay,1,1,2,1);
	stcoordlay->addWidget(sinexcoords,3,0);
	adjustcoords->setChecked(true);

	//Настройка параметра "Задержка сигнала в тропосфере"
	QGroupBox * troposettings = new QGroupBox(
				QString::fromUtf8("Задержка сигнала в тропосфере"),this);
	procParamsLay->addWidget(troposettings);

	QGridLayout * tropolay = new QGridLayout();
	troposettings->setLayout(tropolay);
	tropolay->setVerticalSpacing(1);
	adjusttropo = new QRadioButton(
				QString::fromUtf8("Вычислить с шагом:"),this);
	adjusttropo->setChecked(true);
	sinextropo = new QRadioButton(
				QString::fromUtf8("Использовать SINEX-Tropo "
					"(настройте параметры модели строго в соответствии с"
					" форматом используемых SINEX-Tropo-файлов)."),this);
	connect(adjusttropo,SIGNAL(toggled(bool)),this,
			SLOT(adjustTropoToggled(bool)));
	connect(sinextropo,SIGNAL(toggled(bool)),this,
			SLOT(sinexTropoToggled(bool)));
	tropostep = new QRegExpCheckEdit(numre,"14400.0", this);
	tropolay->setColumnStretch(0,0);
	tropolay->setColumnStretch(1,1);
	tropolay->setColumnStretch(2,0);
	tropolay->addWidget(adjusttropo,0,0);
	tropolay->addWidget(tropostep,0,1);
	tropolay->addWidget(new QLabel(
							QString::fromUtf8("сек."),this),0,2);
	tropolay->addWidget(sinextropo,1,0,1,3);

	QHBoxLayout * tropomodelsettings = new QHBoxLayout();
	tropolay->addLayout(tropomodelsettings,2,0,1,3);
	tropomodelsettings->addWidget(new QLabel(
		QString::fromUtf8("Отображающая функция:"),this));
	mappingfunction = new QComboBox(this);
	mappingfunction->addItem(QString::fromUtf8("GMF"));
	tropomodelsettings->addWidget(mappingfunction);
	tropomodelsettings->addWidget(new QLabel(
		QString::fromUtf8("Тип модели: "),this));
	tropomodel = new QComboBox(this);
	tropomodel->addItem(QString::fromUtf8("DryAndWet"));
	tropomodel->addItem(QString::fromUtf8("Total_WetMF"));
	tropomodel->addItem(QString::fromUtf8("Total_DryMF"));
	tropomodelsettings->addWidget(tropomodel);
	tropogradient = new QCheckBox(QString::fromUtf8("Включить в модель "
			" учет градиентов зенитных задержек"),this);
	tropogradient->setChecked(true);
	tropomodelsettings->addWidget(tropogradient);
	tropomodelsettings->setSpacing(3);

	//Настройка прореживания
	QHBoxLayout * resample_lay = new QHBoxLayout();
	doresample = new QCheckBox(QString::fromUtf8("Прореживать измерения для "
			"вычисления параметров тропосферы и положения БИС с шагом"),this);
	resample = new QRegExpCheckEdit("^[0-9]+$","0",this);
	resample_lay->addWidget(doresample);
	resample_lay->addWidget(resample);
	resample_lay->addWidget(new QLabel(QString::fromUtf8("сек."),this));
	procParamsLay->addLayout(resample_lay);

	//Настройка уточняемого параметра ухода часов БИС
	rinexclockstation = new QCheckBox(
			QString::fromUtf8("Не уточнять уход часов БИС "
			"(будет взят из Clock-файлов, что может привести к"
			" дополнительному прореживанию измерений)"),this);
	procParamsLay->addWidget(rinexclockstation);

	//НКА, участвующие при обработке параметров
	QGroupBox * choosesats = new QGroupBox(
		QString::fromUtf8("НКА, используемые при вычислении выбранных "
						  "параметров"),this);
	procParamsLay->addWidget(choosesats);
	adj_slist = new SatsList(this);
	QVBoxLayout * satlistlay = new QVBoxLayout();
	choosesats->setLayout(satlistlay);
	satlistlay->addWidget(adj_slist);
	satlistlay->setSpacing(0);

//	QStringList satnames;
//	for (unsigned int i=1; i<=24; i++)
//	{
//		QString satnumber = QString::number(i);
//		if (satnumber.length() == 1)
//			satnumber = "0"+satnumber;
//		satnames.push_back("R"+satnumber);
//	}
//	for (unsigned int i=1; i<=32; i++)
//	{
//		QString satnumber = QString::number(i);
//		if (satnumber.length() == 1)
//			satnumber = "0"+satnumber;
//		satnames.push_back("G"+satnumber);
//	}
//	for (unsigned int i=0; i<satnames.size(); i++)
//	{
//		int Y = i % 4;
//		int X = (i-Y)/4;
//		QCheckBox * satchkbox = new QCheckBox(satnames[i],this);
//		satchkbox->setChecked(true);
//		satlistlay->addWidget(satchkbox,Y,X);
//		procsatellites.push_back(satchkbox);
//	}

	procParamsLay->addStretch();

	//Вкладка параметров имитации
	QGridLayout * imitlay = new QGridLayout();
	imit->setLayout(imitlay);

	//Настройка ухода часов НКА
	QGroupBox * satclksrc = new QGroupBox(
				QString::fromUtf8("Уход часов НКА"),this);
	imitlay->addWidget(satclksrc,0,0);
	QVBoxLayout * satclksrclay = new QVBoxLayout();
	SatClkIGS = new QRadioButton(
				QString::fromUtf8("Брать из Clock-файлов"), this);
	SatClkCFr = new QRadioButton(
				QString::fromUtf8("Брать из оперативной информации"), this);
	SatClkCFr->setChecked(true);
	satclksrclay->addWidget(SatClkIGS);
	satclksrclay->addWidget(SatClkCFr);
	satclksrc->setLayout(satclksrclay);
	satclksrclay->setSpacing(1);

	//Настройка орбиты НКА
	QGroupBox * satorbsrc = new QGroupBox(
				QString::fromUtf8("Эфемериды НКА"), this);
	imitlay->addWidget(satorbsrc,0,1);
	QVBoxLayout * satorblay = new QVBoxLayout();
	SatOrbSP3 = new QRadioButton(
				QString::fromUtf8("Брать из SP3-файлов"),this);
	SatOrbSP3->setChecked(true);
	SatOrbCFr = new QRadioButton(
				QString::fromUtf8("Брать из оперативной информации"), this);
	satorblay->addWidget(SatOrbSP3);
	satorblay->addWidget(SatOrbCFr);
	satorbsrc->setLayout(satorblay);
	satorblay->setSpacing(1);

	//Разрешение интерполировать уход часов БИС и НКА
	allowSatClockInterp = new QCheckBox(
				QString::fromUtf8("Разрешить интерполировать уход часов НКА "
								  "по времени"),this);
	allowRecClockInterp = new QCheckBox(
				QString::fromUtf8("Вычислять уход часов БИС в промежуточные "
								  "моменты времени"), this);
	imitlay->addWidget(allowSatClockInterp,1,0);
	imitlay->addWidget(allowRecClockInterp,1,1);
	//Список НКА для имитации
	QGroupBox * imitsatlist_gb = new QGroupBox(
				QString::fromUtf8("Моделируемые НКА"),this);
	QVBoxLayout * imitsatlay = new QVBoxLayout();
	imitsatlist_gb->setLayout(imitsatlay);
	imit_slist = new SatsList(this);
	imitsatlay->addWidget(imit_slist);
	imitlay->addWidget(imitsatlist_gb,2,0,1,2);
	//Пропуски
	imitlay->setRowStretch(4,2);
	imitlay->setRowStretch(0,0);
	imitlay->setRowStretch(1,0);
	//Параметры вычисления URRE и URAE
	QGroupBox * SISREDerivs = new QGroupBox(
				QString::fromUtf8("Параметры URRE и URAE"), this);
	imitlay->addWidget(SISREDerivs,3,0,1,2);
	QHBoxLayout * sisrelay = new QHBoxLayout();
	SISREDerivs->setLayout(sisrelay);
	urrenumpoints = new QSpinBox(this);
	urrenumpoints->setMinimum(3);
	urrenumpoints->setMaximum(1000);
	urreorder = new QSpinBox(this);
	urreorder->setMinimum(2);
	urreorder->setMaximum(999);
	sisrelay->addWidget(new QLabel(
				QString::fromUtf8("Число узлов дифференцирвоания:"),this));
	sisrelay->addWidget(urrenumpoints);
	sisrelay->addWidget(new QLabel(
				QString::fromUtf8("Порядок формулы дифференцирования:"),this));
	sisrelay->addWidget(urreorder);

	//Параметры генерации отчета
	QVBoxLayout * reportlay = new QVBoxLayout();

	//Директория для генерации отчета
	QHBoxLayout * outdirlay = new QHBoxLayout();
	outputDirectory = new QLineEdit(this);
	outdirlay->addWidget(new QLabel(QString::fromUtf8(
										"Директория для отчета:"),this),0);
	outdirlay->addWidget(outputDirectory,1);
	QToolButton * changeoutputdir = new QToolButton(this);
	changeoutputdir->setText("...");
	outdirlay->addWidget(changeoutputdir);
	connect(changeoutputdir,SIGNAL(clicked()),this,
			SLOT(changeOutputDirectory()));
	reportlay->addLayout(outdirlay);

	//Профиль генерации отчета
	QHBoxLayout * outputprofilelay = new QHBoxLayout();
	outputprofile = new QComboBox(this);
	QStringList profileslist = sets.value("OutputDirProfiles").toStringList();
	profileslist.prepend(rememberoutput);
	outputprofile->addItems(profileslist);
	QPushButton * saveoutputprofile = new QPushButton(
				QIcon(":/menuicons/document-save.png"),
				QString::fromUtf8("Запомнить профиль"),this);
	QPushButton * forgetoutputprofile = new QPushButton(
				QIcon(":/menuicons/edit-delete.png"),"",this);
	outputprofilelay->addWidget(outputprofile,1);
	connect(outputprofile,SIGNAL(activated(QString)),this,
			SLOT(loadOutputDirProfile(QString)));
	outputprofilelay->addWidget(saveoutputprofile,0);
	connect(saveoutputprofile,SIGNAL(clicked()),this,
			SLOT(saveOutputDirProfile()));
	outputprofilelay->addWidget(forgetoutputprofile,0);
	connect(forgetoutputprofile,SIGNAL(clicked()),this,
			SLOT(forgetOutputDirProfile()));
	saveoutputprofile->setFixedHeight(outputprofile->height());
	forgetoutputprofile->setFixedHeight(saveoutputprofile->height());
	outputprofile->setFixedHeight(forgetoutputprofile->height());
	reportlay->addLayout(outputprofilelay);
	report->setLayout(reportlay);

	QFile templhintfile(":/txtfiles/templatehint.html");
	templhintfile.open(QIODevice::ReadOnly);
	QString templhint = QString::fromUtf8(templhintfile.readAll());
	templhintfile.close();

	//Параметры текстовых файлов
	QGroupBox * txtoutput = new QGroupBox(
				QString::fromUtf8("Развернутый вывод"),this);
	reportlay->addWidget(txtoutput);
	QGridLayout * txtoutputlay = new QGridLayout();
	txtoutputlay->setColumnStretch(0,0);
	txtoutputlay->setColumnStretch(1,1);
	txtoutputlay->setColumnStretch(2,0);
	txtoutput->setLayout(txtoutputlay);
	txtoutputlay->setVerticalSpacing(1);
	//Шапка
	txtoutputlay->addWidget(new QLabel(QString::fromUtf8("В текстовый файл"),
									   this),0,0);
	txtoutputlay->addWidget(new QLabel(QString::fromUtf8("Шаблон имени файла"),
									   this),0,1);
	txtoutputlay->addWidget(new QLabel(QString::fromUtf8("Рисунки"),this),
							0,2);
	RangeTxt = new QCheckBox(QString::fromUtf8(
							"Невязка моделирования псевдодальностей"),this);
	RangeTxtTemplate = new QLineEdit(this);
	RangeTxtTemplate->setToolTip(templhint);
	RangeGr = new QCheckBox("",this);
	txtoutputlay->addWidget(RangeTxt,1,0);
	txtoutputlay->addWidget(RangeTxtTemplate,1,1);
	txtoutputlay->addWidget(RangeGr,1,2);
	PhaseTxt = new QCheckBox(QString::fromUtf8(
							"Невязка моделирования фазы"),this);
	PhaseTxtTemplate = new QLineEdit(this);
	PhaseTxtTemplate->setToolTip(templhint);
	PhaseGr = new QCheckBox("",this);
	txtoutputlay->addWidget(PhaseTxt,2,0);
	txtoutputlay->addWidget(PhaseTxtTemplate,2,1);
	txtoutputlay->addWidget(PhaseGr,2,2);
	SatCountTemplate = new QLineEdit(this);
	SatCountTemplate->setToolTip(templhint);
	SatCountGr = new QCheckBox("",this);
	txtoutputlay->addWidget(new QLabel(QString::fromUtf8("Видимость НКА"),this),
							3,0);
	txtoutputlay->addWidget(SatCountTemplate,3,1);
	txtoutputlay->addWidget(SatCountGr,3,2);

	URRETxt = new QCheckBox(QString::fromUtf8(
								"Невязка скорости изменения дальности"),this);
	URAETxt = new QCheckBox(QString::fromUtf8(
								"Невязка ускорения изменения дальности"),this);
	URRETxtTemplate = new QLineEdit(this);
	URAETxtTemplate = new QLineEdit(this);
	URRETxtTemplate->setToolTip(templhint);
	URAETxtTemplate->setToolTip(templhint);
	URREGr = new QCheckBox(this);
	URAEGr = new QCheckBox(this);
	txtoutputlay->addWidget(URRETxt,4,0);
	txtoutputlay->addWidget(URAETxt,5,0);
	txtoutputlay->addWidget(URRETxtTemplate,4,1);
	txtoutputlay->addWidget(URAETxtTemplate,5,1);
	txtoutputlay->addWidget(URREGr,4,2);
	txtoutputlay->addWidget(URAEGr,5,2);


	QGroupBox * brief = new QGroupBox(QString::fromUtf8("Краткий отчет"),
									  this);
	reportlay->addWidget(brief);
	QGridLayout * brieflay = new QGridLayout();
	brieflay->setColumnStretch(0,0);
	brieflay->setColumnStretch(1,0);
	brieflay->setColumnStretch(2,1);
	brieflay->setColumnStretch(3,1);
	brief->setLayout(brieflay);
	brieflay->setVerticalSpacing(1);
	CreateBrief=new QCheckBox(
				QString::fromUtf8("Создать краткий отчет"),this);
	BriefName = new QLineEdit(this);
	brieflay->addWidget(CreateBrief,0,0);
	brieflay->addWidget(new QLabel(QString::fromUtf8("Имя относительно папки:"),
								   this),0,1);
	brieflay->addWidget(BriefName,0,2,1,3);
	brieflay->addWidget(new QLabel(QString::fromUtf8(".html"),this),0,5);
	brieflay->addWidget(new QLabel(QString::fromUtf8(
		"Разделить файлы с невязками моделирования по градациям в "
									   "следующей норме:"),this),
						1,0,1,3);
	ErrorMeas=new QComboBox(this);
	ErrorMeas->addItem(QString::fromUtf8("Равномерная норма "
										 "(максимальная невязка)"));
	ErrorMeas->addItem(QString::fromUtf8("Средний квадрат (СКО невязки)"));
	brieflay->addWidget(ErrorMeas,1,4,1,2);
	brieflay->setColumnStretch(4,1);
	brieflay->setColumnStretch(5,0);


	QGridLayout*gradlay = new QGridLayout();
	gradlay->setVerticalSpacing(1);
	rangeErrDivision = new QRegExpCheckEdit(numlistre,"",this);
	phaseErrDivision = new QRegExpCheckEdit(numlistre,"",this);
	URREErrDivision = new QRegExpCheckEdit(numlistre,"",this);
	URAEErrDivision = new QRegExpCheckEdit(numlistre,"",this);
	gradlay->addWidget(new QLabel(QString::fromUtf8("Псевдодальность:"),
								  this),0,0);
	gradlay->addWidget(new QLabel(QString::fromUtf8("Фаза:"),
								  this),0,2);
	gradlay->addWidget(new QLabel(QString::fromUtf8(
									  "Скорость псевдодальности:"), this),1,0);
	gradlay->addWidget(new QLabel(QString::fromUtf8(
									  "Ускорение псевдодальности:"),this),1,2);

	gradlay->addWidget(rangeErrDivision,0,1);
	gradlay->addWidget(phaseErrDivision,0,3);
	gradlay->addWidget(URREErrDivision,1,1);
	gradlay->addWidget(URAEErrDivision,1,3);
	brieflay->addLayout(gradlay,2,0,1,6);

	reportlay->addStretch();

	QHBoxLayout * executionlay = new QHBoxLayout();
	executionlay->addWidget(new QLabel(
		QString::fromUtf8("Точка входа: "), this));
	resumeFrom = new QComboBox(this);
	executionlay->addWidget(resumeFrom,1);
	resumeFrom->addItem(
		QString::fromUtf8("Начать с начала"));
	resumeFrom->addItem(
		QString::fromUtf8("Продолжить с оценки уточняемых параметров")
				);
	resumeFrom->addItem(
		QString::fromUtf8("Продолжить с моделирования измерений")
				);
	resumeFrom->addItem(
		QString::fromUtf8("Перестроить графики и переформировать отчет")
				);
	QToolButton * regeneratecmdline = new QToolButton(this);
	regeneratecmdline->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
	connect(regeneratecmdline,SIGNAL(clicked()),this,SLOT(generateCMDLine()));
	regeneratecmdline->setText(QString::fromUtf8("Сгенерировать команду"));
	regeneratecmdline->setIcon(QIcon(":/menuicons/reset.png"));
	QToolButton * startcmd = new QToolButton(this);
	connect(startcmd,SIGNAL(clicked()),this,SLOT(execute()));
	startcmd->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
	startcmd->setText(QString::fromUtf8("Запустить"));
	startcmd->setIcon(QIcon(":/menuicons/evaluate.png"));
	startcmd->setPopupMode(QToolButton::MenuButtonPopup);
	QMenu * executemenu = new QMenu(this);
	QAction * execmultithreaded = new QAction(
				QString::fromUtf8("В несколько потоков..."),this);
	connect (execmultithreaded,SIGNAL(triggered()),this,
			 SLOT(executeMultithreaded1()));
	executemenu->addAction(execmultithreaded);
	startcmd->setMenu(executemenu);
	executionlay->addWidget(regeneratecmdline,0);
	executionlay->addWidget(startcmd,0);
	startcmd->setFixedHeight(regeneratecmdline->height());
	resumeFrom->setFixedHeight(regeneratecmdline->height());
	vblay->addLayout(executionlay,0);

	displayCurrentOptions(opts);
}

void PPPOptionsWindow::chooseGNUPLOTVis()
{
	QString newfinals = QFileDialog::getOpenFileName(
				this,
				QString::fromUtf8("Выберите скрипт GNUPLOT для построения "
								  "графиков видимости НКА"),
				QDir::currentPath());
	if (newfinals=="")
		return;
	gnuplotvis->setText(newfinals);
}

void PPPOptionsWindow::chooseGNUPLOTRes()
{
	QString newfinals = QFileDialog::getOpenFileName(
				this,
				QString::fromUtf8("Выберите скрипт GNUPLOT для построения "
								  "графиков невязок"),
				QDir::currentPath());
	if (newfinals=="")
		return;
	gnuplotres->setText(newfinals);
}

void PPPOptionsWindow::chooseGNUPLOTURR()
{
	QString newfinals = QFileDialog::getOpenFileName(
				this,
				QString::fromUtf8("Выберите скрипт GNUPLOT для построения "
								  "графиков невязки скорости дальности"),
				QDir::currentPath());
	if (newfinals=="")
		return;
	gnuploturr->setText(newfinals);
}

void PPPOptionsWindow::chooseGNUPLOTURA()
{
	QString newfinals = QFileDialog::getOpenFileName(
				this,
				QString::fromUtf8("Выберите скрипт GNUPLOT для построения "
								  "графиков невязки ускорения дальности"),
				QDir::currentPath());
	if (newfinals=="")
		return;
	gnuplotura->setText(newfinals);
}

void PPPOptionsWindow::addFile()
{
	QStringList existingfileslist;
	for (int i=0; i<filenames->count(); i++)
		existingfileslist.push_back(filenames->item(i)->text());
	QStringList addfiles = QFileDialog::getOpenFileNames(
			this,QString::fromUtf8("Выберите файлы с измерительными данными"),
				QDir::currentPath());
	for (int i=0; i<addfiles.size(); i++)
		if (existingfileslist.indexOf(addfiles[i]) < 0)
		{
			existingfileslist.append(addfiles[i]);
			filenames->addItem(addfiles[i]);
		}
}

void PPPOptionsWindow::removeFile()
{
	filenames->takeItem(filenames->currentRow());
}

void PPPOptionsWindow::rinexToggled(bool checked)
{
	if (checked == true)
	{
		gfnumpoints->setValue(3);
		gforder->setValue(2);
		stationname->setEnabled(false);
		obsfiletype = QString::fromStdString(RinexNames);
	}
}

void PPPOptionsWindow::cframeToggled(bool checked)
{
	if (checked == true)
	{
		gfnumpoints->setValue(60);
		gforder->setValue(3);
		stationname->setEnabled(true);
		obsfiletype = QString::fromStdString(CFrameNames);
	}
}


void PPPOptionsWindow::adjustStationCoordsToggled(bool checked)
{
	if (checked == true)
	{
		stcoordstep->setEnabled(true);
		stx->setEnabled(false);
		sty->setEnabled(false);
		stz->setEnabled(false);
		stcoordsys->setEnabled(false);
	}
}

void PPPOptionsWindow::exactStationCoordsToggled(bool checked)
{
	if (checked == true)
	{
		stcoordstep->setEnabled(false);
		stx->setEnabled(true);
		sty->setEnabled(true);
		stz->setEnabled(true);
		stcoordsys->setEnabled(true);
	}
}

void PPPOptionsWindow::sinexStationCoordsToggled(bool checked)
{
	if (checked == true)
	{
		stcoordstep->setEnabled(false);
		stx->setEnabled(false);
		sty->setEnabled(false);
		stz->setEnabled(false);
		stcoordsys->setEnabled(false);
	}
}

void PPPOptionsWindow::adjustTropoToggled(bool checked)
{
	if (checked == true)
		tropostep->setEnabled(true);
}

void PPPOptionsWindow::sinexTropoToggled(bool checked)
{
	if (checked == true)
		tropostep->setEnabled(false);
}


void PPPOptionsWindow::changeFinalsFile()
{
	QString newfinals = QFileDialog::getOpenFileName(
				this,QString::fromUtf8("Выберите файл с ПВЗ от службы IERS"),
				QDir::currentPath());
	if (newfinals=="")
		return;
	finals->setText(newfinals);
	QSettings sets;
	sets.setValue("LastFinalsFile", newfinals);
}

void PPPOptionsWindow::onDestroy()
{

}

void PPPOptionsWindow::changeOutputDirectory()
{
	QString curoutputpath = QDir::currentPath();
	if (QDir(outputDirectory->text()).exists())
		curoutputpath = outputDirectory->text();
	QString newname = QFileDialog::getExistingDirectory(
			this,QString::fromUtf8("Выберите директорию для отчета"),
				curoutputpath);
	if (newname!="")
		outputDirectory->setText(newname);
}

void PPPOptionsWindow::saveOutputDirProfile()
{
	bool confirmrewrite=true;
	QString profilename = "";
	if (outputprofile->currentText() != rememberoutput)
	{
		profilename = outputprofile->currentText();
		if (QMessageBox::question(this,
					QString::fromUtf8("Сохранить профиль отчета"),
					QString::fromUtf8("Переписать существующий профиль?"),
					QMessageBox::Yes,QMessageBox::No)==QMessageBox::No)
		{
			profilename = "";
		}
		else
		{
			confirmrewrite = false;
		}
	}
	if (profilename == "")
		profilename = QInputDialog::getText(
				this,QString::fromUtf8("Название профиля"),
				QString::fromUtf8("Укажите название нового профиля отчета"));
	if (profilename == "")
		return;

	QSettings sets;
	QStringList outputprofiles = sets.value("OutputDirProfiles").toStringList();
	if (outputprofiles.contains(profilename))
	{
		if (confirmrewrite)
			if
			(QMessageBox::question(this,QString::fromUtf8("Профиль существует"),
			QString::fromUtf8("Профиль отчета с таким именем уже существует."
							  "Переписать его?"), QMessageBox::Yes,
								  QMessageBox::No) == QMessageBox::No)
				return;
	}
	else
		outputprofiles.append(profilename);
	sets.setValue("OutputDirProfiles", outputprofiles);
	QString hash = QString(QCryptographicHash::hash(profilename.toUtf8(),
								QCryptographicHash::Md5).toHex());
	sets.setValue(hash+"_PhaseTXT",QVariant(PhaseTxt->isChecked()).toString());
	sets.setValue(hash+"_RangeTxt",QVariant(RangeTxt->isChecked()).toString());
	sets.setValue(hash+"_URRETxt",QVariant(URRETxt->isChecked()).toString());
	sets.setValue(hash+"_URAETxt",QVariant(URAETxt->isChecked()).toString());
	sets.setValue(hash+"_PhasePNG",QVariant(PhaseGr->isChecked()).toString());
	sets.setValue(hash+"_RangePNG",QVariant(RangeGr->isChecked()).toString());
	sets.setValue(hash+"_URREPng",QVariant(URREGr->isChecked()).toString());
	sets.setValue(hash+"_URAEPng",QVariant(URAEGr->isChecked()).toString());

	sets.setValue(hash+"_PhaseTxtTemplate", PhaseTxtTemplate->text());
	sets.setValue(hash+"_RangeTxtTemplate", RangeTxtTemplate->text());
	sets.setValue(hash+"_URRETxtTemplate", URRETxtTemplate->text());
	sets.setValue(hash+"_URAETxtTemplate", URAETxtTemplate->text());
	sets.setValue(hash+"_SatCountPNG",
				  QVariant(SatCountGr->isChecked()).toString());
	sets.setValue(hash+"_SatCountTemplate", SatCountTemplate->text());
	sets.setValue(hash+"_CreateBrief",
				  QVariant(CreateBrief->isChecked()).toString());
	sets.setValue(hash+"_BriefName",BriefName->text());
	sets.setValue(hash+"_ErrorMeas",ErrorMeas->currentIndex());
	sets.setValue(hash+"_PhaseErrSubdiv", phaseErrDivision->text());
	sets.setValue(hash+"_RangeErrSubdiv", rangeErrDivision->text());
	sets.setValue(hash+"_URREErrSubdiv", URREErrDivision->text());
	sets.setValue(hash+"_URAEErrSubdiv", URAEErrDivision->text());


	outputprofile->clear();
	int idx = outputprofiles.indexOf(profilename);
	outputprofile->addItems(outputprofiles);
	outputprofile->setCurrentIndex(idx);
}

void PPPOptionsWindow::loadOutputDirProfile(const QString &profilename)
{
	if (profilename==rememberoutput)
		return;
	if (outputprofile->itemText(0) == rememberoutput)
		outputprofile->removeItem(0);
	QSettings sets;
	QString hash = QString(QCryptographicHash::hash(profilename.toUtf8(),
									QCryptographicHash::Md5).toHex());
	QVariant lost(QString::fromUtf8("Настройки утеряны"));
	QVariant phasetxt_ = sets.value(hash+"_PhaseTXT",lost);
	QVariant rangetxt_ = sets.value(hash+"_RangeTxt",lost);
	QVariant phasepng_ = sets.value(hash+"_PhasePNG",lost);
	QVariant rangepng_ = sets.value(hash+"_RangePNG",lost);
	QVariant phasetmpl_ = sets.value(hash+"_PhaseTxtTemplate",lost);
	QVariant rangetmpl_ = sets.value(hash+"_RangeTxtTemplate",lost);
	QVariant scountpng_ = sets.value(hash+"_SatCountPNG",lost);
	QVariant scounttmpl_ = sets.value(hash+"_SatCountTemplate",lost);
	QVariant createbrief_ = sets.value(hash+"_CreateBrief",lost);
	QVariant briefname_ = sets.value(hash+"_BriefName",lost);
	QVariant phaseerrdiv_ = sets.value(hash+"_PhaseErrSubdiv",lost);
	QVariant rangeerrdir_ = sets.value(hash+"_RangeErrSubdiv",lost);

	//-----//
	QVariant urretxt_ = sets.value(hash+"_URRETxt",lost);
	QVariant uraetxt_ = sets.value(hash+"_URAETxt", lost);
	QVariant urrepng_ = sets.value(hash+"_URREPng",lost);
	QVariant uraepng_ = sets.value(hash+"_URAEPng", lost);
	QVariant urretempl_ = sets.value(hash+"_URRETxtTemplate", lost);
	QVariant uraetempl_ = sets.value(hash+"_URAETxtTemplate", lost);
	QVariant errormeas_ = sets.value(hash+"_ErrorMeas",lost);
	QVariant urreerrsubdiv = sets.value(hash+"_URREErrSubdiv", lost);
	QVariant uraeerrsubdiv = sets.value(hash+"_URAEErrSubdiv",lost);
	//-----//

	if (!phasetxt_.canConvert(QVariant::Bool))
		phasetxt_ = lost;
	if (!rangetxt_.canConvert(QVariant::Bool))
		rangetxt_ = lost;
	if (!phasepng_.canConvert(QVariant::Bool))
		phasepng_ = lost;
	if (!rangepng_.canConvert(QVariant::Bool))
		rangepng_ = lost;
	if (!scountpng_.canConvert(QVariant::Bool))
		scountpng_ = lost;
	if (!createbrief_.canConvert(QVariant::Bool))
		createbrief_ = lost;
	if (!urretxt_.canConvert(QVariant::Bool))
		urretxt_=lost;
	if (!uraetxt_.canConvert(QVariant::Bool))
		uraetxt_=lost;
	if (!urrepng_.canConvert(QVariant::Bool))
		urrepng_=lost;
	if (!uraepng_.canConvert(QVariant::Bool))
		uraepng_=lost;
	if (!errormeas_.canConvert(QVariant::Int))
		errormeas_=lost;

	//Проверить, все ли настройки есть
	if ((phasetxt_ == lost) || (rangetxt_ == lost) || (phasepng_ == lost)
		|| (rangepng_ == lost) || (phasetmpl_ == lost) || (rangetmpl_ == lost)
		|| (scountpng_ == lost)||(scounttmpl_ == lost)||(createbrief_ == lost)
		||(briefname_ == lost)||(phaseerrdiv_ == lost) || (rangeerrdir_ == lost)
		||(urretxt_ == lost)||(uraetxt_==lost)||(urrepng_==lost)
		||(uraepng_==lost)||(urretempl_==lost)||(uraetempl_==lost)
		||(errormeas_==lost)||(urreerrsubdiv==lost)||(uraeerrsubdiv==lost)
			)
	{
		if (QMessageBox::warning(this,QString::fromUtf8("Потеря настроек"),
						QString::fromUtf8("Настройки профиля отчета:\n")
						+profilename
					+QString::fromUtf8("\nутеряны (файлы настроек повреждены,"
					"либо были некорректно отредактированы вручную)."
					"Удалить всю (возможно, некорректную) информацию "
					"о данном профиле?"),QMessageBox::Yes,QMessageBox::No)
				== QMessageBox::Yes)
		{
			forgetOutputDirProfile();
			return;
		}
	}
	if (phasetxt_ != lost)
		PhaseTxt->setChecked(phasetxt_.toBool());
	if (rangetxt_ != lost)
		RangeTxt->setChecked(rangetxt_.toBool());
	if (phasepng_ != lost)
		PhaseGr->setChecked(phasepng_.toBool());
	if (rangepng_ != lost)
		RangeGr->setChecked(rangepng_.toBool());
	if (scountpng_ != lost)
		SatCountGr->setChecked(scountpng_.toBool());
	if (createbrief_ != lost)
		CreateBrief->setChecked(createbrief_.toBool());
	BriefName->setText(briefname_.toString());
	PhaseTxtTemplate->setText(phasetmpl_.toString());
	RangeTxtTemplate->setText(rangetmpl_.toString());
	SatCountTemplate->setText(scounttmpl_.toString());
	phaseErrDivision->setText(phaseerrdiv_.toString());
	rangeErrDivision->setText(rangeerrdir_.toString());
	if (urretxt_!=lost)
		URRETxt->setChecked(urretxt_.toBool());
	if (uraetxt_!=lost)
		URAETxt->setChecked(uraetxt_.toBool());
	if (urrepng_!=lost)
		URREGr->setChecked(urrepng_.toBool());
	if (uraepng_!=lost)
		URAEGr->setChecked(uraepng_.toBool());
	URRETxtTemplate->setText(urretempl_.toString());
	URAETxtTemplate->setText(uraetempl_.toString());
	if (errormeas_!=lost)
		ErrorMeas->setCurrentIndex(errormeas_.toInt());
	URREErrDivision->setText(urreerrsubdiv.toString());
	URAEErrDivision->setText(uraeerrsubdiv.toString());
}

void PPPOptionsWindow::forgetOutputDirProfile()
{
	QString profilename = outputprofile->currentText();
	if (profilename == rememberoutput)
		return;
	if (QMessageBox::question(this,QString::fromUtf8("Подтверждение"),
			QString::fromUtf8("Забыть настройки прифиля отчета:\n")
				+profilename,QMessageBox::Yes,QMessageBox::No)==QMessageBox::No)
		return;
	QSettings sets;
	QStringList profileslist = sets.value("OutputDirProfiles").toStringList();
	int idx = profileslist.indexOf(profilename);
	if (idx>=0)
		profileslist.removeAt(idx);
	sets.setValue("OutputDirProfiles",profileslist);
	QString hash = QString(QCryptographicHash::hash(profilename.toUtf8(),
									QCryptographicHash::Md5).toHex());
	sets.remove(hash+"_PhaseTXT");
	sets.remove(hash+"_RangeTxt");
	sets.remove(hash+"_PhasePNG");
	sets.remove(hash+"_RangePNG");
	sets.remove(hash+"_PhaseTxtTemplate");
	sets.remove(hash+"_RangeTxtTemplate");
	sets.remove(hash+"_SatCountPNG");
	sets.remove(hash+"_SatCountTemplate");
	sets.remove(hash+"_CreateBrief");
	sets.remove(hash+"_BriefName");
	sets.remove(hash+"_PhaseErrSubdiv");
	sets.remove(hash+"_RangeErrSubdiv");
	sets.remove(hash+"_URRETxt");
	sets.remove(hash+"_URAETxt");
	sets.remove(hash+"_URREPng");
	sets.remove(hash+"_URAEPng");
	sets.remove(hash+"_URRETxtTemplate");
	sets.remove(hash+"_URAETxtTemplate");
	sets.remove(hash+"_ErrorMeas");
	sets.remove(hash+"_URREErrSubdiv");
	sets.remove(hash+"_URAEErrSubdiv");
	profileslist.prepend(rememberoutput);
	outputprofile->clear();
	outputprofile->addItems(profileslist);
}

void PPPOptionsWindow::setMaximalDegree(int N)
{
	gforder->setMaximum(N-1);
}

QStringList & operator<<(QStringList & lhs, const std::string & s)
{
	return (lhs<<QString::fromStdString(s));
}

QStringList PPPOptionsWindow::generateArgumentsList(int threadid)
{
	if (threadid > filenames->count())
		return QStringList();

	QStringList result;

	//Название БИС
	QRegExp stationnameregexp ("^[A-Za-z][A-Za-z0-9]{3}$");
	if (stationname->text() != "")
	{
		if (!(stationnameregexp.exactMatch(stationname->text())))
		{
			if(QMessageBox::question(this,QString::fromUtf8("Название БИС"),
					QString::fromUtf8("Обычно название БИС состоит из четырех "
								"букв и/или цифр. Введённое имя БИС не "
								"удовлетворяет этим условиям. Изменить его?"),
							QMessageBox::Yes,QMessageBox::No)==QMessageBox::Yes)
				return QStringList();
		}
		if (stationname->text()!="")
			result<<QString::fromStdString(StationName)<<stationname->text();
	}

	//Список C-кадров или RINEX-файлов
	if (threadid < 0)
		//Список всех файлов
		for (int i=0; i<filenames->count(); i++)
			if (filenames->item(i)->text()!="")
				result<<obsfiletype<<filenames->item(i)->text();
	else
		//Только файл для одного потока обработки
		if (filenames->item(threadid)->text()!="")
			result<<obsfiletype<<filenames->item(threadid)->text();

	//Выбор каналов измерительных данных
	result<<GPSPhase<<QString::number(fitphaseGPS->currentIndex())
			<<GPSRange<<QString::number(fitRangeGPS->currentIndex())
			  <<GLOPhase<<QString::number(fitphaseGLO->currentIndex())
				<<GLORange<<QString::number(fitRangeGLO->currentIndex());

	//Настройки директории IGS
	if (igs->getAntexName()!="")
	{
		QString antexabspath = QDir(igs->getIGSDirectory()).absoluteFilePath(
					igs->getAntexName());
		result<<Antex<<antexabspath;
	}
	if (igs->getIGSDirectory()!="")
		result<<IGSDir<<igs->getIGSDirectory();
	if (igs->getClkTemplate()!="")
		result<<ClkTmpl<<igs->getClkTemplate();
	if (igs->getSP3Template()!="")
		result<<SP3Tmpl<<igs->getSP3Template();
	if (finals->text()!="")
		result<<ERPFinals<<finals->text();
	result<<SetSettings<<QString("Parsers")<<QString("finals2000A")
		 <<QString("Bulletin")<<fbull->currentText();
	if (igs->getSNXTemplate()!="")
		result<<SNXTmpl<<igs->getSNXTemplate();
	result<<SetSettings<<QString("Parsers")<<QString("SINEX")
			<<QString("SINEX_TRS")<<igs->getSNXCoordSys();
	if (igs->getTroTemplate()!="")
		result<<TroTmpl<<igs->getTroTemplate();

	//Настройки предобработки
	if (usegf->isChecked() == false)
		result<<SetSettings<<QString("Observables")<<QString("Editor")
			 <<QString("usegfdetector")
				<<QString("No");
	if (usemw->isChecked() == false)
		result<<SetSettings<<QString("Observables")<<QString("Editor")
			 <<QString("usemwdetector")<<QString("No");
	if (usemp->isChecked() == false)
		result<<SetSettings<<QString("Observables")<<QString("Editor")
			 <<QString("usempdetector")<<QString("No");
	result<<SetSettings<<QString("Observables")<<QString("Editor")
		 <<QString("GFNumOfPoints")<<QString::number(gfnumpoints->value());
	result<<SetSettings<<QString("Observables")<<QString("Editor")
		 <<QString("GFOrder")<<QString::number(gforder->value());
	if (gfthreshold->isValid() == false)
	{
		QMessageBox::critical(this,QString::fromUtf8("Неверные настройки"),
			QString::fromUtf8("Неверно указан порог выброса для GF-фильтра."
							  "Ожидалось положительное действительное число."),
							  QMessageBox::Ok);
		return QStringList();
	}
	if (mwthreshold->isValid() == false)
	{
		QMessageBox::critical(this,QString::fromUtf8("Неверные настройки"),
			QString::fromUtf8("Неверно указан порог выброса для MW-фильтра."
							  "Ожидалось положительное действительное число."),
							  QMessageBox::Ok);
		return QStringList();
	}
	if (mpthreshold->isValid() == false)
	{
		QMessageBox::critical(this,QString::fromUtf8("Неверные настройки"),
			QString::fromUtf8("Неверно указан порог выброса для MP-фильтра."
							  "Ожидалось положительное действительное число."),
							  QMessageBox::Ok);
		return QStringList();
	}
	if (minterval->isValid() == false)
	{
		QMessageBox::critical(this,QString::fromUtf8("Неверные настройки"),
			QString::fromUtf8("Неверно указана максимальная длина интервала "
				"между измерениями без срыва фазы. "
							  "Ожидалось положительное действительное число."),
							  QMessageBox::Ok);
		return QStringList();
	}
	result<<SetSettings<<QString("Observables")<<QString("Editor")
		 <<QString("GFThreshold")<<gfthreshold->text();
	result<<SetSettings<<QString("Observables")<<QString("Editor")
		 <<QString("WBThreshold")<<mwthreshold->text();
	result<<SetSettings<<QString("Observables")<<QString("Editor")
		 <<QString("MPThreshold")<<mpthreshold->text();
	result<<SetSettings<<QString("Observables")<<QString("Editor")<<
			QString("Interval")<<minterval->text();
	result<<SetSettings<<QString("Least_Squares")<<QString("Pseudorange")
			<<QString("RMSAccountZenith");
	if (accountzenith->isChecked() == true)
		result<<QString("Yes");
	else
		result<<QString("No");
	result<<SetSettings<<QString("Least_Squares")<<QString("Pseudorange")
			<<QString("rms_l")<<rms_l->text();
	result<<SetSettings<<QString("Least_Squares")<<QString("Pseudorange")
			<<QString("rms_p")<<rms_p->text();
	result<<SetSettings<<QString("Parameters_settings")<<QString("trajectory")
			<<QString("extrlim")<<maxtrajextr->text();
	result<<SetSettings<<QString("Parameters_settings")<<QString("trajectory")
			<<QString("maxstep")<<maxtrajstep->text();
	if (minarclen->isValid() == false)
	{
		QMessageBox::critical(this,QString::fromUtf8("Неверные настройки"),
			QString::fromUtf8("Неверно задана минимальная длина непрерывной "
							  "дуги измерений."), QMessageBox::Ok);
		return QStringList();
	}
	else
		result<<SetSettings<<QString("Observables")<<QString("Editor")
			 <<QString("minArcLength")<<minarclen->text();
	result<<SetSettings<<QString("Observables")<<QString("Editor")
		 <<QString("minObsCount")<<minarccount->text();
	bool acclen = count_len->isChecked();
	bool acccnt = count_arc->isChecked();
	if (acclen && acccnt)
		result<<QString::fromStdString(smallArcs)<<QString("Both");
	if (acclen && (!acccnt))
		result<<QString::fromStdString(smallArcs)<<QString("Length");
	if ((!acclen)&&acccnt)
		result<<QString::fromStdString(smallArcs)<<QString("Count");
	if ((!acclen)&&(!acccnt))
	{
		QMessageBox::critical(this,QString::fromUtf8("Критерий коротких дуг"),
						QString::fromUtf8("На отбрасывании коротких дуг "
						"построен алгоритм предобработки измерений. Необходимо"
						" указать хотя бы один критерий."),
							  QMessageBox::Ok);
		return QStringList();
	}

	//Настройки координат БИС
	if (sinexcoords->isChecked())
		result<<SNXCoords;
	if (adjustcoords->isChecked())
	{
		if (stcoordstep->isValid())
			result<<StCrdStep<<stcoordstep->text();
		else
		{
			QMessageBox::critical(this,QString::fromUtf8("Координаты БИС"),
				QString::fromUtf8("Некорректно указан шаг по времени между "
								  "координатами БИС"), QMessageBox::Ok);
			return QStringList();
		}
	}
	if (exactcoords->isChecked())
	{
		if (stx->isValid() && sty->isValid() && stz->isValid())
			result<<ExactCoords<<stx->text()<<sty->text()<<stz->text()
					<<stcoordsys->currentText();
		else
		{
			QMessageBox::critical(this, QString::fromUtf8("Координаты БИС"),
					QString::fromUtf8("Некорректно указаны координаты БИС"),
								  QMessageBox::Ok);
			return QStringList();
		}
	}

	//Настройки тропосферы
	if (sinextropo->isChecked())
		result<<SinexTropo;
	if (adjusttropo->isChecked())
	{
		if (tropostep->isValid())
			result<<TropoStep<<tropostep->text();
		else
		{
			QMessageBox::critical(this,
					QString::fromUtf8("Задержка в тропосфере"),
					QString::fromUtf8("Некорректно указан шиг по времени "
									  "между параметрами тропосферной "
									  "задержки"),QMessageBox::Ok);
			return QStringList();
		}
	}
	result<<TroModel<<tropomodel->currentText()
			<<MapFunc<<mappingfunction->currentText();
	if (tropogradient->isChecked())
		result<<TropoGradient;

	if ((doresample->isChecked()) && (resample->isValid()))
		if (resample->text().toInt()!=0)
			result<<Resample<<resample->text();

	//Уход часов БИС
	if (rinexclockstation->isChecked())
		result<<RClockStation;

	//Набор НКА для уточнения неизвестных параметров
	QString satnames_s = adj_slist->satsliststr().trimmed();
	if (satnames_s != "")
		result<<ChooseSats<<satnames_s;

	//Набор НКА для имитации
	satnames_s = imit_slist->satsliststr().trimmed();
	if (satnames_s != "")
		result<<ChooseImitSats<<satnames_s;

	//Настройка часов и траектории НКА при имитации
	if (SatClkIGS->isChecked())
		result<<SatClkImit;
	if (SatOrbCFr->isChecked())
		result<<UseNavOrbit;

	//Разрежить интерполяцию ухода часов?
	if (allowSatClockInterp->isChecked())
		result<<AllowSClkInt;
	if (allowRecClockInterp->isChecked())
		result<<AllowRClkInt;

	//Параметры URRE и URAE
	if (urrenumpoints->value()<=urreorder->value())
	{
		QMessageBox::critical(this,QString::fromUtf8("Параметры URRE и URAE"),
			QString::fromUtf8("Порядок формулы дифференцирования - это степень "
				"полинома, аппроксимирующего дифференцирующую точку, по "
				"которому вычисляются производные. Он должен быть меньше числа"
							  "точек",QMessageBox::Ok));
		return QStringList();
	}
	else
		result<<URRNumPoints<<urrenumpoints->text()
			 <<URROrder<<urreorder->text();


	//Параметры развернутого отчета
	if (outputDirectory->text()!="")
		result<<OutputDir<<outputDirectory->text();

	if (URRETxt->isChecked())
	{
		if (URRETxtTemplate->text()!="")
			result<<URRERes<<URRETxtTemplate->text();
		else
		{
			QMessageBox::critical(this,QString::fromUtf8("Развернутый вывод"),
				QString::fromUtf8("Не задан шаблон имени для вывода невязок "
								"скорости псевдодальности."),QMessageBox::Ok);
			return QStringList();
		}
	}
	if (URAETxt->isChecked())
	{
		if (URAETxtTemplate->text()!="")
			result<<URAERes<<URAETxtTemplate->text();
		else
		{
			QMessageBox::critical(this,QString::fromUtf8("Развернутый вывод"),
				QString::fromUtf8("Не задан шаблон имени для вывода невязок "
								"ускорения псевдодальности."),QMessageBox::Ok);
			return QStringList();
		}
	}

	if (PhaseTxt->isChecked())
	{
		if (PhaseTxtTemplate->text() != "")
			result<<PhaseRes<<PhaseTxtTemplate->text();
		else
		{
			QMessageBox::critical(this,QString::fromUtf8("Развернутый вывод"),
				QString::fromUtf8("Не задан шаблон имени для вывода невязок "
								  "моделирования фазы."),QMessageBox::Ok);
			return QStringList();
		}
	}

	if (URREGr->isChecked())
		result<<URREPng;
	if (URAEGr->isChecked())
		result<<URAEPng;
	if (PhaseGr->isChecked())
		result<<PhasePNG;
	if (RangeTxt->isChecked())
	{
		if (RangeTxtTemplate->text()!="")
			result<<RangeRes<<RangeTxtTemplate->text();
		else
		{
			QMessageBox::critical(this,QString::fromUtf8("Развернутый вывод"),
				QString::fromUtf8("Не задан шаблон имени для вывода невязок "
						"моделирования псевдодальности."),QMessageBox::Ok);
			return QStringList();
		}
	}
	if (ErrorMeas->currentIndex() == 1)
		result<<ErrGradMode;

	if (RangeGr->isChecked())
		result<<RangePNG;
	if (SatCountGr->isChecked())
	{
		if (SatCountTemplate->text()!="")
			result<<SatCount<<SatCountTemplate->text();
		else
		{
			QMessageBox::critical(this,QString::fromUtf8("Развернутый вывод"),
				QString::fromUtf8("Не задан шаблон имени для вывода графика "
						"видимости НКА."),QMessageBox::Ok);
			return QStringList();
		}
	}

	//Параметры краткого отчета
	if (CreateBrief->isChecked())
	{
		if (BriefName->text() == "")
		{
			QMessageBox::critical(this,QString::fromUtf8("Краткий отчет"),
				QString::fromUtf8("Не задано имя краткого отчета."),
								  QMessageBox::Ok);
			return QStringList();
		}
		result<<Overview<<BriefName->text();

		if (URREErrDivision->isValid())
		{
			QStringList gradation = URREErrDivision->text().split(QChar(','));
			for (int i=0; i<gradation.size(); i++)
				result<<ErrorGradationURRE<<gradation[i];
		}
		else
		{
			QMessageBox::critical(this,QString::fromUtf8("Краткий отчет"),
				QString::fromUtf8("Градации ошибок моделирования "
					"скорости псевдодальности "
					"должны быть заданы в виде списка действительных "
						"чисел, разделённых запятой."), QMessageBox::Ok);
			return QStringList();
		}

		if (URAEErrDivision->isValid())
		{
			QStringList gradation = URAEErrDivision->text().split(QChar(','));
			for (int i=0; i<gradation.size(); i++)
				result<<ErrorGradationURAE<<gradation[i];
		}
		else
		{
			QMessageBox::critical(this,QString::fromUtf8("Краткий отчет"),
				QString::fromUtf8("Градации ошибок моделирования "
					"ускорения псевдодальности "
					"должны быть заданы в виде списка действительных "
						"чисел, разделённых запятой."), QMessageBox::Ok);
			return QStringList();
		}


		if (phaseErrDivision->isValid())
		{
			QStringList gradation = phaseErrDivision->text().split(QChar(','));
			for (int i=0; i<gradation.size(); i++)
				result<<ErrorGradationPhase<<gradation[i];
		}
		else
		{
			QMessageBox::critical(this,QString::fromUtf8("Краткий отчет"),
				QString::fromUtf8("Градации ошибок моделирования фазы "
					"должны быть заданы в виде списка действительных "
						"чисел, разделённых запятой."), QMessageBox::Ok);
			return QStringList();
		}
		if (rangeErrDivision->isValid())
		{
			QStringList gradation = rangeErrDivision->text().split(QChar(','));
			for (int i=0; i<gradation.size(); i++)
				result<<ErrorGradationRange<<gradation[i];
		}
		else
		{
			QMessageBox::critical(this,QString::fromUtf8("Краткий отчет"),
				QString::fromUtf8("Градации ошибок моделирования "
					"псевдодальности должны быть заданы в виде списка "
					"действительных чисел, разделённых запятой."),
								  QMessageBox::Ok);
			return QStringList();
		}
//		if (errorNeighbourhood->isValid())
//			result<<ErrorNeighbourhood<<errorNeighbourhood->text();
//		else
//		{
//			QMessageBox::critical(this,QString::fromUtf8("Краткий отчет"),
//				QString::fromUtf8("Размер показываемой окрестности вокруг "
//					"аномалий должен задаваться числом с плавающей точкой"),
//								  QMessageBox::Ok);
//			return QStringList();
//		}
	}

	result<<ZenithLS<<max_zenith_ls->text()<<max_zenith_since_iter->text();
	result<<ZenithImit<<max_zenith_imit->text()
		 <<((max_zenith_imit_only_stat->isChecked())?QString("Yes"):
													 QString("No"));

	result<<PltRes<<gnuplotres->text();
	result<<PltVis<<gnuplotvis->text();
	result<<PltURR<<gnuploturr->text();
	result<<PltURA<<gnuplotura->text();

	if (mkLoadDump->isChecked())
		result<<LoadDump;
	if (mkAdjustDump->isChecked())
		result<<AdjustDump;
	result<<Stage<<QString::number(resumeFrom->currentIndex());


	return result;
}

void PPPOptionsWindow::generateCMDLine()
{
	QStringList argslist = generateArgumentsList(-1);
	if (argslist.size() == 0)
		return;
	for (unsigned int i=0; i<argslist.size(); i++)
	{
		//Проверить наличие кавычек
		if (argslist[i].contains(QChar('"')))
		{
			QMessageBox::critical(this,QString::fromUtf8("Ошибка!"),
				QString::fromUtf8("Нельзя использовать кавычки в строке: ")
								  +argslist[i],QMessageBox::Ok);
			return;
		}
		//Проверить наличие пробельных символов
		if (argslist[i].contains(QRegExp("[ \f\n\r\t\v]")))
			argslist[i] = "\""+argslist[i]+"\"";
	}
	QString execfile = qApp->arguments()[0];
	QString cmdline = execfile + " "+argslist.join(" ");
	QPlainTextEdit * cmdlineview = new QPlainTextEdit(0);
	cmdlineview->setMinimumWidth(800);
	cmdlineview->setMinimumHeight(300);
	cmdlineview->setWindowTitle(QString::fromUtf8("Сгенерированная команда"));
	cmdlineview->setAttribute(Qt::WA_DeleteOnClose);
	cmdlineview->setWordWrapMode(QTextOption::WrapAtWordBoundaryOrAnywhere);
	cmdlineview->document()->setPlainText(cmdline);
	cmdlineview->setReadOnly(true);
	cmdlineview->show();
	argslist.prepend("-check"); //Провести проверку аргументов
	QProcess * checkoptions = new QProcess(0);
	connect(checkoptions,SIGNAL(readyReadStandardError()),
			this,SLOT(errorReady()));
//	connect(checkoptions,SIGNAL(readyReadStandardOutput()),
//			this,SLOT(readReady()));
	connect(checkoptions,SIGNAL(finished(int,QProcess::ExitStatus)),
			this,SLOT(processFinished(int,QProcess::ExitStatus)));
	runningprocess = checkoptions;
	checkoptions->start(execfile,argslist);
	checkoptions->waitForFinished();
}

void PPPOptionsWindow::execute()
{
	setVisible(false);
	QStringList argslist = generateArgumentsList(-1);
	if (argslist.size() == 0)
		return;
	QString execfile = qApp->arguments()[0];
	OutputViewer * v = new OutputViewer (execfile,false);
	connect(v,SIGNAL(closeWnd()),this,SLOT(show()));
	v->show();
	v->startCMD(execfile,argslist);
}

void PPPOptionsWindow::showhelp()
{
	PPPHelp * hlp = new PPPHelp(0);
	hlp->show();
}


void PPPOptionsWindow::executeMultithreaded1()
{
	bool ok;
	int nthreads = QInputDialog::getInt(this,QString::fromUtf8("Число потоков"),
			QString::fromUtf8("Введите требуемое число потоков"),
										QThread::idealThreadCount(),
										1,16, 1, &ok);
	if (ok==false)
		return;
	QStringList argslist = generateArgumentsList(-1);
	if (argslist.size()==0)
		return;

	setVisible(false);
	PPPMultithread * pppmt = new PPPMultithread(argslist, filenames->count(),
												nthreads);
	connect(pppmt,SIGNAL(closeWnd()),this,SLOT(show()));
	pppmt->setVisible(true);
}

void PPPOptionsWindow::readReady()
{
	QByteArray readproc = runningprocess->readAllStandardOutput();
	processoutput.push_back(QString::fromUtf8(readproc));
}

void PPPOptionsWindow::errorReady()
{
	QByteArray readproc = runningprocess->readAllStandardError();
	processoutput.push_back(QString::fromUtf8(readproc));}

void PPPOptionsWindow::processFinished( int exitCode,
										QProcess::ExitStatus exitStatus )
{
	runningprocess->deleteLater();
	if (exitCode == 0)
		return;
	QTextEdit * showresulttxt = new QTextEdit(0);
	showresulttxt->setWindowTitle(
				QString::fromUtf8("Недостающие настройки"));
	showresulttxt->setAttribute(Qt::WA_DeleteOnClose);
	showresulttxt->setReadOnly(true);
	showresulttxt->setText(processoutput);
	showresulttxt->show();
	showresulttxt->setMinimumSize(640,480);
	processoutput = "";
}

void PPPOptionsWindow::displayCurrentOptions(const PPPOptions &opts)
{
	resumeFrom->setCurrentIndex(opts.stage);
	mkLoadDump->setChecked(opts.loaddump);
	mkAdjustDump->setChecked(opts.adjdump);
	gnuplotres->setText(QString::fromLocal8Bit(opts.pltres.c_str()));
	gnuplotvis->setText(QString::fromLocal8Bit(opts.pltvis.c_str()));
	gnuploturr->setText(QString::fromLocal8Bit(opts.plturr.c_str()));
	gnuplotura->setText(QString::fromLocal8Bit(opts.pltura.c_str()));

	stationname->setText(QString::fromLocal8Bit(opts.stname.data()));
	for (unsigned int i=0; i<opts.cframenames.size(); i++)
		filenames->addItem(QString::fromLocal8Bit(opts.cframenames[i].data()));
	for (unsigned int i=0; i<opts.rinexnames.size(); i++)
		filenames->addItem(QString::fromLocal8Bit(opts.rinexnames[i].data()));
	if (opts.cframenames.size() > 0)
		choosecframe->setChecked(true);
	else if (opts.rinexnames.size() > 0)
		chooserinex->setChecked(true);
	fitphaseGPS->setCurrentIndex(opts.gpsphase);
	fitRangeGPS->setCurrentIndex(opts.gpsrange);
	fitphaseGLO->setCurrentIndex(opts.glophase);
	fitRangeGLO->setCurrentIndex(opts.glorange);
	igs->setIGSDirectory(QString::fromLocal8Bit(opts.igsdir.data()));
	igs->setAntexName(QString::fromLocal8Bit(opts.antex.data()));
	igs->setClkTemplate(QString::fromLocal8Bit(opts.clktemplate.data()));
	igs->setSP3Template(QString::fromLocal8Bit(opts.sp3template.data()));
	igs->setSNXTemplate(QString::fromLocal8Bit(opts.snxtemplate.data()));
	igs->setTroTemplate(QString::fromLocal8Bit(opts.trotemplate.data()));
	urrenumpoints->setValue(opts.urranumpoints);
	urreorder->setValue(opts.urraorder);
	if (opts.finalsfile.size() > 0)
		finals->setText(QString::fromLocal8Bit(opts.finalsfile.data()));
	if (opts.stexactcoord)
	{
		stx->setText(QString::number((double)opts.st_x));
		sty->setText(QString::number((double)opts.st_y));
		stz->setText(QString::number((double)opts.st_z));
		QString crdframe = QString::fromLocal8Bit(opts.crdframe.data());
		int idx = stcoordsys->findText(crdframe, Qt::MatchExactly);
		if (idx < 0)
		{
			QMessageBox::warning(this,
							QString::fromUtf8("Параметры командной строки"),
							QString::fromUtf8("Система координат '")+crdframe
					+QString::fromUtf8("', указанная в командной строке, не "
					 "поддерживается. Вместо неё выбрана ")
								 +stcoordsys->currentText(),QMessageBox::Ok);
		}
		else
			stcoordsys->setCurrentIndex(idx);
		adjustcoords->setChecked(true);
	}
	else if (opts.sinexexact)
		sinexcoords->setChecked(true);
	else
	{
		adjustcoords->setChecked(true);
		if (!(isnan(opts.stcrdstep)))
			stcoordstep->setText(QString::number((double)opts.stcrdstep));
	}

	QString tropomapfunc = QString::fromLocal8Bit(opts.mapfunc.data());
	QString tropodelaymodel = QString::fromLocal8Bit(opts.tromodel.data());
	if (tropomapfunc!="")
	{
		int mf_idx = mappingfunction->findText(tropomapfunc, Qt::MatchExactly);
		if (mf_idx <0)
		{
			QMessageBox::warning(this,
						 QString::fromUtf8("Параметры командной строки"),
						 QString::fromUtf8("Указанная отображающая функция "
						"тропосферы '")+tropomapfunc+QString::fromUtf8(
						 "' не поддерживается. Вместо неё выбрана ")
						 +mappingfunction->currentText(),
						 QMessageBox::Ok
						 );
		}
		else
			mappingfunction->setCurrentIndex(mf_idx);
	}
	if (tropodelaymodel!="")
	{
		int tmod_idx = tropomodel->findText(tropodelaymodel,Qt::MatchExactly);
		if (tmod_idx < 0)
		{
			QMessageBox::warning(this,
							QString::fromUtf8("Параметры командной строки"),
							QString::fromUtf8("Указанный тип модели задержки "
							"сигнала в тропосфере: '")+tropodelaymodel+
							QString::fromUtf8("' не поддерживается. Вместо "
							"него выбрана модель ")+tropomodel->currentText());
		}
		else
			tropomodel->setCurrentIndex(tmod_idx);
	}
	tropogradient->setChecked(opts.tropogradient);
	if (opts.usesinextropo)
		sinextropo->setChecked(true);
	else
		adjusttropo->setChecked(true);
	if (!(isnan(opts.tropostep)))
		tropostep->setText(QString::number((double)opts.tropostep));
	rinexclockstation->setChecked(opts.strinexclock);

	adj_slist->setChecked(opts.adj_satnames);
	imit_slist->setChecked(opts.imit_satnames);

	if (opts.resample!=0)
	{
		doresample->setChecked(true);
		resample->setText(QString::number(opts.resample));
	}
	if (opts.precsatclockimit == true)
		SatClkIGS->setChecked(true);
	else
		SatClkCFr->setChecked(true);
	if (opts.usenavorbit == true)
		SatOrbCFr->setChecked(true);
	else
		SatOrbSP3->setChecked(true);
	allowSatClockInterp->setChecked(opts.allowsatclockinterp);
	allowRecClockInterp->setChecked(opts.allowrecclockinterp);

	outputDirectory->setText(QString::fromLocal8Bit(opts.outputdir.data()));
	PhaseTxt->setChecked(opts.phasetxt);
	RangeTxt->setChecked(opts.rangetxt);
	PhaseGr->setChecked(opts.phasepng);
	RangeGr->setChecked(opts.rangepng);
	URRETxt->setChecked(opts.urretxt);
	URAETxt->setChecked(opts.uraetxt);
	URREGr->setChecked(opts.urrepng);
	URAEGr->setChecked(opts.uraepng);
	RangeTxtTemplate->setText(QString::fromLocal8Bit(opts.rtxttempl.data()));
	PhaseTxtTemplate->setText(QString::fromLocal8Bit(opts.phtxttempl.data()));
	URRETxtTemplate->setText(QString::fromLocal8Bit(opts.urretmpl.data()));
	URAETxtTemplate->setText(QString::fromLocal8Bit(opts.uraetmpl.data()));
	if (opts.errmode_stddev)
		ErrorMeas->setCurrentIndex(1);

	SatCountGr->setChecked(opts.satcount);
	SatCountTemplate->setText(QString::fromLocal8Bit(
								  opts.satcounttemplate.data()));

	CreateBrief->setChecked(opts.overview);
	BriefName->setText(QString::fromUtf8(opts.overviewname.data()));
	QStringList errdiv;
	for (set<real>::iterator it = opts.phaseerrdivision.begin();
		 it!=opts.phaseerrdivision.end(); ++it)
		errdiv.push_back(QString::number((double)(*it)));
	phaseErrDivision->setText(errdiv.join(","));
	errdiv.clear();
	for (set<real>::iterator it = opts.rangeerrdivision.begin();
		 it!=opts.rangeerrdivision.end(); ++it)
		errdiv.push_back(QString::number((double)(*it)));
	rangeErrDivision->setText(errdiv.join(","));


	errdiv.clear();
	for (set<real>::iterator it = opts.urredivision.begin();
		 it!=opts.urredivision.end(); ++it)
		errdiv.push_back(QString::number((double)(*it)));
	URREErrDivision->setText(errdiv.join(","));

	errdiv.clear();
	for (set<real>::iterator it = opts.uraedivision.begin();
		 it!=opts.uraedivision.end(); ++it)
		errdiv.push_back(QString::number((double)(*it)));
	URAEErrDivision->setText(errdiv.join(","));

	//Отобразить глобальные опции обработчика.


	if (opts.settings.at("Parsers").at("finals2000A").at("Bulletin")=="B")
		fbull->setCurrentIndex(0);
	if (opts.settings.at("Parsers").at("finals2000A").at("Bulletin")=="A")
		fbull->setCurrentIndex(1);
	if (opts.settings.at("Parsers").at("SINEX").at("SINEX_TRS")!="")
		igs->setSNXCoordSys(QString::fromUtf8(
			opts.settings.at("Parsers").at("SINEX").at("SINEX_TRS").c_str()));
	if (opts.settings.at("Observables").at("Editor").at("usegfdetector")=="No")
		usegf->setChecked(true);
	if (opts.settings.at("Observables").at("Editor").at("usemwdetector")=="No")
		usemw->setChecked(true);
	if (opts.settings.at("Observables").at("Editor").at("usempdetector")=="No")
		usemp->setChecked(true);
	bool ok;
	gfnumpoints->setValue(QString::fromStdString(
		opts.settings.at("Observables").at("Editor").at("GFNumOfPoints")
							  ).toInt(&ok));
	if (ok==false)
		QMessageBox::warning(this,
			QString::fromUtf8("Настройки GF-детектора разрывов"),
			QString::fromUtf8("Неверно указано число точек для аппроксимации в "
							  "GF-детекторе"), QMessageBox::Ok);
	gforder->setValue(QString::fromStdString(
		opts.settings.at("Observables").at("Editor").at("GFOrder")).toInt(&ok));
	if (ok==false)
		QMessageBox::warning(this,
			QString::fromUtf8("Настройки GF-детектора разрывов"),
			QString::fromUtf8("Неверно указан порядок аппроксимации в "
							  "GF-детекторе"), QMessageBox::Ok);
	gfthreshold->setText(QString::fromStdString(
			opts.settings.at("Observables").at("Editor").at("GFThreshold")));
	if (gfthreshold->isValid()==false)
		QMessageBox::warning(this,
			QString::fromUtf8("Настройки GF-детектора разрывов"),
			QString::fromUtf8("Неверно указан порог выброса в GF-детекторе"),
							 QMessageBox::Ok);
	mwthreshold->setText(QString::fromStdString(
			opts.settings.at("Observables").at("Editor").at("WBThreshold")));
	if (mwthreshold->isValid()==false)
		QMessageBox::warning(this,
			QString::fromUtf8("Настройки MW-детектора разрывов"),
			QString::fromUtf8("Неверно указан порог выброса в MW-детекторе"),
							 QMessageBox::Ok);
	mpthreshold->setText(QString::fromStdString(
			opts.settings.at("Observables").at("Editor").at("MPThreshold")));
	if (mpthreshold->isValid()==false)
		QMessageBox::warning(this,
			QString::fromUtf8("Настройки MP-детектора разрывов"),
			QString::fromUtf8("Неверно указан порог выброса в MP-детекторе"),
							 QMessageBox::Ok);
	minterval->setText(QString::fromStdString(
			opts.settings.at("Observables").at("Editor").at("Interval")));
	if (minterval->isValid()==false)
		QMessageBox::warning(this,
			QString::fromUtf8("Настройки детектора разрывов"),
			QString::fromUtf8("Неверно указан максимально допустимый промежуток"
				" по времени между непрерывными измерениями"), QMessageBox::Ok);
	accountzenith->setChecked(
				opts.settings.at("Least_Squares").at("Pseudorange")
						.at("RMSAccountZenith")=="Yes");
	rms_l->setText(QString::fromStdString(
			opts.settings.at("Least_Squares").at("Pseudorange").at("rms_l")));
	if (rms_l->isValid() == false)
		QMessageBox::warning(this,
				QString::fromUtf8("Настройки масштабирования строк МНК"),
				QString::fromUtf8("Неверно указано предполагаемое СКО фазы"),
				QMessageBox::Ok);
	rms_p->setText(QString::fromStdString(
			opts.settings.at("Least_Squares").at("Pseudorange").at("rms_p")));
	if (rms_p->isValid() == false)
		QMessageBox::warning(this,
				QString::fromUtf8("Настройки масштабирования строк МНК"),
				QString::fromUtf8("Неверно указано предполагаемое СКО "
								  "псевдодальности"), QMessageBox::Ok);
	if (opts.settings.at("Parameters_settings").at("trajectory").at("extrlim")!="")
	{
		maxtrajextr->setText(QString::fromStdString(
			opts.settings.at("Parameters_settings").at("trajectory").
								 at("extrlim")));
		if (maxtrajextr->isValid() == false)
			QMessageBox::warning(this,
				QString::fromUtf8("Настройки аппроксимации траектории НКА"),
				QString::fromUtf8("Неверно задан максимально допустимый выход "
					"целевого момента времени за пределы множества узлов "
								  "аппроксимации"), QMessageBox::Ok);
	}
	if (opts.settings.at("Parameters_settings")
			.at("trajectory").at("maxstep")!="")
	{
		maxtrajstep->setText(QString::fromStdString(
			opts.settings.at("Parameters_settings")
								 .at("trajectory").at("maxstep")));
		if (maxtrajstep->isValid() == false)
			QMessageBox::warning(this,
				QString::fromUtf8("Настройки аппроксимации траектории НКА"),
				QString::fromUtf8("Неверно задан максимальный шаг между узлами "
								  "аппроксимации"),QMessageBox::Ok);
	}
	int minarccnt = QString::fromStdString(opts.settings.at("Observables")
									.at("Editor").at("minObsCount")).toInt(&ok);
	if (ok==false)
		QMessageBox::warning(this,QString::fromUtf8("Критерий коротких дуг"),
			QString::fromUtf8("Неверно задано минимальное число непрерывных "
							  "измерений."),QMessageBox::Ok);
	else
		this->minarccount->setValue(minarccnt);

	minarclen->setText(QString::fromUtf8(opts.settings.at("Observables")
								.at("Editor").at("minArcLength").c_str()));
	if (minarclen->isValid() == false)
		QMessageBox::warning(this,QString::fromUtf8("Критерий коротких дуг"),
			QString::fromUtf8("Неверно задана минимальная длина дуги "
							  "непрерывных измерений"),QMessageBox::Ok);

	count_arc->setChecked((opts.smallarcs == 'C') || (opts.smallarcs == 'B'));
	count_len->setChecked((opts.smallarcs == 'L') || (opts.smallarcs == 'B'));

	max_zenith_imit->setValue(opts.maxzenith_imit);
	max_zenith_ls->setValue(opts.maxzenith_ls);
	max_zenith_since_iter->setValue(opts.since_iter);
	max_zenith_imit_only_stat->setCheckable(opts.still_draw);

	//	errorNeighbourhood->setText(QString::number((double)
//												(opts.errneighbourhood)));
}

#ifndef PPPHELP_H
#define PPPHELP_H

#include <QWidget>
#include <QMainWindow>
#include <QHelpEngine>
#include <QTextBrowser>
#include <QHelpContentWidget>
#include <QVariant>
#include <QAction>

class MyHelpBrowser : public QTextBrowser
{
private:
	QHelpEngine * eng;
public:
	MyHelpBrowser(QHelpEngine * eng, QWidget * parent);
	virtual QVariant loadResource(int type, const QUrl &name);
};

class PPPHelp : public QMainWindow
{
	Q_OBJECT
private:
	QAction * next;
	QAction * prev;
	QHelpEngine * helpengine;
	MyHelpBrowser * helpbrowser;
public:
	explicit PPPHelp(QWidget *parent = 0);

signals:

public slots:
	void openURL(const QUrl&url);
};

#endif // PPPHELP_H

#include <pppimitator.h>
#include <readcframe.h>
#include <ExtrapolateEphemeris.h>
#include <filespool.hpp>
#include <ppp.h>
#include <igstempledit.h>
#include <derivate.hpp>
#include <preprocess.h>
#include <YawAttitude.h>

using namespace libgnss;

/*-----------------------------------------------------------------------------
 *  Классы, принимающие данные от парсера C-кадра
 *----------------------------------------------------------------------------*/
ImitationUsingNavData::ImitationObservationParser::ImitationObservationParser(
		ImitationUsingNavData *parent, char navsys, int obs_src_id,
		const string &p1, const string &p2, const string &l1, const string &l2)
	: ObservablesLoader(parent->tcol,obs_src_id,'C',navsys,
						p1,p2,l1,l2)
{
	ObservableTypes * otypes = (ObservableTypes*)
			(parent->tcol->getTable("observable_types"));
	l1t=otypes->getObservableTypeID(navsys, l1);
	l2t=otypes->getObservableTypeID(navsys, l2);
	r1t=otypes->getObservableTypeID(navsys, p1);
	r2t=otypes->getObservableTypeID(navsys, p2);
	this->parent = parent;
//	cout<<"Имитатор создан."<<endl;
}

void ImitationUsingNavData::ImitationObservationParser::loadObservables(
		int sat_history_id, real t, const map<int, real> &data,
		const map<int, int> &flags)

{
	if ((data.find(r1t) == data.end())
		||(data.find(r2t) == data.end())
		||(data.find(l1t) == data.end())
		||(data.find(l2t) == data.end()))
		return;
	pair<real,real> obsdata;
	real f1,f2;
	if (navsys == 'G')
	{
		f1 = 1.57542e+9;
		f2 = 1.22760e+9;
	}
	else
	{
		int slot = parent->history->read(sat_history_id)[2].toInt();
		int letter = parent->gslots->getLetter(slot,t);
		f1 = 1.602e+9+letter*5.625e+5;
		f2 = 1.246e+9+letter*4.375e+5;
	}
	obsdata.first = (f1*f1*data.at(r1t) - f2*f2*data.at(r2t))/(f1*f1-f2*f2);
	obsdata.second = (f1*f1*data.at(l1t) - f2*f2*data.at(l2t))/(f1*f1-f2*f2);
	parent->acceptObsData(t,sat_history_id,obsdata);
}

void ImitationUsingNavData::ImitationObservationParser::setNewObsSrcID
(int new_obs_src_id)
{
	parent->setNewObsSrcID(new_obs_src_id);
	ObservablesLoader::setNewObsSrcID(new_obs_src_id);
}

void ImitationUsingNavData::setNewObsSrcID(int newobssrcid)
{
	obs_src_id = newobssrcid;
	int markerid = obssrc->read(obs_src_id)[0].toInt();
	markername = markers->read(markerid)[0].toString();
}

ImitationUsingNavData::ImitationGLONavDataParser::ImitationGLONavDataParser(
		ImitationUsingNavData *parent)
{
	this->parent = parent;
}

void ImitationUsingNavData::ImitationGLONavDataParser::loadNavData(
		int orb_slot, real t, real delta_tau, real gamma_n, real tau_n, real x,
		real y, real z, real vx, real vy, real vz, real ax, real ay, real az,
		int freq_n, bool BN, int E, int m, real Ft)
{
	parent->acceptGLONavData(orb_slot,t,delta_tau,gamma_n,tau_n,x,y,z,vx,vy,vz,
							 ax,ay,az,freq_n,BN,E);
}

ImitationUsingNavData::ImitationGPSNavDataParser::ImitationGPSNavDataParser(
		ImitationUsingNavData *parent)
{
	this->parent = parent;
}

void ImitationUsingNavData::ImitationGPSNavDataParser::operator ()(
		tblHdr_t*hdr, tblTmPrmGps_t*tmprm, tblOprGps_t*oper )
{
	parent->acceptGPSNavData(hdr,tmprm,oper);
}




/* --------------------------------------------------------------------------
 *  Методы класса-имитатора
 * -------------------------------------------------------------------------*/

ImitationUsingNavData::ImitationUsingNavData(DBTableCollection *tcol,
											 DBTable * intervals,
											 int obs_src_id,
											 const PPPOptions & options,
											 const set<int> & satlist)
{
	imitlogfn = options.outputdir+"/imitation.log";
	this->satlist = satlist;
	this->tcol = tcol;

	string rl1,rl2,rp1,rp2,gl1,gl2,gp1,gp2;
	int rinexver = 2;
	if (options.cframenames.size()>0)
		rinexver = 3;

	chooseObsDenotement(rp1,rp2,rl1,rl2,options.glophase, options.glorange,
						rinexver);
	chooseObsDenotement(gp1,gp2,gl1,gl2,options.gpsphase, options.gpsrange,
						rinexver);

	gloobsparser = new ImitationObservationParser(this,'R',obs_src_id,
			rp1,rp2,rl1,rl2);
	gpsobsparser = new ImitationObservationParser(this,'G',obs_src_id,
												  gp1,gp2,gl1,gl2);

	glonavparser = 0;
	gpsnavparser = 0;
	if ((options.usenavorbit) || (options.precsatclockimit == false))
	{
		glonavparser = new ImitationGLONavDataParser(this);
		gpsnavparser = new ImitationGPSNavDataParser(this);
	}

	//Установить отсечение по зенитному углу
	//Если указано ограничение по зенитному углу только для
	//вычисления нормы невязки, убрать все ограничения
	if (options.still_draw)
		tcol->getTable("settings")->updateCell(Tuple()<<"Least_Squares"
												<<"Pseudorange"
												<<"maxZenith", 0,
										   180);
	else
		tcol->getTable("settings")->updateCell(Tuple()<<"Least_Squares"
												<<"Pseudorange"
												<<"maxZenith", 0,
										   options.maxzenith_imit);

	lsp = new ObservablesLeastSquaresProblem(tcol);
	this->obs_src_id = obs_src_id;
	this->tcol = tcol;


	gslots=(GLONASSFrequencySlots*)(tcol->getTable("glonass_frequency_slots"));
	history =(SatelliteHistory*)(tcol->getTable("satellite_history"));
	traj = (ParamTrajectory*)(tcol->getTable("trajectory"));
	clkbias = (ClockBias*)(tcol->getTable("time_shift"));
	frm = (Frames*)(tcol->getTable("coordinate_frames"));
	itrft = (ITRFTranslation *)(tcol->getTable("itrf_transformation"));
	obstypes = (ObservableTypes*)(tcol->getTable("observable_types"));
	phambig = (ParamPhaseAmbiguity*)(tcol->getTable("phase_ambiguity"));
	Observables * obs = (Observables*)(tcol->getTable("observables"));
	real T0 = obs->getMinTime();
	//Найти неделю GPS, с которой начинаются измерительные данные
	int w,d; real f;
	UTCDateTime::fromTAIJ2000(T0).getGPSWeekDayFrac(w,d,f);
	this->begingpsw = w;
	this->options = options;
	pz90_idx = frm->getCoordinateFrameID("ПЗ-90.02");
	wgs84_idx = frm->getCoordinateFrameID("WGS84-G1150");
	gcrscoords = frm->getFrameCoordinates(frm->getCoordinateFrameID("GCRS"));
	lglo = obstypes->getObservableTypeID('R',"L12");
	rglo = obstypes->getObservableTypeID('R',"P12");
	lgps = obstypes->getObservableTypeID('G',"L12");
	rgps = obstypes->getObservableTypeID('G',"P12");
	obssrc = (ObservationSource*)
			(tcol->getTable("observation_source"));
	markers = (Markers*)(tcol->getTable("markers"));
	int markerid = obssrc->read(obs_src_id)[0].toInt();
	markername = markers->read(markerid)[0].toString();
	filespool = new FilesPool(512,options.outputdir);
	this->intervals = intervals;
	curobst = numeric_limits<real>::quiet_NaN();
	//Если указано использовать уход часов и/или траекторию из навигационной
	//информации, удалить её из таблиц, чтобы предотвратить использование
	//имеющейся в них информации
	if (options.usenavorbit)
		traj->deleteRows(Tuple());
	if (!(options.precsatclockimit))
		clkbias->deleteRows(Tuple()<<1);
}

ImitationUsingNavData::~ImitationUsingNavData()
{
	delete filespool;
	ofstream imitlog(imitlogfn.c_str());
	l.outputLog(imitlog);
	imitlog.close();
}


void ImitationUsingNavData::acceptObsData(real t, int sat_his_id,
										  const pair<real, real> &obsdata)
{
	if (satlist.find(sat_his_id) == satlist.end())
		return;
	if ((t!=curobst) && (!(isnan(curobst))))
	{
		try
		{
			imitateEpoch();
		}
		catch(const StrException & e)
		{
			l.logException(e);
		}
		this->obsdata.clear();
	}
	curobst = t;
	if (this->obsdata.find(sat_his_id)!=this->obsdata.end())
		l.logException(StrException("ppp", "Повторная запись в C-кадре"));
	this->obsdata[sat_his_id] = obsdata;
}

void ImitationUsingNavData::acceptGLONavData(
						int orb_slot, real t, real delta_tau,
						real gamma_n, real tau_n, real x, real y, real z,
						real vx, real vy, real vz, real ax, real ay, real az,
						int freq_n, bool BN, int E)
{
	try
	{
		if (BN==false)
			return;

		int sat_history_id = history->getSatHistoryID('R',orb_slot,t);
		if (satlist.find(sat_history_id) == satlist.end())
			return;
		l1_l2[sat_history_id] = delta_tau;

		//Если оперативная информация актуальна, ничего не предпринимать
		map<int,real>::iterator it = navdatat0_glo.find(sat_history_id);
		if (it!=navdatat0_glo.end())
			if (it->second == t)
				return;

		//Далее идёт процесс размножения эфемерид, ухода часов, и т.д.

		//1) Размножение эфемерид
		if (options.usenavorbit)
		{
			//Удалить то, что было размножено ранее
			traj->deleteRows(Tuple()<<sat_history_id);

			//Размножить эфемериды, согласно ИКД ГЛОНАСС
			vector<vector<real> > ephemeris =extrapolateGLONASSEphemeris(
						t, t+3600, 9, x,y,z,vx,vy,vz,ax,ay,az);

			//Внести эфемериды в таблицу координат
			for (int i=0; i<ephemeris.size(); i++)
			{
				real curt = t + i*3600/9;
				kinematic<real,6,defaultInert> pos =
						frm->posVelInert(ephemeris[i],pz90_idx,curt);
				for (int j=0; j<6; j++)
					traj->insertRow(Tuple()<<sat_history_id
									<<gcrscoords[j]<<curt,
									Tuple()<<pos[j]);
			}

			calcOrientation(*tcol,false);
		}

		//2) Размножение уходов часов
		if (options.precsatclockimit == false)
		{
			clkbias->deleteRows(Tuple()<<1<<sat_history_id);
			//Удобно, что в ГЛОНАСС уход часов линеен!
			clkbias->insertRow(Tuple()<<1<<sat_history_id<<0<<t,
							   Tuple()<<(-tau_n));
			clkbias->insertRow(Tuple()<<1<<sat_history_id<<0<<(t+3600),
							   Tuple()<<(-(tau_n - gamma_n*3600)));
		}

		navdatat0_glo[sat_history_id] = t;
	}
	catch (const StrException & e)
	{
		l.logException(e);
	}
}

void ImitationUsingNavData::acceptGPSNavData(tblHdr_t *hdr,
											 tblTmPrmGps_t *tmprm,
											 tblOprGps_t *oper)
{
	try
	{
		//Пропустить недействительную оперативную информацию
		if ((tmprm->actual == 0) || (oper->actual == 0))
			return;
		int curgpsw = oper->wn; //Неделя GPS по модулю 1024
		//Считать, что оперативная информация GPS не может относиться к моменту
		//времени за год до первого элемента измерительных данных. В противном
		//случае, вся обработка не имеет смысла
		while (curgpsw<begingpsw-50)
			curgpsw += 1024;
		real Tgpswbegin=UTCDateTime::fromGPSWeekDayFrac(curgpsw,0,0).getTAIJ2000();
		real tofclock = Tgpswbegin + oper->t0c; //Эпоха ухода часов
		real tofeph = Tgpswbegin + oper->t0e; //Эпоха эфемерид
		int prn = hdr->num;
		if (prn == 0)
			prn = 32;
		int sat_history_id = history->getSatHistoryID('G',prn,tofclock);

		if (satlist.find(sat_history_id) == satlist.end())
			return;

		if (navdatat0_gps.find(sat_history_id) == navdatat0_gps.end())
			navdatat0_gps[sat_history_id]=pair<real,real>(
						numeric_limits<real>::quiet_NaN(),
						numeric_limits<real>::quiet_NaN());

		if ((options.usenavorbit) && (navdatat0_gps[sat_history_id].first!=tofeph))
		{
			//Размножение эфемерид GPS
			for (real t = tofeph; t<tofeph+86400; t+=300)
			{
				vector<real> cureph=extrapolateGPSEphemeris(t-tofeph,oper->m0,
					oper->dn, oper->e, oper->sqrtA, oper->omega0, oper->i0,
					oper->omega0, oper->omegaD, oper->idot, oper->cuc, oper->cus,
					oper->cic, oper->cis, oper->crc, oper->crs);
				kinematic<real,3,defaultInert>pos=frm->posInert(cureph,wgs84_idx,t);
				for (int j=0; j<3; j++)
					traj->insertRow(Tuple()<<sat_history_id
									<<gcrscoords[j]<<t,
									Tuple()<<pos[j]);
			}
			navdatat0_gps[sat_history_id].first = tofeph;
		}

		if ((options.precsatclockimit == false) &&
				(navdatat0_gps[sat_history_id].second!=tofclock))
		{
			//Поскольку часы квадратичные, для их определения в любой момент времени
			//можно без потери точности использовать интерполяцию по трем точкам
			real dt0 = oper->af0; //В момент времени toc
			real dt1 = oper->af0 + oper->af1*43200; //В момент времени toc+12 часов
			//В момент времени toc+24 часа
			real dt2 = oper->af0+oper->af1*86400.0l + oper->af2*(86400.0l*86400.0l);
			clkbias->deleteRows(Tuple()<<1<<sat_history_id);
			clkbias->insertRow(Tuple()<<1<<sat_history_id<<0<<tofclock,
							   Tuple()<<dt0);
			clkbias->insertRow(Tuple()<<1<<sat_history_id<<0<<(tofclock+43200.0l),
							   Tuple()<<dt1);
			clkbias->insertRow(Tuple()<<1<<sat_history_id<<0<<(tofclock+86400.0l),
							   Tuple()<<dt2);
			navdatat0_gps[sat_history_id].second = tofclock;
		}
	}
	catch (StrException & e)
	{
		l.logException(e);
	}
}

void ImitationUsingNavData::imitateEpoch()
{
	int w,d;
	real f;
	UTCDateTime::fromTAIJ2000(curobst).getGPSWeekDayFrac(w,d,f);
	for (map<int,pair<real,real> > ::iterator it = obsdata.begin();
		 it!=obsdata.end(); ++it)
	{
		int sat_history_id = it->first;
		Tuple satdetails = history->read(sat_history_id);
		char navsys = satdetails[0].toChar();
		int slot = satdetails[2].toInt();
		int lt = (navsys=='G')?lgps:lglo;
		int rt = (navsys=='G')?rgps:rglo;
		int freqn = obstypes->read(lt)[2].toInt();
		string satname = history->getShortSatName(sat_history_id);

		//state=
		// 0, если момент времени находится внутри "хорошего" интервала
		//непрерывности фазы
		// 1, если момент времени - разрыв фазы
		// 2, если момент времени входит в "плохой" интервал непрерывности фазы
		// 3, если момент времени не принадлежит никакому инервалу непрерывности
		// то есть является большим выбросом.
		int state = 0;

		//1) Если нужно писать файл видимости НКА, определить состояние НКА

		//Момент разрыва фазы
		DBTable::DBConstIterator it1 = intervals->lower_bound(
					Tuple()<<obs_src_id<<sat_history_id<<curobst,1e-5);
		if (it1.isEnd())
			state = 3;
		else if (it1[0].toDouble()-1E-5<=curobst)
			state = 3;
		else
		{
			if (fabs(it1.keyColumnValue(2).toDouble() - curobst)<1e-5)
				state = 1;
			else
				state = it1[1].toInt();
		}

		if (options.satcount)
		{
			int svstate = state;
			if (svstate > 2)
				svstate = 2;
			string satvisfilename=IGSfilenameFromTemplate(
						options.satcounttemplate,markername,satname,w,d,f);
//			visres.insert(satvisfilename);
			ofstream * str = filespool->file(satvisfilename);
			(*str)<<markername<<'\t'<<(double)curobst<<'\t'<<navsys;
			for (unsigned int i=0; i<svstate; i++)
				(*str)<<"\tna";
			(*str)<<"\t"<<slot;
			for (unsigned int i=0; i<2-svstate; i++)
				(*str)<<"\tna";
			(*str)<<endl;
		}

		//2) Отбросить измерения, если на данный момент нет ухода часов.
		bool hasclock = 1; //1-есть часы, -1-вычислить часы для псевдодальности
		//0-нет часов
		//Проверка часов для БИС
		if (clkbias->find(Tuple()<<0<<obs_src_id<<0<<curobst,
						  curobst*1e-15).isEnd())
			if (options.allowrecclockinterp == false)
				hasclock = 0;
		//Проверить часы НКА
		if ((options.allowsatclockinterp == false)
				&& (options.precsatclockimit))
			if (clkbias->find(Tuple()<<1<<sat_history_id
							  <<0<<curobst, curobst*1e-15).isEnd())
				hasclock *= 0;
		if (hasclock == false)
			continue;

		//3) Имитация фазы требует параметра фазовой неоднозначности,
		// а он есть только внутри или в начале "хороших" интервалов
		// непрерывности => при state>1 смысла в фазе нет.
		ObservablesNormalEquation * neq;
		if ((options.phasetxt) && ((state==0)||(state==1)))
		{
			string filename = IGSfilenameFromTemplate(options.phtxttempl,
							markername,satname,w,d,f);
//				phaseres.insert(filename);
			ofstream * cur = filespool->file(filename);
			if (state == 1)
				(*cur)<<endl;
			else
			{
				//Моделирование фазы
				neq = new ObservablesNormalEquation
						(lsp,lsp->getTargetTableName(),
						 lsp->getTargetColumnNumber(),
						 Tuple()<<obs_src_id<<curobst<<sat_history_id
						 <<lt);
				try
				{
					//Смоделировать измерение
					real imitvalue = neq->func0();

					//Реальное фазовое измерение
					real realvalue = it->second.second;

					//Вывести в файл

					//Если был разрыв фалы, поместить разрыв в файл
					//Вывод в файл
					(*cur)<<markername<<'\t'<<satname<<'\t'
					<<(double)curobst<<'\t'
					<<(double)(imitvalue-realvalue)<<'\t'
					<<(double)realvalue<<'\t'
					<<(double)imitvalue<<'\t'
//					<<neq->getTimeDependentInfo().satposinert<<'\t'
//					<<neq->getTimeDependentInfo().recposinert<<'\t'
					<<(double)(neq->getTimeDependentInfo().zenith_azimuth.first)
					<<'\t'
					<<(double)(neq->getTimeDependentInfo().timeShiftSatellite)
					<<endl;
				}
				catch(const StrException & e)
				{
					l.logException(e);
				}
				delete neq;
			}
		}

		//4) Имитация псевдодальности
		if (options.rangetxt)
		{
			//Смоделировать кодовое измерение
			neq = new ObservablesNormalEquation
							(lsp,lsp->getTargetTableName(),
							 lsp->getTargetColumnNumber(),
							 Tuple()<<obs_src_id<<curobst<<sat_history_id
							 <<rt);
			try
			{
				//Смоделировать измерение
				real imitvalue = neq->func0();

				//Реальное кодовое измерение
				real realvalue = it->second.first;

				//Вывести в файл
				string filename = IGSfilenameFromTemplate(options.rtxttempl,
								markername,satname,w,d,f);
//				rangeres.insert(filename);
				ofstream * cur = filespool->file(filename);

				//Если был разрыв фазы или выброс, поместить разрыв в файл
				if ((state == 1) || (state == 3))
					(*cur)<<endl;

				real diff = imitvalue - realvalue;

				//Вывод в файл
				(*cur)<<markername<<'\t'<<satname<<'\t'<<(double)curobst<<'\t'
					<<(double)(diff)<<'\t'
					<<(double)realvalue<<'\t'
					<<(double)imitvalue<<'\t'
					<<(double)(neq->getTimeDependentInfo().zenith_azimuth.first)
					<<endl;

				//Если нужно вычислять URRE и/или URAE, то нужно продвинуть окно
				if ((options.urretxt) || (options.uraetxt))
				{
					int np = options.urranumpoints;
					//Если НКА встртился впервые, или произошел разрыв фазы, то
					//окно необходимо переинициализировати.
					if (ura.find(sat_history_id)==ura.end())
						ura[sat_history_id].npoints = 0;
					CyclicWindow & cw = ura[sat_history_id];

					//Если произошел разрыв фазы, начать накапливать данные для
					//дифференцирования заново
					if ((cw.npoints == 0)
							||(state==1)||(state==3))
					{
						cw.arguments.resize(
									options.urranumpoints);
						cw.values.resize(
									options.urranumpoints);
						cw.npoints = 0;
					}

					//Продвинуть окно
					cw.arguments[cw.npoints % np]
							= curobst;
					cw.values[cw.npoints % np]
							= diff;
					cw.npoints ++;
					//Файл для URRE
					string urrfname;
					string urafname;
					//Вставить пропуски при разрыве фазы
					if (options.urretxt)
					{
						urrfname = IGSfilenameFromTemplate(
									options.urretmpl,
									markername, satname,
									w,d,f);
						cur = filespool->file(urrfname);
						if ((state == 1) || (state == 3))
							(*cur)<<endl;
					}
					if (options.urretxt)
					{
						urafname = IGSfilenameFromTemplate(
									options.uraetmpl,
									markername, satname,
									w,d,f);
						cur = filespool->file(urafname);
						if ((state == 1) || (state == 3))
							(*cur)<<endl;
					}

					if (cw.npoints>=np)
					{
						//Вычислить URRE и URRA
						DifferentiableFit<PowerOfX,real> fit(
									cw.arguments,
									cw.values,
									powerBasis(options.urraorder)
									);
						if (options.urretxt)
						{
							cur = filespool->file(urrfname);
							//URRE
							real window_t0 = cw.arguments[cw.npoints%np];
							real window_t1 = cw.arguments[(cw.npoints+np-1)%np];
							real t = 0.5l*(window_t0+window_t1);
							real urre = fit.derivative(1,t);
							(*cur)<<markername<<'\t'<<satname<<'\t'
								<<(double)t<<'\t'
								<<(double)(urre)<<'\t'
								<<endl;
						}
						if (options.uraetxt)
						{
							cur = filespool->file(urafname);
							//URAE
							real window_t0 = cw.arguments[cw.npoints%np];
							real window_t1 = cw.arguments[(cw.npoints+np-1)%np];
							real t = 0.5l*(window_t0+window_t1);
							real urre = fit.derivative(2,t);
							(*cur)<<markername<<'\t'<<satname<<'\t'
								<<(double)t<<'\t'
								<<(double)(urre)<<'\t'
								<<endl;
						}
					}
				}
			}
			catch(const StrException & e)
			{
				l.logException(e);
			}
			delete neq;

		}
	}
}


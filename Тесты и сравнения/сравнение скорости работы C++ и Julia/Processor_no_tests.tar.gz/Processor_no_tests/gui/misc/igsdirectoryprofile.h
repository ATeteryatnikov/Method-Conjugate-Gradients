#ifndef IGSDIRECTORYPROFILE_H_
#define IGSDIRECTORYPROFILE_H_

#include <QWidget>
#include <QString>

class QComboBox;
class QLineEdit;

namespace libgnss
{


class QIGSPathTemplateEdit;

class QIGSPathTemplateEdit : public QWidget
{
	Q_OBJECT
private:
	QLineEdit * tmpl;
	QLineEdit * igspathwidget;
	QLineEdit * mrknameedit;
	QString dialogtitle;
public:
	QIGSPathTemplateEdit (const QString & dialogtitle,
						  QLineEdit * igspath, QLineEdit *mrkname,
						  const QString & value = "",
						  QWidget * parent = 0);
	QString text() const;
	void setText(const QString & newtext);
protected slots:
	void showDialog();
};


/**
 * @brief Позволяет редактировать профили папок с продуктами IGS
 */
class IGSDirectoryProfile : public QWidget
{
	Q_OBJECT
private:
	static QString rememberdir;
	QString org;
	QString app;
	QComboBox * igsdirectories;
	QLineEdit * igsdir;
	QLineEdit * antexfile;
	QIGSPathTemplateEdit * clktmpl;
	QIGSPathTemplateEdit * snxtmpl;
	QComboBox * snxcs;
	QIGSPathTemplateEdit * sp3tmpl;
	QIGSPathTemplateEdit * trotmpl;
public:

	IGSDirectoryProfile(const QString & orgainzation,
						const QString & application, QLineEdit *stname,
						const QStringList &coordsystems,
						QWidget * parent);

	QString getIGSDirectory();
	QString getAntexName();
	QString getClkTemplate();
	QString getSNXTemplate();
	QString getSP3Template();
	QString getTroTemplate();
	QString getSNXCoordSys();
	void setIGSDirectory(const QString & txt);
	void setAntexName(const QString & txt);
	void setClkTemplate(const QString & txt);
	void setSP3Template(const QString & txt);
	void setTroTemplate(const QString & txt);
	void setSNXTemplate(const QString & txt);
	void setSNXCoordSys(const QString & txt);

protected slots:
	void changeIGSDir();
	void chooseAntexFile();
	void saveIGSDirectoryProfile();
	void loadIGSDirectoryProfile(const QString &dirname);
	void forgetCurrentIGSDirectoryProfile();

};

}

#endif

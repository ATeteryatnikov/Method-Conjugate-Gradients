#include <QRegExpCheckEdit.h>

namespace libgnss
{


QRegExpCheckEdit::QRegExpCheckEdit(const QString &regexp, const QString &value,
								   QWidget *parent)
	: QLineEdit(value, parent)
{
	connect(this,SIGNAL(textChanged(QString)),this,SLOT(edited(QString)));
	//Тест числа с плавающей точкой
	rgexp.setPattern(regexp);
	backgroundcolour = palette().color(QPalette::Background);
	edited(value);
}

void QRegExpCheckEdit::edited(const QString &newtext)
{
	if (rgexp.exactMatch(newtext))
		setStyleSheet("QLineEdit{background: white;}");
	else
		setStyleSheet("QLineEdit{background : pink;}");
}

bool QRegExpCheckEdit::isValid()
{
	return rgexp.exactMatch(text());
}

void QRegExpCheckEdit::setNumber(double n)
{
	setText(QString::number(n));
}

}

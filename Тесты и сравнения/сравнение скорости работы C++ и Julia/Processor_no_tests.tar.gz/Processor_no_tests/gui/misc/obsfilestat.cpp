#include <set>
#include <string>

using namespace std;

#include <obsfilestat.h>
#include <DBTableCollection.h>
#include <QGridLayout>
#include <observables.h>
#include <StdTables.h>
#include <QSet>
#include <QMap>
#include <QThread>
#include <ctime>
#include <cstdlib>
#include <readcframe.h>

namespace libgnss
{

class SingleObsCounter : public ObservablesLoader
{
private:
	clock_t lastclk;
	//Имя НКА -> Заголовок измерения -> число измерений данного типа
	QMap<QString, QMap<QString, QPair<int, bool> > > obscount;

	ObsLoaderThread * parent;
public:
	SingleObsCounter(ObsLoaderThread * parent)
	{
		lastclk = clock();
		this->parent = parent;
	}

	void loadObservables(int sat_history_id, real t,
								 const map<int, real> &data,
								 const map<int, int> &flags)
	{
		for (map<int,real>::const_iterator it = data.begin();
			 it!=data.end(); ++it)
		{
			int obs_type_id = it->first;
			QString obsname = parent->parent->getObservableDenotement(obs_type_id);
			QString satname = parent->parent->getSatelliteShortName(sat_history_id);
			QString navsysname = parent->parent->getNavSystemName(satname[0].toAscii());
			obscount[satname][obsname].first++;
			obscount[satname][obsname].second = true;
			obscount[navsysname][obsname].first++;
			obscount[navsysname][obsname].second = true;
		}
		real ellapsed = ((double)(clock()-lastclk))/CLOCKS_PER_SEC;
		if (ellapsed > 0.3)
		{
			lastclk = clock();
			for(QMap<QString, QMap<QString, QPair<int, bool> > >::iterator
				it = obscount.begin(); it!=obscount.end(); ++it)
			{
				QMap<QString, QPair<int, bool> > & obsmap = it.value();
				QString satname = it.key();
				for(QMap<QString, QPair<int, bool> >::iterator
					it2 = obsmap.begin(); it2 != obsmap.end(); ++it2)
				{
					QString obsname = it2.key();
					QPair<int, bool> & obs = it2.value();
					if (obs.second == true)
						parent->sigNewColumnValue(obsname, satname, obs.first);
					obs.second = false;
				}
			}
		}
	}
};

ObsLoaderThread::ObsLoaderThread(ObservationFileStatistics *parent)
{
	this->parent = parent;
}


void ObsLoaderThread::run()
{
	//Создать загрузчики
	QMap<QChar, ObservablesLoader *> loaders;
	for (DBTable::DBConstIterator it = parent->navsys->const_begin();
		 it!=parent->navsys->const_end(); ++it)
	{
		QChar letter = QChar(it.keyColumnValue(0).toChar());
		loaders[letter] = new SingleObsCounter(this);
	}
	parent->startLoading(loaders);
}

ObservationFileStatistics::ObservationFileStatistics(DBTableCollection *tcol,
													 QWidget *parent)
	: QWidget(parent)
{
	QGridLayout * mylay = new QGridLayout(this);
	otypes = (ObservableTypes *) (tcol->getTable("observable_types"));
	history = (SatelliteHistory *)
			(tcol->getTable("satellite_history"));
	//Строкам будут соответствовать типы измерений
	for (DBTable::DBConstIterator it = otypes->const_begin();
		 !(it.isEnd()); ++it)
		obsnames[QString::fromUtf8(it[0].toString().c_str())]=
				QPair<int, bool>(1,false);
	int i = 0;
	for (QMap<QString,QPair<int, bool> >::iterator it = obsnames.begin();
		 it!=obsnames.end(); ++it)
	{
		i++;
		//mylay->addWidget(new QLabel(it.key(),this),i,0);
		it.value().first = i;
	}

	//Столбцам будут соответствовать имена НКА и имена навигационных систем
	for (DBTable::DBConstIterator it = history->const_begin();
		 !(it.isEnd()); ++it)
		colnames[QString::fromUtf8(history->getShortSatName(
						it.keyColumnValue(0).toInt()).c_str())]=1;
	navsys = (NavigationSystem*)
			(tcol->getTable("navigation_systems"));
	for (DBTable::DBConstIterator it = navsys->const_begin();
		 !(it.isEnd()); ++it)
		colnames[QString(" ")+ //Маленький хак, чтобы
				//столбцы с именами систем шли первыми
				QString::fromUtf8(it[0].toString().c_str())] = 1;

	i = 0;
	for (QMap<QString,int>::iterator it = colnames.begin(); it!=colnames.end();
		 ++it)
	{
		i++;
		colnames[it.key()] = i;
		mylay->addWidget(new QLabel(it.key(),this),0,i);
	}
	loader = new ObsLoaderThread(this);
}

void ObservationFileStatistics::loadFile()
{
	loader->start();
}

void ObservationFileStatistics::setValue(const QString &row,
										 const QString &column,
										 int newnumber)
{
	//Проверить, были ли уже измерения данного типа. Если нет - нужно создать
	//QLabel
	if (labels[column].contains(row) == false)
	{
		QLabel * newlabel = new QLabel("0",this);
		labels[column][row] = newlabel;
		int colidx = colnames[column];
		int rowidx = obsnames[row].first;
		((QGridLayout*)layout())->addWidget(newlabel,rowidx,colidx);
		//Проверить, есть ли уже данная строка. Если строки нет,
		//вставить в 0-й столбец название измерения
		if (obsnames[row].second == false)
			((QGridLayout*)layout())->addWidget(new QLabel(row,this),rowidx,0);
	}
	//Установить новый номер
	labels[column][row]->setText(QString::number(newnumber));
}

QString ObservationFileStatistics::getObservableDenotement(int id)
{
	return QString::fromUtf8(otypes->read(id)[0].toString().c_str());
}

QString ObservationFileStatistics::getSatelliteShortName(int id)
{
	return history->getShortSatelliteName(id);
}

QString ObservationFileStatistics::getNavSystemName(char letter)
{
	return QString::fromUtf8(navsys->read(letter)[0].toString().c_str());
}


CFrameStatistics::CFrameStatistics(DBTableCollection *tcol, QWidget *parent)
	: ObservationFileStatistics(tcol,parent)
{

}

void CFrameStatistics::startLoading(QMap<QChar, ObservablesLoader *> loaders )
{
	parseCFrames(cframefilename.toStdString(),loaders['R'],loaders['G'],0,0,0);
}

void CFrameStatistics::setFileName(const QString & filename)
{
	this->cframefilename = filename;
}
}

#include <igsdirectoryprofile.h>
#include <QWidget>
#include <QLineEdit>
#include <QString>
#include <QString>
#include <QSettings>
#include <QGridLayout>
#include <QComboBox>
#include <QPushButton>
#include <QToolButton>
#include <QLabel>
#include <igstempledit.h>
#include <QDir>
#include <QFileDialog>
#include <QMessageBox>
#include <QCryptographicHash>
#include <QInputDialog>
#include <QLineEdit>

namespace libgnss
{

QString IGSDirectoryProfile::rememberdir=QString::fromUtf8(
			"Выберите ранее сохраненную директорию из списка");


QIGSPathTemplateEdit::QIGSPathTemplateEdit(const QString &dialogtitle,
										   QLineEdit *igspath,
										   QLineEdit *mrkname,
										   const QString &value,
										   QWidget *parent)
	: QWidget(parent)
{
	mrknameedit = mrkname;
	this->dialogtitle = dialogtitle;
	igspathwidget = igspath;
	tmpl = new QLineEdit(value,this);
	QToolButton * ShowDialog  = new QToolButton(this);
	ShowDialog->setText("...");
	connect(ShowDialog,SIGNAL(clicked()),this,SLOT(showDialog()));
	QHBoxLayout * lay = new QHBoxLayout();
	lay->addWidget(tmpl);
	lay->addWidget(ShowDialog);
	setLayout(lay);
//	lay->setVerticalSpacing(1);
	setContentsMargins(0,0,0,0);
	lay->setMargin(0);
}

QString QIGSPathTemplateEdit::text()const
{
	return tmpl->text();
}

void QIGSPathTemplateEdit::setText(const QString &newtext)
{
	tmpl->setText(newtext);
}

void QIGSPathTemplateEdit::showDialog()
{
	QString editthis = tmpl->text();
	QString mrkname = mrknameedit->text();
	if (mrkname.length() != 4)
		mrkname = "%MRKN";
	IGSTemplateEdit::editIGSTemplate(dialogtitle,igspathwidget->text(),
									 mrkname, editthis);
	tmpl->setText(editthis);
}

IGSDirectoryProfile::IGSDirectoryProfile(const QString &organization,
										 const QString &application,
										 QLineEdit * stationname,
										 const QStringList & coordsystems,
										 QWidget *parent)
	: QWidget(parent)
{
	org = organization;
	app = application;
	QGridLayout * chooseigslay = new QGridLayout();
	setLayout(chooseigslay);
	chooseigslay->setVerticalSpacing(1);
	igsdirectories = new QComboBox(this);
	QSettings sets(org,app);
	QStringList dirslist = sets.value("IGSDirectories").toStringList();
	dirslist.prepend(rememberdir);
	igsdirectories->addItems(dirslist);
	connect(igsdirectories,SIGNAL(activated(QString)),this,
			SLOT(loadIGSDirectoryProfile(QString)));
	QPushButton * saveIGSProfile = new QPushButton(
				QString::fromUtf8("Запомнить директорию"),this);
	saveIGSProfile->setFixedHeight(igsdirectories->height());
	saveIGSProfile->setIcon(QIcon(":/menuicons/document-save.png"));
	QToolButton * deleteIGSProfile = new QToolButton(this);
	deleteIGSProfile->setText("");
	deleteIGSProfile->setIcon(QIcon(":/menuicons/edit-delete.png"));
	deleteIGSProfile->setFixedHeight(saveIGSProfile->height());
	igsdirectories->setFixedHeight(deleteIGSProfile->height());
	connect(saveIGSProfile,SIGNAL(clicked()),this,
			SLOT(saveIGSDirectoryProfile()));
	connect(deleteIGSProfile,SIGNAL(clicked()),this,
			SLOT(forgetCurrentIGSDirectoryProfile()));
	QHBoxLayout * sublay1 = new QHBoxLayout();
	sublay1->addWidget(igsdirectories,1);
	sublay1->addWidget(saveIGSProfile,0);
	sublay1->addWidget(deleteIGSProfile,0);
	chooseigslay->addLayout(sublay1,0,0,1,5);
	igsdir = new QLineEdit(this);
	QToolButton * chigsdir = new QToolButton(this);
	chigsdir->setText("...");
	connect(chigsdir,SIGNAL(clicked()),this,SLOT(changeIGSDir()));
	chooseigslay->addWidget(
				new QLabel(QString::fromUtf8("Путь к продуктам IGS:"),this),
				1,0);
	chooseigslay->addWidget(igsdir,1,1,1,3);
	chooseigslay->addWidget(chigsdir,1,4);
	antexfile = new QLineEdit(QString::fromUtf8("igs08.atx"),this);
	QToolButton * chantex = new QToolButton(this);
	chantex->setText("...");
	connect(chantex,SIGNAL(clicked()),this,SLOT(chooseAntexFile()));
	chooseigslay->addWidget(
				new QLabel(QString::fromUtf8("Antex-файл:"),this),2,0);
	chooseigslay->addWidget(antexfile,2,1,1,3);
	chooseigslay->addWidget(chantex,2,4);

	clktmpl = new QIGSPathTemplateEdit(
				QString::fromUtf8("Шаблон имени Clock-файлов"),igsdir,
				stationname,"",this);
	chooseigslay->addWidget(
				new QLabel(QString::fromUtf8("Шаблон имен clock-файлов"),this),
				3,0);
	chooseigslay->addWidget(clktmpl,3,1,1,4);

	sp3tmpl = new QIGSPathTemplateEdit(
				QString::fromUtf8("Шаблон имени SP3-файлов"), igsdir,
				stationname,"",this);
	chooseigslay->addWidget(
				new QLabel(QString::fromUtf8("Шаблон имен SP3-файлов"),this),
				4,0);
	chooseigslay->addWidget(sp3tmpl,4,1,1,4);

	snxtmpl = new QIGSPathTemplateEdit(
				QString::fromUtf8("Шаблон имени SINEX-файлов"),igsdir,
				stationname,"",this);
	chooseigslay->addWidget(
				new QLabel(QString::fromUtf8("Шаблон имен SINEX-файлов"),this),
				5,0);
	chooseigslay->addWidget(snxtmpl,5,1);
	chooseigslay->addWidget(new QLabel(QString::fromUtf8("Система координат"),
									   this),5,2);
	snxcs=new QComboBox(this);
	snxcs->addItems(coordsystems);
	snxcs->setCurrentIndex(coordsystems.size()-1);

//	snxcs->addItem(QString::fromUtf8("IGb08"));
//	snxcs->addItem(QString::fromUtf8("ITRF08"));
//	snxcs->addItem(QString::fromUtf8("IGS05"));
//	snxcs->addItem(QString::fromUtf8("ITRF05"));
//	snxcs->addItem(QString::fromUtf8("ITRF00"));
//	snxcs->addItem(QString::fromUtf8("WGS-05"));
//	snxcs->addItem(QString::fromUtf8("WGS84"));
//	snxcs->addItem(QString::fromUtf8("ПЗ-90"));
//	snxcs->addItem(QString::fromUtf8("ПЗ-90.02"));
//	snxcs->addItem(QString::fromUtf8("ПЗ-90.11"));
	chooseigslay->addWidget(snxcs,5,3,1,2);

	trotmpl = new QIGSPathTemplateEdit(
				QString::fromUtf8("Шаблон имени SINEX-Tropo-файлов"),
									   igsdir,stationname,"",this);
	chooseigslay->addWidget(
				new QLabel(QString::fromUtf8("Шаблон имен SINEX-Tropo-файлов"),
						   this), 6,0);
	chooseigslay->addWidget(trotmpl,6,1,1,4);
}

QString IGSDirectoryProfile::getIGSDirectory()
{
	return igsdir->text();
}

QString IGSDirectoryProfile::getAntexName()
{
	return antexfile->text();
}

QString IGSDirectoryProfile::getClkTemplate()
{
	return clktmpl->text();
}

QString IGSDirectoryProfile::getSNXTemplate()
{
	return snxtmpl->text();
}

QString IGSDirectoryProfile::getSP3Template()
{
	return sp3tmpl->text();
}

QString IGSDirectoryProfile::getTroTemplate()
{
	return trotmpl->text();
}

QString IGSDirectoryProfile::getSNXCoordSys()
{
	return snxcs->currentText();
}

void IGSDirectoryProfile::setIGSDirectory(const QString & txt)
{
	igsdir->setText(txt);
}

void IGSDirectoryProfile::setAntexName(const QString & txt)
{
	antexfile->setText(txt);
}

void IGSDirectoryProfile::setClkTemplate(const QString & txt)
{
	clktmpl->setText(txt);
}

void IGSDirectoryProfile::setSP3Template(const QString & txt)
{
	sp3tmpl->setText(txt);
}

void IGSDirectoryProfile::setTroTemplate(const QString & txt)
{
	trotmpl->setText(txt);
}

void IGSDirectoryProfile::setSNXTemplate(const QString & txt)
{
	snxtmpl->setText(txt);
}

void IGSDirectoryProfile::setSNXCoordSys(const QString & txt)
{
	int idx = snxcs->findText(txt);
	if (idx>0)
		snxcs->setCurrentIndex(idx);
	else
		QMessageBox::warning(this,"Система координат SINEX-файла",
					"Неизвестная система координат SINEX-файла: "+txt+
							 " будет проигнорирована.",QMessageBox::Ok);
}

void IGSDirectoryProfile::changeIGSDir()
{
	QString curigsdir = QDir::currentPath();
	if (QDir(igsdir->text()).exists())
		curigsdir = igsdir->text();
	QString dir = QFileDialog::getExistingDirectory(
				this, QString::fromUtf8("Путь к продуктам IGS"),
				QDir::currentPath());
	if (dir=="")
		return;
	igsdir->setText(dir);
}

void IGSDirectoryProfile::chooseAntexFile()
{
	QDir qigsdir(igsdir->text());
	if (!(qigsdir.exists()))
		qigsdir = QDir::root();
	QString antexfilename = QFileDialog::getOpenFileName(
				this, QString::fromUtf8("Выберите ANTEX-файл"),
				qigsdir.path(),
				QString::fromUtf8("ANTEX (*.atx);;Все файлы(*.*)"));
	if (antexfilename == "")
		return;
	antexfilename = qigsdir.relativeFilePath(antexfilename);
	antexfile->setText(antexfilename);
}

void IGSDirectoryProfile::saveIGSDirectoryProfile()
{
	//Проверить, что директория существует
	QDir checkdirectory(igsdir->text());
	if (!(checkdirectory.exists()))
		if (QMessageBox::question(
			this, QString::fromUtf8("Сохранение пути к продуктам IGS"),
				QString::fromUtf8("Директория по данному пути не существует. "
				"Всё равно сохранить?"),QMessageBox::Yes,QMessageBox::No)
				== QMessageBox::No)
			return;

	//Если пользователь укажет пересохранить текущий профиль, дальнейшее
	//подтверждение не требуется.
	//В противном случае, забыть прежнее имя текущего профиля (затем
	//запросить новое)
	bool confirmrewrite = true;
	QString profilename = "";
	if (igsdirectories->currentText()!=rememberdir)
	{
		profilename = igsdirectories->currentText();
		if (QMessageBox::question(this,
			QString::fromUtf8("Запомнить директорию IGS"),
			QString::fromUtf8("Переписать существующий профиль директории?"),
			QMessageBox::Yes, QMessageBox::No) == QMessageBox::No)
		{
			profilename = "";
		}
		else
		{
			confirmrewrite = false;
		}
	}

	//Если имени текущего профиля нет, запросить его.
	if (profilename == "")
		profilename = QInputDialog::getText(this,
						QString::fromUtf8("Название профиля"),
					QString::fromUtf8("Укажите название нового профиля "
									  "директории IGS"));

	if (profilename == "")
		return;

	//Запросить подтверждение, если нужно переписать другой профиль
	QSettings sets(org, app);
	QStringList profiles = sets.value("IGSDirectories").toStringList();
	if (profiles.contains(profilename))
	{
		if (confirmrewrite)
			if (QMessageBox::question(this,
						QString::fromUtf8("Подтверждение"),
						QString::fromUtf8("Профиль с данным именем существует."
										" Переписать его?"),
						QMessageBox::Yes,
						QMessageBox::No) == QMessageBox::No)
				return;
	}
	else
		profiles.append(profilename);
	sets.setValue("IGSDirectories", profiles);
	QString hash = QString(QCryptographicHash::hash(profilename.toUtf8(),
							 QCryptographicHash::Md5).toHex());
	sets.setValue(hash + "_path", igsdir->text());
	sets.setValue(hash + "_antex", antexfile->text());
	sets.setValue(hash + "_clktmpl", clktmpl->text());
	sets.setValue(hash + "_sp3tmpl", sp3tmpl->text());
	sets.setValue(hash + "_snxtmpl", snxtmpl->text());
	sets.setValue(hash + "_trotmpl", trotmpl->text());
	sets.setValue(hash + "_crdsys", snxcs->currentText());
	igsdirectories->clear();
	int idx = profiles.indexOf(profilename);
	igsdirectories->addItems(profiles);
	igsdirectories->setCurrentIndex(idx);
}

void IGSDirectoryProfile::loadIGSDirectoryProfile(const QString & profilename)
{
	if (profilename==rememberdir)
		return;
	if (igsdirectories->itemText(0) == rememberdir)
		igsdirectories->removeItem(0);
	QSettings sets(org, app);
	QString hash = QString(QCryptographicHash::hash(profilename.toUtf8(),
							 QCryptographicHash::Md5).toHex());

	//Попробовать прочитать все настройки
	bool settingsOK = true;
	QVariant path_ = sets.value(hash+"_path");
	if (path_ == QVariant())
		settingsOK = false;
	QVariant antex_ = sets.value(hash+"_antex");
	if (antex_ == QVariant())
		settingsOK = false;
	QVariant clk_ = sets.value(hash+"_clktmpl");
	if (clk_ == QVariant())
		settingsOK = false;
	QVariant sp3_ = sets.value(hash+"_sp3tmpl");
	if (sp3_ == QVariant())
		settingsOK = false;
	QVariant snx_ = sets.value(hash+"_snxtmpl");
	if (snx_ == QVariant())
		settingsOK = false;
	QVariant tro_ = sets.value(hash+"_trotmpl");
	if (tro_ == QVariant())
		settingsOK = false;
	QVariant scs_ = sets.value(hash+"_crdsys");
	if (scs_ == QVariant())
		settingsOK = false;

	if (settingsOK == false)
		if (QMessageBox::warning(this,QString::fromUtf8("Потеря настроек"),
						QString::fromUtf8("Настройки профиля директории IGS:\n")
						+profilename
					+QString::fromUtf8("\nотеряны (файлы настроек повреждены,"
					"либо были некорректно отредактированы вручную)."
					"Удалить всю (возможно, некорректную) информацию "
					"о данной директории?"),QMessageBox::Yes,QMessageBox::No)
				== QMessageBox::Yes)
		{
			forgetCurrentIGSDirectoryProfile();
			return;
		}

	QString slost = QString::fromUtf8("Настройки утеряны");

	if (path_ == QVariant())
		igsdir->setText(slost);
	else
		igsdir->setText(path_.toString());
	if (antex_ == QVariant())
		antexfile->setText(slost);
	else
		antexfile->setText(antex_.toString());

	if (clk_ == QVariant())
		clktmpl->setText(slost);
	else
		clktmpl->setText(clk_.toString());

	if (sp3_ == QVariant())
		sp3tmpl->setText(slost);
	else
		sp3tmpl->setText(sp3_.toString());

	if (snx_ == QVariant())
		snxtmpl->setText(slost);
	else
		snxtmpl->setText(snx_.toString());

	if (tro_ == QVariant())
		trotmpl->setText(slost);
	else
		trotmpl->setText(tro_.toString());

	if (scs_ != QVariant())
	{
		int idx = snxcs->findText(scs_.toString(),Qt::MatchExactly);
		if (idx > -1)
			snxcs->setCurrentIndex(idx);
	}
}

void IGSDirectoryProfile::forgetCurrentIGSDirectoryProfile()
{
	QString profilename = igsdirectories->currentText();
	if (profilename==rememberdir)
		return;
	if (QMessageBox::question(this,QString::fromUtf8("Подтверждение"),
		QString::fromUtf8("Забыть настройки профиля директории с продуктами "
						  "IGS:\n")
			+profilename,QMessageBox::Yes, QMessageBox::No)==QMessageBox::No)
		return;
	QSettings sets(org, app);
	QStringList dirslist = sets.value("IGSDirectories").toStringList();
	int idx = dirslist.indexOf(profilename);
	if (idx>=0)
		dirslist.removeAt(idx);
	//Забыть директорию из настроек
	sets.setValue("IGSDirectories",dirslist);
	//Забыть параметры директории из настроек
	QString hash = QString(QCryptographicHash::hash(profilename.toUtf8(),
							 QCryptographicHash::Md5).toHex());
	sets.remove(hash+"_antex");
	sets.remove(hash+"_clktmpl");
	sets.remove(hash+"_sp3tmpl");
	sets.remove(hash+"_snxtmpl");
	sets.remove(hash+"_trotmpl");
	sets.remove(hash+"_crdsys");
	dirslist.prepend(rememberdir);
	igsdirectories->clear();
	igsdirectories->addItems(dirslist);
}
}

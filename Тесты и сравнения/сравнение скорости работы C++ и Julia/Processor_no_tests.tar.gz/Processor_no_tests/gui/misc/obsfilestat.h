#ifndef OBSFILESTAT_H_
#define OBSFILESTAT_H_

#include <QWidget>
#include <QMap>
#include <QString>
#include <QLabel>
#include <QThread>
#include <observables.h>
#include <ctime>

namespace libgnss
{

class DBTableCollection;
class ObservablesLoader;
class ObservationFileStatistics;

/**
 * @brief Счетчик измерительных данных
 *
 * Принимает измерительные данные от парсера и подсчитывает количество
 * измерительных данных разных типов от разных НКА
 */
class ObsLoaderThread : public QThread
{
	Q_OBJECT
public:
	ObservationFileStatistics * parent;
	ObsLoaderThread (ObservationFileStatistics*parent);
	inline void sigNewColumnValue(const QString & row, const QString & column,
								  int newnumber)
	{
		newColumnValue(row,column,newnumber);
	}

signals:
	void newColumnValue(const QString & row, const QString & column,
					  int newnumber);
protected:
	virtual void run();

};


/**
 * @brief Виджет, отображающий число измерений разных типов
 *
 * Виджет считывает измерения из файла (процесс загрузки запускается методом
 * startLoading(), который не реализован в базовом классе) и отображает в виде
 * таблицы число измерений каждого типа для каждого НКА и для каждой из
 * навигационных систем.
 *
 * Для создания класса, подсчитывающего измерения из конкретного источника
 * (C-кадра, RINEX-, или других форматов) необходимо перегрузить метод
 * startLoading().
 *
 * Подсчет запускается в отдельном потоке, поэтому можно видеть число уже
 * подсчитанных измерений, не дожидаясь окончания загрузки. Интервал обновления
 * составляет полсекунды.
 */
class ObservationFileStatistics : public QWidget
{
friend class ObsLoaderThread;
	Q_OBJECT
private:
	//Надписи таблицы в виде отображения:
	//Название столбца -> Название строки -> метка
	QMap<QString, QMap<QString, QLabel * > > labels;
	ObservableTypes * otypes;
	SatelliteHistory * history;
	NavigationSystem * navsys;

	//Строки таблицы в виде отображения:
	//Заголовок строки->Пара(номер строки, есть ли уже измерения данного типа)
	QMap<QString, QPair<int, bool> > obsnames;
	QMap<QString,int> colnames;
	ObsLoaderThread * loader;
protected:
	virtual void startLoading(QMap<QChar, ObservablesLoader *> loaders ) = 0;
public:
	ObservationFileStatistics(DBTableCollection * tcol,
							  QWidget * parent = 0);
	QString getObservableDenotement(int id);
	QString getSatelliteShortName(int id);
	QString getNavSystemName(char letter);
	void loadFile();
public slots:
	void setValue(const QString & row, const QString & column,
				  int newnumber);
};

//class RINEX2Statistics : public ObservationFileStatistics
//{
//private:
//	QString rinexfilename;
//protected:
//	void startLoading(QMap<QChar, ObservablesLoader *> loaders );
//public:
//	void setFileName(const QString & filename);
//};

class CFrameStatistics : public ObservationFileStatistics
{
private:
	QString cframefilename;
protected:
	virtual void startLoading(QMap<QChar, ObservablesLoader *> loaders );
public:
	CFrameStatistics(DBTableCollection * tcol,
							  QWidget * parent = 0);
	void setFileName(const QString & filename);
};

}

#endif

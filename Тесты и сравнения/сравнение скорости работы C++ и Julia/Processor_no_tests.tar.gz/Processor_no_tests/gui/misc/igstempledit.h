#ifndef IGSTEMPLEDIT_H_
#define IGSTEMPLEDIT_H_

#include <string>
#include <Types.h>

#include <QDialog>
#include <QString>
#include <QDateTime>
//#include <QStandardItemModel>
//#include <QLineEdit>
//#include <QDateTimeEdit>
//#include <QComboBox>
//#include <QTreeView>
//#include <QLabel>

class QLineEdit;
class QDateTimeEdit;
class QComboBox;
class QTreeView;
class QLabel;


namespace libgnss
{




/**
 * @brief Заполнение шаблона имени IGS-файла
 * @param tmpl Шаблон имени файла
 * @param w Неделя GPS
 * @param d День GPS
 * @param f Дробная часть дня
 * @return Заполненный шаблон
 *
 * Функция принимает шаблон, в котором на месте переменных стоят плейсхолдеры.
 * Соответствующие им значения вычисляются и подставляются в шаблон, давая
 * итоговое имя файла.
 *
 * Допустимые плейсхолдеры:
 *
 * %WWWW - неделя GPS (четырехзначное число)
 * %D - день недели GPS (одна цифра 0-6)
 * %YYYY - год (четырехзначное число)
 * %yy - год (двухзначное число)
 * %YDD - день в году (трехзначное число)
 * %MM - месяц (двухзначное число)
 * %MD - день месяца (двухзначное число)
 * %MRKN - название маркера (БИС)
 * %SNN - имя НКА
 * %N - буква навигационной системы
 *
 * Если при переводе в строку получается меньшее число цифр, то строка
 * дополняется нулями.
 */
std::string IGSfilenameFromTemplate(const std::string & tmpl,
									const std::string &markername,
							   const std::string & satname,
							   int w, int d, real f);

class IGSTemplateEdit : public QDialog
{
	Q_OBJECT
private:
	QLineEdit * templ;
	QDateTimeEdit * from;
	QDateTimeEdit * until;
	QComboBox * tscale;
	QLabel * showsamples;
	std::string productpath;
	std::string markername;
protected slots:
	void chgDt(const QDateTime & newdt);
	void templchg(const QString & newtmpl);
	void refresh();
	void finished_sig(int result);
public:
	IGSTemplateEdit (const QString & title,
					 const QString & igsdir,
					 const QString & mrkname,
					 const QString & initialvalue,
					 QWidget * parent);

	static void editIGSTemplate(const QString & dialogtitle,
								const QString &igsdir, const QString &mrkname,
								QString &result);
};

}

#endif

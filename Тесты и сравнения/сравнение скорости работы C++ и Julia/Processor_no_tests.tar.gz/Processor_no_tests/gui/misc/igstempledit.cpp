#include <igstempledit.h>
#include <tstemplate.h>
#include <QGridLayout>
#include <QLabel>
#include <QScrollArea>
#include <QPushButton>
#include <UTCDateTime.h>
#include <fstream>
#include <QSettings>
#include <QPalette>
#include <QDebug>
#include <QFile>
#include <QLineEdit>
#include <QDateTimeEdit>

using namespace std;

namespace libgnss
{

string IGSfilenameFromTemplate(const string & tmpl,
							   const string & markername, const string &satname,
							   int w, int d, real f)
{
	map<string,string> replacements;
	replacements["%MRKN"]=markername;
	replacements["%SNN"]=satname;
	replacements["%N"]=satname.substr(0,1);
	return fillTemplate(tmpl,UTCDateTime::fromGPSWeekDayFrac(w,d,f),
						replacements);
//	string result = tmpl;
//	char tmp[12];

//	//Заменить %MRKN
//	if (markername!="%MRKN")
//		while (true)
//		{
//			int p = result.find("%MRKN");
//			if (p == string::npos)
//				break;
//			result.replace(p,5,markername);
//		}

//	if (satname!="%SNN")
//	{
//		//Заменить %SNN
//		while (true)
//		{
//			int p = result.find("%SNN");
//			if (p == string::npos)
//				break;
//			result.replace(p,4,satname);
//		}
//		//Заменить &N
//		char navletter = satname[0];
//		while (true)
//		{
//			int p = result.find("%N");
//			if (p == string::npos)
//				break;
//			result.replace(p,2,string(1,navletter));
//		}
//	}

//	//Заменить %WWWW неделей GPS
//	int N = sprintf(tmp, "%04d", w);
//	while (true)
//	{
//		int p = result.find("%WWWW");
//		if (p == string::npos)
//			break;
//		result.replace(p,5,string(&(tmp[0])));
//	}

//	//Заменить %D днем GPS
//	while (true)
//	{
//		int p = result.find("%D");
//		if (p== string::npos)
//			break;
//		result.replace(p,2,string(1,'0'+d));
//	}

//	//Вычислить дату GPS
//	UTCDateTime dt = UTCDateTime::fromGPSWeekDayFrac(w,d,f);
//	int year, month, day, hour, minute;
//	double second;
//	dt.getGPSDateTime(year,month,day,hour,minute,second);
//	int year2 = year % 100;

//	//Заменить %YYYY
//	N = sprintf(tmp, "%04d", year);
//	while (true)
//	{
//		int p = result.find("%YYYY");
//		if (p== string::npos)
//			break;
//		result.replace(p,5,string(&(tmp[0])));
//	}

//	//Заменить %MM
//	N = sprintf(tmp, "%02d", month);
//	while (true)
//	{
//		int p = result.find("%MM");
//		if (p== string::npos)
//			break;
//		result.replace(p,3,string(&(tmp[0])));
//	}

//	//Заменить %MD
//	N = sprintf(tmp, "%02d", day);
//	while (true)
//	{
//		int p = result.find("%MD");
//		if (p== string::npos)
//			break;
//		result.replace(p,3,string(&(tmp[0])));
//	}

//	//Заменить %yy
//	N = sprintf(tmp, "%02d", year2);
//	while (true)
//	{
//		int p = result.find("%yy");
//		if (p== string::npos)
//			break;
//		result.replace(p,3,string(&(tmp[0])));
//	}

//	//Вычислить число дней от начала года
//	UTCDateTime dt0 = UTCDateTime::fromGPSDateTime(year,1,1,0,0,0);
//	real delta = dt.getTAIJ2000() - dt0.getTAIJ2000();
//	int dayofyear = floor(delta/86400) + 1;

//	//Заменить %DDD
//	N = sprintf(tmp, "%03d", dayofyear);
//	while (true)
//	{
//		int p = result.find("%YDD");
//		if (p== string::npos)
//			break;
//		result.replace(p,4,string(&(tmp[0])));
//	}

//	return result;

}


IGSTemplateEdit ::IGSTemplateEdit(const QString & dialogtitle,
								const QString &igsdir,
								  const QString & mrkname,
								  const QString &initialvalue, QWidget *parent)
	: QDialog (parent)
{
	connect(this,SIGNAL(finished(int)),this,SLOT(finished_sig(int)));
	setWindowTitle(dialogtitle);
	productpath = string(igsdir.toUtf8().data()) + "/";
	markername = mrkname.toStdString();
	connect(this,SIGNAL(finished(int)),this,SLOT(finished_sig(int)));
	QGridLayout * lay = new QGridLayout();
	lay->setColumnStretch(3,0);
	lay->setColumnStretch(4,0);
	lay->setColumnStretch(2,1);
	QLabel * hint = new QLabel(this);
	hint->setTextFormat(Qt::RichText);
	hint->setText(QString::fromUtf8(
				"Имена файлов формируются путём подстановки значений "
				"переменных в шаблон. Доступные переменные:<br/>"
				"<style>td{padding-left:15px;}</style>"
				"<table>"
				"<tr><td>%WWWW - неделя GPS (4 знака)</td>"
				"<td>%D - день GPS-недели (1 знак)</td></tr>"
				"<tr><td>%YDD - день в году в шкале GPS (3 знака)</td>"
				"<td>%YYYY - год в шкале GPS (4 знака)</td></tr>"
				"<tr><td>%yy - год в шкале GPS (2 знака)</td>"
				"<td>%MM - месяц в шкале GPS (2 знака)</td></tr>"
				"<tr><td>%MD - день месяца в шкале GPS (2 знака)</td>"
				"<td>%MRKN - имя маркера (4 символа)</td></tr>"
				"</table><br/><br/>"
				"При необходимости недостающие знаки дополняются нулями."));
	lay->addWidget(hint,0,0,1,5);
	lay->addWidget(new QLabel(QString::fromUtf8("Путь к продуктам IGS:\n")+
							  igsdir),1,0,1,5);
	lay->addWidget(new QLabel(QString::fromUtf8("Шаблон:"),this),2,0);
	templ = new QLineEdit(initialvalue,this);
	connect(templ,SIGNAL(textEdited(QString)),this,SLOT(templchg(QString)));
	lay->addWidget(templ,2,1,1,4);
	QPushButton * okbtn = new QPushButton(QString::fromUtf8("ОК"),this);
	connect(okbtn,SIGNAL(clicked()),this,SLOT(accept()));
	QPushButton * cancelbtn = new QPushButton(QString::fromUtf8("Отмена"),this);
	connect(cancelbtn,SIGNAL(clicked()),this,SLOT(reject()));
	lay->addWidget(okbtn,3,3);
	lay->addWidget(cancelbtn,3,4);
	QLabel * hint2 = new QLabel (QString::fromUtf8("Для проверки правильности "
		"введённого шаблона выберите приблизительный интервал обработки"),this);
	lay->addWidget(hint2,4,0,1,5);
	lay->addWidget(new QLabel(QString::fromUtf8("Время начала:"),this),5,0);
	lay->addWidget(new QLabel(QString::fromUtf8("Время конца:"),this),6,0);
	QSettings sets;
	QVariant from_save = sets.value("IGSTemplateEdit_t0");
	QVariant until_save = sets.value("IGSTemplateEdit_t1");
	from = new QDateTimeEdit(this);
	from->setDisplayFormat("hh:mm:ss dd.MM.yyyy");
	until = new QDateTimeEdit(this);
	until->setDisplayFormat("hh:mm:ss dd.MM.yyyy");
	if (from_save!=QVariant())
		from->setDateTime(from_save.toDateTime());
	if (until_save!=QVariant())
		until->setDateTime(until_save.toDateTime());
	connect(from,SIGNAL(dateTimeChanged(QDateTime)),this,
			SLOT(chgDt(QDateTime)));
	connect(until,SIGNAL(dateTimeChanged(QDateTime)),this,
			SLOT(chgDt(QDateTime)));
	lay->addWidget(from,5,1,1,4);
	lay->addWidget(until,6,1,1,4);
	QScrollArea * scroll = new QScrollArea(this);
	lay->addWidget(scroll,7,0,1,5);
	QPalette samppalette = scroll->palette();
	samppalette.setColor(QPalette::Background, QColor(255,255,255));
	scroll->setPalette(samppalette);
	showsamples = new QLabel(this);
	scroll->setWidget(showsamples);
	setLayout(lay);
	refresh();
}

void IGSTemplateEdit::editIGSTemplate(const QString & dialogtitle,
									  const QString &igsdir,
									  const QString &mrkname,
									  QString &result)
{
	IGSTemplateEdit * edit = new IGSTemplateEdit(dialogtitle,igsdir,mrkname,
												 result,0);
	int d = edit->exec();
	if (d == QDialog::Accepted)
		result = edit->templ->text();
	delete edit;
}

void IGSTemplateEdit::chgDt(const QDateTime & newdt)
{
	refresh();
}

void IGSTemplateEdit::templchg(const QString & newtmpl)
{
	refresh();
}

void IGSTemplateEdit::refresh()
{
	QDateTime dt1 = from->dateTime();
	QDateTime dt2 = until->dateTime();
	if (dt1>dt2)
		return;
	UTCDateTime udt1=UTCDateTime::fromGPSDateTime(dt1.date().year(),
												  dt1.date().month(),
												  dt1.date().day(),
												  dt1.time().hour(),
												  dt1.time().minute(),
												  dt1.time().second());
	UTCDateTime udt2=UTCDateTime::fromGPSDateTime(dt2.date().year(),
												  dt2.date().month(),
												  dt2.date().day(),
												  dt2.time().hour(),
												  dt2.time().minute(),
												  dt2.time().second());
	int w1, w2, d1, d2;
	real f1, f2;
	udt1.getGPSWeekDayFrac(w1,d1,f1);
	udt2.getGPSWeekDayFrac(w2,d2,f2);
	int day1 = w1*7+d1;
	int day2 = w2*7+d2;
	QString refreshed = "<table>";
	string curtmpl (templ->text().toUtf8().data());
	if (curtmpl == "")
		return;
	for (int d = day1; d<=day2; d++)
	{
		refreshed+="<tr><td>";
		int gpsd = d % 7;
		int week = (d-gpsd)/7;
		string fn=productpath+IGSfilenameFromTemplate(curtmpl,markername,
													  "%SNN",
													  week,
													  gpsd,0);
		refreshed+=QString::fromUtf8(fn.c_str());
		refreshed+="</td>";
		QFile check(QFile::decodeName(fn.c_str()));
		if (check.exists())
			refreshed+=QString::fromUtf8("<td>Найден</td>");
		else
			refreshed+=QString::fromUtf8("<td color:Pink>Не найден</td>");
		refreshed+="</tr>";
		if (d-day1 > 30)
		{
			refreshed+="<tr><td>...</td><td/></tr>";
			break;
		}
	}
	refreshed+="</table>";
	showsamples->setText(refreshed);
	showsamples->adjustSize();
}

void IGSTemplateEdit::finished_sig(int result)
{
	QSettings sets;
	sets.setValue("IGSTemplateEdit_t0", QVariant(from->dateTime()));
	sets.setValue("IGSTemplateEdit_t1", QVariant(until->dateTime()));
}
}

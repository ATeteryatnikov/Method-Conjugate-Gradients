#ifndef QREGEXPCHECKEDIT_H_
#define QREGEXPCHECKEDIT_H_

#include <QLineEdit>
#include <QString>
#include <QRegExp>

namespace libgnss
{


class QRegExpCheckEdit : public QLineEdit
{
	Q_OBJECT
private:
	QRegExp rgexp;
	QColor backgroundcolour;
public:
	QRegExpCheckEdit (const QString & regexp, const QString & value = "",
					  QWidget * parent = 0);
	bool isValid();
	void setNumber(double n);
protected slots:
	void edited(const QString & newtext);
};

}

#endif

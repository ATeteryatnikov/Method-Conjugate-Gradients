#ifndef FULLSESSION_H_
#define FULLSESSION_H_

#include <string>
#include <DBTableCollection.h>

namespace libgnss
{

class GLONASSModels;
class Settings;
class LeapSeconds;
class SatelliteHistory;
class AntennaModels;
class ReceivingAntennas;
class SVAntennas;
class Frames;
class CoordinateTypes;
class PhaseCentreOffsetFrequency;
class PhaseCentreVariationGrid;
class SVPhaseCentreModels;
class ReceivingAntennaPhaseCentreModels;
class Markers;
class Receivers;
class ObservableTypes;
class ObservationSource;
class Observables;
class NavigationSystem;
class GLONASSFrequencySlots;
class ERPStorage;
class ParamTrajectory;
class MarkerEccentricity;
class MarkerPosition;
class ITRFTranslation;
class ClockBias;
class ParamTroposphere;
class ParamDCB;
class ParamPhaseAmbiguity;
class ClockVarBinomial;
class ClockLinearResidue;
class ReferenceFrames;
class GravityPotential;
class LongperiodSolidTides;
class DiurnalSolidTides;
class SemidiurnalSolidTides;
class OceanTides;
class OceanPoleTides;
class CelestialBodies;
class ParameterRadPressureBerne;

/**
 * @brief Сеанс, включающий все доступные в библиотеке таблицы
 */
class Session : public DBTableCollection
{
public:
	Settings*sets;
	LeapSeconds*leaps;
	SatelliteHistory*his;
	AntennaModels*antmods;
	ReceivingAntennas*recants;
	SVAntennas*svants;
	Frames*frames;
	CoordinateTypes*ctypes;
	PhaseCentreOffsetFrequency*phcof;
	PhaseCentreVariationGrid*phcvg;
	SVPhaseCentreModels*svphcm;
	ReceivingAntennaPhaseCentreModels*rcantpcm;
	Markers*mrk;
	Receivers*rec;
	ObservableTypes*otypes;
	ObservationSource*osrc;
	Observables*obs;
	NavigationSystem*ns;
	GLONASSFrequencySlots*gfs;
	ERPStorage*erp;
	ParamTrajectory*traj;
	MarkerEccentricity*ecc;
	MarkerPosition*mpos;
	ParameterRadPressureBerne*berne;
	ITRFTranslation*itrft;
	ClockBias*clkbias;
	ParamTroposphere*trop;
	ParamDCB*dcb;
	ParamPhaseAmbiguity*phsambig;
	ClockVarBinomial*clkvarbin;
	ClockLinearResidue*clkvarresid;
	ReferenceFrames*rfrm;
	GravityPotential*grav;
	LongperiodSolidTides*lpst;
	DiurnalSolidTides*dst;
	SemidiurnalSolidTides*sdst;
	OceanTides*ot;
	OceanPoleTides*opt;
	CelestialBodies*cb;
	GLONASSModels*glom;

	Session(const std::string & coordinates="coordinates.tc",
			const std::string & leapseconds="leap_seconds.dates");
	~Session();
};

}
#endif

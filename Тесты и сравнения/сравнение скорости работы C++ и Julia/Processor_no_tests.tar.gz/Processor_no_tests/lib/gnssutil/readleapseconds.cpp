#include <readleapseconds.h>
#include <DBVariant.h>
#include <UTCDateTime.h>
#include <string>

using namespace std;

namespace libgnss
{


ReadLeapSecondsError::ReadLeapSecondsError(const std::string & what)
	: StrException("ReadLeapSecondsError",
			"Ошибка чтения секунд координации из человеко-читаемого формата: "
				   +what)
{

}

void addLeapSecond(LeapSeconds &target, const string &datetime)
{
	int curleapsecond;
	real curdate;
	if (target.count() == 0)
	{
		target.insertRow(Tuple()<<394372835, Tuple()<<35);
		target.insertRow(Tuple()<<284040034, Tuple()<<34);
		target.insertRow(Tuple()<<189345633, Tuple()<<33);
		target.insertRow(Tuple()<<-31579168, Tuple()<<32);
		target.insertRow(Tuple()<<-79012769, Tuple()<<31);
		target.insertRow(Tuple()<<-126273570, Tuple()<<30);
		target.insertRow(Tuple()<<-173707171, Tuple()<<29);
		target.insertRow(Tuple()<<-205243172, Tuple()<<28);
		target.insertRow(Tuple()<<-236779173, Tuple()<<27);
		target.insertRow(Tuple()<<-284039974, Tuple()<<26);
		target.insertRow(Tuple()<<-315575975, Tuple()<<25);
		target.insertRow(Tuple()<<-378734376, Tuple()<<24);
		target.insertRow(Tuple()<<-457703977, Tuple()<<23);
		target.insertRow(Tuple()<<-520862378, Tuple()<<22);
		target.insertRow(Tuple()<<-552398379, Tuple()<<21);
		target.insertRow(Tuple()<<-583934380, Tuple()<<20);
		target.insertRow(Tuple()<<-662731181, Tuple()<<19);
		target.insertRow(Tuple()<<-694267182, Tuple()<<18);
		target.insertRow(Tuple()<<-725803182, Tuple()<<17);
		target.insertRow(Tuple()<<-757339183, Tuple()<<16);
		target.insertRow(Tuple()<<-788875184, Tuple()<<15);
		target.insertRow(Tuple()<<-820411185, Tuple()<<14);
	}

	DBTable::DBConstIterator it = target.end();
	it.dec(1);
	curdate = it.keyColumnValue(0).toDouble();
	curleapsecond = it[0].toInt();

	//1) Распознать дату в передаваемой строке
	UTCDateTime utc = UTCDateTime::fromUTCDateTimeString(trim(datetime));

	//2) Вычислить время введения секунды в шкале TAI
	real taij2000 = utc.getTAIJ2000();
	//Если эта секунда координации уже была добавлена - пропустить её.
	//Если это новая секунда координации, но она раньше уже добавленных, то
	//возникает ошибка.
	if (taij2000 <= curdate)
	{
		if (target.find(curdate).isEnd())
			throw ReadLeapSecondsError("Можно добавлять секунды координции"
						   " только в порядке возрастания.");
		return;
	}

	//3) Записать секунду в таблицу
	curdate = taij2000 + 1;
	curleapsecond ++;
	target.insertRow(Tuple()<<curdate, Tuple()<<curleapsecond);
}

void readLeapSeconds(LeapSeconds & target, istream & data)
{
	while(true)
	{
		if (data.eof())
			break;
		string line;
		getline(data,line);
		if (trim(line) == "")
			break;
		try
		{
			addLeapSecond(target,line);
		}
		catch (const ReadLeapSecondsError & e)
		{

		}

	}
}
}

#include <fstream>

using namespace std;

#include <fullsession.h>
#include <DBTableCollection.h>
#include <PhaseCentre.h>
#include <Pseudorange.h>
#include <StdTables.h>
#include <ERPStorage.h>
#include <ParamTrajectory.h>
#include <Troposphere.h>
#include <dcb.h>
#include <Frames.h>
#include <PseudorangeRegularise.h>
#include <ClockVariance.h>
#include <GravityPotential.h>
#include <PhaseAmbiguity.h>
#include <SiteDisplacement.h>
#include <readleapseconds.h>
#include <observables.h>
#include <TimeShift.h>
#include <LoadEGM08.h>
#include <RadPressureBerne.h>
#include <readRINEXNavGLO.h>

namespace libgnss
{

Session::Session(const string &coordinates, const string &leapseconds)
{
	sets=new Settings(this);
	leaps=new LeapSeconds(this);
	his=new SatelliteHistory(this);
	antmods=new AntennaModels(this);
	recants=new ReceivingAntennas(this);
	svants=new SVAntennas(this);
	frames=new Frames(this);
	ctypes=new CoordinateTypes(this);
	phcof=new PhaseCentreOffsetFrequency(this);
	phcvg=new PhaseCentreVariationGrid(this);
	svphcm=new SVPhaseCentreModels(this);
	rcantpcm=new ReceivingAntennaPhaseCentreModels(this);
	mrk=new Markers(this);
	rec=new Receivers(this);
	otypes=new ObservableTypes(this);
	osrc=new ObservationSource(this);
	obs=new Observables(this);
	ns=new NavigationSystem(this);
	gfs=new GLONASSFrequencySlots(this);
	erp=new ERPStorage(this);
	berne=new ParameterRadPressureBerne(this);
	traj=new ParamTrajectory(this);
	ecc=new MarkerEccentricity(this);
	mpos=new MarkerPosition(this);
	itrft=new ITRFTranslation(this);
	clkbias=new ClockBias(this);
	trop=new ParamTroposphere(this);
	dcb=new ParamDCB(this);
	phsambig=new ParamPhaseAmbiguity(this);
	clkvarbin=new ClockVarBinomial(this);
	clkvarresid=new ClockLinearResidue(this);
	rfrm=new ReferenceFrames(this);
	grav=new GravityPotential(this);
	lpst=new LongperiodSolidTides(this);
	dst=new DiurnalSolidTides(this);
	sdst=new SemidiurnalSolidTides(this);
	ot=new OceanTides(this);
	opt=new OceanPoleTides(this);
	cb=new CelestialBodies(this);
	cb->loadDefaultValues();
	glom=new GLONASSModels(this);
	LoadEGM08(*this,20);

	//Загрузка секунд координации
	if (leapseconds!="")
	{
		ifstream ls_f(leapseconds.c_str());
		if (ls_f.is_open() == false)
			throw FileNotFoundException(leapseconds);
		readLeapSeconds(*leaps, ls_f);
		ls_f.close();
	}

	//Загрузка систем координат
	if (coordinates!="")
	{
		ifstream coords_f(coordinates.c_str());
		if (coords_f.is_open()==false)
			throw FileNotFoundException(coordinates);
		readFromStream(coords_f, cout);
		coords_f.close();
	}

	//Список навигационных систем
	istringstream navsystems(
					"navigation_systems	G	GPS	USDoD\n"
					"navigation_systems	R	ГЛОНАСС	РосКосмос\n");
	readFromStream(navsystems,cout);
}

Session::~Session()
{
	delete glom;
	delete cb;
	delete opt;
	delete ot;
	delete sdst;
	delete dst;
	delete lpst;
	delete grav;
	delete rfrm;
	delete clkvarresid;
	delete clkvarbin;
	delete phsambig;
	delete dcb;
	delete trop;
	delete clkbias;
	delete itrft;
	delete mpos;
	delete ecc;
	delete traj;
	delete berne;
	delete erp;
	delete gfs;
	delete ns;
	delete obs;
	delete osrc;
	delete otypes;
	delete rec;
	delete mrk;
	delete rcantpcm;
	delete svphcm;
	delete phcvg;
	delete phcof;
	delete ctypes;
	delete frames;
	delete svants;
	delete recants;
	delete antmods;
	delete his;
	delete leaps;
	delete sets;
}
}

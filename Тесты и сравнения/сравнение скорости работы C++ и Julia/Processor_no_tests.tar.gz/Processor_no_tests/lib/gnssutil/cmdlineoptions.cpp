#include <cmdlineoptions.h>
#include <Settings.h>

namespace libgnss
{

SettingKeyNotDefined::SettingKeyNotDefined(const string &key)
	: StrException("SettingKeyNotDefined", "Ключ опции командной строки '"
				   +key+"' должен быть задан до сопоставления его с "
				   "настройками обработчика.")
{

}

AdditiveKeyError::AdditiveKeyError(const string &cmdline_key,
								   const string &set_hint)
	: StrException("AdditiveKeyError", "Ключ командной строки '"+cmdline_key
				   +"' не может быть аддитивным, поскольку аргументу данного "
				   "ключа сопоставлена настройка '"+set_hint+"', тип которой "
				   "тличается от 'array'.")
{

}

GNSSOptionsParser::GNSSOptionsParser()
{

}

void GNSSOptionsParser::addOption(const std::string & cmdline_key,
			   const std::string & user_hint)
{
	options[cmdline_key].hint = user_hint;
}

void GNSSOptionsParser::forgetOption(const std::string & cmdline_key)
{
	if (options.find(cmdline_key) == options.end())
		return;
	options.erase(cmdline_key);
}

void GNSSOptionsParser::setAdditive ( const std::string & cmdline_key,
									  bool additive )
{
	if (options.find(cmdline_key) == options.end())
		throw SettingKeyNotDefined(cmdline_key);
	//Проверить, что все настройки имеют тип "массив"
	for (std::list<SettingKey>::iterator
		 it = options.at(cmdline_key).settingslist.begin();
		 it != options.at(cmdline_key).settingslist.end();
		 ++it)
	{
		SettingKey key = *it;
		Tuple skey = Tuple()<<key.group<<key.module<<key.key;
		std::string typename_s =
				Settings::Enumerator::enumerator()->read(skey)[0].toString();
		std::string hint_s =
				Settings::Enumerator::enumerator()->read(skey)[1].toString();
		if (CType::getCType(typename_s) != Variant::TYPE_ARRAY)
			throw AdditiveKeyError(cmdline_key, hint_s);
	}
	options[cmdline_key].additive = additive;
}

void GNSSOptionsParser::addSettingToOption(const string &cmdline_key,
										   const string &group,
										   const string &module,
										   const string &key)
{
	if (options.find(cmdline_key) == options.end())
		throw SettingKeyNotDefined(cmdline_key);
	options[cmdline_key].settingslist.push_back(
				SettingKey(group, module, key));
}

void GNSSOptionsParser::addSettingToOption(const std::string & cmdline_key,
						const Settings::Enumerator & en)
{
	addSettingToOption(cmdline_key,en.Group,en.Module,en.Key);
}

string GNSSOptionsParser::parseCMDLine( int argc, const char ** argv,
				   DBTableCollection & tcol,
				   std::map<std::string, bool> * flags) const
{
	Settings * target = (Settings*)(tcol.getTable("settings"));
	std::map<std::string, bool> flags_;
	for (std::map<std::string,OptionRecord>::const_iterator it=options.begin();
		 it!=options.end(); ++it)
		if (it->second.settingslist.size() == 0)
			flags_[it->first] = false;

	//Временная таблица для хранения настроек на случай ошибки.
	//Затем настройки будут скопированы из неё в таблицу настроек целевой
	//коллекции.
	DBTableCollection tempcol;
	Settings temp(&tempcol);
	int i = 0;
	while (true)
	{
		//Взять ключ командной строки и отрезать у него дефис
		i++;
		if (i>argc)
			break;
		if (argv[i][0]!='-')
			return "Ожидался ключ командной строки, начинающийся с дефиса. "
					"Вместо него получено: '"+string(argv[i])+"'.";
		string curoption (argv[i]+1);
		std::map < std::string, OptionRecord >::const_iterator optit =
				options.find(curoption);
		if (optit == options.end())
			return "Неизвестный ключ настроек: '"+curoption+"'.";
		//Считать необходимое количество настроек и проверить возможность их
		//преобразования в нужные типы
		int k = 0;
		if (optit->second.settingslist.size() == 0)
		{
			flags_[curoption] = true;
			continue;
		}
		for ( std::list < SettingKey > :: const_iterator
			  it = optit->second.settingslist.begin();
			  it != optit->second.settingslist.end();
			  ++it)
		{
			k++;
			const SettingKey & key = *it;
			Tuple skey=Tuple()<<key.group<<key.module<<key.key;
			//Какую настройку необходимо считать?
			std::string tn = Settings::Enumerator::enumerator()->
					read(skey)[0].toString();
			std::string shint = Settings::Enumerator::enumerator()->
					read(skey)[1].toString();

			//Есть ли аргумент в командной строке?
			i++;
			if (i>argc)
				return "Неожиданный конец командной строки. После ключа "
						+curoption+" на позиции №" + Variant(k).toString()+
						" ожидалось: '"+ shint+"'.";
			std::string curarg (argv[i]);

			//Когда настройка аддитивная, просто добавить её к уже существующему
			//массиву (или создать массив, если он не существует)
			if (isAdditive(curoption))
			{
				if (temp.find(skey).isEnd()) //Создать массив
					temp.insertRow(skey,Tuple()<<map<int,Variant>());
				//Дописать строку в массив
				map<int,Variant> curvalue = temp.read(skey)[0].toArray();
				curvalue[curvalue.size()] = curarg;
				temp.updateCell(skey,0,curvalue);
				//Следующий аргумент ключа
				continue;
			}

			//Если неаддитивный тип:
			//Проверить возможность преобразования типа
			CType * t = CType::getCType(tn);
			try
			{
				Variant v = t->fromString(curarg);
			}
			catch (const StrException & e)
			{
				return "Ошибка преобразования аргумента командной строки '"
						+curarg+" к типу '" + tn +"'. what(): "+
						e.what();
			}

			//Записать в таблицу настроек
			DBTable::DBConstIterator setiterator = temp.find(skey);
			if (setiterator.isEnd())
				temp.insertRow(skey,Tuple()<<curarg);
			else
				return "Ошибка: ключ командной строки '"+curoption+
						"' задан повторно.";


		}
	}
	target->copyFrom(temp.const_begin(), temp.const_end());
	return "";
}

}

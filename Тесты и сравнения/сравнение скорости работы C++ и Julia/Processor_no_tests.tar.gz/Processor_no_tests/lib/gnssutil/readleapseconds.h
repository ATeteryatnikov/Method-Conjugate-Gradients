#ifndef READLEAPSECONDS_H_
#define READLEAPSECONDS_H_

#include <string>
#include <iostream>
#include <LeapSeconds.h>
#include <DBError.h>

namespace libgnss
{

class ReadLeapSecondsError : public StrException
{
public:
	ReadLeapSecondsError(const std::string & what);
};

/**
 * @brief Добавляет секунду координации, заданную датой-временем UTC
 * @param target Таблица, в которую будет добавлена секунда координации
 * @param datetime Дата и время в формате YYYY-MM-DD_hh:mm:SS.sss
 */
void addLeapSecond(LeapSeconds & target, const std::string & datetime);

/**
 * @brief Читает из потока даты введения секунд координации и заполняет таблицу
 * @param target Таблица секунд координации, в которую нужно считать данные
 * @param data Поток с данными
 *
 * Данные должны представлять собой последовательность строк, в каждой строке
 * записана дата следующей секунды координации. Даты должны быть упорядочены по
 * возрастанию и все должны быть больше уже имеющейся в таблице. Считается, что
 * каждая вводимая секунда положительная. Записи, не удовлетворяющие последнему
 * условию, отбрасываются.
 *
 * Если в таблице нет секунд координации, то в таблицу пишутся секунды
 * координации до 2014 года.
 */
void readLeapSeconds(LeapSeconds & target, istream & data);
}

#endif

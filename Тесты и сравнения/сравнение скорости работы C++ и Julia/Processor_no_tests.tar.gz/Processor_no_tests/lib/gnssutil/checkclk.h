#ifndef CHECKCLK_H_
#define CHECKCLK_H_

#include <string>
#include <set>
#include <DBVariant.h>
#include <Types.h>

namespace libgnss
{

class DBTableCollection;
class ClockBias;

/**
 * @brief Класс создан для проверки наличия ухода часов в clock-файлах
 *
 * Класс используется для загрузки clock-файлов по требованию и проверки
 * наличия в них ухода часов на заданный момент времени.
 *
 * Считается, что все значения ухода часов на одни сутки хранятся в одном
 * файле. Для оптимизации список загруженных файлов сохраняется.
 */
class CheckClk
{
private:
	//! Коллекция таблиц, в которую будут считываться clock-файлы
	DBTableCollection * tcol;

	//! Таблица ухода часов из коллекции tcol
	ClockBias * clkbias;

	//! Шаблон имен clock-файлов для автоматического формирования
	std::string clkfilenametmpl;

	//! Список загруженных clock-файлов, как множества пар (неделя GPS,день GPS)
	std::set<std::pair<int,int> > loadeddays;

	Tuple checksat, checkrec;

	/**
	 * @brief Метод загружает clock-файл на заданный момент времени
	 *
	 * Если clock-файл был ранее уже загружен, повторная загрузка не происходит,
	 * метод возвращает false. Если файл потребовалось загрузить, будет
	 * возвращено true. Если файл не найден, будет сгенерировано исключение
	 * @ref FileNotFoundException.
	 *
	 * @param t Момент времени, секунды TAI от 12:00 01.01.2000
	 * @return true, если пришлось загружать clock-файл, false - иначе.
	 */
	bool loadClockFile (real t);
public:
	CheckClk (DBTableCollection * tcol,
			  const std::string & clkfilenametmpl);

	/**
	 * @brief Если нужно, загружает clock-файл, и проверяет наличие записи в нём
	 *
	 * Функция проверяет, загружен ли уже clock-файл, в котором должен быть уход
	 * часов на данный момент времени, и, если не загружен, то загружает его.
	 * После этого проверяет, был ли в данном clock-файле уход часов данного БИС
	 * и/или данного НКА в заданный момент времени.
	 *
	 * Если указан идентификатор БИС или НКА < 0, то проверка для БИС или НКА
	 * не выполяется.
	 *
	 * @param obs_src_id Идентификатор БИС
	 * @param sat_history_id Идентификатор НКА
	 * @param t МОмент времени, секунды TAI от 12:00 01.01.2000
	 * @return true, если уход часов есть, false - иначе.
	 *
	 */
	bool checkClk(int obs_src_id, int sat_history_id, real t);

	OperatorPushableVector<std::string> loadedFilesList();
};
}
#endif

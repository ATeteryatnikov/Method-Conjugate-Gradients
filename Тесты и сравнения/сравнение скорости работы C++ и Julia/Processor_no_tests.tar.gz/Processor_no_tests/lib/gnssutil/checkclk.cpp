#include <checkclk.h>
#include <DBTableCollection.h>
#include <TimeShift.h>
#include <StdTables.h>
#include <tstemplate.h>
#include <UTCDateTime.h>
#include <fstream>
#include <RINEXClock.h>

using namespace std;

namespace libgnss
{

CheckClk::CheckClk(DBTableCollection *tcol,
				   const string &clkfilenametmpl)
{
	this->tcol = tcol;
	this->clkbias = (ClockBias*)(tcol->getTable("time_shift"));
	this->clkfilenametmpl = clkfilenametmpl;
	checkrec<<0<<0<<0<<(real)0.0l;
	checksat<<1<<0<<0<<(real)0.0l;
}

bool CheckClk::loadClockFile(real t)
{
	//Вычислить неделю и день GPS
	int weekt0, dayt0;
	real fract0;
	UTCDateTime::getGPSWeekDayFrac(t,weekt0,dayt0,fract0);
	//dt.getGPSWeekDayFrac(weekt0, dayt0, fract0);

	//Если clock-файл уже загружен, то вернуть false
	if (loadeddays.find(pair<int,int>(weekt0,dayt0))!=loadeddays.end())
		return false;

	//Получить имя файла
	UTCDateTime dt = UTCDateTime::fromTAIJ2000(t);
	string clkfilename_t = fillTemplate(clkfilenametmpl, dt);

	//Загрузить clock-файл
	ifstream clkfile(clkfilename_t.c_str());
	if (!(clkfile.is_open()))
		throw FileNotFoundException(clkfilename_t);
	readRINEXClock(tcol, clkfile, false, false);
	clkfile.close();

	//Запомним прочитанный файл
	loadeddays.insert(pair<int,int>(weekt0,dayt0));

	return true;
}

bool CheckClk::checkClk(int obs_src_id, int sat_history_id, real t)
{
	loadClockFile(t);
	if (obs_src_id>=0)
	{
		checkrec[1] = obs_src_id;
		checkrec[3] = t;
		if (clkbias->find(checkrec).isEnd())
			return false;
	}
	if (sat_history_id>=0)
	{
		checksat[1] = sat_history_id;
		checksat[3] = t;
		if (clkbias->find(checksat).isEnd())
			return false;
	}
	return true;
}

OperatorPushableVector<std::string> CheckClk::loadedFilesList()
{
	OperatorPushableVector<std::string> result;
	for (set<pair<int,int> >::iterator it = loadeddays.begin();
		 it!=loadeddays.end(); ++it)
	{
		UTCDateTime dt=UTCDateTime::fromGPSWeekDayFrac(it->first,it->second,0);
		result<< fillTemplate(clkfilenametmpl,dt);
	}
	return result;
}

}

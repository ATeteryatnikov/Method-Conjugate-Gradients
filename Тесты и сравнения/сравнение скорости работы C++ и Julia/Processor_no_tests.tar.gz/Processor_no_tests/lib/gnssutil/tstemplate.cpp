#include <tstemplate.h>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <limits>

using namespace std;

namespace libgnss
{


void makeReplacements(std::string & tmpl,
							 const std::map<std::string,std::string> & repl)
{
	for (map<string,string>::const_iterator it = repl.begin(); it!=repl.end();
		 ++it)
	{
		string key = it->first;
		string val = it->second;
		while (true)
		{
			int p = tmpl.find(key);
			if (p==string::npos)
				break;
			tmpl.replace(p,key.size(),val);
		}
	}
}

/**
 * @brief Находит целую часть числа с учетом погрешности.
 *
 * Если число существенно (более чем на величину погрешности) отличается от
 * целого, то его округление происходит с помощью функции floor.
 *
 * Если число близко к целому (например, 0.99999999), то, скорее всего, оно
 * не равно целому из-за ошибки округления. В этом смысле, 0.99999999 = 1 =
 * 1.000000001. Тогда число округляется до ближайшего целого алгоритмом round.
 *
 * @param r Число с плавающей точкой
 * @param prec Величина возможной ошибки представления целого числа
 * @return Целая часть числа с учетом погрешности
 */
int floorPrec(real r, real prec)
{
	int r_i = (int)round(r);
	if (fabs((real)r_i-r)<fabs(prec))
		return r_i;
	else
		return (int)floor(r);
}

std::string fillTemplate(const std::string & templ,
						 const UTCDateTime & dt,
						 const std::map<std::string,std::string> & repl)
{

	string result = templ;

	//Полный список всех замен, связанных с датой и временем
	std::map<std::string,std::string> dtreplacements;

	real gpsj2000 = dt.getGPSJ2000();
	real prec = numeric_limits<double>::epsilon() * gpsj2000 * 10;


	// I)Пополнить список замен заменами с меткой времени

	int Y,y,M,D,H,m,s,yd;
	real s_;
	char h;
	char tmp[12];

	//1) В шкале GPS
	int gpsw, gpsd; real f;
	dt.getGPSWeekDayFrac(gpsw,gpsd,f);
	dt.getGPSDateTime(Y,M,D,H,m,s_);
	real gpsj2000d1=UTCDateTime::fromGPSDateTime(Y,1,1,0,0,0).getGPSJ2000();
	yd = floor((gpsj2000-gpsj2000d1)/86400) + 1;
	s = (int)floorPrec(s_,prec);
	y = Y % 100;
	h = 'a'+H;
	int N = sprintf(tmp,"%04d",gpsw);
	dtreplacements["%WWWW"] = string(tmp);
	N = sprintf(tmp,"%d",gpsd);
	dtreplacements["%D"] = string(tmp);
	N = sprintf(tmp,"%04d",Y);
	dtreplacements["%YYYY"] = string(tmp);
	dtreplacements["%GYYYY"] = string(tmp);
	N = sprintf(tmp,"%02d",y);
	dtreplacements["%yy"] = string(tmp);
	dtreplacements["%Gyy"] = string(tmp);
	N = sprintf(tmp,"%03d",yd);
	dtreplacements["%YDD"] = string(tmp);
	dtreplacements["%GYDD"] = string(tmp);
	N = sprintf(tmp,"%02d",M);
	dtreplacements["%MM"]=string(tmp);
	dtreplacements["%GMM"]=string(tmp);
	N = sprintf(tmp,"%02d",D);
	dtreplacements["%MD"]=string(tmp);
	dtreplacements["%GMD"]=string(tmp);
	N = sprintf(tmp,"%02d",H);
	dtreplacements["%HH"]=string(tmp);
	dtreplacements["%GHH"]=string(tmp);
	N = sprintf(tmp,"%02d",m);
	dtreplacements["%mm"]=string(tmp);
	dtreplacements["%Gmm"]=string(tmp);
	N = sprintf(tmp,"%02d",s);
	dtreplacements["%SS"]=string(tmp);
	dtreplacements["%GSS"]=string(tmp);
	dtreplacements["%h"]=string(1,h);
	dtreplacements["%Gh"]=string(1,h);

	if (templ.find("%R")!=templ.npos)
	{

		//2) В шкале ГЛОНАСС
		dt.getMSKDateTime(Y,M,D,H,m,s_);
		yd = floor((dt.getMSKJ2000()-
			UTCDateTime::fromMSKDateTime(Y,1,1,0,0,0.0).getMSKJ2000()) /86400) + 1;
		s = (int)floorPrec(s_,prec);
		y = Y % 100;
		h = 'a'+H;
		N = sprintf(tmp,"%04d",Y);
		dtreplacements["%RYYYY"] = string(tmp);
		N = sprintf(tmp,"%02d",y);
		dtreplacements["%Ryy"] = string(tmp);
		N = sprintf(tmp,"%03d",yd);
		dtreplacements["%RYDD"] = string(tmp);
		N = sprintf(tmp,"%02d",M);
		dtreplacements["%RMM"]=string(tmp);
		N = sprintf(tmp,"%02d",D);
		dtreplacements["%RMD"]=string(tmp);
		N = sprintf(tmp,"%02d",H);
		dtreplacements["%RHH"]=string(tmp);
		N = sprintf(tmp,"%02d",m);
		dtreplacements["%Rmm"]=string(tmp);
		N = sprintf(tmp,"%02d",s);
		dtreplacements["%RSS"]=string(tmp);
		dtreplacements["%Rh"]=string(1,h);
	}

	if (templ.find("%U")!=templ.npos)
	{
		//3) В шкале UTC
		yd = floor((dt.getUTCJ2000()-
			UTCDateTime::fromUTCDateTime(Y,1,1,0,0,0).getUTCJ2000())/86400)+1;
		dt.getUTCDateTime(Y,M,D,H,m,s_);
		s = (int)floorPrec(s_,prec);
		y = Y % 100;
		h = 'a'+H;
		N = sprintf(tmp,"%04d",Y);
		dtreplacements["%UYYYY"] = string(tmp);
		N = sprintf(tmp,"%02d",y);
		dtreplacements["%Uyy"] = string(tmp);
		N = sprintf(tmp,"%03d",yd);
		dtreplacements["%UYDD"] = string(tmp);
		N = sprintf(tmp,"%02d",M);
		dtreplacements["%UMM"]=string(tmp);
		N = sprintf(tmp,"%02d",D);
		dtreplacements["%UMD"]=string(tmp);
		N = sprintf(tmp,"%02d",H);
		dtreplacements["%UHH"]=string(tmp);
		N = sprintf(tmp,"%02d",m);
		dtreplacements["%Umm"]=string(tmp);
		N = sprintf(tmp,"%02d",s);
		dtreplacements["%USS"]=string(tmp);
		dtreplacements["%Uh"]=string(1,h);
	}

	//II) Провести все замены
	makeReplacements(result,dtreplacements);
	makeReplacements(result,repl);
	return result;
}

std::set<std::string> fillTemplate(const std::string & templ,
								  const UTCDateTime & t0,
								  const UTCDateTime & t1,
								  const std::map<std::string,std::string> & repl
								  )
{
	std::set<std::string> result;
	int step_sec = 86400; //Шаг по времени в секундах. По умолчанию, одни сутки

	if ((templ.find("%GHH")!=string::npos)
		||(templ.find("%RHH")!=string::npos)
		||(templ.find("%UHH")!=string::npos)
		||(templ.find("%Gh")!=string::npos)
		||(templ.find("%Rh")!=string::npos)
		||(templ.find("%Uh")!=string::npos)
		||(templ.find("%HH")!=string::npos))
		step_sec = 3600;
	if ((templ.find("%Gmm")!=string::npos)
		||(templ.find("%Rmm")!=string::npos)
		||(templ.find("%Umm")!=string::npos)
		||(templ.find("%mm")!=string::npos))
		step_sec = 60;
	if ((templ.find("%GSS")!=string::npos)
		||(templ.find("%RSS")!=string::npos)
		||(templ.find("%USS")!=string::npos)
		||(templ.find("%SS")!=string::npos)
			)
		step_sec = 1;

	real T0 = t0.getTAIJ2000();
	real T1 = t1.getTAIJ2000();
	//Будем прибавлять по пол-шага, чтобы из-за ошибок округления не пропустить
	for (real t = T0; t<=T1; t+=real(step_sec)*0.5l)
	{
		UTCDateTime curdt = UTCDateTime::fromTAIJ2000(t);
		string curstr = fillTemplate(templ,curdt,repl);
		result.insert(curstr);
	}
	return result;
}

}

#ifndef CMDLINEOPTIONS_H_
#define CMDLINEOPTIONS_H_

#include <map>
#include <string>
#include <list>
#include <set>
#include <iostream>

#include <DBTableCollection.h>
#include <DBError.h>
#include <Settings.h>

namespace libgnss
{

/**
 * @brief Ошибка отсутствия ключа настройки
 *
 * Возникает, если при задании соответствия ключа командной строки с настройками
 * обработчика использован ключ, ранее не добавленный методом
 * @ref GNSSOptionsParser::addOption().
 */
class SettingKeyNotDefined : public StrException
{
public:
	SettingKeyNotDefined(const std::string & key);
};


/**
 * @brief Ошибка определения аддитивного ключа комадной строки
 *
 * Ключ называется аддитивным, если его аргументы накапливаются при повторном
 * использовании ключа в аргументах командной строки. Поэтому настройка,
 * которой соответствует ключ, должна иметь тип массива. Нарушение этого условия
 * ведёт к вызову данного исключения.
 */
class AdditiveKeyError : public StrException
{
public:
	AdditiveKeyError(const std::string & cmdline_key,
					 const std::string & set_hint);
};


/**
 * @brief Класс парсера параметров командной строки в таблицу настроек
 *
 * Данный класс предназначен для записи значений аргументов из командной строки
 * в таблицу настроек @ref Settings.
 *
 * Командная строка программы должна иметь вид:
 *
 * ./prg [-key1 [val11 [val12 [...]]] [ -key2 [val21 [val22 [...]]] ]...]
 *
 * Здесь key1, key2 - ключи командной строки, val11, val12 - аргументы для ключа
 * key1, val21, val22 - аргументы для ключа key2.
 *
 * После каждого ключа может быть фиксированное число аргументов. Для каждого
 * аргумента указывается, в какую строку таблицы настроек обработчика
 * (@ref Settings) записывается этот аргумент.
 *
 * Если у ключа не указано ни одной настройки, он считается флагом, т.е.
 * обозначает одну настройку логического типа (bool).
 *
 * Если всем аргументам какого-либо ключа назначены настройки типа "массив", то
 * при повторном использовании данного ключа в командной строке его аргументы
 * будут дописываться как новые элементы массивов.
 *
 */
class GNSSOptionsParser
{
private:
	//! Структура, описывающая ключ в таблице настроек
	struct SettingKey
	{
		inline SettingKey (const std::string & group_,
						   const std::string & module_,
						   const std::string & key_)
		{
			group = group_;
			module = module_;
			key = key_;
		}

		std::string group;
		std::string module;
		std::string key;
	};

	/** Структура, описывающая структуру одного параметра командной строки
	 *
	 * После ключа в командной строке указываются некоторые значения, которые
	 * будут присвоены настройкам с заданными ключами. Например:
	 *
	 * ./myprog -mykey myvalue1 myvalue2 myvalue3
	 *
	 * Здесь mykey однозначно задаёт один объект со структурой OptionRecord,
	 * в списке settingslist которого должны быть записаны три настройки,
	 * каждая из которых задаётся ключем SettingKey. При разборе этой командной
	 * строки myvalue1 будет записан в первую настройку, myvalue2 - во вторую,
	 * myvalue3 - в третью.
	 */
	struct OptionRecord
	{
		/**
		 * @brief Признак аддитивности настройки.
		 *
		 * Аддитивность настройки возможна, когда она имеет тип "массив".
		 * Тогда повторное указаные ключа приведёт к дописыванию элемента в
		 * массив. Например,
		 *
		 * ./myprog -mykey a1 -mykey a2 -mykey a3
		 *
		 * В этом случае аддитивная настройка, соответствующая mykey будет
		 * хранить массив из элементов {a1, a2, a3}. Если ключ даёт доступ
		 * к нескольким настройкам, все они должны быть массивами, и все
		 * будут дополняться при повторном указании ключа.
		 */
		bool additive;

		//! Список настроек обработчика, в которые записываются аргументы
		std::list < SettingKey > settingslist;

		//! Подсказка для пользователя
		std::string hint;

	};

	std::map < std::string, OptionRecord > options;

public:
	GNSSOptionsParser();

	/**
	 * @brief Добавить ключ командной строки
	 * @param cmdline_key Ключ командной строки
	 * @param user_hint Подсказка для пользователя
	 *
	 * Если данный ключ существует, то у него будет обновлена подсказка для
	 * пользователя.
	 */
	void addOption(const std::string & cmdline_key,
				   const std::string & user_hint);

	/**
	 * @brief Забыть ключ командной строки
	 * @param cmdline_key
	 */
	void forgetOption(const std::string & cmdline_key);

	void addSettingToOption(const std::string & cmdline_key,
							const std::string & group,
							const std::string & module,
							const std::string & key);

	void addSettingToOption(const std::string & cmdline_key,
							const Settings::Enumerator & en);

	//! Установить, является ли данный ключ аддитивным
	void setAdditive ( const std::string & cmdline_key, bool additive );

	inline bool isAdditive(const std::string & cmdline_key) const
	{
		return options.at(cmdline_key).additive;
	}

	/**
	 * @brief Метод разбирает командную строку программы
	 * @param argc Число аргументов командной строки
	 * @param argv Аргументы командной строки
	 * @param tcol Коллекция таблиц, в которую будут записаны настройки
	 * @param flags Набор установленных флагов (ключей без доп. аргументов).
	 * @return Сообщение о распознавании параметров
	 *
	 * Существуют следующие возможности:
	 * @li Пользователь запросил помощь по параметрам командной строки командой
	 * -help. Тогда метод вернёт строку, содержащую список всех ключей.
	 * @li Пользователь запросил помощь по одному ключу командной строки
	 * командой -help key. Тогда метод вернёт строку, содержащую подробную
	 * информацию о данном ключе.
	 * @li При разборе возникла ошибка. Сообщение об ошибке будет возвращено
	 * методом.
	 * @li Разбор прошел без ошибок. Будет возвращена пустая строка.
	 */
	virtual string parseCMDLine(int argc, const char **argv,
					   DBTableCollection & tcol,
					   std::map<std::string, bool> * flags = 0) const;
};

}
#endif

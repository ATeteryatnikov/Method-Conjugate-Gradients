/* CLAPACK 3.0 BLAS wrapper macros
 * Feb 5, 2000
 */

#ifndef __BLASWRAP_H
#define __BLASWRAP_H

#ifndef NO_BLAS_WRAP
 

#endif /* NO_BLAS_WRAP */

#endif /* __BLASWRAP_H */

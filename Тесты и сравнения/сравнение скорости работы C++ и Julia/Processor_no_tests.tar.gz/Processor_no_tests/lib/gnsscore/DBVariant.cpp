#include <cstdlib>
#include <sstream>
#include <map>
#include <cstdio>
#include <limits>

using namespace std;

//! @file

#include <DBVariant.h>
#include <strtod_nolocale.h>
#include <dtostr_nolocale.h>

namespace libgnss
{

int stringToIntE(const std::string & str)
{
	char * endp;
	int result = strtol(str.c_str(), &endp, 10);
	if (endp[0] != 0)
		throw TypeMismatchException(Variant::TYPE_STRING->getName(),
									Variant::TYPE_INT->getName());
	return result;
}

Variant::Type Variant::TYPE_NULL = new CType("null","NULL");
Variant::Type Variant::TYPE_INT = new CType("int","0");
Variant::Type Variant::TYPE_DOUBLE = new CType("double","0.0");
Variant::Type Variant::TYPE_CHAR = new CType("char"," ");
Variant::Type Variant::TYPE_STRING = new CType("string","");
Variant::Type Variant::TYPE_ARRAY = new CType("array","");
Variant::Type Variant::TYPE_DATETIME = new CType("datetime","J2000");

class VariantTypesDeleter
{
public:
	~VariantTypesDeleter()
	{
		delete Variant::TYPE_DATETIME;
		delete Variant::TYPE_ARRAY;
		delete Variant::TYPE_STRING;
		delete Variant::TYPE_CHAR;
		delete Variant::TYPE_DOUBLE;
		delete Variant::TYPE_INT;
		delete Variant::TYPE_NULL;
	}
};

VariantTypesDeleter variantTypesDeleter;

WrongArrayFormatException::WrongArrayFormatException(const std::string & str,
													 int pos,
													 const std::string&whatisit)
	: StrException("WrongArrayFormatException", "Ошибка преобразования "
			   "строки "+str+" в массив в позиции "
			   +Variant(pos).toString()+": "+
			   whatisit)
{

}

CType::CType(const std::string & paramname, const string &defaultstr)
{
	//Запомнить свой заголовок
	ParamName = paramname;

	//Добавить тип в список известных типов
	CType * me = getCType(paramname, this);

	defaultString = defaultstr;
}

const string & CType::getName() const
{
	return ParamName;
}

void CType::initVariant(Variant &target, const Variant &other)
{

}

int CType::compare(const Variant &a, const Variant &b) const
{
	throw IncomparableTypesException(a.type->getName(),b.type->getName());
}

std::string arrayToString(const std::map<int,Variant> & v)
{
	Tuple result_v;
	for (map<int,Variant>::const_iterator it = v.begin();
		 it!=v.end(); ++it)
	{
		string idx_s = Variant(it->first).toString();
		string tname = it->second.getType()->getName();
		std::string str = it->second.toString();
		//Добавить символ "\" к каждой кавычке и к каждому символу "\"
		//(количество таких символов будет обозначать глубину вложенности)
		int i=0;
		while (true)
		{
			if ((str[i] == '\\') || (str[i] == '\"'))
			{
				str = str.substr(0,i) +"\\"+str.substr(i);
				i++;
			}
			i++;
			if (i>=str.length())
				break;
		}
		str = "\"" + str + "\"";
		//Записать в выходной массив
		result_v<<idx_s<<tname<<str;
	}
	return result_v.join(",");
}

std::map<int,Variant> stringToArray(const std::string & s)
{
	std::string s1 = s;
	std::map<int,Variant> result;
	if (s.length() == 0)
		return result;
	if (s[0] == '\"')
		throw WrongArrayFormatException(s,0,"Здесь должен быть индекс элемента "
										"в массиве.");
	int pos = 0;
	char * curpos = &(s1[0]);
	while (true)
	{
		//Выбрать первый элемент тройки - индекс в массиве
		//Для этого нужно дойти до запятой
		char * commapos = curpos;
		while (*commapos!=',')
		{
			commapos++;
			pos++;
			if (*commapos == '\0')
				throw WrongArrayFormatException(s,pos,"Здесь должен был быть "
												"индекс элемента в массиве.");
		}
		*commapos = '\0';
		commapos++;
		pos++;

		int idx;
		try
		{
			idx = Variant::fromString(Variant::TYPE_INT,string(curpos)).toInt();
		}
		catch (const exception & e)
		{
			throw WrongArrayFormatException(s,pos-1,"Здесь должен был быть "
											"индекс элемента в массиве.");
		}
		curpos = commapos;

		//Прочитать тип элемента - дойти до следующей запятой
		while(*commapos != ',')
		{
			commapos++;
			pos++;
			if (*commapos == '\0')
				throw WrongArrayFormatException(s,pos,"Здесь должен был быть "
												"тип элемента массива.");
		}
		*commapos = '\0';
		commapos++;
		pos++;

		CType * t;
		try
		{
			t = CType::getCType(string(curpos));
		}
		catch (const exception & e)
		{
			throw WrongArrayFormatException(s,pos-1,"Не удалось опознать тип "
							"элемента массива. Ошибка: "+string(e.what()));
		}

		curpos = commapos;

		//Теперь считать сам элемент массива
		if (*curpos!='\"')
			throw WrongArrayFormatException(s,pos,"Здесь должна быть строка в "
								"кавычках, преобразуемая к заданному типу.");
		curpos++;
		pos++;
		char * quotepos = curpos;
		//Дойти до следующей кавычки, которой не предшествует обратная косая
		while (true)
		{
			if ((*quotepos=='\"') && (*(quotepos-1)!='\\'))
				break;
			quotepos++;
			pos++;
		}
		*quotepos='\0';
		string curv_s = string(curpos);

		//Снять с каждого служебного символа по одной косой черте.
		int i = 0;
		while (true)
		{
			if (curv_s[i] == '\\')
				curv_s = curv_s.substr(0,i)+curv_s.substr(i+1);
			i++;
			if (i>=curv_s.length())
				break;
		}

		Variant curvalue;
		try
		{
			curvalue = t->fromString(curv_s);
		}
		catch (const exception & e)
		{
			throw WrongArrayFormatException(s,pos-1,"Не удалось преобразовать "
						"строку '"+curv_s+"' к типу "+t->getName()+". "
						"Ошибка: "+string(e.what()));
		}

		result[idx] = curvalue;
		curpos=quotepos;
		curpos++;
		pos++;
		if (*curpos == '\0')
			break;
		curpos++;
		pos++;
	}
	return result;
}


Variant CType::fromString ( const std::string & str) const
{
	//Если требуется извлеч пустое значение (странно?)
	if (this == Variant::TYPE_NULL)
		return Variant();

	//Если требуется строка, ничего делать не нужно
	if (this == Variant::TYPE_STRING)
		return Variant ( str );

	if (this == Variant::TYPE_CHAR)
		return Variant (str[0]);

	if (this == Variant::TYPE_DATETIME)
		return Variant(UTCDateTime::fromUTCDateTimeString(str));

	if (this == Variant::TYPE_DOUBLE)
	{
		char * p0;
		Variant res = Variant(strtofloat<real> (str.data(), &p0));
		if (*p0!=0)
			throw TypeMismatchException("String:"+str, "double");
		return res;
	}

	if (this == Variant::TYPE_INT)
		return Variant(stringToIntE(str));

	//Массивы пока не поддерживаются
	if (this == Variant::TYPE_ARRAY)
		return Variant(stringToArray(str));

	return Variant();
}

string CType::toString ( const Variant & v) const
{
	if (this==Variant::TYPE_STRING)
		return *(v.value.str);

	if (this==Variant::TYPE_CHAR)
		return std::string (1, v.value.chr);

	if (this==Variant::TYPE_NULL)
		return "";

	if (this==Variant::TYPE_DOUBLE)
		return floattostr(v.value.dbl);

	std::stringstream ss;

	if (this==Variant::TYPE_INT)
		ss<<v.value.intg;

	if (this==Variant::TYPE_ARRAY)
	{
		//Преобразование массива в строку
		return arrayToString(*(v.value.arr));
	}

	if (this==Variant::TYPE_DATETIME)
		ss<<(v.value.dt);

	if (ss.str().length() == 0)
		throw TypeMismatchException("unknown", "string");

	return ss.str();
}

CType * CType::getCType (const std::string & paramname,
				 CType * add)
{
	static map < string, CType * > knownTypes;
	map < string, CType * > ::iterator it1 = knownTypes.find(paramname);
	if (it1!=knownTypes.end())
		return it1->second;
	if (add == 0)
		throw UnknownTypeException(paramname);
	knownTypes[paramname] = add;
	return add;
}

Variant CType::defaultValue() const
{
	return Variant::fromString((Variant::Type)this, this->defaultString);
}

//Методы DBVariant'а, которые нельзя сделать inline по причине ре

void Variant::init(const Variant &other)
{
	type = other.getType();
	if (type==TYPE_INT)
	{
		init (other.toInt());
		return;
	}
	if (type==TYPE_DOUBLE)
	{
		init (other.toDouble());
		return;
	}
	if (type==TYPE_CHAR)
	{
		init (other.toChar());
		return;
	}
	if (type==TYPE_STRING)
	{
		init (other.toString());
		return;
	}
	if (type==TYPE_DATETIME)
	{
		init (other.toUTCDateTime());
		return;
	}
	if (type==TYPE_ARRAY)
	{
		init (*(other.value.arr));
		return;
	}
	//Если тип объекта other не является стандартным,
	//вызвать соответствующий метод для синглтона типа.
	type->initVariant(*this, other);
}


std::string Variant::toString(const std::string & format) const
{
	char buff[10000];
	if (getType() == TYPE_INT)
		if (sprintf(buff,format.c_str(),toInt())>=0)
			return string(buff);

	if (getType() == TYPE_DOUBLE)
	{
		int l=snprintf(buff, 10000, format.c_str(), toInt());
		if ((l>=0) && (l<10000))
			return string(buff);
		else if (l>=0)
		{
			char * buff0 = new char[l+1];
			int l = sprintf(buff0, format.c_str(), toInt());
			if (l>=0)
				return string(buff0);
		}
	}
	throw TypeMismatchException(getType()->getName(),
								"string(формат: "+format+")");
}

real Variant::convertToDouble() const
{

	if (type==TYPE_INT)
		return value.intg;

	if (type==TYPE_NULL)
		return 0.0;

	if (type==TYPE_CHAR)
		return value.chr;

	if (type==TYPE_STRING)
	{
		char * p0;
		real result = strtofloat<real>(value.str->data(), &p0);
		if (*p0==0)
			return result;
		else
			throw TypeMismatchException("String:"+(*value.str), "double");
	}

	if (type==TYPE_ARRAY)
		throw TypeMismatchException("array", "double");

	if (type==TYPE_DATETIME)
		throw TypeMismatchException("datetime","double");

	throw TypeMismatchException("unknown", "double");
}

int Variant::convertToInt() const
{
	if (type==TYPE_NULL)
		return 0;

	if (type==TYPE_DOUBLE)
		return value.dbl;

	if (type==TYPE_CHAR)
		return value.chr;

	if (type==TYPE_STRING)
		return stringToIntE(*(value.str));

	if (type==TYPE_ARRAY)
		throw TypeMismatchException("array", "int");

	if (type==TYPE_DATETIME)
		throw TypeMismatchException("datetime","int");

	throw TypeMismatchException("unknown", "int");
}

bool Variant::isLessThan(const Variant &second) const
{
	if (type==TYPE_INT)
	{
		//Тип int можно сравнивать с тремя типами
		if (second.getType() == TYPE_INT)
			return value.intg < second.toInt();
		if (second.getType() == TYPE_DOUBLE)
			return (double)(value.intg) < second.toDouble();
		if (second.getType() == TYPE_CHAR)
			return value.intg < second.toChar();
	}

	if (type==TYPE_DOUBLE)
	{
		//Тип double можно сравнивать с тремя типами
		if (second.getType() == TYPE_DOUBLE)
			return value.dbl < second.toDouble();
		if (second.getType() == TYPE_INT)
			return value.dbl < (double)(second.toInt());
		if (second.getType() == TYPE_CHAR)
			return value.dbl < (double)(second.toChar());
	}

	if (type==TYPE_CHAR)
	{
		//Тип char можно сравнивать с тремя типами
		if (second.getType() == TYPE_CHAR)
			return value.chr < second.toChar();
		if (second.getType() == TYPE_INT)
			return (int)(value.chr) < second.toInt();
		if (second.getType() == TYPE_DOUBLE)
			return (double)value.chr < second.toDouble();
	}

	if (type==TYPE_STRING)
	{
		if (second.getType() == TYPE_STRING)
			return *(value.str)<second.toString();
	}

	if (type==TYPE_DATETIME)
	{
		if (second.getType() == TYPE_DATETIME)
			return this->value.dt< second.value.dt;
	}

	//Неизвестно, для какого из типов реализован мультиметод сравнения
	try
	{
		return (getType()->compare(*this,second) == -1);
	}
	catch (const IncomparableTypesException & e)
	{
		return (getType()->compare(*this,second) == -1);
	}

	throw IncomparableTypesException(getTypeName(), second.getTypeName());
}

Variant::Variant(const Variant &other)
{
	init (other);
}

void Variant::init(const std::map<int, Variant> &value)
{
	type = TYPE_ARRAY;
	this->value.arr = new std::map < int, Variant > (value);
}

Variant::Variant(const std::map<int, Variant> &value)
{
	init (value);
}

Variant::~Variant()
{
	if (type==TYPE_STRING)
		delete value.str;

	if (type==TYPE_ARRAY)
		delete value.arr;

}

Variant & Variant::operator[] (const int index)
{
	if (type==TYPE_ARRAY)
	{
		return (*(value.arr))[index];
	}

	if (type==TYPE_NULL)
	{
		//Инициализация массива
		type=TYPE_ARRAY;
		value.arr = new std::map < int, Variant >;
		return (*(value.arr))[index];
	}

	if (type==TYPE_INT)
		throw TypeMismatchException("int", "array");

	if (type==TYPE_DOUBLE)
		throw TypeMismatchException("double", "array");

	if (type==TYPE_CHAR)
		throw TypeMismatchException("char", "array");

	if (type==TYPE_STRING)
		throw TypeMismatchException("string", "array");

	if (type==TYPE_DATETIME)
		throw TypeMismatchException("datetime", "array");

	throw NotImplementedException("Variant::operator[](unknown type)");


}

Variant & Variant::operator= (const std::map <int, Variant> & other)
{
	this->~Variant();
	init (other);
	return *this;
}

Variant & Variant::operator =(const Variant &other)
{
	this->~Variant();
	init(other);
	return *this;
}

Variant Variant::fromString
	(Type desiredType, const std::string &str)
{
	return desiredType->fromString(str);
}


CTypeSelectOptionNotFound::CTypeSelectOptionNotFound(const string &option,
													 const string & type)
	: StrException ("CTypeSelectOptionNotFound", "Указанное значение "
					+option+" не найдено среди вариантов для выборного типа "
					+type)
{

}

//-------------CTypeSelect---------------------------------------//
CTypeSelect::CTypeSelect (const std::string & name, const Tuple & options,
						  int defaultvalue)
	: CType(name,options[defaultvalue].toString())
{
	current_id = 0;
	for (unsigned int i=0; i<options.size(); i++)
		addOption(options[i].toString());
}

void CTypeSelect::addOption ( const std::string & option )
{
	strint[option] = current_id;
	intstr[current_id++] = option;
}

void CTypeSelect::removeOption ( const std::string & option )
{
	int curid = strint[option];
	strint.erase(option);
	intstr.erase(curid);
}

const std::map < std::string, int > & CTypeSelect::getOptions ()
{
	return strint;
}

const std::map < int, std::string > & CTypeSelect::getOptionsRev()
{
	return intstr;
}

CTypeSelect * CTypeSelect ::yesOrNo()
{
	static CTypeSelect YesOrNo("YesOrNo", Tuple()<<string("No")<<string("Yes"),
							   0);
	return &YesOrNo;
}

Variant CTypeSelect::yes()
{
	return CTypeSelect::yesOrNo()->fromString("Yes");
}

Variant CTypeSelect::no()
{
	return CTypeSelect::yesOrNo()->fromString("No");
}

Variant CTypeSelect::fromString ( const std::string & str) const
{
	Variant result;
	result.type = (CType*)this;
	result.value.intg = strint.at(str);
	return result;
}

int CTypeSelect::compare(const Variant &a, const Variant &b) const
{
	if ((a.getType()!=this) || (b.getType()!=this))
		return CType::compare(a,b);
	if (a.value.intg == b.value.intg)
		return 0;
	else if (a.value.intg > b.value.intg)
		return 1;
	else
		return -1;
}

std::string CTypeSelect::toString ( const Variant & v) const
{
	return intstr.at(v.value.intg);
}

void CTypeSelect::initVariant(Variant &target, const Variant &other)
{
	target.type = (CType*)this;
	if (other.getType() == Variant::TYPE_STRING)
	{
		target.value.intg = strint.at(other.toString());
		return;
	}
	if ((other.getType() == Variant::TYPE_INT)||(other.getType() == this))
	{
		target.value.intg = other.value.intg;
		return;
	}
	throw TypeMismatchException(other.getType()->getName(),
								getName());
}

}

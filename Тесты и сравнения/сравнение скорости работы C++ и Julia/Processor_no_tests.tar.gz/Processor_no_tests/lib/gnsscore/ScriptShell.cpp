#include <gnssconfig.h>
#ifdef WithQT
#include <iostream>

using namespace std;

//! @file

#include <ScriptShell.h>
#include <QVariantList>

#include <Distribute.hpp>
#include <Kinematic.h>
#include <ephemeris.h>
#include <BuiltIn.h>
#ifdef UseMPI
#include <mpi.h>
#endif

namespace libgnss
{


QScriptValue myPrintFunction(QScriptContext *context, QScriptEngine *engine)
{
	for (int i=0; i<context->argumentCount(); ++i)
	{
		QString stri = context->argument(i).toString();
		cout<<(stri.toUtf8().data())<<" ";
	}
	cout<<endl;
	return engine->undefinedValue();
}

QScriptValue aborteval(QScriptContext * ctx, QScriptEngine * eng)
{
	if (ctx->argumentCount() == 0)
		eng->abortEvaluation(eng->toScriptValue<QString>("Прервано."));
	eng->abortEvaluation(ctx->argument(0));
	return QScriptValue();
}

BuiltIn abortev("abort",1,aborteval);

ScriptShell::ScriptShell ()
{
	// Создание ядра
	engine = new QScriptEngine();
	QScriptValue coreimport = engine->importExtension("qt.core");
	if (!(coreimport.equals(engine->undefinedValue())))
	{
		cout<<"Ошибка загрузки дополнения qt.core: "
		   <<coreimport.toString().toStdString()<<endl;
	}


	// Добавление функций
	initializeBuildInFunctions(engine);
	engine->globalObject().setProperty("print",
									   engine->newFunction(myPrintFunction));

}

ScriptShell::~ScriptShell()
{
	delete engine;
}

void ScriptShell::addCollection (const QString & name,
										DBTableCollection * collection)
{
	collections[name] = collection;
	collection->assignScriptEngine(engine);
	QScriptValue val = engine->newQObject(collection);
	engine->globalObject().setProperty(name,val);

}

void ScriptShell::removeCollection ( const QString & name )
{
	collections.remove(name);
	engine->globalObject().setProperty(name, QScriptValue());
}

QScriptValue ScriptShell::evaluate ( const QString & expression )
{
	return engine->evaluate(expression);
}

#ifdef UseMPI

QMPICommunicator::QMPICommunicator(const MPI_Comm & mpicomm,
								  QScriptEngine * engine, bool iscw)
{
	this->mpicomm = mpicomm;
	this->eng = engine;
	this->iscommworld = iscw;
	MPI_Comm_size(mpicomm, &commsize);
	MPI_Comm_rank(mpicomm, &commrank);
}

QMPICommunicator::~QMPICommunicator ()
{
	if (iscommworld == false)
		MPI_Comm_free(&mpicomm);
}

QScriptValue QMPICommunicator::commSplit(int colour, int key) const
{
	MPI_Comm newcomm;
	MPI_Comm_split(mpicomm, colour, key, &newcomm);
	return eng->newQObject(new QMPICommunicator(newcomm, eng, false),
						   QScriptEngine::ScriptOwnership);
}

QVariantList QMPICommunicator::distributeTasks(int first, int last) const
{
	pair<unsigned int,unsigned int>d=distribute(first,last,commsize, commrank);
	QVariantList result;
	result.push_back(d.first);
	result.push_back(d.second);
	return result;
}

int QMPICommunicator::getCommSize() const
{
	return commsize;
}

int QMPICommunicator::getCommRank() const
{
	return commrank;
}

QScriptValue getMPICW (QScriptContext*ctx, QScriptEngine * eng)
{
	QMPICommunicator * mpicw = new QMPICommunicator(MPI_COMM_WORLD,
													eng, true);
	return eng->newQObject(mpicw,QScriptEngine::ScriptOwnership);
}

BuiltIn getmpicw ("getMPI_COMM_WORLD",0, getMPICW);


#endif
}
#endif


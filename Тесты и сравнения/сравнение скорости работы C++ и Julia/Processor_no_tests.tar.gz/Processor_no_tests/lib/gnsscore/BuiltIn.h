#ifndef BUILDIN_H_
#define BUILDIN_H_

#include <gnssconfig.h>
#ifdef WithQT
//! @file

#include <QObject>
#include <QVariantList>
#include <QScriptEngine>
#include <QMap>
#include <Types.h>

namespace libgnss
{

class BuiltInFunctionSet
		: public QMap<QString, QPair < int, QScriptEngine::FunctionSignature > >
{
public:
	BuiltInFunctionSet();
};

/** @brief Класс, собирающий встраиваемые в QtScript функции
 * @ingroup script
 * 
 * Для определения новой встроенной функции необходимо:
 * 
 * 1) Реализовать функцию вида:
 * \code
	QScriptValue f(QScriptContext *, QScriptEngine *)
   \endcode
 * 
 * 2) Создать сигнлтон класса BuildIn:
 * \code
   BuildIn(<Function name>, <Arguments count>, f);
 \endcode
 * 
 * Здесь Function name - имя, по которому можно будет вызывать данную функцию
 * из QtScript, Arguments count - ожидаемое число аргументов функции
 */
class BuiltIn
{
public:	
	
	/**
	 * @brief Добавление новой встроенной функции
	 * 
	 * @param name QtScript-имя встроенной функции
	 * @param argcount Число аргументов функции
	 * @param fun Указатель на реализацию функции
	 */
	BuiltIn (QString name, int argcount, QScriptEngine::FunctionSignature fun);
	
	struct FuncSign
	{
		QString name;
		int argcount;
		QScriptEngine::FunctionSignature sig;
	};
	
	
	/**
	 * @brief Метод, осуществляющий доступ к списку встроенных функций
	 */
	static BuiltInFunctionSet & functions();
	
};

/** @brief Инициализировать встроенные функции в QtScript-движке
 * @ingroup script
 * 
 * @param engine Движок, в который добавляются встроенные функции
 * 
 * Функция, которая собирает все добавленные в проект встроенные функции и
 * добавляет их в скриптовый движок.
 */
void initializeBuildInFunctions (QScriptEngine * engine);

/**
 * @brief Прекращает выполнение команд в движке с возвратом сообщения об ошибке
 * @ingroup script
 * @param eng QtScript-движок
 * @param err_utf8 Сообщение об ошибке (в кодировке UTF8!)
 */
inline void returnError(QScriptEngine * eng, const std::string & err_utf8)
{
	eng->abortEvaluation(QString::fromUtf8(err_utf8.c_str()));
}

}

#endif
#endif

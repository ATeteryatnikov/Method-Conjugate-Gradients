#ifndef DBTABLECOLLECTION_H_
#define DBTABLECOLLECTION_H_

#include <gnssconfig.h>

#ifdef WithQT
#include <QObject>
#include <QVariantList>
#include <QScriptValue>
#include <QScriptEngine>
#endif

#include <map>
#include <string>
#include <istream>
#include <ostream>

//using namespace std;

//! @file

#include <DBTable.h>

namespace libgnss
{

/**
 * @brief Исключение возникает при запросе несуществующей таблицы
 *
 * @ingroup except
 */
class TableNotFoundException : public StrException
{
public:
	TableNotFoundException(const string & tableName)
		: StrException ("TableNotFoundException","Таблица "+
						tableName+ " не найдена.")
	{

	}
};

/**
 * @brief Исключение возникает при добавлении таблицы с уже занятым именем
 *
 * @ingroup except
 */
class TableAlreadyExists : public StrException
{
public:
	TableAlreadyExists (const string & name)
		: StrException("TableAlreadyExists","Невозможно добавить таблицу "+name+
					   ". Таблица с таким именем уже существует.")
	{
	}
};

/**
 * @brief Исключение возникает при добавлении строки неправильного формата
 *
 * Чтобы добавить строку в таблицу, необходимо передать значения ключевых полей
 * и значения полей данных в виде векторов; типы и количество элементов векторов
 * должны соответствовать числу и типам соответствующих полей таблицы.
 *
 * @ingroup except
 */
class WrongTableFormatOnInput : public StrException
{
public:
	WrongTableFormatOnInput(const string & tableName, const string & value,
							Variant::Type type, const string & col)
		: StrException("WrongTableFormatOnInput",
					   "Колонка "+col+" таблицы "+tableName+" имеет тип "+
					   type->getName()+", в который не может быть переведена "
					   "вводимая строка "+value)
	{

	}
};

/** @brief Набор проименованных таблиц DBTable
 *
 * @ingroup core
  *
  * Объект данного класса хранит набор проименованных таблиц.
  * Основное назначение данного класса - разбор данных, поступающих
  * с потока ввода, и заполнение этими данными таблиц, входящих в коллекцию.
  *
  */
class DBTableCollection : public QObject
{
	Q_OBJECT
private:
	map <  string, DBTable * > tables;
public:

	/**
	 * @brief Считывает одну строку данных
	 *
	 * Формат строки данных оговорен в документации к методу readFromStream().
	 *
	 * @param line Строка данных
	 * @return false, если таблицы с указанным именем не существует. true иначе.
	 *
	 * Если строка не может быть вставлена по любой другой причине, помимо
	 * отсутствия таблицы, будет сгенерировано соответствующее исключение.
	 */
	bool readLine (string line);

	/** @brief Заполнение таблиц коллекции данными из потока
	  *
	  * Данный метод читает входной поток и записывает поступающие по нему
	  * данные по таблицам коллекции.
	  *
	  * Данные должны поступать в строгом формате:
	  \verbatim
	  <Имя таблицы> <Ключевые поля> <Поля данных>
	  \endverbatim
	  *
	  * По первому столбцу определяется в какую таблицу коллекции необходимо
	  * записать поступающие данные. Затем из потока выбираются ключевые
	  * поля и поля данных. Полученные данные записываются в выбранную
	  * таблицу.
	  *
	  * Если таблицы с требуемым именем не существует, данные передаются
	  * в неизменном виде на выходной поток. Подразумевается, что, если
	  * программа, использующая данный класс, работает в составе
	  * конвейера, данные могут предназначаться программе, стоящей на
	  * следующей его ступени, и поэтому не должны быть изъяты из потока.
	  *
	  * @param input Входной поток данных
	  * @param output Поток данных, передаваемых далее по конвееру
	  */
	void readFromStream ( istream & input, ostream & output );

	//! @brief Получить описание формата принимаемых данных
	string getAcceptableFormat ();

	/** @brief Вернуть указатель на необходимую таблицу
	  *
	  * @param name Имя требуемой таблицы
	  * @return Указатель на таблицу, если она найдена.
	  *
	  * Данный метод предназначен для обращения к таблицам, которые
	  * необходимы для совершения операции. Если такая таблица не найдена,
	  * будет вызвано исключение TableNotFoundException().
	  */
	DBTable * getTable ( const string & name ) const;

	/** @brief Вернуть указатель на таблицу
	  *
	  * @param name Имя требуемой таблицы
	  * @return Указатель на таблицу, если она найдена, или 0
	  */
	DBTable * getTableIfExists (const string &name) const;

	/** @brief Вывести в поток содержимое таблицы
	  *
	  * @param name Имя требуемой таблицы
	  */
	void dumpTable (const string & name, ostream & output);

	
	/**
	 * @brief Вывести в поток содержимое всех таблиц
	 *
	 * @param output Выходной поток
	 **/
	void dump (ostream & output);

typedef DBTable * PDBT;

	inline const PDBT & operator [] (const std::string & str) const
	{
		return tables.at(str);
	}

	inline void addTable (const std::string & name, DBTable * table)
	{
		if (tables.find(name) != tables.end())
			throw TableAlreadyExists (name);
		tables[name] = table;
	}

	/**
	 * @brief Метод удаляет указатель на таблицу из коллекции (таблица остаётся
	 * @param name Имя таблицы
	 */
	inline void deleteTable (const std::string & name)
	{
		tables.erase(name);
	}

	inline map < string, DBTable * > ::iterator find(const std::string str)
	{
		return tables.find(str);
	}

	inline map < string, DBTable * >::const_iterator begin()
	{
		return tables.begin();
	}

	inline map < string, DBTable * > ::const_iterator end()
	{
		return tables.end();
	}

private:

#ifdef WithQT
	QScriptEngine * engine;
#endif

public:

	DBTableCollection ();

	~DBTableCollection ();

#ifdef WithQT
public slots:

	inline void assignScriptEngine (QScriptEngine * eng0)
	{
		engine = eng0;
	}

	inline QScriptEngine * getEngine ()
	{
		return engine;
	}

	QScriptValue readFromString(const QString& data);

	void readFromFile(const QString & filename);
	
	//! Возвращает список всех таблиц коллекции
	QVariantList getTablesList();

	//! Возвращает QTScript-обертку для таблицы с заданным именем
	QObject* table(const QString & name);
	
	//! Удалить указатель на таблицу из коллекции (таблица остаётся)
	void deleteTable(const QString & name);
#else
	void readFromFile(const std::string & filename);

#endif


};
}
#endif

#ifndef SETTINGS_H_
#define SETTINGS_H_

#include <DBError.h>
#include <DBTable.h>
#include <DBTableCollection.h>

namespace libgnss
{

class SettingsNotDefinedException : public StrException
{
public:
	SettingsNotDefinedException(const string & group,
					 const string & module,
					 const string & key );
};

class DefaultValueForbiddenException : public StrException
{
public:
	DefaultValueForbiddenException(const string & group,
					 const string & module,
					 const string & key );

};

/**
 * @brief Таблица глобальных настроек обработчика
 *
 * @ingroup core
 *
 * Класс преследует две цели:
 * @li Собрать информацию обо всех глобальных настройках обработчика, то есть
 * тех, которые задаются один раз на весь сеанс работы, и предоставить список
 * настроек пользователю (например, для использования в графическом интерфейсе)
 * @li Хранить введённые пользователем настройки для текущего сеанса и
 * передавать их при необходимости требующим их модулям обработчика.
 *
 * Для того, чтобы ввести новую опцию настройки, необходимо создать синглтон
 * класса @ref Settings::Enumerator. Например:
 * \code
 Settings::Enumerator trajmaxstep("Parameters_settings", "trajectory",
				"maxstep",Variant::TYPE_DOUBLE,
				"Максимально допустимый шаг между узлами интерполяции, сек.",
				(real)3600l);
  \endcode
 *
 * При создании синглтона опция настройки автоматически помещается в общую
 * таблицу @ref DBTable, получить доступ на чтение которой можно с помощью
 * метода @ref Settings::Enumerator::enumerator().
 *
 * Для хранения настроек таблицу необходимо добавить в сеанс
 * @ref DBTableCollection. Хранить можно и настройки, не определенные в общей
 * таблице. Для чтения настроек следует использовать методы @ref getSettings().
 *
 * Для удобства настройки разделяются по трехуровневой иерархии со следующими
 * ступенями: группа, модуль, ключ настройки. Модуль - это класс, или функция,
 * реализующая некоторую функциональность; группа - множество модулей,
 * объединенных по типу решаемых задач. Каждый модуль имеет несколько настроек,
 * различаемых по ключу.
 *
 * Ключевые поля:
 * @li string group Группа настроек
 * @li string module Модуль
 * @li string key Ключ
 *
 * Поля данных:
 * @li string value
 *
 * Значения настреок хранятся в виде строк, и преобразуются в нужный тип при
 * запросе значения настройки.
 */
class Settings : public DBTable
{
public:

	/**
	 * @brief Таблица определения (definition) всех настроек обработчика
	 *
	 * Таблица определения имеет следующие колонки:
	 *
	 * Ключи:
	 * @li group группа настроек
	 * @li module программный модуль
	 * @li key ключ настройки
	 *
	 * Данные:
	 * @li type имя типа данных (Variant::CType) настройки
	 * @li hint Человеко-читаемое описание настройки
	 * @li default значение по умолчанию - в виде строки
	 */
	class Enumerator
	{
	public:
		~Enumerator();
		string Module;
		string Group;
		string Key;

		static DBTable * enumerator();

		/**
		 * @brief Конструктор новой настройки
		 *
		 * В качестве аргументов конструктор принимает поля таблицы определения
		 * настроек.
		 */
		Enumerator ( string group, string module, string key,
				 Variant::Type type, string hint, Variant def);

		/**
		 * @brief Тип данных настройки
		 *
		 * В качестве параметров метод принимает ключевые поля таблицы
		 * определения настроек
		 *
		 * @return Тип настройки
		 */
		static Variant::Type getSettingType(const string & group,
								   const string & module, const string & key);

		/**
		 * @brief Значение настройки по умолчанию
		 *
		 * В качестве параметров метод принимает ключевые поля таблицы
		 * определения настроек
		 */
		static Variant getDefaultValue ( const string & group,
				const string & module, const string & key);
	};

	Settings (DBTableCollection * base);

	/**
	 * @brief Возвращает значение заданной опции обработчика
	 *
	 * Если опция хранится в таблице (в виде строки), то значение будет считано
	 * и возвращено пользователю, преобразованное к нужному типу.
	 *
	 * Если настройка не задана в таблице, будет возвращено значение по
	 * умолчанию, взятое из таблицы Settings::Enumerator::enumerator().
	 * При этом, если настройка не была введена с помощью синглтона класса
	 * Settings::Enumerator, будет сгенерировано исключение
	 * @ref SettingsNotDefinedException. Если настройка была введена, но для
	 * неё нет значения по умолчанию (тип значения по умолчанию
	 * Variant::TYPE_NULL), то будет сгенерировано исключение
	 * @ref DefaultValueForbiddenException.
	 *
	 * В качестве параметров метод принимает ключевые поля таблицы.
	 *
	 * @return Значение указанной настройки
	 */
	Variant getSettings(const string&group,const string&module,
						const string&key) const;

	//! Метод добавлен для удобства - принимает указатель на синглтон настройки
	inline Variant getSettings(const Enumerator & en) const
	{
		return getSettings(en.Group, en.Module, en.Key);
	}

};

}

#endif

#include <gnssconfig.h>
#ifdef WithQT
//#include <iostream>

//! @file

#include <BuiltIn.h>
#include <Kinematic.h>
#include <Frames.h>
#include <ephemeris.h>

namespace libgnss
{

BuiltInFunctionSet::BuiltInFunctionSet()
{
//	cout<<"Создание списка встроенных функций..."<<endl;
}

//----------------------Добавление встроенных функций-------------------------//

BuiltIn::BuiltIn(QString name,int argcount,QScriptEngine::FunctionSignature fun)
{
	functions()[name]=QPair<int,QScriptEngine::FunctionSignature>(argcount,fun);
}

BuiltInFunctionSet& BuiltIn::functions()
{
	static BuiltInFunctionSet funcs;
	return funcs;
}

void initializeBuildInFunctions (QScriptEngine * engine)
{
	for(QMap<QString,QPair<int,QScriptEngine::FunctionSignature> >::Iterator it=
		BuiltIn::functions().begin(); it!=BuiltIn::functions().end(); ++it)
	{
//		cout<<"Добавление встроенной функции: "<<it.key().toStdString()<<"\n";
		engine->globalObject().setProperty(it.key(),
					engine->newFunction(it.value().second,it.value().first));
	}
}

}

#endif

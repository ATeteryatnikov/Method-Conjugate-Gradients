#include <cstdlib>
#include <sstream>
#include <string>
#include <ctime>

using namespace std;

//! @file

#include <UTCDateTime.h>
#include <DBTable.h>
#include <StdTables.h>
#include <BuiltIn.h>

namespace libgnss
{

string UTCDateTime ::DateTimeFormat = "YYYY-MM-DD_hh:mm:SS.sss";

DBTable * UTCDateTime::leapSeconds = 0;

WrongGLONASSNavDataDateTime::WrongGLONASSNavDataDateTime(int tb, int Nt, int N4)
	: StrException("WrongGLONASSNavData",
				   "Неверные компоненты даты/времени в оперативной информации "
				   "GLONASS: tb="+Variant(tb).toString()+", Nt="
				   +Variant(Nt).toString()+", N4="+Variant(N4).toString())
{

}

pair < int, int > UTCDateTime::yearDayToDayMonth(int yearday, int year)
{
	UTCDateTime udt = UTCDateTime::fromTAIJ2000(
			UTCDateTime::fromTAIDateTime(year,1,1,0,0,0.0).getTAIJ2000()
			+ 86400*yearday);
	int Y,M,D,h,m; real s;
	udt.getTAIDateTime(Y,M,D,h,m,s);
	return pair < int, int > (M, D);
}

int UTCDateTime::getLeapSeconds(real taij2000)
{
	if (leapSeconds == 0)
		throw LeapSecondsNotAvailableException();
	return ((LeapSeconds*)(leapSeconds))->getLeapSeconds(taij2000);
}

void UTCDateTime::strToDate(const std::string & str,
					int & year, int & month, int & day,
					int & hour, int & minute, real & sec,
					const std::string & format)
{
	//Универсальное значение даты обозначается через J2000
	if (str=="J2000")
	{
		year=2000;
		month=1;
		day=1;
		hour=12;
		minute=0;
		sec=0;
		return;
	}

	if (str.length()!=format.length())
		throw IncorrectDateFormat(str, format);

	string DD;
	string MM;
	string YYYY;
	string hh;
	string mm;
	string SS;
	string ss;
	for (unsigned int i=0; i<str.length(); ++i)
	{
		if (format[i] == 'D')
		{
			DD.push_back(str[i]);
			continue;
		}
		if (format[i] == 'M')
		{
			MM.push_back(str[i]);
			continue;
		}
		if (format[i] == 'Y')
		{
			YYYY.push_back(str[i]);
			continue;
		}
		if (format[i] == 'h')
		{
			hh.push_back(str[i]);
			continue;
		}
		if (format[i] == 'm')
		{
			mm.push_back(str[i]);
			continue;
		}
		if (format[i] == 'S')
		{
			SS.push_back(str[i]);
			continue;
		}
		if (format[i] == 's')
		{
			ss.push_back(str[i]);
			continue;
		}
		if (str[i]!=format[i])
			throw IncorrectDateFormat(str, format);
	}

	day = atoi(DD.c_str());
	if ((day<=0) || (day>31))
		throw IncorrectDateFormat(str, format);;

	month = atoi(MM.c_str());
	if ((month<0) || (month > 12))
		throw IncorrectDateFormat(str, format);;

	year = atoi(YYYY.c_str());
	if ((YYYY.length() == 4) && (year == 0) && (YYYY!="0000"))
		throw IncorrectDateFormat(str, format);;

	if (YYYY.length() == 2)
	{
		//Когда год задан двумя цифрами, считаем, что
		//год > 50 означает 19xx, а год < 50 означает 20xx.
		if (year < 50)
			year += 2000;
		if (year >= 50)
			year += 1900;
	}

	if ((YYYY.length() != 2) && (YYYY.length() != 4))
	{
		InternalException("Утерян формат даты");
	}

	hour = atoi (hh.c_str());
	//Час не может быть равен 24?
	if (((hour == 0) && (hh!="00")) || (hour<0) || (hour>23))
		throw IncorrectDateFormat(str, format);

	minute = atoi (mm.c_str());
	if (((minute == 0) && (mm!="00")) || (minute<0) || (hour>59))
		throw IncorrectDateFormat(str, format);

	string SSss=SS+"."+ss;
	sec = atof (SSss.c_str());
	if (((sec == 0) && (SS!="00")) || (sec<0) || (sec>=61))
		throw IncorrectDateFormat(str, format);
}

string zeroComplete(const string & str, unsigned int l)
{
	string result = str;
	while (result.length()<l)
		result = "0"+result;
	return result;
}

std::string UTCDateTime::dateToStr(int year, int month, int day,
							 int hour, int minute, real sec,
					const std::string & format)
{
	string res = format;

	if (res.find("YYYY") != res.npos)
	{
		int posyyy = res.find("YYYY");
		string replaceYear = zeroComplete(itoa(year),4);
		res.replace(posyyy,4,replaceYear);
	}
	else
	{
		if (res.find("YY") != res.npos)
		{

			if ((year<1950) || (year>2050))
				throw AmbigousYearException(year);

			res.replace(res.find("YY"),2,
					   zeroComplete(itoa(year%100),2));
		}
	}

	res.replace(res.find("MM"),2,zeroComplete(itoa(month),2));

//	cout<<res<<endl;

	res.replace(res.find("DD"),2,zeroComplete(itoa(day),2));
	res.replace(res.find("hh"),2,zeroComplete(itoa(hour),2));
	res.replace(res.find("mm"),2,zeroComplete(itoa(minute),2));
	res.replace(res.find("SS"),2,zeroComplete(itoa(floor(sec)),2));

	real fracsecond = sec - floor(sec);

	if (fracsecond<0)
		fracsecond = 0;
	if (fracsecond>=1.0)
		fracsecond = 0.999999999999999999l;

	//Узнать сколько знаков после запятой требует формат для секунды
	int ssc = 0;
	for (unsigned int i=0; i<format.length(); i++)
	{
		if (format[i] == 's')
		{
			ssc++;
			fracsecond*=10;
		}
	}

	string s_fracsecond = zeroComplete(itoa(fracsecond), ssc);
	ssc = 0;
	for (unsigned int i=0; i<res.length(); i++)
		if (res[i] == 's')
		{
			res[i] = s_fracsecond[ssc];
			ssc++;
		}

	return res;
}


UTCDateTime UTCDateTime::now()
{
	return UTCDateTime::fromUTCJ2000(-946728000+time(NULL));
}

#ifdef WinthQT
QScriptValue UTC2TAIJ2000 (QScriptContext * ctx, QScriptEngine * eng)
{
	int year = ctx->argument(0).toInt32();
	int month = ctx->argument(1).toInt32();
	int day = ctx->argument(2).toInt32();
	int hour = ctx->argument(3).toInt32();
	int minute = ctx->argument(4).toInt32();
	double second = ctx->argument(5).toNumber();
	double TAIJ2000 = UTCDateTime::fromUTCDateTime(year,month,day,hour,minute,
								second).getTAIJ2000();
	return eng->toScriptValue<double>(TAIJ2000);
}

QScriptValue UTC2UTCJ2000(QScriptContext * ctx, QScriptEngine * eng)
{
	int year = ctx->argument(0).toInt32();
	int month = ctx->argument(1).toInt32();
	int day = ctx->argument(2).toInt32();
	int hour = ctx->argument(3).toInt32();
	int minute = ctx->argument(4).toInt32();
	double second = ctx->argument(5).toNumber();
	double UTCJ2000 = UTCDateTime::fromUTCDateTime(year,month,day,hour,minute,
								second).getUTCJ2000();
	return eng->toScriptValue<double>(UTCJ2000);
}

QScriptValue UTCJ20002UTC(QScriptContext * ctx, QScriptEngine * eng)
{
	double j2000 = ctx->argument(0).toNumber();
	QVariantList result;
	UTCDateTime fj2000 = UTCDateTime::fromUTCJ2000(j2000);
	int Y,M,D,h,m; real s;
	fj2000.getUTCDateTime(Y,M,D,h,m,s);
	result.push_back((int)Y);
	result.push_back((int)M);
	result.push_back((int)D);
	result.push_back((int)h);
	result.push_back((int)m);
	result.push_back((double)s);
	return eng->toScriptValue<QVariantList>(result);
}

QScriptValue GPSToTAIJ2000 (QScriptContext * ctx, QScriptEngine * eng)
{
	int year = ctx->argument(0).toInt32();
	int month = ctx->argument(1).toInt32();
	int day = ctx->argument(2).toInt32();
	int hour = ctx->argument(3).toInt32();
	int minute = ctx->argument(4).toInt32();
	double second = ctx->argument(5).toNumber();
	double TAIJ2000 = UTCDateTime::fromGPSDateTime(year,month,day,hour,minute,
												   second).getTAIJ2000();
	return eng->toScriptValue<double>(TAIJ2000);
}

QScriptValue GPSWeekDayFrac(QScriptContext*ctx, QScriptEngine * eng)
{
	double tai = ctx->argument(0).toNumber();
	UTCDateTime dt = UTCDateTime::fromTAIJ2000(tai);
	int week,day;
	real frac;
	dt.getGPSWeekDayFrac(week,day,frac);
	QVariantList result;
	result.push_back(week);
	result.push_back(day);
	result.push_back((double)frac);
	return eng->toScriptValue<QVariantList>(result);
}

QScriptValue TAIJ2000Now(QScriptContext*ctx, QScriptEngine * eng)
{
	double result = UTCDateTime::now().getTAIJ2000();
	return eng->toScriptValue<double>(result);
}

QScriptValue UTCJ2000Now(QScriptContext*ctx, QScriptEngine * eng)
{
	double result = UTCDateTime::now().getUTCJ2000();
	return eng->toScriptValue<double>(result);
}

QScriptValue TAIJ2000ToGPSDateTime(QScriptContext * ctx,
								   QScriptEngine * eng)
{
	double taij2000 = ctx->argument(0).toNumber();
	UTCDateTime utc = UTCDateTime::fromTAIJ2000(taij2000);
	int year,month,day,hour,minute;
	real sec;
	QVariantList result;
	utc.getGPSDateTime(year,month,day,hour,minute,sec);
	result<<year<<month<<day<<hour<<minute<<(double)sec;
	return eng->toScriptValue<QVariantList>(result);
}

QScriptValue GPSWeekDayFracToTAIJ2000(QScriptContext * ctx,
									  QScriptEngine * eng)
{
	int w = ctx->argument(0).toInt32();
	int d = ctx->argument(1).toInt32();
	double f = ctx->argument(2).toNumber();
	double taij2000 = UTCDateTime::fromGPSWeekDayFrac(w,d,f).getTAIJ2000();
	return eng->toScriptValue<double>(taij2000);
}


BuiltIn utc2taij2000_ ("UTCToTAIJ2000", 6, UTC2TAIJ2000);
BuiltIn utc2utcj2000_ ("UTCToUTCJ2000", 6, UTC2UTCJ2000);
BuiltIn utcj20002utc_ ("UTCJ2000ToUTC", 1, UTCJ20002UTC);
BuiltIn gpstotaij2000_ ("GPSToTAIJ2000", 6, GPSToTAIJ2000);
BuiltIn gpsweekdayfrac_ ("getGPSWeekDayFrac", 1, GPSWeekDayFrac);
BuiltIn taij2000now_ ("TAIJ2000Now", 0, TAIJ2000Now);
BuiltIn utcj2000now_("UTCJ2000Now", 0, UTCJ2000Now);
BuiltIn taij2000togpsdatetime("TAIJ2000ToGPSDateTime",1,TAIJ2000ToGPSDateTime);
BuiltIn gpswdftotaij2000("GPSWeekDayFracToTAIJ2000",3,GPSWeekDayFracToTAIJ2000);
#endif
}

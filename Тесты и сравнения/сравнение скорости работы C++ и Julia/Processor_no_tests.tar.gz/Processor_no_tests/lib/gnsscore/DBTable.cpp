#include <map>
#include <cmath>
#include <fstream>

using namespace std;

//! @file

#include <DBTable.h>
#include <DBVariant.h>
#include <DBError.h>

#ifdef WithQT
#include <QDateTime>
#include <QScriptValue>
#include <BuiltIn.h>
#endif

namespace libgnss
{


TooFewKeyFieldsException::TooFewKeyFieldsException()
	: StrException("TooFewKeyFieldsException",
				   "Указано недостаточно ключевых полей.")
{

}

TooFewDataFieldsException::TooFewDataFieldsException()
	: StrException("TooFewDataFieldsException",
				   "Указано недостаточно полей данных.")
{

}

DuplicateKeyException::DuplicateKeyException(const Tuple &keyValues)
	: StrException ("DuplicateKeyException",
					"Попытка добавления строки с уже существующим"
			" значением ключа: ("+
			keyValues.join(";")+")")
{
	this->kv = keyValues;
}

IndexUniquenessException::IndexUniquenessException(const Tuple &keyvalues,
							const Tuple &values, const string &idxname)
	: StrException ("IndexUniquenessException",
					"Добавление строки ("+keyvalues.join(";")+")->"
					"("+values.join(";")+") нарушает уникальность в "
					"индексе "+idxname)
{

}

WrongTableFormatForCopy::WrongTableFormatForCopy()
	: StrException("WrongTableFormatForCopy",
				   "Невозможно скопировать данные в таблицу с другой "
				   "структурой.")
{

}

string DBMap::tuplePrettyPrint(const Tuple& k, const Tuple& v) const
{
	stringstream s0;
	s0<<"(";
	if (k.size()>0)
		for (unsigned int i=0; (i<k.size())&&(i<keyColumns.size()); i++)
			s0<<keyColumns[i].second<<"="<<k[i].toString()<<" ";
	if (v.size()>0)
		for (unsigned int i=0; (i<v.size())&&(i<valueColumns.size()); i++)
			s0<<valueColumns[i].second<<"="<<v[i].toString()<<" ";
	s0<<")";
	return s0.str();
}


//-------------------------------DBMap--------------------------------------//

DBMap::DBMap(const Columns& key, const Columns& value)
{
#ifdef WithQT
	engine = 0;
#endif

	//Запомнить список ключевых полей и полей данных
	keyColumns = key;
	valueColumns = value;
	rowsCount = 0;

	//Проверить, что таблица обладает ключом
	if (key.size() == 0)
		throw StrException("DBMap::DBMap","Указан пустой ключ таблицы.");

	//Проверить, что выбран ключ допустимого типа
	for (unsigned int i=0; i<key.size(); ++i)
		if ((key[i].first != Variant::TYPE_INT)
			&& (key[i].first != Variant::TYPE_DOUBLE)
			&& (key[i].first != Variant::TYPE_CHAR)
			&& (key[i].first != Variant::TYPE_STRING)
			&& (key[i].first != Variant::TYPE_DATETIME)
		)
			throw StrException("DBMap::DBMap","В качестве ключа в таблице DBMap"
	"был использован тип, отличный от int, double, char, string, datetime.");

	//Создать корневой элемент таблицы
	map < Variant, vector < Variant > * > * tblroot =
						new map < Variant, vector < Variant > * >;

	tableRoot = tblroot;
}

void DBMap::copyFrom(const DBMap::DBConstIterator &itbegin,
					 const DBMap::DBConstIterator &itend,
					 int colidx, int fixidx, int inc)
{
	if ((itbegin.parent->getKeyColumns()!=keyColumns)
		||(itbegin.parent->getValueColumns()!=valueColumns))
		throw WrongTableFormatForCopy ();
	if (colidx < 0)
		colidx = keyColumns.size()-1;
	for (DBTable::DBConstIterator it = itbegin; it!=itend;
		 it.subinc(colidx, fixidx, inc))
		if (find(it.subkey()).isEnd() == false)
			throw DuplicateKeyException(it.subkey());
	for (DBTable::DBConstIterator it = itbegin; it!=itend;
		 it.subinc(colidx, fixidx, inc))
		insertRow(it.subkey(), *it);
}

DBMap::DBMap(const DBMap &another)
#ifdef WithQT
	:QObject(),
	  engine(another.engine)
#endif
{
	DBMap(another.getKeyColumns(), another.getValueColumns()); //! @bug Конструктор не вызывается!
	copyFrom(another.const_begin(), another.const_end());
}


void DBMap::cleanNode (void* node, unsigned int level)
{
	if (level == keyColumns.size())
	{
		//processChanges();
		rowsCount--;
		delete ((vector < Variant > *)(node));
		return;
	}

	//Пока не удалены все дочерние узлы
	while (!(((map < Variant, void * >*)(node))->empty()))
	{
		map < Variant, void * >::iterator it =
				((map < Variant, void * >*)(node))->begin();
		cleanNode(it->second,level+1);
		((map < Variant, void * >*)(node))->erase(it);
	}

	//Очистить связи текущего узла таблицы
	((map < Variant, void * >*)(node))->clear();

	//Удалить текущий узел таблицы, если это не корневой узел
	if (node!=tableRoot)
		delete ((map < Variant, void * >*)(node));
}

DBMap::~DBMap()
{
	cleanNode(this->tableRoot, 0);
	delete (map < Variant, vector < Variant > * > *)(tableRoot);
}

const Tuple & DBMap::operator[] ( const Tuple& keyValue ) const
{

	if (keyValue.size() < keyColumns.size())
		throw StrException("DBMap::operator[]",
						   "Указано недостаточно ключевых полей.");

	// Пройти докуда возможно по значениям ключа.
	unsigned int i = 0;
	map < Variant, void * > * cur = (map < Variant, void * > *)tableRoot;

	//Пройти по всем полям ключа
	for (;i<keyColumns.size(); ++i)
	{

		//Поиск в подиндексе
		map < Variant, void * >::iterator found = cur->find(keyValue[i]);

		//Если элемент подиндекса не найден
		if (found == cur->end())
			//В константом варианте данного метода запрещено
			//добавлять новые строки в таблицу.
			throw KeyNotFoundException
				(keyValue);
		else
			cur = (map < Variant, void * > *)found->second;
	}

	return   *((Tuple *)(cur));
}

DBMap::DBConstIterator DBMap::const_begin() const
{
	if (count() == 0)
		return const_end();
	
	//Выделить память под результат
	DBMap::DBConstIterator result;

	//Указать, что итератор относится к данной таблицу
	result.parent = this;

	//Указать, что итератор указывает не на конец таблицы
	result.isend = false; result.isrend = false;

	//Начать с корня дерева
	map <Variant, void * > * cur = (map <Variant,void * > *)this->tableRoot;

	//Для каждого ключевого элемента
	for (unsigned int i=0; i<keyColumns.size(); ++i)
	{
		//Выбрать наименьшее значение этого ключевого элемента
		result.tableIterator.push_back(cur->begin());

		//Если этот ключевой элемент не принимает никаких значений,
		//положить
		if (cur->begin() == cur->end())
		{
			result.isend = true; result.isrend = true;
			return result;
		}
		cur = (map <Variant, void * > *)(cur->begin()->second);
	}
	return result;
}

DBMap::DBConstIterator DBMap::const_end() const
{
	DBMap::DBConstIterator result;
	result.parent = this;
	result.isrend = false;
	result.isend = true;
	return result;
}

DBMap::DBIterator DBMap::begin()
{
	return DBIterator (const_begin());
}

DBMap::DBIterator DBMap::end()
{
	return DBIterator (const_end());
}

DBMap::DBConstIterator DBMap::find(const Tuple &keyValue) const
{
	DBMap::DBConstIterator result;
	result.isend = false; result.isrend = false;
	result.parent = this;
	result.tableIterator.resize(keyColumns.size());
	map <Variant, void * > * cur = (map <Variant,void * > *)this->tableRoot;
	//Произвести поиск по значениям заданных ключевых полей
	for (unsigned int i=0; i<keyValue.size(); ++i)
	{
		result.tableIterator[i]=cur->find(keyValue[i]);
		//result.tableIterator.push_back(cur->find(keyValue[i]));
		if (result.tableIterator[i] == cur->end())
		{
			result.isend = true; result.isrend = true;
			return result;
		}
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}

	//Установить наименьшие значения оставшихся ключевых полей
	for (unsigned int i=keyValue.size(); i<keyColumns.size(); ++i)
	{
		result.tableIterator[i] = cur->begin();
		//result.tableIterator.push_back(cur->begin());
		if (result.tableIterator[i] == cur->end())
		{
			result.isend = true; result.isrend = true;
			return result;
		}
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}
	return result;
}

DBMap::DBConstIterator DBMap::find(const Tuple &keyValue, real precision) const
{
	int N = keyValue.size();
	DBConstIterator lb = lower_bound(keyValue);
	if (lb.isEnd())
		return const_end();
	if (fabs(lb.keyColumnValue(N-1).toDouble() - keyValue[N-1].toDouble())
			<= precision)
		return lb;
	lb.subinc(N-1,N-2);
	if (lb.isEnd())
		return const_end();
	if (fabs(lb.keyColumnValue(N-1).toDouble() - keyValue[N-1].toDouble())
			<= precision)
		return lb;
	return const_end();
}

DBMap::DBIterator DBMap::find (const Tuple &keyValue)
{
	return DBMap::DBIterator (((const DBMap*)(this))->find(keyValue));
}

DBMap::DBIterator DBMap::find(const Tuple &keyValue, real precision)
{
	return DBMap::DBIterator (((const DBMap*)(this))->find(keyValue,precision));
}

void DBMap::insertRow(const Tuple &keyValue, const Tuple &values)
{

	if (keyValue.size() < keyColumns.size())
		throw TooFewKeyFieldsException();
	
	if (values.size() < valueColumns.size())
		throw TooFewDataFieldsException();
	
	map < Variant, void * > * cur = (map < Variant, void * > *) tableRoot;
	
	for (unsigned int i = 0; i<keyColumns.size(); ++i)
	{
		//Поиск в подиндексе
		map < Variant, void * >::iterator found = cur->find(keyValue[i]);
		
		//Если подиндекс не найден, создать поддерево
		if (found == cur->end())
		{
			//Если это последний элемент индекса,
			//записать требуемую строку данных
			if (i == keyColumns.size()-1)
			{
				vector < Variant > * newv = new vector < Variant > (values);
				(*cur)[keyValue[i]] = newv;
				rowsCount++;
				
				Tuple oldvals;
				oldvals.resize(valueColumns.size());
				
				//Вставка завершена
				return;
			}
			//В противном случае - создат поддерево
			else
			{
				map < Variant, void*> * newsubtree = new map <Variant, void*>;
				(*cur)[keyValue[i]] = newsubtree;
				cur = newsubtree;
			}
				
		}
		else
			cur = (map<Variant, void*>*)(found->second);
	}
	
	//Если выполнение дошло до этого места, это означает, что строка с таким
	//ключом уже существует.
	throw DuplicateKeyException (keyValue);

}

void DBMap::updateCell(const Tuple &keyValue, int colnumber,
					   const Variant &value)
{

	if (keyValue.size() < keyColumns.size())
		throw TooFewKeyFieldsException();

	// Пройти докуда возможно по значениям ключа.
	unsigned int i = 0;
	void * cur = tableRoot;

	//Пройти по всем полям ключа
	for (;i<keyColumns.size(); ++i)
	{

		//Поиск в подиндексе
		map < Variant, void * >::iterator found =
			((map < Variant, void * > *)(cur))->find(keyValue[i]);

		//Если элемент подиндекса не найден
		if (found == (( map < Variant, void * > * )(cur))->end())
			//В константом варианте данного метода запрещено
			//добавлять новые строки в таблицу.
			throw KeyNotFoundException
				(keyValue);
		else
			cur = found->second;
	}

	Tuple * values = (Tuple *)cur;
	(*values)[colnumber] = value;

	//return   *((Tuple *)(cur));
}

DBMap::DBConstIterator DBMap::upper_bound(const Tuple &keyValue) const
{
	DBMap::DBConstIterator result;
	result.isend = false;
	result.isrend = false;
	result.parent = this;
	map <Variant, void * > * cur = (map <Variant,void * > *)this->tableRoot;
	int N = keyValue.size()-1;

	result.tableIterator.reserve(keyColumns.size());
	//Произвести поиск по значениям заданных ключевых полей
	Tuple foundt;
	for (int i=0; i<N; ++i)
	{
		foundt.push_back(keyValue[i]);
		map < Variant, void * > :: iterator curit = cur->find(keyValue[i]);
		if (curit == cur->end())
			return const_end();
		result.tableIterator.push_back(curit);
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}

	//n-е ключевое поле выбрать командой lower_bound
	result.tableIterator.push_back(cur->lower_bound(keyValue[N]));
	//result.tableIterator[N] = cur->lower_bound(keyValue[N]);
	if (result.tableIterator[N] == cur->end())
		return const_end();
	cur = (map <Variant, void* >*)(result.tableIterator[N]->second);

	//Установить наименьшие значения оставшихся ключевых полей
	for (unsigned int i=keyValue.size(); i<keyColumns.size(); ++i)
	{
		//result.tableIterator[i] =cur->begin();
		result.tableIterator.push_back(cur->begin());
		if (result.tableIterator[i] == cur->end())
			return const_end();
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}
	return result;
}

DBMap::DBConstIterator DBMap::lower_bound(const Tuple &keyValue) const
{
	DBMap::DBConstIterator result;
	result.isend = false; result.isrend = false;
	result.parent = this;
	map <Variant, void * > * cur = (map <Variant,void * > *)this->tableRoot;
	int N = keyValue.size()-1;

	result.tableIterator.reserve(keyColumns.size());

	//Произвести поиск по значениям заданных ключевых полей
	for (int i=0; i<N; ++i)
	{
		//result.tableIterator[i] = cur->find(keyValue[i]);
		result.tableIterator.push_back(cur->find(keyValue[i]));
		if (result.tableIterator[i] == cur->end())
			return const_end();
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}

	//Выбрать верхнюю грань и уменьшать поле, пока не получим нижнюю грань

	//n-е ключевое поле выбрать командой lower_bound
	map < Variant, void * > :: iterator it0 = cur->lower_bound(keyValue[N]);

	//Если не удалось выбрать lower_bound(), попробовать начать поиск с
	//максимального значения ключа
	if (it0 == cur->end())
	{
		it0 = cur->find(cur->rbegin()->first);
		if (it0 == cur->end())
		{
			result.isend = true; result.isrend = true;
			return result;
		}
	}

	while (it0->first > keyValue[N])
	{
		if (it0 == cur->begin())
		{
			result.isend = true; result.isrend = true;
			return result;
		}
		it0--;
	}

	//result.tableIterator[N] = it0;
	result.tableIterator.push_back(it0);
	if (result.tableIterator[N] == cur->end())
	{
		result.isend = true; result.isrend = true;
		return result;
	}

	cur = (map <Variant, void* >*)(result.tableIterator[N]->second);

	//Установить наименьшие значения оставшихся ключевых полей
	for (unsigned int i=keyValue.size(); i<keyColumns.size(); ++i)
	{
		//result.tableIterator[i] = cur->begin();
		result.tableIterator.push_back(cur->begin());
		if (result.tableIterator[i] == cur->end())
		{
			result.isend = true; result.isrend = true;
			return result;
		}
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}
	return result;
}

DBMap::DBConstIterator DBMap::lower_bound (const Tuple &keyValue,
											   real prec) const
{
	int keyField = keyValue.size()-1;
	real t0 = keyValue[keyField].toDouble();
	Tuple newkeyval = keyValue;
	newkeyval[keyField]=newkeyval[keyField].toDouble() + prec;
	DBTable::DBConstIterator it = lower_bound(newkeyval);
	if (it.isEnd())
	{
		Tuple keyvaltobegin = newkeyval;
		keyvaltobegin.pop_back();
		it = find(keyvaltobegin);
	}
	if (it.isEnd())
		return it;
	if (it.keyColumnValue(keyField)>t0+prec)
		return const_end();

	DBTable::DBConstIterator it1 = it;
	while(true)
	{
		it1.subinc(keyField,keyField-1,1);
		if (it1.isEnd())
			return it;
		if (it1.keyColumnValue(keyField).toDouble()>t0+prec)
			return it;
		it=it1;
		it1++;
	}
}

void DBMap::deleteRows( const Tuple & keyValue )
{
	int N = keyValue.size()-1;

	//Вершины дерева, путь по которым приводит к удаляемому поддереву
	//При этом, хотя начальной вершиной такого пути должна быть корневая
	//вершина, она не включается в данный массив
	//Последняя вершина также не лежит в удаляемом поддереве.
	vector < map < Variant, void * > * > maps;
	maps.resize(N+1);
	void * cur = tableRoot;

	//С помощью ключа выбрать поддерево, которое необходимо удалить
	for (int i=0; i<=N; i++)
	{
		maps[i] = (map < Variant, void * > *) (cur);
		map < Variant, void * > :: iterator it0 =
			((map < Variant, void * > *)cur)->find(keyValue[i]);
		//Если удалять нечего, ничего не удалять.
		if (it0 == ((map < Variant, void * > *)cur)->end())
			return;
		cur=it0->second;
	}

	//Удалить поддерево
	cleanNode (cur, N+1);

	//Удалить ссылку на поддерево из родительского дерева
	if (N>=0)
		maps[N]->erase(keyValue[N]);

	//Удалить все пустые поддеревья
	for (int i=N; i>0; i--)
		if (maps[i]->size() == 0)
		{
			//Удалить опустевшее поддерево
			delete maps[i];

			//Удалить ссылку на только что удаленное поддерево
			maps[i-1]->erase(keyValue[i-1]);
		}
		else
			break;
}

unsigned int DBMap::getValueColumnIndex(const std::string &valueColumnName)
const
{
	for (unsigned int i=0; i<valueColumns.size(); ++i)
		if (valueColumns[i].second == valueColumnName)
			return i;
	throw NoSuchFieldWithName(valueColumnName);
}

unsigned int DBMap::getKeyColumnIndex(const std::string &keyColumnName)
const
{
	for (unsigned int i=0; i<keyColumns.size(); ++i)
		if (keyColumns[i].second == keyColumnName)
			return i;
	throw NoSuchFieldWithName(keyColumnName);
}

#ifdef WithQT
//------------Переводы между QVariant и Variant-------------------------------//

Variant qvToV(const QVariant & qv)
{
	if ((qv.type() == QVariant::Int)||(qv.type() == QVariant::UInt)||
							(qv.type()==QVariant::ULongLong))
		return Variant(qv.toInt());
	if (qv.type() == QVariant::Double)
		return Variant((real)(qv.toDouble()));
	if (qv.type() == QVariant::Invalid)
		return Variant();
	if (qv.type() == QVariant::Char)
		return Variant(qv.toChar().toAscii());
	if ((qv.type() == QVariant::Date)||(qv.type() == QVariant::DateTime))
	{
		QDateTime dt = qv.toDateTime();
		return Variant(UTCDateTime::fromUTCDateTime(dt.date().year(),
		dt.date().month(), dt.date().day(),dt.time().hour(),dt.time().minute(),
			dt.time().second()+0.001*dt.time().msec()));
	}
	if (qv.type() == QVariant::String)
		return Variant(qv.toString().toStdString());

	throw TypeMismatchException("QVariant", "DBVariant");
}

QVariant vToQV(const Variant & v)
{
	if (v.getType() == Variant::TYPE_CHAR)
		return QVariant((char)(v.toChar()));
	if (v.getType() == Variant::TYPE_DATETIME)
	{
		int Y,M,D,h,m; real s;
		const UTCDateTime & dt = v.toUTCDateTime();
		dt.getUTCDateTime(Y,M,D,h,m,s);
		int sec = floor(s);
		int msec = floor(1000*(s-sec));
		return QVariant(QDateTime(QDate(Y,M,D),
				QTime(h,m,sec,msec)));
	}
	if (v.getType() == Variant::TYPE_DOUBLE)
		return QVariant((double)(v.toDouble()));
	if (v.getType() == Variant::TYPE_INT)
		return QVariant((int)(v.toInt()));
	if (v.getType() == Variant::TYPE_STRING)
		return QVariant(QString::fromStdString(v.toString()));
	return QVariant(QVariant::Invalid);
}

Tuple variantListToTuple(const QVariantList & list)
{
	Tuple result;
	for (QVariantList::const_iterator it0=list.begin(); it0!=list.end(); ++it0)
		result<<qvToV(*it0);
	return result;
}

QVariantList tupleToVariantList (const Tuple & tuple)
{
	QVariantList result;
	for (int i=0; i<tuple.size(); i++)
		result.push_back(vToQV(tuple[i]));
	return result;
}
#endif

#ifdef UseMPI
void DBMap::synchronize(MPI_Comm comm)
{
	int commsize, commrank;
	MPI_Comm_size(comm, &commsize);
	MPI_Comm_rank(comm, &commrank);

	if (commsize == 1)
		return;

	//Синхронизировать можно только таблицы, в которых колонки имеют атомарный
	//тип: int, double, char, UTCDateTime.
	for (int i=0; i<keyColumns.size(); i++)
		if ((keyColumns[i].first!=Variant::TYPE_INT)
				&&(keyColumns[i].first!=Variant::TYPE_DOUBLE)
				&&(keyColumns[i].first!=Variant::TYPE_CHAR)
				&&(keyColumns[i].first!=Variant::TYPE_DATETIME))
			throw SynchronizationError ("Данные типа "+
									keyColumns[i].first->getName()+
									" невозможно напрямую передать через MPI.");
	for (int i=0; i<valueColumns.size(); i++)
		if ((valueColumns[i].first!=Variant::TYPE_INT)
				&&(valueColumns[i].first!=Variant::TYPE_DOUBLE)
				&&(valueColumns[i].first!=Variant::TYPE_CHAR)
				&&(valueColumns[i].first!=Variant::TYPE_DATETIME))
			throw SynchronizationError ("Данные типа "+
									valueColumns[i].first->getName()+
									" невозможно напрямую передать через MPI.");

	//Синхронизация происходит путем передачи (Broadcast) данных таблицы
	//от каждого потока всем потокам и внесения в их таблицы недостающих
	//данных.
	int * rowscounts = new int[commsize];
	MPI_Allgather(&rowsCount, 1, MPI_INT, rowscounts, 1, MPI_INT, comm);
	//Полученные строки, которых нет в данной таблице, сохраняются в отдельной
	//таблице, а затем копируется в основну таблицу после всех проверок
	//корректности. Таким образом, в случае возникновения исключение исходное
	//состояние таблицы не будет изменено.
	DBTable received(keyColumns, valueColumns);
	for (unsigned int i=0; i<commsize; i++)
	{
		//Раздать таблицу i-го потока в другие потоки.
		//Передать таблицу i-го потока во все остальные потоки
		//Передавать данные порциями по NTransmit записей.
		//(Увеличение NTransmit не увеличит значительно скорость передачи)
		const int NTransmit = 1024;
		int currowscount = rowscounts[i];
		//Число передаваемых порций
		int portions = (currowscount-(currowscount % NTransmit))/NTransmit+1;
		int colscount = getKeyColumnsCount()+getValueColumnsCount();
		DBTable::DBConstIterator it = begin();
		for (unsigned int j = 0; j<portions; j++)
		{
			//Число записей для передачи в данной порции
			int nrecords = (j==(portions-1))?(currowscount%NTransmit):NTransmit;
			//Данные передаваемые в данной порции
			//Если tabledata[0] имеет тип NULL, то
			Variant::VariantAtom * tabledata =
					new Variant::VariantAtom[nrecords*colscount];
			//Код ошибки - используется только для синхронизации генерации
			//исключения во всех потоках.
			int errcode = 0;

			if (i == commrank)
				for (unsigned int k=0; k<nrecords; k++)
				{
					if (it == const_end())
					{
						//Нужно вызвать ошибку синхронизации, но её нужно
						//вызвать одновременно во всех потоках.
						errcode = 1;
						break;
					}
					for (unsigned int l=0; l<keyColumns.size(); l++)
					{
						int idx = l+k*colscount;
						if (keyColumns[l].first == Variant::TYPE_INT)
							tabledata[idx].intg = it.keyColumnValue(l).toInt();
						if (keyColumns[l].first == Variant::TYPE_DOUBLE)
							tabledata[idx].dbl=it.keyColumnValue(l).toDouble();
						if (keyColumns[l].first == Variant::TYPE_CHAR)
							tabledata[idx].chr = it.keyColumnValue(l).toChar();
						if (keyColumns[l].first == Variant::TYPE_DATETIME)
							tabledata[idx].dt =
									it.keyColumnValue(l).toUTCDateTime();
					}
					for (unsigned int l=0; l<valueColumns.size(); l++)
					{
						int idx = l + keyColumns.size() + k*colscount;
						if (valueColumns[l].first == Variant::TYPE_INT)
							tabledata[idx].intg=it[l].toInt();
						if (valueColumns[l].first == Variant::TYPE_DOUBLE)
							tabledata[idx].dbl=it[l].toDouble();
						if (valueColumns[l].first == Variant::TYPE_CHAR)
							tabledata[idx].chr=it[l].toChar();
						if (valueColumns[l].first == Variant::TYPE_DATETIME)
							tabledata[idx].dt=it[l].toUTCDateTime();
					}
					++it;
				}

			//Проверить код ошибки
			MPI_Bcast(&errcode,1,MPI_INT,i,comm);
			if (errcode!=0)
				throw SynchronizationError("Неожиданный конец таблицы в "
										   +Variant((int)i).toString()+
										   "-м потоке.");

			//Передать данные
			MPI_Bcast(tabledata,nrecords*colscount*sizeof(Variant::VariantAtom),
						  MPI_BYTE, i, comm);

			if (i!=commrank)
				//Записать недостающие данные
				for (int k=0; k<nrecords; k++)
				{
					Tuple key;
					Tuple value;
					key.reserve(keyColumns.size());
					value.reserve(valueColumns.size());
					for (unsigned int l=0; l<keyColumns.size(); l++)
					{
						int idx = l+k*colscount;
						if (keyColumns[l].first == Variant::TYPE_INT)
							key.push_back(tabledata[idx].intg);
						if (keyColumns[l].first == Variant::TYPE_DOUBLE)
							key.push_back(tabledata[idx].dbl);
						if (keyColumns[l].first == Variant::TYPE_CHAR)
							key.push_back(tabledata[idx].chr);
						if (keyColumns[l].first == Variant::TYPE_DATETIME)
							key.push_back(tabledata[idx].dt);
					}
					for (unsigned int l=0; l<valueColumns.size(); l++)
					{
						int idx = l + keyColumns.size() + k*colscount;
						if (valueColumns[l].first == Variant::TYPE_INT)
							value.push_back(tabledata[idx].intg);
						if (valueColumns[l].first == Variant::TYPE_DOUBLE)
							value.push_back(tabledata[idx].dbl);
						if (valueColumns[l].first == Variant::TYPE_CHAR)
							value.push_back(tabledata[idx].chr);
						if (valueColumns[l].first == Variant::TYPE_DATETIME)
							value.push_back(tabledata[idx].dt);
					}
					DBConstIterator itr = find(key);
					if (itr==const_end())
					{
						itr = received.find(key);
						if (itr == received.const_end())
						{
							received.insertRow(key,value);
							continue;
						}
						else
						{
							if (*itr != value)
							{
								errcode = k;
								break;
							}
						}
					}
					//Проверить, что поля значений совпадают.
					if (*itr != value)
					{
						errcode = 1;
						break;
					}
				}

			//Проверить код ошибок со всех потоков
			int * errcodes = new int[commsize];
			MPI_Allgather(&errcode, 1, MPI_INT, errcodes, 1, MPI_INT, comm);
			for (unsigned int k=0; k<commsize; k++)
				if (errcodes[k] != 0)
				{
					//В потоке, чьи данные вызвали ошибку, вернуть ещё
					//ключ, вызвавший ошибку.
					if (i == commrank)
					{
						Tuple keycols;
						colscount = keyColumns.size();
						for (unsigned int l=0; l<keyColumns.size(); l++)
						{
							int idx = l+k*colscount;

							if (keyColumns[l].first == Variant::TYPE_INT)
								keycols.push_back(tabledata[idx].intg);
							if (keyColumns[l].first == Variant::TYPE_DOUBLE)
								keycols.push_back(tabledata[idx].dbl);
							if (keyColumns[l].first == Variant::TYPE_CHAR)
								keycols.push_back(tabledata[idx].chr);
							if (keyColumns[l].first == Variant::TYPE_DATETIME)
								keycols.push_back(tabledata[idx].dt);

						}
						throw SynchronizationError("В потоках "
											+Variant((int)i).toString()+" и "
											+Variant((int)k).toString()+
											" есть одинаковые ключи: "+
											tuplePrettyPrint(keycols,Tuple())+
											" с разными значениями."
											);
					}
					else
						throw SynchronizationError("В потоках "
											   +Variant((int)i).toString()+" и "
											   +Variant((int)k).toString()+
											   " есть одинаковые ключи "
											   " с разными значениями."
											   );
				}
			delete [] errcodes;
			delete [] tabledata;
		} // по j - номеру порции
	} // по i = номер потока
	delete [] rowscounts;
	//Скопировать строки из временной таблицы
	for (DBTable::DBConstIterator it = received.const_begin();
		 it!=received.const_end(); ++it)
		insertRow(it.subkey(), *it);
}
#endif

Variant DBMap::getMaximalKeyElementValue(const Tuple &subkey,
										 const Variant &nonexisting) const
{
	int n = keyColumns.size();
	int m = subkey.size();
	if (m>=n)
		throw NoSuchFieldWithNumber(m);
	DBConstIterator it;
	if (m==0)
	{
		if (count() == 0)
		{
			if (nonexisting.getType()== Variant::TYPE_NULL)
				throw KeyNotFoundException(subkey);
			else
				return nonexisting;
		}
		else
		{
			it = const_end();
			it.dec(m);
			return it.keyColumnValue(m);
		}

	}
	else
	{
		it = find(subkey);
		if (it.isEnd())
		{
			if (nonexisting.getType() == Variant::TYPE_NULL)
				throw KeyNotFoundException(subkey);
			else
				return nonexisting;
		}
		it.inc(m-1);
		it.dec(m);
		return it.keyColumnValue(m);
	}
}

//------------------Скриптовые обёртки DBMap--------------------------------//

#ifdef WithQT
DBIteratorQS* DBMap::wrapIterator(const DBConstIterator & it) const
{
	return new DBIteratorQS(it);
}

QScriptValue myObjectToScriptValue(QScriptEngine *engine,
								   DBIteratorQS * const &in)
{
	return engine->newQObject(in, QScriptEngine::ScriptOwnership);
}

void myObjectFromScriptValue(const QScriptValue &object, DBIteratorQS* &out)
{
	out = qobject_cast<DBIteratorQS*>(object.toQObject());
}

void DBMap::setEngine(QScriptEngine *eng)
{
	engine = eng;
	qScriptRegisterMetaType(engine, myObjectToScriptValue,
							myObjectFromScriptValue);
}


QString DBMap::dump ( const QString & tablename ) const
{
	std::ostringstream str;
	dump(str,tablename.toStdString());
	return QString::fromStdString(str.str());
}

void DBMap::dump(const QString &tablename, const QString &filename) const
{
	string filename_ = filename.toStdString();
	ofstream tblfile(filename_.c_str());
	dump(tblfile,tablename.toStdString());
	tblfile.close();
}

void DBMap::insertRow ( const QVariantList & key, const QVariantList & value)
{
	insertRow(variantListToTuple(key), variantListToTuple(value));
}

QVariant DBMap::value(const QVariantList & key, int colnumber) const
{
	return vToQV(this->read(variantListToTuple(key))[colnumber]);
}

void DBMap::setValue(const QVariantList & key, int colnumber, QVariant value)
{
	updateCell(variantListToTuple(key),colnumber,qvToV(value));
}

void DBMap::deleteRows(const QVariantList & key)
{
	this->deleteRows(variantListToTuple(key));
}

QString DBMap::getKeyColumnName(int k) const
{
	return QString::fromStdString(keyColumns[k].second);
}

QString DBMap::getValueColumnName(int k) const
{
	return QString::fromStdString(valueColumns[k].second);
}

int DBMap::getKeyColumnByName(const QString & name) const
{
	return getKeyColumnIndex(name.toStdString());
}

int DBMap::getValueColumnByName(const QString & name) const
{
	return getValueColumnIndex(name.toStdString());
}

QVariantList DBMap::read(const QVariantList & keyValue) const
{
	return tupleToVariantList(read(variantListToTuple(keyValue)));
}

DBIteratorQS *DBMap::Begin() const
{
	return wrapIterator(const_begin());
}

DBIteratorQS * DBMap::End() const
{
	return wrapIterator(const_end());
}

DBIteratorQS * DBMap::find (const QVariantList & keyValue ) const
{
	return wrapIterator(find(variantListToTuple(keyValue)));
}

DBIteratorQS * DBMap::upperBound(const QVariantList & keyValue ) const
{
	return wrapIterator(upper_bound(variantListToTuple(keyValue)));
}

DBIteratorQS *DBMap::lowerBound(const QVariantList & keyValue ) const
{
	return wrapIterator(lower_bound(variantListToTuple(keyValue)));
}

QVariantList colstovl(const Columns & cols)
{
	QVariantList result;
	for (int i = 0; i<cols.size(); i++)
	{
		result.push_back(QString::fromStdString(cols[i].first->getName()));
		result.push_back(QString::fromStdString(cols[i].second));
	}
	return result;
}

QVariantList DBMap::getKeyColumnsList() const
{
	return colstovl(keyColumns);
}

QVariantList DBMap::getValueColumnsList() const
{
	return colstovl(valueColumns);
}

QString DBMap::tuplePrettyPrint(const QVariantList &k, const QVariantList &v)
const
{
	return QString::fromStdString(tuplePrettyPrint(variantListToTuple(k),
											  variantListToTuple(v)));
}

void DBMap::copyFrom(const QObject *from, const QObject *to)
{
	const DBIteratorQS * from_ = qobject_cast<const DBIteratorQS*>(from);
	const DBIteratorQS * to_ = qobject_cast<const DBIteratorQS*>(to);
	copyFrom(from_->dbIterator(), to_->dbIterator());
}
#endif

int DBMap::count() const
{
	return rowsCount;
}

int DBMap::getKeyColumnsCount() const
{
	return this->getKeyColumns().size();
}

int DBMap::getValueColumnsCount() const
{
	return this->getValueColumns().size();
}



//------------------------DBConstIterator-------------------------------------//

const Variant & DBMap::DBConstIterator::operator[]
	( const unsigned int & valueColumnIndex ) const
{
	if (isend || isrend)
		throw EndIteratorException();
	if (valueColumnIndex > parent->valueColumns.size())
		throw NoSuchFieldWithNumber (valueColumnIndex);
	return ((Tuple*)(tableIterator[tableIterator.size()-1]->second))->
			operator [](valueColumnIndex);
}

const Variant & DBMap::DBConstIterator::operator[]
	( const std::string & valueColumnName ) const
{
	if (isend || isrend)
		throw EndIteratorException();
	return ((Tuple*)(tableIterator[tableIterator.size()-1]->second))->
			operator [](
				parent->getValueColumnIndex(valueColumnName)
				);
}

const Variant & DBMap::DBConstIterator::keyColumnValue
(const unsigned int &keyColumnIndex) const
{
	if (isend || isrend)
		throw EndIteratorException();
	if (keyColumnIndex > tableIterator.size())
		throw NoSuchFieldWithNumber (keyColumnIndex);
	return tableIterator[keyColumnIndex]->first;
}

const Variant & DBMap::DBConstIterator::keyColumnValue
(const std::string &keyColumnName) const
{
	if (isend || isrend)
		throw EndIteratorException();
	return tableIterator[
			parent->getKeyColumnIndex(keyColumnName)
			]->first;
}

bool DBMap::DBConstIterator::operator ==(
		const DBMap::DBConstIterator & second ) const
{
	bool isend1 = isend;
	bool isend2 = second.isend;
	bool isrend1 = isrend;
	bool isrend2 = second.isrend;
	if (isend1&&isend2)
		return true;
	if (isrend1&&isrend2)
		return true;
	if (isend1||isend2)
		return false;
	if (isrend1||isrend2)
		return false;

	if (second.parent != parent)
		return false;
	for (unsigned int i=0; i<parent->keyColumns.size(); ++i)
		if (tableIterator[i]!=second.tableIterator[i])
			return false;
	return true;
}

DBMap::DBConstIterator & DBMap::DBConstIterator::subinc
(const int colnumber, const int fixcolnumber, const int incriment)
{
	if (colnumber <= fixcolnumber)
	{
		isend = true;
		isrend = true;
		return (*this);
	}

	if (incriment <= 0)
		return (*this);

	if (isrend)
	{
		*this = parent->const_begin();
		return (*this);
	}

	//Свести задачу к увеличению на единицу
	if (incriment > 1)
		subinc (colnumber, fixcolnumber, incriment-1);

	if (isend)
		throw OutOfBoundException();

	//Инкримент
	++(tableIterator[colnumber]);

	//Проверить, не дошел ли итератор до конца
	map<Variant,void*> * previous;
	if (colnumber == 0)
		previous = (map<Variant,void*> *) (parent->tableRoot);
	else
		previous = (map<Variant,void*> *)(tableIterator[colnumber-1]->second);

	//По текущей колонке дошли до конца - проверить, можно ли совершить
	//инкримент по предыдущей колонке
	if (tableIterator[colnumber] == previous->end())
	{
		//Ещё есть одна предыдущая колонка, по которой можно сделать инкримент
		if (colnumber > fixcolnumber + 1)
			return subinc(colnumber-1,fixcolnumber, 1);
		//В противном случае - дошли до конца
		isend = true;
		return (*this);
	}

	//Теперь установить все последующие ключевые поля на наименьшие
	//значения
	for (unsigned int j = colnumber+1; j<tableIterator.size(); ++j)
	{
		map < Variant, void * > * cur =
				(map < Variant, void * > * )(tableIterator[j-1]->second);
		tableIterator[j] = cur->begin();
	}

	return (*this);
}

DBMap::DBConstIterator & DBMap::DBConstIterator::inc
(const int colnumber, const int incriment)
{
	return subinc(colnumber, -1, incriment);
}

DBMap::DBConstIterator & DBMap::DBConstIterator::subdec
(const int colnumber, const int fixcolnumber, const int decriment)
{
	if (colnumber <= fixcolnumber)
	{
		isend = true;
		return (*this);
	}

	int fieldscount = parent->keyColumns.size();

	if (decriment <= 0)
		return (*this);

	if (isrend)
		throw OutOfBoundException();

	//Свести задачу к декременту на единицу
	if (decriment > 1)
		subdec (colnumber, fixcolnumber, decriment-1);

	//Если указывает на конец, перейти к последнему элементу.
	if (isend)
	{
		//Если число записей равно нулю, то последнего элемента также нет
		if (parent->count() == 0)
			return *this;

		//Выделить нужное число map::iterator'ов
		if (fieldscount>tableIterator.size())
			tableIterator.resize(fieldscount);
		
		map<Variant, void*>* cur = ((map<Variant, void*>*)(parent->tableRoot));
		
		//Установить самое большое допустимое значение для нулевого поля
		map<Variant,void*>::reverse_iterator itr = cur->rbegin();
		if (itr == cur->rend())
			return (*this);
		
		//Теперь заполнить все оставшиеся поля
		tableIterator[0] = cur->find(itr->first);
		for (unsigned int i=1; i<fieldscount; i++)
		{
			cur = (map<Variant, void*>*)(tableIterator[i-1]->second);
			itr = cur->rbegin();
			tableIterator[i] = cur->find(itr->first);
		}
		this->isrend = false;
		this->isend = false;
		return (*this);

	}

	map<Variant,void*> * previous;
	if (colnumber == 0)
		previous = (map<Variant, void*>*)(parent->tableRoot);
	else
		previous = (map<Variant, void*>*)(tableIterator[colnumber-1]->second);

	//Если сейчас по текущей колонке уже установлено минимальное значение
	if (previous->begin() == tableIterator[colnumber])
	{
		//Если предыдущую колонку нельзя уменьшать
		if (colnumber <= fixcolnumber +1)
		{
			isrend = true;
			return (*this);
		}

		return subdec (colnumber - 1, fixcolnumber);
	}

	//Декремент
	--tableIterator[colnumber] ;

	//Установить все последующие колонки в end-1
	//Для этого используются обратный итератор
	for (unsigned int j = colnumber+1; j<tableIterator.size(); ++j)
		tableIterator[j] =
			((map<Variant, void*>*)(tableIterator[j-1]->second))->
				find(
			((map<Variant, void*>*)(tableIterator[j-1]->second))->
					rbegin()->first
					);

	return (*this);
}

DBMap::DBConstIterator & DBMap::DBConstIterator::dec
(const int colnumber, const int decriment)
{
	return subdec(colnumber, -1, decriment);
}

void DBMap::DBIterator::deleteRow(int colidx, int fixidx, int inc)
{
	if (colidx == -1)
		colidx = parent->getKeyColumnsCount()-1;
	Tuple toDelete = subkey();
	if (inc>0)
		subinc(colidx,fixidx,inc);
	if (inc<0)
		subdec(colidx,fixidx,inc);
	Tuple newkey;
	if ((isend == false) && (isrend == false))
		newkey = subkey();
	((DBMap*)(parent))->deleteRows(toDelete);
	if (inc == 0)
	{
		isrend = true;
		isend = true;
		return;
	}
	if (newkey.size() > 0)
		*this = parent->find(newkey);
}

//-----------------Скриптовая обертка вокруг итератора---------------------//
#ifdef WithQT
DBIteratorQS::DBIteratorQS (const DBMap::DBIterator & intern)
{
	internal = intern;
}

void DBIteratorQS::inc()
{
	++internal;
}

void DBIteratorQS::dec()
{
	--internal;
}

void DBIteratorQS::dec(int columnnumber)
{
	internal.dec(columnnumber);
}

void DBIteratorQS::dec(int columnnumber, int decrement)
{
	internal.dec(columnnumber, decrement);
}

void DBIteratorQS::inc(int columnnumber)
{
	internal.inc(columnnumber);
}

void DBIteratorQS::inc(int columnnumber, int increment)
{
	internal.inc(columnnumber, increment);
}

void DBIteratorQS::subinc(int columnnumber, int fixcolumnnumber)
{
	internal.subinc(columnnumber, fixcolumnnumber);
}

void DBIteratorQS::subinc(int columnnumber, int fixcolumnnumber,
						  int increment)
{
	internal.subinc(columnnumber, fixcolumnnumber, increment);
}

void DBIteratorQS::subdec(int columnnumber, int fixcolumnnumber)
{
	internal.subdec(columnnumber, fixcolumnnumber);
}

void DBIteratorQS::subdec(int columnnumber, int fixcolumnnumber,int decrement)
{
	internal.subdec(columnnumber, fixcolumnnumber, decrement);
}

QVariant DBIteratorQS::keyColumnValue (const QString & columnname) const
{
	return vToQV(internal.keyColumnValue(columnname.toStdString()));
}

QVariant DBIteratorQS::keyColumnValue (int columnindex) const
{
	return vToQV(internal.keyColumnValue(columnindex));
}

QVariant DBIteratorQS::value(int columnindex) const
{
	return vToQV(internal[columnindex]);
}

QVariantList DBIteratorQS::keyValues() const
{
	return tupleToVariantList(internal.subkey());
}

QVariantList DBIteratorQS::values() const
{
	return tupleToVariantList(*internal);
}

bool DBIteratorQS::equal(const DBIteratorQS *another)
{
	return internal.operator==(another->internal);
}

void DBIteratorQS::updateCell(int columnnumber, const QVariant & newvalue)
{
	internal.updateCell(columnnumber, qvToV(newvalue));
}

void DBIteratorQS::deleteRow()
{
	internal.deleteRow();
}

void DBIteratorQS::deleteRow(int columnnumber)
{
	internal.deleteRow(columnnumber, -1, 1);
}

void DBIteratorQS::deleteRow(int columnnumber, int fixcolumnnumber)
{
	internal.deleteRow(columnnumber, fixcolumnnumber, 1);
}

bool DBIteratorQS::isEnd() const
{
	return internal.isEnd();
}
#endif

//-------------------------------ИСКЛЮЧЕНИЯ---------------------------------//

KeyNotFoundException::KeyNotFoundException(const Tuple &keyValues)
	: StrException ("KeyNotFoundException",
					"Не удалось найти строку по элементам"
			" ключа: ("+
			keyValues.join(";")+")")
{

}

OutOfBoundException::OutOfBoundException()
	: StrException("OutOfBoundException","Выход за границу массива")
{

}

EndIteratorException::EndIteratorException()
	: StrException("EndIteratorException",
				   "Обращение к данным по итератору, указывающему за "
		       "пределы таблицы.")
{

}

IndexAlreadyExistsException::IndexAlreadyExistsException(string indexname)
	: StrException("IndexAlreadyExistsException",
				   "Таблица уже имеет индекс '"+indexname+"'.")
{

}

NoSuchFieldWithName::NoSuchFieldWithName(const string &name)
	: StrException("NoSuchFieldWithName",
				   "Обращение к полю по несуществующему имени поля: "+name)
{

}

NoSuchFieldWithNumber::NoSuchFieldWithNumber(int number)
	: StrException ("NoSuchFieldWithNumber",
					"Обращение к полю по номеру, превышающему число "
					"полей: " + Variant(number).toString())
{

}

SynchronizationError::SynchronizationError(const string &what)
	: StrException ("SynchronizationError",
					"Невозможно синхронизировать таблицу между потоками: "
					+what)
{

}

void DBMap::dump(ostream & output, const string & name) const
{
	for (DBConstIterator it0=const_begin(); it0!=const_end(); ++it0)
	{
		output<<name;
		for (unsigned int i = 0; i<getKeyColumns().size(); i++)
		{
			string kv = it0.keyColumnValue(i).toString();
			output<<'\t'<<kv;
		}
		for (unsigned int i=0; i<getValueColumns().size(); i++)
		{
			string dv = it0[i].toString();
			output<<'\t'<<dv;
		}
		output<<endl;
	}

}

//-----------------DBTable------------------------------------------------//

Tuple DBTable::idx_key(string idxname, const Tuple &key, const Tuple &value)
{
	Tuple result;
	result.resize(indices[idxname].first.size());
	for (unsigned int i=0; i<indices[idxname].first.size(); i++)
	{
		if (indices[idxname].first[i].first=='K')
			result[i] = key[indices[idxname].first[i].second];
		else
			result[i] = value[indices[idxname].first[i].second];
	}
	return result;
}

void DBTable::addToIndices(const Tuple &keyValue, const Tuple &values)
{
	for (map < string, pair < vector < pair<char, int> >,DBMap*> >::iterator
		 it0 = indices.begin(); it0!=indices.end(); ++it0)
	{
		Tuple idxkey = idx_key(it0->first, keyValue, values);
		try
		{
			it0->second.second->insertRow(idxkey,keyValue);
		}
		catch (DuplicateKeyException e)
		{
			//В случае нарушения уникальности в индексе, откатить уже
			//добавленные индексы и вернуть исключение
			if (it0!=indices.begin())
				while (true)
				{
					--it0;
					Tuple idxdelkey = idx_key(it0->first, keyValue, values);
					it0->second.second->deleteRows(idxdelkey);
					if (it0==indices.begin())
						break;
				}
			throw IndexUniquenessException (keyValue, values, it0->first);
		}
	}
}

void DBTable::removeFromIndices(const Tuple &keyValue, const Tuple &values)
{
	for (map < string, pair < vector < pair<char, int> >,DBMap*> >::iterator
		 it0 = indices.begin(); it0!=indices.end(); ++it0)
	{
		Tuple idxkey = idx_key(it0->first, keyValue, values);
		it0->second.second->deleteRows(idxkey);
	}
}

void DBTable::insertRow(const Tuple &keyValue, const Tuple &values)
{
	//1) Сначала попробовать вставить во все индексы. Если возникло исключение,
	// не обрабатывать его, но выйти из процедуры
	addToIndices(keyValue,values);

	//2) Теперь попробовать вставить в основной индекс
	try
	{
		DBMap::insertRow(keyValue, values);
	}
	catch (DuplicateKeyException e)
	{
		//3) Если не удалось вставить в таблицу, удалить из всех индексов
		removeFromIndices(keyValue,values);
		throw e;
	}
}

void DBTable::deleteRows(const Tuple &keyValue)
{
	if (indices.size()>0)
		//Обойти всё поддерево и стереть его из индексов
		for (DBTable::DBConstIterator it0 = find(keyValue); it0!=const_end();
			 it0.subinc(keyColumns.size()-1,keyValue.size()-1))
		{
			Tuple key = it0.subkey();
			removeFromIndices(key,*it0);
		}
	DBMap::deleteRows(keyValue);
}

void DBTable::updateCell(const Tuple &keyValue, int colnumber,
						 const Variant &value)
{
	Tuple oldValues = read(keyValue);
	Tuple newValue = oldValues;
	newValue[colnumber] = value;

	//Удалить из индексов эту строку
	removeFromIndices(keyValue,oldValues);

	//Добавить в индексы новую строку
	try
	{
		addToIndices(keyValue, newValue);
	}
	catch (IndexUniquenessException e)
	{
		//Если не получилось, то задержать вызов исключения до того, как
		//строка будет возвращена во все индексы
		addToIndices(keyValue, oldValues);
		throw e;
	}

	//После этого можно спокойно внести изменения в таблицу
	DBMap::updateCell(keyValue, colnumber, value);

}


void DBTable::createIndex (const string&name,
						   const OperatorPushableVector < string > & fields)
{
	//Поиск поля по названию среди полей основного ключа и значений
	vector < pair < char, int > > indexfields;
	Columns keycolumns;
	for (unsigned int i=0; i<fields.size(); i++)
	{
		for (unsigned int j=0; j<keyColumns.size(); j++)
			if (keyColumns[j].second == fields[i])
			{
				indexfields.push_back(pair<char, int>('K',j));
				keycolumns.push_back(Column(keyColumns[j].first,fields[i]));
			}
		for (unsigned int j=0; j<valueColumns.size(); j++)
			if (valueColumns[j].second == fields[i])
			{
				indexfields.push_back(pair<char, int>('V',j));
				keycolumns.push_back(Column(valueColumns[j].first,fields[i]));
			}
	}

	//Добавление нового индекса
	DBMap * dbm = new DBMap (keycolumns, keyColumns);

	indices[name] = pair < vector < pair<char, int> >, DBMap * >
			(indexfields, dbm);
//	indices[name] =


	//Создание нового индекса
	for (DBMap::DBConstIterator it0 = const_begin(); it0!=const_end(); ++it0)
	{
		Tuple keyvals;
		keyvals.resize(indexfields.size());
		for (unsigned int i=0; i<indexfields.size(); i++)
		{
			if (indexfields[i].first=='K')
				keyvals[i]=it0.keyColumnValue(indexfields[i].second);
			else
				keyvals[i]=it0[indexfields[i].second];
		}
		dbm->insertRow(keyvals, it0.subkey());
	}
}

void DBTable::dropIndex ( const string & name)
{
	indices.erase(name);
}

const Tuple & DBTable::mainKey ( const string & name, const Tuple & idx_key )
const
{
	return indices.at(name).second->read(idx_key);
}

DBMap::DBConstIterator DBTable::idx_upper_bound(const string & name,
												const Tuple &keyValue) const
{
	DBTable::DBConstIterator it0=indices.at(name).second->upper_bound(keyValue);
	if (it0 == indices.at(name).second->const_end())
		return const_end();
	else
		return find(*it0);
}

DBMap::DBConstIterator DBTable::idx_lower_bound(const string & name,
												const Tuple &keyValue) const
{
	DBTable::DBConstIterator it0=indices.at(name).second->lower_bound(keyValue);
	if (it0 == indices.at(name).second->const_end())
		return const_end();
	else
		return find(*it0);
}

DBMap::DBConstIterator DBTable::idx_find(const string &name,
										 const Tuple &idx_key) const
{
	DBMap::DBConstIterator it1 = indices.at(name).second->find(idx_key);
	if (it1 == indices.at(name).second->const_end())
		return const_end();
	else
		return find(it1.values());
}


//------------------------NUMERATEDTABLE-----------------------------//

int NumeratedTable::insertRow(const Tuple &values)
{
	int newkeyvalue = 0;
	if (count() == 0)
		newkeyvalue = 0;
	else
	{
		//Перейти к последнему элементу
		DBTable::DBConstIterator it = const_end();
		it.dec(0);

		//Новое значение ключа на 1 больше предыдущего
		newkeyvalue = it.keyColumnValue(0).toInt() + 1;
	}
	DBTable::insertRow(Tuple()<<newkeyvalue, values);

	return newkeyvalue;
}

#ifdef WithQT

//------------------------Функции создания таблицы-------------------------//
Columns vltocols(const QVariantList & l)
{
	Columns result;
	CType * t;
	for (unsigned int i=0; i<l.size(); i++)
	{
		if ((i%2) == 0)
			t = CType::getCType(l[i].toString().toStdString());
		else
			result<<
				pair<Variant::Type,string>(t,l[i].toString().toStdString());
	}
	return result;
}

QScriptValue newtbl(QScriptContext*ctx, QScriptEngine * eng)
{
	QVariantList keycols = ctx->argument(0).toVariant().toList();
	QVariantList valcols = ctx->argument(1).toVariant().toList();
	DBTable * result = new DBTable(vltocols(keycols),vltocols(valcols));
	return eng->newQObject(result, QScriptEngine::ScriptOwnership);
}

QScriptValue newntbl(QScriptContext*ctx, QScriptEngine * eng)
{
	QVariantList valuecols = ctx->argument(0).toVariant().toList();
	NumeratedTable * result = new NumeratedTable(vltocols(valuecols));
	return eng->newQObject(result, QScriptEngine::ScriptOwnership);
}

BuiltIn newTbl("newTable", 2, newtbl);
BuiltIn newNTbl("newNumeratedTable",1, newntbl);
#endif

}

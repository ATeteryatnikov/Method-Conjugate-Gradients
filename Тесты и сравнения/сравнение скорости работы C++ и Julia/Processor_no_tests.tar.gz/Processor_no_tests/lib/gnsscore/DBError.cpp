#include <DBError.h>

//! @file

#include <UTCDateTime.h>

using namespace std;

namespace libgnss
{


StrException::StrException(const std::string &exceptiontype,
						   const std::string& exceptionMessage): exception()
{
	this->exceptiontype = exceptiontype;
	this->exceptionMessage = exceptionMessage;
}


const char* StrException::what() const throw()
{
	return exceptionMessage.c_str();
}

StrException::~StrException() throw()
{

}

NotImplementedException::NotImplementedException(const std::string &function)
	: StrException ("NotImplementedException",
					"Вызов нереализованной функции: "+function)
{

}

void ExceptionsLog::logException(const StrException & e)
{
	std::string etype = e.getExceptionType();
	std::map<std::string, int>::iterator it =
			maxExceptionsCount.find(etype);
	if (it==maxExceptionsCount.end())
	{
		maxExceptionsCount[etype] = 1000;
		exceptionsCount[etype] = 0;
	}
	if (exceptionsCount[etype] < maxExceptionsCount[etype])
		log.push_back(UTCDateTime::now().getUTCDateTimeString()+"\tТип: "
					+etype+"\tСообщение: "+e.what());
	if (exceptionsCount[etype] == maxExceptionsCount[etype])
		log.push_back(UTCDateTime::now().getUTCDateTimeString()+"\tТип: "
					+etype+"\tПоследующие ошибки данного типа не "
					  "записаны в журнал. См. статистику в конце журнала.");
	exceptionsCount[etype]++;
}

void ExceptionsLog::setMaxExceptionsCount(const std::string & etype, int count)
{
	maxExceptionsCount[etype] = count;
}

void ExceptionsLog::outputLog(std::ostream & str) const
{
	for (std::list<std::string>::const_iterator it = log.begin();
		 it!=log.end(); ++it)
		str<<(*it)<<endl;
	str<<"Статистика ошибок: "<<endl;
	for (std::map<std::string,int>::const_iterator it = exceptionsCount.begin();
		 it!=exceptionsCount.end(); ++it)
		str<<"Тип ошибок: "<<it->first<<" Число возникновений: "<<it->second
			 <<endl;

}

void ExceptionsLog::drop()
{
	log.clear();
	exceptionsCount.clear();
}

FileNotFoundException::FileNotFoundException(const string &filename)
	: StrException("FileNotFoundException",
				   "Файл не найден: "+filename)
{
	this->filename = filename;
}

InternalException::InternalException(const string &wh)
	: StrException("InternalException", "Внутренняя ошибка: "+wh)
{

}

}

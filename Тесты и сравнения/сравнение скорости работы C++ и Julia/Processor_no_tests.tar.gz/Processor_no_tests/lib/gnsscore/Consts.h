#ifndef CONSTS_H_
#define CONSTS_H_

namespace libgnss
{

//! @file

//! Скорость света в вакууме, км/с
const double lightSpeed = 299792.458;

//! Количество секунд в юлианских сутках
const double jsecondsPerDay = 86400;

//! Количество суток в одном веке
const double jdaysPerCentury = 36525;

const double JD_J2000 = 2451545.0;

const double Pi = 3.141592653589793238;

//! Коэффициент перехода от секунд дуги к радианам
const double AS2R = Pi/6.48e5; //4.848136811095359935899141e-6;

//! Cредняя угловая скорость вращения Земли (nominal mean Earth's angular velocity), (рад/с)
const double earthAngularVelocity=7.292115e-5; //Или 0.72921158553e10−4 согласно NGA GPS Ephemeris/Station/Antenna Offset Documentation −− WGS84 (G1150) (http://sci.tech-archive.net/Archive/sci.geo.satellite-nav/2005-07/msg00705.html)

//! Cреднее экваториальное значение ускорения свободного падения (mean equatorial gravity), (м/c^2)
const double earthEquatorialGravity=9.7803278;

// Гравитационный параметр Земли м^3/с^2
// const double GM=3.986004418e14;

//! Гравитационная постоянная (сonstant of gravitation), (м^3/(кг c^2))
const double earthConstantOfGravitation=6.67428e-11;

//! Астрономическая единица в километрах
const double astrounit = 149597870.691;


//Бывшая таблица CelestialBodies - кажется, не нужна

const int Idx_venus = 2;
const double GM_venus = 324937.3218;
const double R_venus = 6051.8;

const int Idx_earth = 3;
const double GM_earth = 398600.4418;
const double R_earth = 6378.1366;
const double Flat_earth = 0.00345713060397332;

const int Idx_mars = 4;
const double GM_mars = 42838.86618;
const double R_mars = 3386.2;
const double Flat_mars = 0.00589;

const int Idx_jupiter = 5;
const double GM_jupiter = 126717880.08;
const double R_jupiter = 66854;
const double Flat_jupiter = 0.06487;

const int Idx_saturn = 6;
const double GM_saturn = 37940612.088;
const double R_saturn = 54364;
const double Flat_saturn = 0.09796;

const int Idx_sun = 11;
const double GM_sun = 132712400000.0;
const double R_sun = 696000;
const double Flat_sun = 9e-06;

const int Idx_moon = 10;
const double GM_moon = 4902.799186;
const double R_moon = 1738;
const double Flat_moon = 0.00125;

//Номера систем координат

//! Внутренняя инерциальная система координат
const int defaultInert = 0;

//! Внутренняя неинерциальная система координат
const int defaultNonInert = 1;

//! Внутренняя геодезическая система координат
const int defaultGeodetic = 2;

//! Любая другая система координат
const int otherCoordSys = 3;

}

#endif

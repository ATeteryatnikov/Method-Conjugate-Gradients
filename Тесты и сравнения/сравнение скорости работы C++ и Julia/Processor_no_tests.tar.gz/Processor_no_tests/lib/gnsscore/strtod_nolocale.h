#ifndef STRTOD_NOLOC
#define STRTOD_NOLOC

#include <ctype.h>
#include <cstring>

static int mul10 [] = {1,10,100,1000,10000,100000,1000000,10000000,100000000,
					  1000000000};

/** @brief Преобразует строку в число с плавающей точкой
 *
 * @tparam resulttype Тип числа с плавающей точкой
 * @param str C-строка с нулем в конце
 * @param output Указатель для записи результата
 * @param str_ Указатель на позицию после числа
 *
 * Процедура выполняет действия:
 * @li Пропускает все начальные пробелы
 * @li Распознаёт число с плавающей точкой
 * @li Пробегает все пробелы после числа
 * @li Возвращает полученный указатель на позицию в строке
 *
 * Если строка состоит только из числа и пробелов, то str_
 * будет указывать на ноль в конце строки; если после числа
 * идут сразу непробельные символы, str_ укажет на первый
 * такой символ; если после числа и нескольких пробелов в
 * строке стоят непробельные символы, str_ укажет на последний
 * пробел.
 *
 * @warning Требуется, чтобы число с плавающей точкой хранилось
 * в памяти, выделяемой под тип resulttype, и не использовало
 * указателей на другие области памяти. Кроме того, resulttype
 * должен поддерживать арифметические операции и конструктор
 * преобразования из целого числа.
 *
 */
template <typename resulttype>
resulttype strtofloat (const char * str, char ** str_ = 0)
{
  //Пропустить пробелы
  while ( isspace(* str) )
	str++;

  //false - положительное число, true - отрицательное
  bool sign = false;

  //Считать знак, если есть
  if ( *str == '-' )
  {
	sign = true;
	str++;
  }
  else if (*str == '+')
	str++;

  resulttype result = 0;

  //Ячейка для промежуточного запоминания не более девяти считанных цифр
  int limb = 0;
  //Позиция десятичного знака
  int decimalpoint = -1;
  //Число считанных в limb десятичных знаков
  int decdigits = 0;

  //Считать мантиссу, определив позицию десятичной точки
  while (true)
  {
	char c = *str;
	if (c == '.')
	{
	  decimalpoint = decdigits;
	  str++;
	  continue;
	}

	//Мантисса считана?
	if(!isdigit(c))
	  break;
	str++;

	//Если ещё есть место, считать ещё цифру мантиссы
	limb = limb * 10 + (c-'0');
	decdigits ++;

	if ((decdigits % 9) == 0)
	{
	  result = result * 1000000000 + limb;
	  limb = 0;
	}

  }

  if (decdigits % 9 > 0)
	result = result * mul10[decdigits % 9] + limb;

  if (sign == true)
	result = -result;


  //Считать экспоненту, если есть
  int exponent = 0;
  if ((*str == 'E')||(*str == 'D')||(*str=='e')||(*str=='d'))
  {
	str++;
	bool expsign = false;
	if (*str == '-')
	{
	  expsign = true;
	  str++;
	}
	else if (*str == '+')
	  str++;
	//Считать величину экспоненты
	while (isdigit(*str))
	{
	  exponent = exponent * 10 + (*str) - '0';
	  str++;
	}
	if (expsign)
	  exponent = -exponent;
  }


  //Установить указатель после числа
  int finspaces = 0;
  while (isspace(*str))
  {
	finspaces ++;
	str++;
  }
  if ((*str != 0) && (finspaces > 0))
	str--;
  if (str_ != 0)
	*str_ = (char*)str;

  //Теперь установить экспоненту
  int finexp = exponent;
  if (decimalpoint > -1)
	finexp -= (decdigits - decimalpoint);

  if (finexp != 0)
  {
	bool signfexp = (finexp < 0);
	//Вычислить 10^finexp с помощью бинарного алгоритма
	resulttype expmul = 1;
	resulttype power10 = 10;
	if (finexp < 0)
		finexp = -finexp;
	while (finexp != 0)
	{
	  if ((finexp % 2) != 0)
	  expmul *= power10;
	  power10 *= power10;
	  finexp >>= 1;
	}
	if (signfexp)
	  expmul = (resulttype)1/expmul;
	result *= expmul;
  }

  return result;

}

#endif

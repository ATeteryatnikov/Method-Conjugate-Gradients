#ifndef DBERROR_H_
#define DBERROR_H_

//! @file

#include <exception>
#include <string>
#include <map>
//#include <iostream>
#include <vector>
#include <list>

namespace libgnss
{

/**
 * @brief Исключение с заданной строкой сообщения об ошибке
 *
 * @ingroup except
 * @ingroup core
 */
class StrException : public std::exception
{
private:
	std::string exceptionMessage;
	std::string exceptiontype;
public:
	StrException ( const std::string & exceptiontype,
				   const std::string & exceptionMessage );
	~StrException () throw();
	virtual const char* what() const throw();
	inline const std::string & getExceptionType() const
	{
		return exceptiontype;
	}
};

/**  @brief Исключение при вызове нереализованной функциональности
 *
 * @ingroup core
 * @ingroup except
  *
  * Любая нереализованная функция должна содержать либо заглушку,
  * адекватно заменяющую недостающую функциональность, либо содержать
  * команду генерации данного исключения. В последнем случае предполагается,
  * что функция пока не должна быть вызвана при нормальной работе программы.
  *
  */
class NotImplementedException : public StrException
{
public:
	NotImplementedException (const std::string & function);
};

/**
 * @brief Класс для сбора статистики исключений во время длительной операции
 *
 * @ingroup core
 *
 * Иногда возникновение исключений не должно приводить к прерыванию длительной
 * операции, однако информацию об ошибках необходимо накапливать, для чего и
 * используется данный класс.
 *
 * Для его использования нужно создать объект данного класса, и при
 * возникновении исключения в теле catch нужно вставить вызов метода
 * @ref logException() .
 *
 * Исключения записываются до достижения определённого количества исключений
 * данного типа, после этого сохраняется только число исключений данного типа.
 * Для установки порога запоминания исключений используется метод
 * @ref setMaxExceptionsCount().
 */
class ExceptionsLog
{
private:
	std::map<std::string, int> maxExceptionsCount;
	std::map<std::string, int> exceptionsCount;
	std::list<std::string> log;

public:
	/**
	 * @brief Сохранить информацию об исключении
	 * @param e Исключение
	 */
	void logException(const StrException & e);

	/**
	 * @brief Задать максимальное число запоминаемых исключений данного типа
	 * @param etype Тип исключений
	 * @param count Ограничение для числа запоминаемых исключений
	 */
	void setMaxExceptionsCount(const std::string & etype, int count);

	/**
	 * @brief Вывести журнал исключений в поток
	 * @param str Поток вывода
	 */
	void outputLog(std::ostream & str) const;

	/**
	 * @brief Сбросить журнал исключений
	 */
	void drop();
};

/**
 * @brief Исключение, возникающее, когда невозможно открыть файл
 *
 * @ingroup except
 */
class FileNotFoundException : public StrException
{
private:
	std::string filename;
public:
	FileNotFoundException (const std::string & filename);

	inline ~FileNotFoundException() throw()
	{

	}

	inline const std::string & getFileName() const
	{
		return filename;
	}
};

/**
 * @brief Исключение, возникшее из-за ошибки в библиотеке libgnss
 *
 * @ingroup except
 */
class InternalException : public StrException
{
public:
	InternalException (const std::string & wh);
};

}
#endif

#ifndef UTCDATETIME_H_
#define UTCDATETIME_H_

#include <sstream>
#include <limits>

#include <Types.h>
#include <DBError.h>
#include <sofa.h>
#include <sofam.h>

namespace libgnss
{


//! @file

/** @brief Исключение выхода за допустимые пределы одного из компонент даты
 *
 * @ingroup except
  *
  * Исключение генерируется, когда при задании одной из компонент даты
  * происходит выход за допустимые пределы: месяц от 1 до 12, день от 1 до 31,
  * час от 0 до 23, минуты от 0 до 59, секунды от 0 до 60. 60-я секунда
  * возникает при добавлении секунды синхронизации (leap second).
  */
class DateTimeBoundException : public StrException
{
public:

	//! Конструктор, просто создающий класс StrException
	inline DateTimeBoundException(const std::string & message)
		: StrException ("DateTimeBoundException", message)
	{

	}
};

/**
 * @brief Исключение: таблица секунд координации не найдена
 *
 * @ingroup except
 *
 * Исключение генерируется при переводе метки времени между шкалами UTC и TAI,
 * если таблица секунд координации не была загружена.
 */
class LeapSecondsNotAvailableException : public StrException
{
public:
	inline LeapSecondsNotAvailableException ()
		: StrException ("LeapSecondsNotAvailableException",
						"К текущей коллекции таблиц не подключена "
		"таблица leap_seconds. Конвертация UTC<->TAI невозможна.")
	{

	}
};

/**
 * @brief Исключение: неправильная метка времени оперативной информации ГЛОНАСС
 *
 * Возникает при создании метки времени на основе метки времени из оперативной
 * информации ГЛОНАСС, задаваемой номер четырехлетнего интервала N4, номером
 * дня в четырехлетнем интервале Nt и секундой в пределах суток tb.
 *
 * Исключение генерируется, когда при создании метки времени значения этих полей
 * выходят за допустимые пределы.
 *
 * @ingroup except
 */
class WrongGLONASSNavDataDateTime : public StrException
{
public:
	WrongGLONASSNavDataDateTime(int tb, int Nt, int N4);
};

inline std::string itoa (int i)
{
	std::stringstream ss;
	ss<<i;
	return ss.str();
}

inline void HourMinuteSecond(real hms, int&hour, int&minute, real&second)
{
	int ihms = (int)hms;
	real frac = (hms-ihms);
	int isecond = ihms%60;
	minute = ((ihms - isecond)/60) % 60;
	hour =  ((ihms-isecond)/60 - minute)/60;
	second = isecond + frac;
}

/** @brief Исключение записи года в виде двух цифр
 *
 * @ingroup except
  *
  * Исключение генерируется, когда дата преобразуется в строку, формат требует
  * задать год в виде двух цифр, и год выходит за пределы [1951; 2050]. В этом
  * случае, обратное преобразование невозможно.
  */
class AmbigousYearException : public StrException
{
public:
	AmbigousYearException(int year)
		: StrException ("AmbigousYearException",
						"Год невозможно однозначно задать двумя "
				"цифрами в соответствии с форматом: "+
				itoa(year)
				)
	{

	}
};

class DBTable;

/**
 * @brief Ошибка несоответствия строкового представления метки времени и шаблона
 *
 * @ingroup except
 */
class IncorrectDateFormat : public StrException
{
public:
	IncorrectDateFormat ( const std::string & date, const std::string & format )
		: StrException ("IncorrectDateFormat",
			  "Дата '"+date+"' не соответствует формату '"+
			  format+"' "
			  )
	{

	}
};


/**
 * @brief Метка времени
 *
 * @ingroup core
 *
 * Класс используется для представления, хранения и преобразования меток
 * времени.
 *
 * Внутри метка времени хранится в виде дробного числа секунд от
 * 12:00 01.01.2000 TAI.
 */
class UTCDateTime
{
private:
//	long long int Y_MDHM;
//	double sec;
	real t2000;
	static std::string DateTimeFormat;

public:
	static DBTable * leapSeconds;

	/**
	 * @brief Перевести номер дня в году в день и номер месяца
	 * @param yearday Номер дня в году
	 * @param year Год
	 * @return Пара (месяц, день в месяце)
	 */
	static std::pair < int, int > yearDayToDayMonth (int yearday, int year);

	/**
	 * @brief Возвращает число секунд координации на данную эпоху
	 * @param taij2000 Число секунд от 12:00 01.01.2000 TAI
	 */
	static int getLeapSeconds(real taij2000);

	/**
	 * @brief Разбор компонент даты, заданной в виде строки
	 * @param str Разбираемая строка
	 * @param format Формат строки
	 *
	 * В выходные аргументы записываются соответствующие компоненты разобранной
	 * даты. При несоответствии формата даты и полученной строки str
	 * генерируется исключение @ref IncorrectDateFormat.
	 *
	 * В формате строки допустимо использовать любые символы, кроме Y,M,D,h,m,S,
	 * s, которые являются компонентами плейсхолдеров.
	 *
	 * Плейсхолдеры:
	 * @li YYYY - четырехзначный год
	 * @li YY - двухзначный год
	 * @li MM - месяц
	 * @li DD - день месяца
	 * @li hh - час
	 * @li mm - минута
	 * @li SS - секунда
	 * @li sss - дробная часть секунды.
	 *
	 * В одной строке нельзя использовать YYYY и YY одновременно.
	 *
	 * Пример: YYYY-MM-DD_hh:mm:SS.sss -> 2004-02-29_12:13:14.000
	 *
	 * Отметим, что шаблон и получаемая по нему дата имеют равную длину.
	 */
	static void strToDate(const std::string & str,
						int & year, int & month, int & day,
						int & hour, int & minute, real & sec,
						const std::string & format = "YYYY-MM-DD_hh:mm:SS.sss");

	/**
	 * @brief Получение строкового представления даты по шаблону
	 * @param format Формат даты
	 *
	 * По принимаемым компонентам даты её строковое представление будет
	 * собрано по шаблону. Описание шаблона см. в @ref strToDate();
	 *
	 * Если год не находится в интервале от 1950 до 2050, то невозможно
	 * использовать плейсхолдер YY - будет сгенерировано исключение
	 * AmbigousYearException.
	 *
	 * @return Строковое представление даты
	 */
	static std::string dateToStr(int year, int month, int day,
								 int hour, int minute, real sec,
						const std::string & format = "YYYY-MM-DD_hh:mm:SS.sss");


	/**
	 * @brief Переводит дату/время в секунды от 12:00 1 января 2000 г.
	 *
	 * Метод принимает компоненты даты/времени и преобразует их в число секунд.
	 * Метод не зависит от шкалы времени; допустимо использовать Second>60,
	 * однако наличие секунды координации, и, вообще, неравномерность шкалы
	 * никак не контролируется.
	 *
	 * @param[out] sec2000 Число секунд от 12:00 1 января 2000 г.
	 */
	inline static void dateTimeToSec2000(int Year, int Month, int Day,
									int Hour, int Minute, double Second,
									real & sec2000)
	{
		double djmjd0, date, time;
		iauCal2jd (Year, Month, Day, &djmjd0, &date);
		time = 60*(60*Hour + Minute) + Second;
		sec2000 = (real)((date-DJM00)*DAYSEC) + (real)time;
	}

	/**
	 * @brief Преобразование секунд от 12:00 1 января 2000 г. в дату и время
	 * @param sec2000 Секунды от 12:00 1 января 2000 г. в какой-либо шкале
	 *
	 * Возвращаются компоненты даты и времени.
	 */
	inline static void sec2000ToDateTime(real sec2000,
										 int & Year, int & Month, int & Day,
										 int & Hour, int & Minute, real &Second)
	{
		sec2000/=86400;
		double hms;
		iauJd2cal(DJ00,sec2000,&Year,&Month,&Day,&hms);
		real sec;
		HourMinuteSecond(hms*86400, Hour, Minute, sec);
		Second=sec;
	}

//   ШКАЛА TAI

	inline bool operator== ( const UTCDateTime & other) const
	{
		return (t2000 == other.t2000);
	}

	inline bool operator< (const UTCDateTime & other) const
	{
		return (t2000<other.t2000);
	}

	/** @brief Создать метку времени из числа секунд
	*
	* @param tai2000 Число секунд в шкале TAI от 12:00 1 января 2000
	*
	* @return Метка времени, созданная из заданного числа секунд
	*/
	inline static UTCDateTime fromTAIJ2000( real tai2000 )
	{
		UTCDateTime result;
		result.t2000 = tai2000;
		return result;
	}

	//! @brief Возвращает число секунд в шкале TAI от 12:00 12 января 2000 г.
	inline real getTAIJ2000 () const
	{
		return t2000;
	}

	//! Возвращает компоненты даты/времени в шкале TAI
	inline void getTAIDateTime(int & Y, int & M, int & D, int & h,
							   int & m, real & s) const
	{
		sec2000ToDateTime(getTAIJ2000(), Y, M, D, h, m, s);
	}

	/**
	 * @brief Создаёт метку времени исходя из даты и времени TAI
	 *
	 * Метод принимает компоненты даты/времени TAI
	 */
	inline static UTCDateTime fromTAIDateTime(int Year, int Month, int Day,
					int Hour, int Minute, double Second)
	{
		real taij2000;
		dateTimeToSec2000(Year,Month,Day,Hour,Minute,Second,taij2000);
		return fromTAIJ2000(taij2000);
	}

	/**
	 * @brief Создаёт метку времени из строки
	 *
	 * @param str Строка в формате YYYY-MM-DD_hh:mm:SS.sss
	 *
	 * Описание формата см. @ref strToDate()
	 *
	 * @return Вычисленная метка времени
	 */
	inline static UTCDateTime fromTAIDateTimeString(const std::string & str)
	{
		int Y,M,D,h,m;
		real s;
		strToDate(str, Y,M,D,h,m,s,DateTimeFormat);
		return fromTAIDateTime(Y,M,D,h,m,s);
	}

	//! @brief Возвращает строковое представления даты/времени в шкале TAI
	inline std::string getTAIDateTimeString() const
	{
		int Y,M,D,h,m; real s;
		getTAIDateTime(Y,M,D,h,m,s);
		return dateToStr(Y,M,D,h,m,s,DateTimeFormat);
	}


//ШКАЛА UTC

	/**
	 * @brief Возвращает число секунд UTC от 12:00 1 января 2000 г.
	 * @return Число секунд UTC
	 *
	 * @note Преобразование в UTC2000 не взаимно однозначно. Например, метки
	 * 2015-06-30_23:59:60.000 и 2015-07-01_00:00:00.000 различаются, для них
	 * getUTC2000() возвращает одинаковый разультат.
	 */
	inline real getUTCJ2000 () const
	{
		int LS = getLeapSeconds(t2000);
		//TAI = UTC+Leap
		return t2000-LS;
	}

	/**
	 * @brief Возвращает компоненты даты и времени UTC
	 *
	 * В отличие от секунд UTC от 12:00 01.01.2000, преобразование даты UTC
	 * в TAI и обратно взаимно однозначно, если секунда координации обозначается
	 * числом 23:59:60.
	 *
	 */
	inline void getUTCDateTime(int & Y, int & M, int & D, int & h,
							   int & m, real & s) const
	{
		/** Проверить, находится ли момент в пределах секунды координации?
		 *
		 * Необходимо учесть ошибки округления double.
		 */
		int LS = getLeapSeconds(t2000
						-2*std::numeric_limits<double>::epsilon()*t2000);
		int LSp = getLeapSeconds(t2000+1
						+2*std::numeric_limits<double>::epsilon()*t2000);

		if (LSp==LS)
			/** Если момент времени не в пределах секунды координации, то
			  * getUTCJ2000() и sec2000ToDateTime() даст правильный результат.
			  */
			sec2000ToDateTime(getUTCJ2000(), Y, M, D, h, m, s);
		else
		{
			/** Если момент времени в пределах секунды координации, то возможны
			 * два варианта.
			 *
			 * 1) Если момент времени с точностью до epsilon совпадает с
			 * моментов ввода новой секунды координации, т.е. находится в
			 * пределах 23:59:60+(1-epsilon) - 00:00:00+epsilon, то вывести
			 * целую дату и время 00:00:00, поскольку правильные дата и время
			 * неотличимы от неё с точностью до double.
			 */
			int LSp1 = getLeapSeconds(t2000
							+2*std::numeric_limits<double>::epsilon()*t2000);
			if (LSp1!=LS)
			{
				/** Для вывода целой даты продвинуться вперёд на 0.1 сек.,
				  * чтобы перейти в следующие сутки после введения секунды,
				  * а затем занулить секунды.
				  */
				sec2000ToDateTime(getUTCJ2000()+0.1, Y, M, D, h, m, s);
				s=0;
			}
			else
			{
				/**
				 * В оставшемся случае продвинемся на 1 секунду назад, чтобы
				 * остаться в предыдущих сутках, а затем прибавим эту секунду
				 * к числу секунд, чтобы оно получилось больше или равно 60.
				 */
				sec2000ToDateTime(getUTCJ2000()-1, Y, M, D, h, m, s);
				s+=1.0l;
			}
		}
	}

	/** @brief Получить метку времени по числу секунд от 12:00 1 января 2000
	*
	* Данная процедура принимает число секунд, прошедших с 1 января 2000 г.
	* 12:00 в шкале UTC и возвращает метку времени.
	*
	* Внимание! С помощью числа секунд UTC невозможно закодиро-
	* вать момент времени 23:59:60, который наступает со вводом новой
	* секунды координации.
	*
	* @param utcj2000 Число секунд, прошедших с 12:00 1 января 2000 г
	* @return Метка времени
	*/
	inline static UTCDateTime fromUTCJ2000 (real  utcj2000)
	{
		//TAI = UTC+Секунды координации
		int LS = getLeapSeconds(utcj2000);
		real tai1 = utcj2000+LS;

		//Секунды координации были запрошены в момент времени tai2000-LS.
		//Проверить, не введена ли секунда координации между tai2000-LS и
		//tai2000. Тогда tai1<tai2000.
		if (UTCDateTime::fromTAIJ2000(tai1).getUTCJ2000() < utcj2000)
			return fromTAIJ2000(tai1+1);
		else
			return fromTAIJ2000(tai1);
	}

	/**
	 * @brief Создать метку времени по компонентам даты/времени UTC
	 *
	 * Принимает компоненты даты/времени UTC. Секунды координации задаются
	 * указанием Second >=60.
	 */
	inline static UTCDateTime fromUTCDateTime(int Year, int Month, int Day,
											int Hour, int Minute, double Second)
	{
		real utc2000;
		dateTimeToSec2000(Year, Month, Day, Hour, Minute, Second, utc2000);
		int LS = getLeapSeconds(utc2000);
		real tai2000 = utc2000+LS;
		//Поскольку секунды координации были запрошены по utc2000, то
		//они могли быть ошибочными.
		int LSp = getLeapSeconds(tai2000+1
						+std::numeric_limits<double>::epsilon()*tai2000);
		if (LSp!=LS)
		{
			if (Second<60)
				tai2000+=1.0l;

		}
		return fromTAIJ2000(tai2000);
	}

	/**
	 * @brief fromUTCDateTimeString Преобразование из строки в дату/время
	 * @param str Строковое представление даты и времени в соответствии формату
	 * @return Объект даты и времени, считанный из строки
	 *
	 * Для преобразования используется формат, содержащийся в переменной
	 * DateTimeFormat. Допустимо также использоват обозначение J2000,
	 * которое автоматически преобразуется в 1 января 2000, 12:00 TAI
	 */
	inline static UTCDateTime fromUTCDateTimeString ( const std::string & str )
	{
		int year, month, day, hour, minute;
		real sec;
		strToDate(str,year, month, day, hour, minute, sec, DateTimeFormat);
		return fromUTCDateTime(year,month,day,hour,minute,sec);
	}

	inline std::string getUTCDateTimeString() const
	{
		int Y,M,D,h,m; real s;
		getUTCDateTime(Y,M,D,h,m,s);
		return dateToStr(Y,M,D,h,m,s,DateTimeFormat);
	}


//ШКАЛА GPS

	inline static real GPSJ2000ToTAIJ2000(real gpsj2000)
	{
		return gpsj2000 + 19.0;
	}

	inline static real TAIJ2000ToGPSJ2000(real taij2000)
	{
		return taij2000 - 19.0;
	}

	//! Возвращает число секунд от 12:00 01.01.2000 в шкале GPS
	inline real getGPSJ2000 () const
	{
		return TAIJ2000ToGPSJ2000(getTAIJ2000());
	}

	//! Возвращает дату и время в шкале GPS
	inline real getGPSDateTime(int &year, int &month, int &day, int &hour,
							   int &minute, real &second) const
	{
		real gps2000 = TAIJ2000ToGPSJ2000(getTAIJ2000());
		sec2000ToDateTime(gps2000, year, month, day, hour, minute, second);
	}

	/**
	 * @brief Вычисляет метку времени исходя из числа секунд от
	 * 12:00 01.01.2000 в шкале GPS
	 */
	inline static UTCDateTime fromGPSJ2000(real gps2000)
	{
		return fromTAIJ2000(GPSJ2000ToTAIJ2000(gps2000));
	}

	//! @brief Вычисляет метку времени по компонентам даты/времени GPS
	inline static UTCDateTime fromGPSDateTime(int Year, int Month, int Day,
								int Hour, int Minute, double Second)
	{
		real gps2000;
		dateTimeToSec2000(Year, Month, Day, Hour, Minute, Second, gps2000);
		return fromGPSJ2000(gps2000);
	}

	//! @brief Получить метку из строкового представления даты/времени GPS
	inline static UTCDateTime fromGPSDateTimeString(const std::string &s)
	{
		int year, month, day, hour, minute;
		real sec;
		strToDate(s,year, month, day, hour, minute, sec, DateTimeFormat);
		return fromGPSDateTime(year,month,day,hour,minute,sec);
	}

	/**
	 * @brief Возвращает метку времени, заданную в шкале GPS
	 * @param w Неделя GPS
	 * @param d День GPS
	 * @param f Число секунд в сутках GPS
	 * @return Внутренняя метка времени
	 */
	inline static UTCDateTime fromGPSWeekDayFrac(int w, int d, real f)
	{
		return fromTAIJ2000(-630763181 + 86400*(7*w + d) + f);
	}

	/**
	 * @brief Перевести момент времени из TAIJ2000 в шкалу GPS
	 * @param tai2000 Момент времени, секунды от 12:00 01.01.2000 TAI
	 * @param[out] week Неделя GPS
	 * @param[out] day День GPS
	 * @param[out] frac Число секунд внутри суток GPS
	 */
	inline static void getGPSWeekDayFrac(real tai2000, int &week, int &day,
									real &frac)
	{
		int gpsorigin = -630763181;
		int daysfromorigin = (int)(floor((tai2000 - gpsorigin)/86400.0l));
		day = daysfromorigin % 7;
		week = (daysfromorigin - day)/7;
		frac = tai2000 - 86400 * daysfromorigin - gpsorigin;
	}

	/**
	 * @brief Вычисляет номер недели GPS, день недели и дробную часть дня
	 * @param week Неделя GPS
	 * @param day 0 = воскресенье, 1 = понедельник, ...
	 * @param frac Число секунд внутри суток GPS
	 */
	inline void getGPSWeekDayFrac(int &week, int &day, real &frac) const
	{
		return getGPSWeekDayFrac(getTAIJ2000(),week,day,frac);
	}


//РОССИЙСКИЕ ШКАЛЫ

	inline static real GLN6jan1980ToUTCJ2000 ( real gln6jan1980 )
	{
		const static real utc_6jan1980 = -630763200;
		return gln6jan1980-3*3600+utc_6jan1980;
	}

	inline static UTCDateTime fromGLN6jan1980 (real gln6jan1980)
	{
		return fromUTCJ2000(GLN6jan1980ToUTCJ2000(gln6jan1980));
	}

	//! Вычисляет число секунд от 12:00 01.01.2000 Московского времени
	inline real getMSKJ2000() const
	{
		return getUTCJ2000() + 3*3600;
	}

	/**
	 * @brief Возвращает компоненты московской даты и времени
	 *
	 * В каждый момент времени числа
	 *
	 * msk2000=cal2jd(year_msk,month_msk,day_msk,hour_msk,minute_msk,second_msk)
	 *
	 * и
	 *
	 * utc2000=cal2jd(year_utc,month_utc,day_utc,hour_utc,minute_utc,second_utc)
	 *
	 * удовлетворяют соотношению: msk2000 =utc2000 + 3*3600. Из этого следует
	 * алгоритм нахождения московской даты и времени:
	 *
	 * 1) Получить msk2000 = cal2jd(year,month,day,hour,minute,second)+3*3600
	 * 2) Получить (year_msk,month_msk,...)=jd2cal(msk2000).
	 */
	inline void getMSKDateTime(int & year, int & month, int & day,
							   int & hour, int & minute, real & second) const
	{
		UTCDateTime msk = UTCDateTime::fromUTCJ2000(getTAIJ2000()+3*3600);
		msk.getUTCDateTime(year,month,day,hour,minute,second);
	}

	/**
	 * @brief Создание метки времени исходя из Московской даты/времени
	 *
	 * Принимает компоненты Московской даты/времени
	 */
	static UTCDateTime fromMSKDateTime(int year, int month, int day,
									int hour, int minute, double second)
	{
		real msk2000=UTCDateTime::fromUTCDateTime(year,month,day,hour,minute,
												second).getUTCJ2000();
		return UTCDateTime::fromUTCJ2000(msk2000-3*3600);
	}

	/**
	 * @brief Получить UTC-метку времени по параметрам из оперативной информации
	 * @param tb Число секунд с начала текущих суток ГЛОНАСС
	 * @param Nt Номер суток ГЛОНАСС в течение четырехлетнего итервала
	 * @param N4 Номер четырехлетнего интервала (1996-2000 - 1-й интервал)
	 * @return UTC-метка времени
	 *
	 * Если метка времени задана некорректно, будет сгенерировано исключение
	 * WrongGLONASSNavDataDateTime.
	 */
	inline static UTCDateTime fromGLONASSNavData (int tb, int Nt, int N4)
	{
		//Начало четырехлетнего интервала в шкале TAI
		real fouryearint =
			UTCDateTime::fromUTCDateTime(1996+(N4-1)*4,1,1,0,0,0).getUTCJ2000();
		real utcj2000 = fouryearint + (Nt-1)*86400+tb-3*3600;
		return UTCDateTime::fromUTCJ2000(utcj2000);

//		//Число секунд от 00:00:00 1 янв. 1996 до 12:00:00 1 янв. 2000
//		//(неважно, в UTC или в ШВ GLONASS)
//		real j2000_1996 =
//				UTCDateTime::fromUTCDateTime(1996,1,1,0,0,0).getUTCJ2000();
//		//Число секунд от 00:00:00 1 янв. 1996 (ШВ ГЛОНАСС)
//		real glo1996 = ((N4-1)*1461 + Nt)*86400 + tb;
//		real utcj2000 = j2000_1996 + glo1996 - 3*3600;

//		return UTCDateTime::fromUTCJ2000(utcj2000);
	}



	//! Возвращает текущую метку времени
	static UTCDateTime now();

};

inline std::ostream & operator<< (std::ostream & stream, const UTCDateTime & dt)
{
	stream<<dt.getUTCDateTimeString();
	return stream;
}

}

#endif

#include <Settings.h>

namespace libgnss
{


SettingsNotDefinedException::SettingsNotDefinedException
(const string &group, const string &module, const string &key)
	: StrException("SettingsNotDefinedException",
				   "Настройка [Группа="+group+",Модуль="
		+module+",Ключ="+key+"] не была определена.")
{

}




DefaultValueForbiddenException:: DefaultValueForbiddenException
(const string & group, const string & module, const string & key )
		: StrException("DefaultValueForbiddenException",
			  "Настройка [Группа="+group+",Модуль="
			+module+",Ключ="+key+"] не имеет "
				   "значения по умолчанию.")
{

}



Settings:: Settings (DBTableCollection * base)
	: DBTable (
		  Columns()
		  <<Column(Variant::TYPE_STRING, "group")
		  <<Column(Variant::TYPE_STRING, "module")
		  <<Column(Variant::TYPE_STRING, "key"),
		  Columns()
		  <<Column(Variant::TYPE_STRING, "value")
		  )
{
	base->addTable("settings", this);
}

DBTable * Settings::Enumerator::enumerator()
{
	static DBTable stor (Columns()
				 <<Column(Variant::TYPE_STRING, "group")
				 <<Column(Variant::TYPE_STRING, "module")
				 <<Column(Variant::TYPE_STRING, "key"),
					  Columns()
				 <<Column(Variant::TYPE_STRING, "type")
				 <<Column(Variant::TYPE_STRING, "hint")
				 <<Column(Variant::TYPE_STRING, "default"));
	return &stor;
}

Settings::Enumerator::Enumerator ( string group, string module, string key,
		 Variant::Type type, string hint, Variant def)
{
	enumerator()->insertRow(Tuple()<<group<<module<<key,
					Tuple()<<type->getName()<<hint<<def);
	Module = module;
	Group = group;
	Key = key;
}

Variant Settings::Enumerator::getDefaultValue(const string &group,
					const string &module, const string &key)
{
	if (enumerator == 0)
		throw SettingsNotDefinedException(group,module,key);
	DBConstIterator it0 = enumerator()->find(Tuple()<<group<<module<<key);
	if (it0 == enumerator()->end())
		throw SettingsNotDefinedException(group,module,key);
	Variant::Type stype = Enumerator::getSettingType(group,module,key);
	Variant result = stype->fromString(it0[2].toString());
	if (result.getType() == Variant::TYPE_NULL)
		throw DefaultValueForbiddenException(group,module,key);
	return result;
}

Settings::Enumerator::~Enumerator()
{
//	if (enumerator == 0)
//		return;
//	enumerator->deleteRows(Tuple()<<Group<<Module<<Key);
//	if (enumerator->count() == 0)
//	{
//		delete enumerator;
//		enumerator = 0;
//	}
}

Variant::Type Settings::Enumerator::getSettingType(const string &group,
										const string &module, const string &key)
{
	return CType::getCType(enumerator()->find(
							   Tuple()<<group<<module<<key)[0].toString());
}

Variant Settings::getSettings(const string &group, const string &module,
				  const string &key) const
{
	//Проверить наличие настройки в таблице
	DBConstIterator it0 = find(Tuple()<<group<<module<<key);
	if (it0 != const_end())
	{
		Variant::Type stype = Enumerator::getSettingType(group,module,key);
		return stype->fromString(it0[0].toString());
	}
	//Иначе вернуть значение по умолчанию.
	else
		return Enumerator::getDefaultValue(group,module,key);

}

}

//! @file

/** @namespace libgnss
 *
 * Пространство имен, содержащее все классы и функции библиотек
 * libgnsscore, libgnss, libgnssutil.
 * 
 */


/** @defgroup core Базовые компоненты библиотек GNSS
 *  @defgroup script ECMAScript-обертка библиотек GNSS
 *  @defgroup approximation Модуль аппроксимации по таблицам
 *  @defgroup coordsys Модуль работы с системами координат
 *  @defgroup integrate Модуль расчета траектории НКА
 *  @defgroup leastsq Модуль метода наименьших квадратов
 *  @defgroup numeric Численные методы
 *  @defgroup obsdata Модуль для работы с измерительными данными
 *  @defgroup adjparams Модуль уточняемых параметров
 *  @defgroup trajectory Модуль обработки эфемерид НКА
 *  @defgroup parsers Модуль чтения данных в разлиных форматах
 *  @defgroup except Исключения
 */

#include <string>
#include <sstream>
#include <map>
#include <fstream>
#include <BuiltIn.h>
#ifdef WithQT
#include <QFile>
#include <QDebug>
#endif

using namespace std;

//! @file

#include <DBTableCollection.h>

namespace libgnss
{

void DBTableCollection::dump(ostream& output)
{
	for (map < string, DBTable * >::iterator it = tables.begin();
		 it!=tables.end(); ++it)
		 dumpTable(it->first, output);
}

bool DBTableCollection::readLine(string line)
{
	//Отрезать коментарий
	int commentpos = line.find_first_of('#');
	line = trim(line.substr(0,commentpos));
	if (line.length() == 0)
		return false;

	vector < string > cols = split(line, '\t');

	//Первый столбец показывает в какую таблицу предназначены данные
	string strname = cols[0];

	//Найти соответствующую таблицу
	map<string, DBTable * >::iterator tbl = tables.find(strname);

	//Если таблицы не существует, продолжить
	if (tbl == tables.end())
		return false;

	Tuple keyColumns;
	Tuple valueColumns;

	int keycolscount = tbl->second->getKeyColumns().size();

	//Прочитать из входного потока значения ключей
	for (unsigned int i=0;i<keycolscount;++i)
	{
		try
		{
			keyColumns<<Variant::fromString
				 (tbl->second->getKeyColumns()[i].first, cols[i+1]);
		}
		catch (std::ios_base::failure f)
		{
			throw WrongTableFormatOnInput(strname,cols[i+1],
									tbl->second->getKeyColumns()[i].first,
									tbl->second->getKeyColumns()[i].second);
		}
	}

	//Прочитать из входного потока значения полей данных
	for (unsigned int i=0; i<tbl->second->getValueColumns().size();
		 ++i)
	{
		try
		{
			valueColumns<<Variant::fromString
				(tbl->second->getValueColumns()[i].first,
				 cols[keycolscount + i + 1]);
		}
		catch (const std::ios_base::failure & f)
		{
			throw WrongTableFormatOnInput(strname,cols[keycolscount+i+1],
								tbl->second->getValueColumns()[i].first,
								tbl->second->getValueColumns()[i].second);
		}
	}

	//Вставить новую строку в таблицу
	tbl->second->insertRow(keyColumns, valueColumns);

	return true;
}

void DBTableCollection::readFromStream(istream &stream, ostream & next )
{
	while (true)
	{
		//Извлечь строку
		string line;
		if (stream.eof())
			break;
		try
		{
			getline(stream, line);
		}
		catch (...)
		{
			return;
		}

		//Если строка пустая, это означает конец ввода
		if (line.length() == 0)
			break;

		if(readLine(line)==false)
			next<<line;
	}
}

string DBTableCollection::getAcceptableFormat()
{
	stringstream accform;
	accform<<"Каждая строка имеет структуру: "<<endl<<endl
		<<"<tablename> <columns>"<<endl<<endl
		<<"где <tablename> - имя таблицы,"<<endl
		<<"<columns> - колонки таблицы."<<endl<<endl
		<<"Доступны для заполнения следующие таблицы:"<<endl;

	for (map <string, DBTable*>::iterator it0=tables.begin(); it0!=tables.end();
	     ++it0)
	{
		accform<<endl;
		accform<<"Название: '"<<it0->first<<"'"<<endl<<"Поля:"<<endl;
		DBTable * t = it0->second;

		//Перечислить ключевые поля
		for (unsigned int i=0; i<t->getKeyColumns().size(); ++i)
		{
			accform<<"(Kлючевое поле) "
			<<t->getKeyColumns()[i].second<<" "
			<<Variant::getTypeName(t->getKeyColumns()[i].first)
			<<endl;
		}

		//Перечислить поля данных
		for (unsigned int i=0; i<t->getValueColumns().size(); ++i)
		{
			accform<<"(Поле данных)   "
			<<t->getValueColumns()[i].second<<" "
			<<Variant::getTypeName(t->getValueColumns()[i].first)
			<<endl;
		}

	}

	return accform.str();
}

DBTableCollection::DBTableCollection()
	: QObject()
{
	//cout<<"Коллекция создана."<<endl;
}

DBTableCollection::~DBTableCollection()
{
	//cout<<"Коллекция таблиц уничтожена"<<endl;
}

DBTable * DBTableCollection::getTable(const string &name) const
{
	map < string, DBTable * >::const_iterator it0 = tables.find(name);
	if (it0 == tables.end())
		throw TableNotFoundException(name);
	return it0->second;
}

DBTable * DBTableCollection::getTableIfExists(const string &name) const
{
	map < string, DBTable * >::const_iterator it0 = tables.find(name);
	if (it0 == tables.end())
		return 0;
	return it0->second;
}

void DBTableCollection::dumpTable (const string & name, ostream & output)
{
	DBTable * tbl = getTable(name);
	tbl->dump(output,name);
}

#ifdef WithQT
QVariantList DBTableCollection::getTablesList()
{
	QVariantList result;
	for (map < string, DBTable * > :: iterator it0 = tables.begin();
			it0 != tables.end(); ++it0)
		result.push_back(QVariant(QString::fromStdString(it0->first)));
	return result;
}


QObject *DBTableCollection::table(const QString &name)
{
	QObject * obj = tables[name.toStdString()];
	return obj;
}

void DBTableCollection::deleteTable(const QString &name)
{
	deleteTable(name.toStdString());
}


void DBTableCollection::readFromFile(const QString &filename)
{
	ostringstream outs;
	ifstream readfile;
	readfile.exceptions(ifstream::failbit);
	readfile.open(filename.toStdString().c_str());
	if (readfile.is_open())
	{
		readFromStream(readfile,outs);
		readfile.close();
	}
	else
		throw FileNotFoundException(filename.toStdString());
}

QScriptValue DBTableCollection::readFromString(const QString& data)
{
	istringstream ss(data.toStdString());
	ostringstream empty;
	readFromStream(ss,empty);
	QString remaining = QString::fromStdString(empty.str());
	return QScriptValue(remaining);
}

QScriptValue createCollection (QScriptContext*ctx, QScriptEngine * eng)
{
	DBTableCollection * col = new DBTableCollection;
	col->assignScriptEngine(eng);
	return eng->newQObject(col,QScriptEngine::ScriptOwnership);
}

BuiltIn createcol("newCollection",0,createCollection);
#else

void DBTableCollection::readFromFile(const string &filename)
{
	ostringstream outs;
	ifstream readfile;
	readfile.exceptions(ifstream::failbit);
	readfile.open(filename.c_str());
	if (readfile.is_open())
	{
		readFromStream(readfile,outs);
		readfile.close();
	}
	else
		throw FileNotFoundException(filename);
}

#endif

}

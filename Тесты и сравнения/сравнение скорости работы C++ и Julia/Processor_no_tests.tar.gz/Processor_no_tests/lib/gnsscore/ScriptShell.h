#ifndef SCRIPTSHELL_H_
#define SCRIPTSHELL_H_

//! @file

/** @file ScriptShell.h
 *
 * @brief Модуль скриптования
 *
 * Модуль добавляет в комплекс возможность написания сценариев на языке
 * QtScript (сборка комплекса с возможностью скриптования требует наличия
 * Qt >= 4.4).
 *
 * Сборка комплекса с возможностью скриптования требует указания опции
 *
 *\code
  #define SCRIPTABLE
  \endcode
 *
 * При этом у скриптуемых классов будут активированы новые методы, которые будут
 * доступны из оболочки языка Qt Script.
 *
 * Можно скриптовать отдельные классы комплекса. В то же время, класс
 * @ref ScriptShell позвоялет создать Qt Script-оболочку, в которой несколько
 * коллекций таблиц будут доступны под разными Qt Script-именами. Для
 * использования последнего подхода нужно создать объект класса @ref ScriptShell
 * и добавить в него несколько коллекций, указывая Qt Script-имя.
 */

#include <gnssconfig.h>

#ifdef WithQT
#include <QObject>
#include <QScriptable>
#include <QScriptEngine>
#include <QMap>
#include <QVariantList>

#include <DBTableCollection.h>
#include <DBTable.h>

#ifdef UseMPI

#include <mpi.h>

#endif

namespace libgnss
{

/**
 * @brief QtScript-оболочка для работы с несколькими коллекциями таблиц
 *
 * Оболочка создаёт ядро языка QtScript, позволяя добавлять к нему коллекции
 * таблиц. Кроме того, оболочка добавляет в QtScript некоторые стандартные
 * функции, такие как вычисление эфемерид планет, угла СОЗ, перевод шкал времени
 * и др.
 */
class ScriptShell
{
private:
	QMap < QString, DBTableCollection * > collections;
public:
	QScriptEngine * engine;
	ScriptShell ();
	~ScriptShell();
	void addCollection (const QString & name, DBTableCollection * collection);
	void removeCollection ( const QString & name );
	QScriptValue evaluate ( const QString & expression );
};

#ifdef UseMPI

/**
 * @brief QtScript-обёртка для MPI коммуникаторов
 */
class QMPICommunicator : public QObject
{
	Q_OBJECT
	friend QScriptValue getMPICW(QScriptContext*ctx, QScriptEngine * eng);
private:
	MPI_Comm mpicomm;
	bool iscommworld;
	QScriptEngine * eng;
	int commsize;
	int commrank;
public:
	QMPICommunicator(const MPI_Comm & mpicomm,
									  QScriptEngine * engine, bool iscw);

	~QMPICommunicator ();

	inline MPI_Comm currentCommunicator() const
	{
		return mpicomm;
	}

public slots:

	int getCommSize() const;
	int getCommRank() const;

	/**
	 * @brief Разбивает коммуникатор
	 * @param colour Цвет
	 * @param key Ключ
	 * @return Объект нового коммуникатора, в который попал данный процесс
	 */
	QScriptValue commSplit(int colour, int key) const;

	/**
	 * @brief Возвращает номера заданий, которые нужно делать в данном потоке
	 * @param first Номер первого задания
	 * @param last Номер последнего задания
	 * @return Пара: номер первого моего задания, номер последнего моего задания
	 *
	 * Предполагается, что существует набор независимых заданий, пронумерованных
	 * от first до last; длительность выполнения всех заданий одинакова.
	 * Необходимо разбить эти задания между MPI-процессами поровну.
	 */
	QVariantList distributeTasks(int first, int last) const;
};

#endif
}
#endif

#endif

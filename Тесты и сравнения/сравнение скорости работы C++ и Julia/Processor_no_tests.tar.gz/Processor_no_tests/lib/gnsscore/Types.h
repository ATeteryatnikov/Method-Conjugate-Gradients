#ifndef TYPES_H_
#define TYPES_H_

#include <gnssconfig.h>

namespace libgnss
{

//! @file

//Определение типов точности внутри Обработчика


//typedef real real;

//typedef real real;

//typedef real real;

typedef real leastsquaresprec;

}

#endif

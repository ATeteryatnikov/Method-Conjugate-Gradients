#ifndef INDEXEDTABLE_H_
#define INDEXEDTABLE_H_

#include <map>
#include <vector>
#include <string>
#include <sstream>

#include <gnssconfig.h>

#ifdef WithQT
#include <QObject>
#include <QString>
#include <QVariantList>
#include <QScriptValue>
#include <QScriptEngine>
#endif
//! @file
#include <DBVariant.h>

#ifdef UseMPI
#include <mpi.h>
#endif



namespace libgnss
{

//----- Возможные ошибки работы с классов таблиц с ключами --------------//

/**
 * @brief Исключение добавления в таблицу записи с повторяющимся значением ключа
 *
 * @ingroup except
 */
class DuplicateKeyException : public StrException
{
private:
	Tuple kv;
public:
	inline ~DuplicateKeyException() throw () {}
	DuplicateKeyException (const Tuple & keyValues);
	inline const Tuple & keyValues() const
	{
		return kv;
	}
};

/** @brief Исключение нарушения уникальности в одном из индексов таблицы
 *
 * @ingroup except
 */
class IndexUniquenessException : public StrException
{
public:
	inline IndexUniquenessException ( const Tuple & keyvalues,
			const Tuple & values, const string & idxname);
};

/** @brief Исключение поиска в таблице строки по несуществующему значению ключа
 *
 * @ingroup except
 */
class KeyNotFoundException : public StrException
{
public:
	KeyNotFoundException (const Tuple & keyValues);
};

/** @brief Исключение выхода за границу массива при просмотре таблицы итератором
 *
 * @ingroup except
 */
class OutOfBoundException : public StrException
{
public:
	OutOfBoundException ();
};

/**
 * @brief Исключение разыменования итератора, указывающего на конец таблицы
 *
 * @ingroup except
 */
class EndIteratorException : public StrException
{
public:
	EndIteratorException();
};

/**
 * @brief Исключение возникает при создании индекса с уже существующим именем
 *
 * @ingroup except
 */
class IndexAlreadyExistsException : public StrException
{
public:
	IndexAlreadyExistsException(string indexname);
};

/** @brief Исключение возникает при попытке прочитать поле данных с номером,
 * превышающем число полей данных.
 *
 * @ingroup except
 */
class NoSuchFieldWithNumber : public StrException
{
public:
	NoSuchFieldWithNumber ( int number );
};

/**
 * @brief Исключение возникает при указании несуществующего имени поля данных
 *
 * @ingroup except
 */
class NoSuchFieldWithName : public StrException
{
public:
	NoSuchFieldWithName ( const std::string & name);
};

/**
 * @brief Исключение возникает при невозможности синхронизировать таблицы
 *
 * @ingroup except
 *
 */
class SynchronizationError : public StrException
{
public:
	SynchronizationError (const std::string & what);
};

/**
 * @brief Исключение возникает при копировании из таблицы другого формата
 *
 * @ingroup except
 */
class WrongTableFormatForCopy : public StrException
{
public:
	WrongTableFormatForCopy();
};

/**
 * @brief Исключение: указано значение не всех ключевых полей
 *
 * @ingroup except
 */
class TooFewKeyFieldsException : public StrException
{
public:
	TooFewKeyFieldsException();
};

/**
 * @brief Исключение: указано значение не всех полей данных
 *
 * @ingroup except
 */
class TooFewDataFieldsException : public StrException
{
public:
	TooFewDataFieldsException();
};

#ifdef WithQT
class DBIteratorQS;
#endif

/**
 * @brief Класс, реализующий таблицу с одним индексом
 *
 * @ingroup core
 *
 * Данный класс используется для хранения и изменения таблицы с индексом.
 * При создании объекта необходимо указать структуру индекса и хранимых данных.
 * Например:
 *
 * \code
	DBMap myTable ( Columns()
		<<Column(TYPE_INT, "keyColumn0")
		<<Column(TYPE_INT, "keyColumn1")
		<<Column(TYPE_DOUBLE, "keyColumn2"),
		Columns()
		<<Column(TYPE_DOUBLE, "valueColumn0")
		<<Column(TYPE_DOUBLE, "valueColumn1")
		<<Column(TYPE_STRING, "valueColumn2") );
   \endcode
 *
 * Для обращения к элементам такой структуры используется оператор [] :
 * \code
	myTable[DBTuple()<<35<<3<<0.35]["valueColumn1"] = 1.84;
   \endcode
 * или с предварительным запросом индекса столбца:
 * \code
unsigned int valueColumn1Index = myTable.getValueColumnIndex("valueColumn1");
myTable[DBTuple()<<35<<3<<0.35][valueColumn1Index] = 1.84;
   \endcode
 *
 * последний вариант предпочтительнее при многократном обращении к данным.
 * Оператор [] можно использовать и для добавления новых элементов.
 *
 * Для обращения к данным без добавления нового элемента, если его не
 * существует, используется метод find().
 *
 * Для того, чтобы принудить таблицу только читать значения по ключу, но
 * запретить создание новой строки, как это может произойти при использовании
 * оператора [], можно использовать метод DBMap::read().
 *
 * Для прохождения по всем строкам доступны методы begin(), end(),
 * аналогичные соответствующим функциям любого stl-контейнера.
 *
 **/
class DBMap
#ifdef WithQT
		: public QObject
#endif
{
#ifdef WithQT
	Q_OBJECT
#endif
public:

	/** @brief Итератор по индексированной таблице
	 *
	 * @ingroup base
	  *
	  * Итератор используется в том случае, когда требуется получить
	  * последовательный доступ к данным в таблице. При этом итератор
	  * позволяет перемещаться к строкам с соседними значениями ключевых
	  * элементов, фиксируя при этом необходимые ключевые поля, а другие
	  * ключевые поля игнорируя. Для этого используются методы
	  * DBMap::DBConstIterator::subdec() и
	  * DBMap::DBConstIterator::subinc() . Для чтения значений полей, на
	  * которые указывает итератор, используется оператор
	  * DBMap::DBConstIterator::operator[]() .
	  *
	  */
	class DBConstIterator
	{
	friend class DBMap;
	protected:
		const DBMap * parent;
		vector< map < Variant, void* >:: iterator > tableIterator;
		bool isend;
		bool isrend;
	public:

		//! Возвращает true, если итератор указывает за конец области
		bool isEnd() const
		{
			return isend;
		}

		//! Возвращает true, если итератор указывает до начала области
		bool isReverseEnd() const
		{
			return isrend;
		}

		DBConstIterator()
		{
			isend = true;
			isrend = true;
			parent = 0;
		}

		/** @brief Вернуть значение поля данных
		  *
		  * Вернуть значение поля данных, индекс которого указан в
		  * аргументах. Первый столбец данных имеет индекс 0.
		  *
		  * Если указать номер поля, превышающий число полей данных, будет
		  * сгенерировано исключение @ref NoSuchFieldWithNumber .
		  *
		  * @param valueColumnIndex Индекс столбца данных
		  */
		const Variant & operator[]
			( const unsigned int & valueColumnIndex ) const;

		/** @brief Вернуть значение поля данных
		  *
		  * Вернуть значение поля данных, имя которого указан в
		  * аргументах.
		  *
		  * Если поля данных с заданным именем не существует, будет
		  * сгенерировано исключение @ref NoSuchFieldWithName .
		  *
		  * @param valueColumnName Заголовок столбца данных
		  */
		const Variant & operator[]
			( const std::string & valueColumnName ) const;

		/** @brief Вернуть значение ключевого поля
		  *
		  * Вернуть значение ключевого поля, индекс которого указан в
		  * аргументах. Первый ключевой столбец имеет индекс 0.
		  *
		  * Если будет указан номер поля, превышающий число полей, будет
		  * сгенерировано исключение @ref NoSuchFieldWithNumber .
		  *
		  * @param keyColumnIndex Индекс ключевого столбца
		  */
		const Variant & keyColumnValue
			( const unsigned int & keyColumnIndex ) const;

		/** @brief Вернуть значение ключевого поля
		  *
		  * Вернуть значение ключевого поля, имя которого указан в
		  * аргументах.
		  *
		  * Если поля с заданным именем не существует, будет сгенерировано
		  * исключение @ref NoSuchFieldWithName .
		  *
		  * @param keyColumnName Имя ключевого столбца
		  */
		const Variant & keyColumnValue
			( const std::string & keyColumnName ) const;

		/** @brief Сравнить два итератора
		  *
		  * Сравнивает данный итератор с другим.
		  * Возвращает true, если итераторы взяты из одной таблицы, и
		  * если  они совпадают по всем ключевым полям. В противном
		  * случае,  функция возвращает false.
		  *
		  * @param second Итератор, который сравнивается с данным
		  */
		bool operator==(const DBMap::DBConstIterator & second ) const;

		/** @brief Сравнить два итератора
		  *
		  * Сравнивает данный итератор с другим.
		  * Возвращает true, если итераторы взяты из одной таблицы, и
		  * если  они совпадают по всем ключевым полям. В противном
		  * случае,  функция возвращает false.
		  *
		  * @param second Итератор, который сравнивается с данным
		  */
		inline bool operator!=(const DBMap::DBConstIterator & second )
		const
		{
			return !(operator==(second));
		}

		/** @brief Перейти к следующему значению ключа
		  *
		  * Сохранить значения ключевых полей 0,1, ..., colnumber-1;
		  * выбрать следующее по порядку значение ключевого поля
		  * colnumber;
		  * выбрать наименьшие по порядку значения ключевых полей
		  * colnumber+1, ...
		  *
		  * Если значение следующего поля colnumber выбрать невозможно,
		  * то выполняется inc (colnumber-1). Если невозможно перейти к
		  * следующему значению ни по одному из ключевых полей, то
		  * итератор устанавливается в состояние end().
		  *
		  * Если итератор уже установлен в end(), то будет сгенерировано
		  * исключение @ref OutOfBoundException .
		  *
		  * @param colnumber Номер наращиваемого столбца
		  */
		DBConstIterator & inc
			(const int colnumber, const int incriment = 1);

		/** @brief Перейти к предыдущему значению ключа
		  *
		  * Сохранить значения ключевых полей 0,1, ..., colnumber-1;
		  * выбрать предыдущее по порядку значение ключевого поля
		  * colnumber;
		  * выбрать наибольшее по порядку значения ключевых полей
		  * colnumber+1, ...
		  *
		  * Если значение следующего поля colnumber выбрать невозможно,
		  * то выполняется dec (colnumber-1). Если невозможно перейти к
		  * следующему значению ни по одному из ключевых полей, то
		  * итератор вызывается ошибка. Для того, чтобы этого не
		  * допустить, нужно перед переходом проверять == begin().
		  *
		  * Если итератор указывает за конец таблицы (isEnd()), то в результате
		  * выполнения этого метода он будет указывать на самый последний
		  * элемент таблицы.
		  *
		  * Если итератор уже установлен в begin(), то будет сгенерировано
		  * исключение @ref OutOfBoundException .
		  *
		  * @param colnumber Номер уменьшаемого столбца
		  */
		DBConstIterator & dec
			(const int colnumber, const int decriment = 1);


		/** @brief Перейти к следующему значению ключа
		  *
		  * Сохранить значения полей 0,1,...,colnumber-1;
		  * Установить следующее значение ключевого поля номер colnumber
		  * Поля colnumber+1, ... установить в begin().
		  *
		  * Если достигнуто наибольшее значение ключевого поля colnumber
		  * то выполнить subinc(colnumber-1), если colnumber-1>
		  * fixcolnumber. В противном случае, установить итератор в
		  * состояние end(). Отличается от метода inc тем, что
		  * не позволяет увеличивать итератор по колонкам 0,1,...
		  * fixcolnumber.
		  *
		  * Если итератор уже установлен в end(), то будет сгенерировано
		  * исключение @ref OutOfBoundException .
		  *
		  * @param colnumber Номер увеличиваемого столбца
		  * @param fixcolnumber Номер фиксируемого столбца
		  * @param incriment Число шагов наращивания столбца
		  *
		  */
		DBConstIterator & subinc (const int colnumber,
					  const int fixcolnumber,
					  const int incriment = 1);

		/** @brief Перейти к предыдущему значению ключа
		  *
		  * Сохранить значения полей 0,1,...,colnumber-1;
		  * Установить предыдущее значение ключевого поля colnumber
		  * Поля colnumber+1, ... установить в максимальный элемент.
		  *
		  * Если достигнуто наименьшее значение ключевого поля colnumber
		  * то выполнить subdec(colnumber-1), если colnumber-1>
		  * fixcolnumber. В противном случае, cгенерируется ошибка.
		  * Отличается от метода dec тем, что не позволяет уменьшать
		  * итератор по колонкам 0,1,... fixcolnumber.
		  *
		  * Если итератор указывает за конец таблицы (isEnd()), то в результате
		  * выполнения этого метода он будет указывать на самый последний
		  * элемент таблицы.
		  *
		  * Если дальнейшее продвижение к меньшему значению неизбежно должно
		  * привести к изменению ключевого поля номер fixcolnumber, то будет
		  * сгенерировано исключение @ref OutOfBoundException .
		  *
		  * @param colnumber Номер увеличиваемого столбца
		  * @param fixcolnumber Номер фиксируемого столбца
		  * @param decriment Число шагов наращивания столбца
		  *
		  */
		DBConstIterator & subdec (const int colnumber,
					  const int fixcolnumber,
					  const int decriment = 1);

		//! Префиксный оператор инкримента с использованием @ref inc().
		inline DBConstIterator & operator++()
		{
			unsigned int s = parent->keyColumns.size() - 1;
			return inc(s);
		}
		
		//! Префиксный оператор декремента с использованием @ref dec()
		inline DBConstIterator & operator--()
		{
			unsigned int s = parent->keyColumns.size() - 1;
			return dec(s);
		}
	

		//! Постфиксный оператор инкримента с использованием @ref inc().
		inline DBConstIterator operator++(int)
		{
			unsigned int s = parent->keyColumns.size()-1;
			DBConstIterator thisiterator (*this);
			inc (s);
			return thisiterator;
		}
		
		//! Постфиксный оператор декремента с использованием @ref dec()
		inline DBConstIterator operator--(int)
		{
			unsigned int s = parent->keyColumns.size()-1;
			DBConstIterator thisiterator (*this);
			dec (s);
			return thisiterator;
		}

		/**
		 * @brief Операция разыменования итератора
		 *
		 * Если применяется к итератору в состоянии end(), будет сгенерировано
		 * исключение @ref EndIteratorException .
		 *
		 * @return Ссылка на строку данных.
		 */
		inline const Tuple & operator* () const
		{
			if (isend || isrend)
				throw EndIteratorException();

			return *((Tuple *)
			(tableIterator[tableIterator.size()-1]->second));
		}

		/**
		 * @brief Возвращает массив значений ключевых полей
		 * @param n Число требуемых ключевых полей
		 *
		 * Если итератор находится в состоянии end(), будет сгенерировано
		 * исключение @ref EndIteratorException .
		 *
		 * Если n больше числа ключевых полей, будет сгенерировано исключение
		 * @ref NoSuchFieldWithNumber .
		 *
		 * @return Вектор значений ключевых полей от 0 до n-1.
		 */
		inline Tuple subkey (unsigned int n) const
		{
			if (isend || isrend)
				throw EndIteratorException();;
			if (n>parent->keyColumns.size())
				throw NoSuchFieldWithNumber(n-1);
			Tuple result;
			for (unsigned int i=0; i<n; i++)
				result.push_back(keyColumnValue(i));
			return result;
		}

		/**
		 * @brief Возвращает массив значений ключевых полей
		 *
		 * Если итератор находится в состоянии end(), будет сгенерировано
		 * исключение @ref EndIteratorException .
		 *
		 * @return Массив значений ключевых полей
		 */
		inline Tuple subkey() const
		{
			return subkey(parent->getKeyColumns().size());
		}

		inline const Tuple & values ()
		{
			if (isend || isrend)
				throw EndIteratorException();
			return *((Tuple*)(tableIterator[
					    tableIterator.size()-1]->second));
		}

	};

	/** @brief Итератор по индексированной таблице
	 *
	 * @ingroup core
	  *
	  * Отличается от класса DBConstIterator тем, что допускает
	  * доступ к колонкам на запись.
	  */
	class DBIterator : public DBConstIterator
	{
	friend class DBMap;

	public:
		DBIterator()
			: DBConstIterator()
		{
		}

		DBIterator (const DBConstIterator & it)
			: DBConstIterator (it)
		{

		}

		inline void updateCell (int colnumber, const Variant & newvalue)
		{
			((DBMap*)parent)->updateCell(subkey(),colnumber,newvalue);
		}

		/**
		 * @brief Удаляет текущую строку таблицы и переходит к следующей строке
		 *
		 * Аргументы метода полностью соответствуют аргументам метода subinc().
		 *
		 * @param colidx Значение по какому столбцу увеличить
		 * @param fixidx Значение по какому столбцу фиксировать
		 * @param inc Величина инкримента по выбранной колонке
		 */
		void deleteRow(int colidx = -1, int fixidx = -1, int inc = 1);
	};

private:
	void * tableRoot;

	/**
	 * @brief Удаление поддерева в таблице
	 *
	 * @param node Вершина удаляемого поддерева
	 * @param level Расстояние удаляемого поддерева от вершины
	 */
	void cleanNode (void* node, unsigned int level);
	int rowsCount;
#ifdef WithQT
	DBIteratorQS * wrapIterator (const DBConstIterator & it) const;

public:

	void setEngine(QScriptEngine * eng);

protected:
	QScriptEngine * engine;
#endif

protected:
	Columns keyColumns;
	Columns valueColumns;

public:
	
	/** @brief Возвращает читаемое строковое представление n-ки
	 * 
	 * Переводит две n-ки, ключ и значение, в строковое представление вида
	 * {Поле=Значение}
	 */
	string tuplePrettyPrint(const Tuple & k, const Tuple & v) const;
	
	/** @brief Основной конструктор таблицы
	  *
	  * Конструируется таблица с заданными полями ключа и заданными полями
	  * данных. Поля ключа и данных задаются однотипно, например, так:
	  \code
Columns()<<Column(TYPE_INT, "keyColumn0")
	 <<Column(TYPE_INT, "keyColumn1")
	 <<Column(TYPE_DOUBLE, "keyColumn2"),
	  \endcode
	  *
	  * @param key Набор полей ключа
	  * @param value Набор полей данных
	  */
	DBMap ( const Columns & key, const Columns & value );

	//! Копирующий конструктор
	DBMap ( const DBMap & another );

	/**
	 * @brief Копирует выбранные строки из другой таблицы
	 * @param itbegin Итератор, с которого нужно начать копирование
	 * @param itend Итератор, указывающий на конец таблицы
	 * @param colidx Инкриминируемый столбец
	 * @param fixidx Фиксируемый столбец
	 * @param inc Величина инкримента
	 *
	 * Данный метод копирует данные из другой таблицы, начиная с итератора
	 * itbegin и заканчивая itend (не включая). Для пробегания диапазона
	 * используется метод subinc, которому передаются параметры colidx, fixidx,
	 * inc.
	 *
	 * Если есть совпадающие ключи, ни одной записи скопировано не будет.
	 */
	void copyFrom(const DBMap::DBConstIterator & itbegin,
				  const DBMap::DBConstIterator & itend,
				  int colidx=-1, int fixidx=-1, int inc=1);

	//! Удаление таблицы из памяти
	~DBMap ();

	/** @brief Оператор чтения данных по значениям всех элементов ключа
	  *
	  * Возвращает константную ссылку на вектор данных. Обращение к
	  * отдельному полю данных можно затем осуществить с помощью обычного
	  * оператора [] контейнера vector.
	  *
	  * Если указано значение не всех ключевых полей, будет сгенерировано
	  * исключение.
	  *
	  * Если строки с указанными ключевыми значениями не существует, будет
	  * сгенерировано исключение @ref KeyNotFoundException .
	  *
	  * Ввод значений ключевых полей обеспечивается классов DBTuple,
	  * например
   \code
   (*this)[DBTuple()<<string("str_value")<<11.24564<<1024]
   \endcode
	  *
	  * @param keyValue Набор значений ключевых полей
	  *
	  */
	const Tuple & operator[]( const Tuple & keyValue ) const;

	/**
	 * @brief Оператор чтения по значению ключа, состоящего из одного элемента
	 * @param keyvalue Значение единственного ключевого поля
	 * @return Ссылка на вектор данных
	 */
	inline const Tuple & operator[](const Variant & keyvalue) const
	{
		return operator[](Tuple()<<keyvalue);
	}

	/** @brief Метод чтения из таблицы
	  *
	  * В то время, как оператор [] может производить запись в таблицу,
	  * данный метод позволяет производить только чтение, и в случае, если
	  * данные по ключу не найдены, будет сгенерировано исключение.
	  *
	  * Используется константный оператор [].
	  *
	  * @param keyValue Набор значений ключевых полей
	  */
	inline const Tuple & read ( const Tuple & keyValue ) const
	{
		return (* ((const DBMap*)(this)))[keyValue];
	}

	inline const Tuple & read ( const Variant & keyvalue) const
	{
		return read(Tuple()<<keyvalue);
	}

	//! Константный итератор первой строки таблицы
	DBConstIterator const_begin() const;

	//! Константный итератор, указывающий в конец таблицы
	DBConstIterator const_end() const;

	//! Итератор первой строки таблицы
	DBIterator begin();

	//! Итератор конца таблицы
	DBIterator end();

	/** @brief Поиск строки в таблице с заданным значением ключа
	  *
	  * Осуществляет поиск в таблице по заданному значению ключа.
	  * Значения ключевых полей задаются средствами класса DBTuple,
	  *
	  * например
	  \code
	  (*this)[DBTuple()<<string("str_value")<<11.24564<<1024]
	  \endcode
	  *
	  * Если строки с заданными значениями ключевых полей не существует,
	  * будет возвращён итератор @ref const_end() .
	  *
	  * @param keyValue Набор значений ключевых полей
	  */
	DBConstIterator find ( const Tuple & keyValue ) const;

	/** @brief Поиск строки в таблице с заданным значением ключа
	  *
	  * @param keyValue Набор N значений ключевых полей
	  * @param precision Точность выбора элемента по последнему ключевому полю
	  *
	  * В отличие от метода без аргумента precision, данный метод выбирает
	  * строку таблицы, в которой первые N-1 полей задаются ключом, а N-й
	  * элемент выбирается ближайший к N-му значению ключевого поля, который
	  * отличается от заданного значения не больше чем на precision. Это
	  * позволяет выполнять поиск по полям с плавающей точкой.
	  */
	DBConstIterator find ( const Tuple & keyValue, real precision) const;

	/**
	 * @brief Поиск строки в таблице с заданным значением одного ключевого поля
	 * @param keyValue Значение первого ключевого поля
	 * @return Итератор, указывающий на первую найденную строку таблицы
	 */
	inline DBConstIterator find ( const Variant & keyValue ) const
	{
		return find (Tuple()<<keyValue);
	}

	DBIterator find (const Tuple & keyValue );
	DBIterator find (const Tuple & keyValue, real precision);

	/** @brief Возвращает итератор на точную верхнюю грань элемента
	  *
	  * Если keyValue содержит n ключевых полей, то результат будет
	  * удовлетворять следующим условиям:
	  *
	  * 1) Первые n-1 ключевые поля полученного итератора будут совпадать
	  *    с первыми n-1 переданными ключевыми полями
	  * 2) По n-му ключевому полю будет выполнена операция upper_bound,
	  *    то есть будет выбрано наименьшее значение n-го ключевого поля,
	  *    которое не меньше, чем переданное n-е ключевое значение.
	  * 3) Если задано меньше ключевых полей, чем имеет таблица, то все
	  *    последующие ключевые поля будут выставлены в минимальные значения
	  *    begin().
	  * 4) Если выбрать итератор, отвечающий условиям (1-3) невозможно,
	  *    полученный итератор будет находится в состоянии end().
	  *
	  * Вопреки стандартному С++-алгоритму lower_bound, выполняющем
	  * аналогичную операцию, данный метод всё-таки назван upper_bound,
	  * т.к. метод lower_bound() имеет другой смысл.
	  *
	  * @param keyValue Значения нескольких ключевых полей
	  *
	  * @return Итератор, указывающий на точную верхнюю грань элемента
	  */
	DBConstIterator upper_bound ( const Tuple & keyValue ) const;


	/** @brief Возвращает итератор на точную нижнюю грань элемента
	  *
	  * Если keyValue содержит n ключевых полей, то результат будет
	  * удовлетворять следующим условиям:
	  *
	  * 1) Первые n-1 ключевые поля полученного итератора будут совпадать
	  *    с первыми n-1 переданными ключевыми полями
	  * 2) По n-му ключевому полю будет выполнена операция lower_bound,
	  *    то есть будет выбрано набольшее значение n-го ключевого поля,
	  *    которое не больше, чем переданное n-е ключевое значение.
	  * 3) Если задано меньше ключевых полей, чем имеет таблица, то все
	  *    последующие ключевые поля будут выставлены в минимальные значения
	  *    begin().
	  * 4) Если выбрать итератор, отвечающий условиям (1-3) невозможно,
	  *    полученный итератор будет находится в состоянии end().
	  *
	  * Суть данного метода и метода upper_bound() расходится с сутью
	  * стандартных c++-алгоритмов upper_bound и lower_bound.
	  *
	  * @param keyValue Значения нескольких ключевых полей
	  *
	  * @return Итератор, указывающий на точную нижнюю грань элемента
	  */
	DBConstIterator lower_bound ( const Tuple & keyValue ) const;

	/**
	 * @brief Находит иератор на точную нижнюю грань с точностью до ошибки
	 * @param keyValue Значение нескольких ключевых полей
	 * @param prec Точность, с которой определяется ключевое поле
	 * @return Итератор, указывающий на точную нижнюю грань элемента
	 *
	 * Считается, что ключевое поле, по которому ищется точная нижняя грань,
	 * задано с низкой точностью, и грань ищется с допуском.
	 *
	 * Однако данный метод работает некорректно, если разность между разными
	 * строками таблицы по ключевому полю меньше допуска.
	 */
	DBConstIterator lower_bound (const Tuple &keyValue, real prec) const;



	//! Вставка строки в таблицу
	virtual void insertRow ( const Tuple & keyValue,
					const Tuple & values );

	/** @brief Удаление строки из таблицы
	 * @param keyValue Ключ к поддереву, которое необходимо удалить
	 *
	 * Если keyValue содержит значения всех ключевых полей, удаляется одна
	 * строка таблицы.
	 *
	 * Если keyValue содержит значения только первых k ключевых полей, то
	 * удаляются все строки с этими значениями первых k ключевых полей.
	 *
	 * Если ни одной подходящей строки не найдено, никаких действий не
	 * совершается и исключение не генерируется.
	 */
	virtual void deleteRows ( const Tuple & keyValue );

	//! Изменение ячейки в таблице
	virtual void updateCell (const Tuple & keyValue, int colnumber,
							  const Variant & value );

	//! Вернуть индекс поля с данными по его имени
	unsigned int getValueColumnIndex (const std::string & valueColumnName )
		const;

	//! Вернуть индекс ключевого поля по его имени
	unsigned int getKeyColumnIndex (const std::string & valueColumnName )
		const;

	inline bool isEmpty () const
	{
		return ((map < Variant, void * > *)(this->tableRoot))->empty();
	}

	/**
	 * @brief Экспорт таблицы в поток в текстовом формате
	 * @param output Поток
	 * @param tablename Приписываемое имя таблицы
	 *
	 * Таблица в текстовом формате представляет собой набор строк вида
	 * <Имя таблицы> <Ключевые поля, разделяемые \\t> <Поля значений>
	 *
	 * В таком виде таблица может быть прочитана методом
	 * @ref DBMapCollection::readFromStream().
	 *
	 */
	void dump(ostream & output, const string & tablename) const;

#ifdef UseMPI

	/**
	 * @brief Синхронизация таблиц в MPI-процессах в пределах коммуникатора
	 * @param comm MPI-коммуникатор
	 * @bug Может возникнуть проблема при совпадении значений в индексах
	 */
	virtual void synchronize(MPI_Comm comm);
#endif

	inline const  Columns & getKeyColumns() const
	{
		return keyColumns;
	}

	inline const  Columns & getValueColumns() const
	{
		return valueColumns;
	}

	/**
	 * @brief Находит максимальное значение элемента ключа
	 * @param subkey Подключ
	 * @param nonexisting Значение, верращаемое, если подключа в таблице нет
	 *
	 * Пусть ключ таблицы состоит из n ключевых полей, и задан подключ с m<n
	 * полями. Данный метод находит максимальное значение m+1-го поля ключа при
	 * заданных значениях полей с 1 по m.
	 *
	 * Если с данным подключем нет ни одной записи, возвращается значение
	 * nonexisting.
	 *
	 * Если nonexisting=Variant() (т.е. тип Variant::TYPE_NULL), то будет
	 * сгенерировано исключение KeyNotFoundException .
	 *
	 * @return Максимальное значение m+1-го элемента ключа
	 */
	Variant getMaximalKeyElementValue(const Tuple & subkey,
									  const Variant & nonexisting) const;

#ifdef WithQT
public slots:
#endif

	int count() const;

	/** @brief Возвращает число ключевых полей
	 * @return Число ключевых полей
	 */
	int getKeyColumnsCount() const;

	/** @brief Возвращает число полей данных
	 * @return Число полей данных
	 */
	int getValueColumnsCount() const;

#ifdef WithQT
public slots:

	/**
	 * @brief Экспорт таблицы в текстовом формате в строку
	 * @param tablename Приписываемое имя таблицы
	 * @return Текстовое представление таблицы
	 *
	 * Является обёрткой метода void dump(), созданной для вызова через
	 * QtScript.
	 */
	QString dump ( const QString & tablename ) const;

	/**
	 * @brief Экспорт таблицы в текстовом формате в файл
	 * @param tablename Имя таблицы
	 * @param filename Имя файла
	 */
	void dump (const QString &tablename, const QString & filename) const;

	/**
	 * @brief Вставка строки в таблицу
	 * @param key Ключевые поля строки
	 * @param value Поля значений строки
	 */
	void insertRow ( const QVariantList & key, const QVariantList & value);

	/**
	 * @brief Значение поля данных
	 * @param key Значение ключевых полей
	 * @param colnumber Номер столбца с данными
	 * @return Значение поля данных в заданном столбце с заданным ключом
	 */
	QVariant value(const QVariantList & key, int colnumber) const;

	/**
	 * @brief Присвоить значение заданному полю данных
	 * @param key Значение ключевых полей
	 * @param colnumber Номер столбца с данными
	 */
	void setValue(const QVariantList & key, int colnumber, QVariant value);

	/**
	 * @brief Удалить все строки, подходящие по значению ключа
	 * @param key Значения первых n ключевых полей, по которым будет сравнение
	 */
	void deleteRows(const QVariantList & key);

	/**
	 * @brief Возвращает имя k-го ключевого поля
	 * @param Номер ключевого поля
	 * @return Имя заданного ключевого поля
	 */
	QString getKeyColumnName(int k) const;

	/**
	 * @brief Возвращает имя k-го поля данных
	 * @param Номер поля данных
	 * @return Имя заданного поля данных
	 */
	QString getValueColumnName(int k) const;

	/**
	 * @brief Возвращает индекс названного ключевого поля
	 * @param Имя ключевого поля
	 * @return  Индекс названного ключевого поля
	 */
	int getKeyColumnByName(const QString & name) const;

	/**
	 * @brief Возвращает индекс названного поля данных
	 * @param Имя поля данных
	 * @return  Индекс названного поля данных
	 */
	int getValueColumnByName(const QString & name) const;

	QVariantList read(const QVariantList & keyValue) const;
	DBIteratorQS * Begin() const;
	DBIteratorQS * End() const;
	DBIteratorQS * find (const QVariantList & keyValue ) const;
	DBIteratorQS * upperBound(const QVariantList & keyValue ) const;
	DBIteratorQS * lowerBound(const QVariantList & keyValue ) const;
	QVariantList getKeyColumnsList() const;
	QVariantList getValueColumnsList() const;
	QString tuplePrettyPrint(const QVariantList & k,
							 const QVariantList & v) const;
	void copyFrom(const QObject * from, const QObject * to);

#endif

};

#ifdef WithQT
class DBIteratorQS : public QObject
{
	Q_OBJECT
private:
	DBMap::DBIterator internal;
	DBIteratorQS ()
		: internal ()
	{

	};
public:
	DBIteratorQS (const DBMap::DBIterator & intern);
	inline const DBMap::DBIterator & dbIterator() const
	{
		return internal;
	}

public slots:
	void inc();
	void dec();
	void dec(int columnnumber);
	void dec(int columnnumber, int decrement);
	void inc(int columnnumber);
	void inc(int columnnumber, int increment);
	void subinc(int columnnumber, int fixcolumnnumber);
	void subinc(int columnnumber, int fixcolumnnumber, int increment);
	void subdec(int columnnumber, int fixcolumnnumber);
	void subdec(int columnnumber, int fixcolumnnumber, int decrement);
	QVariant keyColumnValue (const QString & columnname) const;
	QVariant keyColumnValue (int columnindex) const;
	QVariant value(int columnindex) const;
	QVariantList keyValues() const;
	QVariantList values() const;
	bool equal(const DBIteratorQS * another);
	void updateCell(int columnnumber, const QVariant & newvalue);
	void deleteRow();
	void deleteRow(int columnnumber);
	void deleteRow(int columnnumber, int fixcolumnnumber);
	bool isEnd() const;
};

Tuple variantListToTuple(const QVariantList & list);
#endif

/**
 * @brief Таблица с несколькими индексами
 *
 * @ingroup core
 *
 * Для добавления индекса используется метод createIndex(), для удаления
 * индекса - dropIndex(). По индексу можно осуществлять поиск (idx_find(),
 * idx_upper_bound(), idx_lower_bound()).
 */
class DBTable : public DBMap
{
private:
	map < string, pair < vector < pair<char, int> >, DBMap * > > indices;

	//Извлечь ключ индекса из основного ключа и значения
	Tuple idx_key (string idxname, const Tuple & key, const Tuple & value);

	//! Добавление строки в индексы
	void addToIndices(const Tuple &keyValue, const Tuple &values);

	//! Удаление строки изо всех индексов
	void removeFromIndices(const Tuple &keyValue, const Tuple &values);

public:
	DBTable (const Columns & key, const Columns & value )
		: DBMap (key,value)
	{

	}

	~DBTable()
	{
		for (map<string,pair<vector<pair<char,int> >,DBMap*> >::iterator
			 it = indices.begin(); it!=indices.end(); ++it)
		{
			delete it->second.second;
		}
		indices.clear();
	}

	/**
	  * Добавить строку в таблицу, вставив её ещё во все индексы. При нарушении
	  * уникальности индексов выбрасывается исключение DuplicateKeyException(),
	  * таблица остаётся без изменений.
	 */
	virtual void insertRow(const Tuple &keyValue, const Tuple &values);

	/**
	  * Удаление строки из таблицы и изо всех индексов
	  *
	 */
	virtual void deleteRows(const Tuple &keyValue);

	/**
	 * Обновление строки вместе с корректным обновлением всех индексов
	 */
	virtual void updateCell(const Tuple &keyValue, int colnumber,
							const Variant &value);

	/**
	 * @brief Создать индекс
	 * @param name Имя нового индекса
	 * @param fields Названия полей, входящих в индекс
	 */
	void createIndex (const string & name,
					  const OperatorPushableVector<string> &fields);

	//! Удалить индекс с заданным именем
	void dropIndex ( const string & name);

	/**
	 * @brief Найти строку по индексу
	 * @param name Имя индекса
	 * @param idx_key Значения полей индекса
	 * @return Основной ключ найденной по индексу строки
	 *
	 * Выбрасывает KeyNotFoundException, если строка не найдена.
	 */
	const Tuple & mainKey ( const string & name, const Tuple & idx_key ) const;

	/**
	 * @brief Поиск строки по индексу
	 * @param name Имя индекса
	 * @param idx_key Значения полей индекса
	 * @return Итератор строки, найденной по индексу
	 *
	 * Если строка не найдена, будет возвернут итератор const_end().
	 */
	DBConstIterator idx_find (const string & name, const Tuple & idx_key )
	const;

	/**
	 * @brief Поиск точной верхней грани по индексу
	 * @param name Имя индекса
	 * @param keyValue Значения полей индекса
	 *
	 * @return Итератор найденной точной верхней грани, или const_end()
	 */
	DBConstIterator idx_upper_bound(const string &name, const Tuple &keyValue)
	const;


	/**
	 * @brief Поиск точной нижней грани по индексу
	 * @param name Имя индекса
	 * @param keyValue Значения полей индекса
	 *
	 * @return Итератор найденной точной нижней грани, или const_end()
	 */
	DBConstIterator idx_lower_bound(const string & name,const Tuple &keyValue)
	const;

//	Tuple & mainKey ( const string & name, const Tuple & idx_key );
};

/**
 * @brief Таблица, ключём которой служит автоматический счетчик
 *
 * @ingroup core
 *
 * Для использования автоматической нумерации используется метод
 * insertRow().
 *
 */
class NumeratedTable : public DBTable
{
private:
	//Запретить конструктор, принимающий поля ключа
	NumeratedTable ( const Columns & key, const Columns & value )
		: DBTable(key,value)
	{

	}

public:
	//! Копирующий конструктор
	NumeratedTable ( const NumeratedTable & another )
		: DBTable (another)
	{

	}

	/**
	 * @brief Конструктор автоматически нумеруемой таблицы
	 * @param Список полей значений
	 *
	 * Создаваемая таблица будет иметь ключевое автоматически инкриминируемое
	 * поле autoinc.
	 */
	NumeratedTable ( const Columns & value )
		: DBTable (Columns()<<Column(Variant::TYPE_INT,"autoinc"),
				   value)
	{

	}

	int insertRow(const Tuple &values);
};

}

#ifdef WithQT
Q_DECLARE_METATYPE(libgnss::DBIteratorQS*)
Q_DECLARE_METATYPE(libgnss::Columns)
#endif

#endif

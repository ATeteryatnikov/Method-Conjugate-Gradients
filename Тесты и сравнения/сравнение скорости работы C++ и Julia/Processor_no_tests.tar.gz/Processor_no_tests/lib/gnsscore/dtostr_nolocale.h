#include <string>
#include <limits>
#include <cmath>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <assert.h>

template<typename realtype> realtype poweroften(int n)
{
	bool inv=false;
	if (n<0)
	{
		inv = true;
		n=-n;
	}
	realtype result = (realtype)(1);
	realtype tmp = (realtype)(10);
	for (unsigned int i=0; i<32; i++)
	{
		if (n % 2 == 1)
			result *= tmp;
		tmp = tmp*tmp;
		n>>=1;
		if (n==0)
			break;
	}
	if (inv)
		result = (realtype)(1)/result;
	return result;
}

//a - строка, c - дополняющий символ, w - ширина

/** @brief Функция, преобразующая число в строку
 * 
 * Функция получает число и возвращает строку с наибольшим числом
 * значащих цифр.
 * 
 * @tparam realtype Тип преобразуемого числа
 * @param value Преобразуемое число
 */
template<typename realtype> 
std::string floattostr (realtype value)
{
	if (std::isnan(value))
		return "nan";
	
	if (std::isinf(value))
		return "inf";
	
	const static realtype zero = (realtype)0;
	if (value == zero)
		return "0";
	


	bool isnegative=false;
	if (value<zero)
	{
		isnegative = true;
		value = -value;
	}
	
	//Теперь число value положительное. Найти строку мантиссы.

	//Размер одного куска мантиссы
	int limbsize;
	unsigned long long int limbpower;
//	if (sizeof(long long unsigned int) == 8)
//	{
//		limbsize = 18;
//		limbpower = 1000000000000000000;
//	}
//	else
//	{
		limbsize = 9; //Лучше меньше, да лучше
		limbpower = 1000000000;
//	}
	int mant_w = std::numeric_limits<realtype>::digits10+2;
	int numlimbs = (mant_w/limbsize)+1;
	int hp = floor(log10(value));
	
	//Создать куски мантиссы
	std::vector<long long unsigned int> limbs(numlimbs);
	
	value=value*poweroften<realtype>(limbsize-hp-1);
	
	//Разбить мантиссу на куски
	for (unsigned int i=0; i<numlimbs; i++)
	{
		unsigned long long int curlimb = floor(value);
		if ((i>0) && (curlimb>limbpower))
		{
			limbs[i-1]+=1;
			curlimb-=limbpower;
		}
		limbs[i]=curlimb;
		value=(value - curlimb)*(realtype)(limbpower);
	}

	//Теперь соберём из кусков мантиссу
        std::string mant(numlimbs*(limbsize+2),'0');
	int printed = 0;
	for (unsigned int i=0; i<numlimbs; i++)
		printed+=std::sprintf(&(mant[printed]),"%09llu",limbs[i]);

	char exponent[1000];
	std::sprintf(exponent,"e%+d",hp); //Разделитель и экспонента
	int expl = (hp==0)?0:strlen(exponent);
	int negl = (isnegative?1:0);
	int dotl = (mant_w>1)?1:0;
	std::string result(mant_w //Мантисса
					   +negl //Знак мантиссы
					   +dotl  //Десятичная точка
					   +expl,'\0'); //Экспонента с запасом
	if(isnegative)
		result[0] = '-';
	result[negl] = mant[0];
	if (mant_w>1)
	{
		result[negl+1]='.';
		memcpy(&(result[negl+2]),&(mant[1]),mant_w-1);
	}
	if (hp!=0)
		memcpy(&(result[negl+mant_w+dotl]),exponent,expl);
	return result;
}

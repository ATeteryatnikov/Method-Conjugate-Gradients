#include <LeapSeconds.h>

namespace libgnss
{

LeapSeconds::LeapSeconds(DBTableCollection *base)
	: DBTable (Columns()
		   <<Column(Variant::TYPE_DOUBLE, "taij2000"),
		   Columns()
		   <<Column(Variant::TYPE_INT, "tai_utc")
			 )
{
	base->addTable("leap_seconds", this);
	if (UTCDateTime::leapSeconds == 0)
		UTCDateTime::leapSeconds = this;
}

LeapSeconds::~LeapSeconds()
{
	if (this == UTCDateTime::leapSeconds)
		UTCDateTime::leapSeconds = 0;
}

LeapSecondsLowerBoundException::LeapSecondsLowerBoundException(real taij2000)
	:StrException("LeapSecondsLowerBoundException",
				  "Таблица секунд координации не позволяет "
			  "определить параметр TAI-UTC для метки времени "+
			  UTCDateTime::fromTAIJ2000(taij2000).getTAIDateTimeString())
{

}
}

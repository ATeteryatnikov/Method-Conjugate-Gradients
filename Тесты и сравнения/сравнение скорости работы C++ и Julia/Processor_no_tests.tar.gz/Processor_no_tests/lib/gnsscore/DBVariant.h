#ifndef DBVARIANT_H_
#define DBVARIANT_H_

//! @file

#include <vector>
#include <map>
#include <string>
#include <sstream>

using namespace std;

#include <Types.h>
#include <DBError.h>
#include <UTCDateTime.h>

namespace libgnss
{

/** @brief Исключение при попытке привести данные к несовместимому типу
 *
 * @ingroup except
 */
class TypeMismatchException : public StrException
{
public:

	/**
	 * @param type0 Тип, из которого осуществляется приведение
	 * @param type1 Тип, к которому осуществляется приведение
	 */
	inline TypeMismatchException (const std::string & type0,
				      const std::string & type1)
		: StrException ("TypeMismatchException","Ошибка приведения типов:"
		"невозможно перейти от типа "+type0+" к типу "+type1+".")
	{

	}
};

/**
 * @brief Исключение возникает при попытке найти тип по неизвестному имени
 *
 * @ingroup except
 */
class UnknownTypeException : public StrException
{
public:

	/**
	 * @param type0 Имя, которое не значится ни за одним типом
	 */
	inline UnknownTypeException ( const std::string & type0 )
		: StrException ("UnknownTypeException","Тип не зарегистрирован: "+type0)
	{

	}
};

class Variant;

/**
 * @brief Исключение возникает при нарушении синтаксиса строки при её переводе
 * в массив
 *
 * См. @ref arrayToString(), @ref stringToArray().
 *
 * @ingroup except
 */
class WrongArrayFormatException : public StrException
{
public:

	/**
	 * @param str Ошибочная строка
	 * @param pos Позиция, в которой возникла ошибка
	 * @param whatisit Причина ошибки
	 */
	WrongArrayFormatException(const std::string & str,
									 int pos,
									 const std::string & whatisit);
};

/**
 * @brief Преобразование массива в строку
 * @param v Массив
 * @return  Полученная строка
 *
 * @ingroup core
 *
 * После преобразования получается строка вида:
 *
 * [индекс1,тип1,"строка1"[,индекс2,тип2,"строка2"[...]]]
 *
 * тип1, тип2 - типы элементов, в которые должны быть преобразованы строки.
 * Если в строке1 есть кавычки или косая черта, то к ним подписывается по
 * одной косой черте. Наоборот, при обратном преобразовании косая черта
 * удаляется, и этим достигается взаимная обратность с методом
 * @ref arrayToString().
 */
std::string arrayToString(const std::map<int,Variant> & v);

/**
 * @brief Преобразование строки в массив
 *
 * @ingroup core
 *
 * @param s Строка
 * @return Массив, полученный из строки
 */
std::map<int,Variant> stringToArray(const std::string & s);


/** @brief Класс, описывающий тип данных, хранящийся в объекте Variant
 *
 * @ingroup core
  *
  * Признак типа у объектов Variant есть указатель на объект класса
  * CType. В Variant уже встроены синглтоны атомарных типов данных.
  * Для добавления нового типа данных необходимо перегрузить тип CType
  * и создать синглтон, или воспользоваться одним из готовых каркасов
  * для составных типов (см. например @ref CTypeSelect ).
  */
class CType
{
private:
	//! Имя вводимого типа
	std::string ParamName;

	//! Строка значения по умолчанию
	std::string defaultString;

public:
	/** @brief Конструктор нового типа
	  *
	  * Конструктор запоминает имя нового типа и добавляет его
	  * в общий список типов.
	  *
	  * @param paramname Имя нового типа
	  */
	CType(const std::string & paramname, const std::string & defaultstr);

	/** @brief Инициализация объекта данного типа с помощью другого объекта
	 *
	 * Данный метод вызывается из метода Variant::init() для объекта, тип
	 * которого отличается от стандартных.
	 *
	 * Данный метод базового класса CType ничего не делает!
	 *
	 * @param target Инициализируемый объект
	 * @param other Другой объект
	 */
	virtual void initVariant(Variant & target, const Variant & other);

	//! Метод возвращает имя данного типа
	const std::string & getName() const;

	/** @brief Метод, преобразующий строку в объект данного типа
	  *
	  * @param str Строка, преобразуемая в объект
	  *
	  * В базовом классе CType метод реализован для атомарных
	  * типов. Во вновь создаваемых типах он должен быть
	  * перегружен.
	  *
	  * Решение о том, в какой тип преобразовывать строку,
	  * принимается на основании сравнения указателя this с
	  * встроенными в Variant указателями TYPE_INT, TYPE_DOUBLE,...
	  */
	virtual Variant fromString ( const std::string & str) const;

	/** @brief Метод, преобразующий объект типа Variant в строку
	  *
	  * @param v Объект, преобразуемый в строку
	  *
	  * В базовом классе CType метод реализован для атомарных
	  * типов. Во вновь создаваемых типах он должен быть
	  * перегружен.
	  */
	virtual std::string toString ( const Variant & v) const;

	/**
	 * @brief Возвращает непустое значение данного типа
	 * @return Непустое значение данного типа
	 */
	virtual Variant defaultValue() const;

	/**
	 * @brief Сравнение двух значений
	 * @param a Первое значение
	 * @param b Второе значение
	 * @return 0, если a=b; 1, если a>b; -1, если a<b.
	 *
	 * Атомарные типы имеют встроенную функцию сравнения. При реализации
	 * новых типов, отличных от атомарных, нужно реализовать функцию сравнения
	 * соответствующих значений с атомарными типами (или в противном случае
	 * будет вызвано исключение несравнимости типов).
	 *
	 * По умолчанию данный метод вызывает исключение несравнимости типов.
	 */
	virtual int compare(const Variant & a, const Variant & b) const;

	/** @brief Метод, возвращающий указатель на тип по его заголовку
	  *
	  * @param paramname Строковый заголовок типа
	  * @param add Указатель на добавляемый в список тип
	  *
	  * Если требуется получить указатель на синглтон уже имеющегося
	  * в списке типа, то следует передавать add = 0. Если требуется
	  * добавить новый тип, следует передать в add указатель на его
	  * синглтон. Если требуется проверить, зарегистрирован ли уже
	  * некоторый тип в списке, следует выполнить следующую
	  * процедуру:
	  \code
//Создать новый синглтон
NewType * newsingleton = new NewType ("заголовок");

//Получить указатель на него с помощью метода getCType()
CType * checktype = CType::getCType("заголовок");

//Если указатели совпадают, то синглтон уже был создан;
if (newsingleton!=checktype)
	//Удалить только что созданный синглтон
	delete newsingleton;
	  \endcode
	  */
	static CType * getCType (const std::string & paramname,
				 CType * add = 0);
};




/** @brief Класс, представляющий переменную нефиксированного типа.
 *
 * @ingroup core
  *
  * Класс используется для того, чтобы хранить какие-то значения, типы которых
  * не известны при написании текста программы.
  *
  * Основное использование - для чтения результатов запросов из БД.
  *
  * Класс имеет встроенные функции, оптимизированные для работы с атомарными
  * типами, но с помощью дополнительного наращивания возможна реализация работы
  * с любыми типами. Объект класса Variant хранит две характеристики - тип
  * объекта @ref Type и содержимое объекта. Содержимое может иметь либо один
  * из атомарных типов, либо быть указателем. Тип объекта является указателем
  * на синглтон класса CType, который реализует основные методы работы
  * с объектом. При этом, для атомарных типов double и int эти методы зашиты
  * в класс Variant для увеличения производительности.
  */
class Variant
{
friend class CType;
friend class CTypeSelect;
public:

typedef CType * Type;

	static Type TYPE_NULL;
	static Type TYPE_INT;
	static Type TYPE_DOUBLE;
	static Type TYPE_CHAR;
	static Type TYPE_STRING;
	static Type TYPE_ARRAY;
	static Type TYPE_DATETIME;

	union VariantAtom
	{
		int intg;
		real dbl;
		char chr;
		std::string * str;
		std::map < int, Variant > * arr;
		UTCDateTime dt;
		void * pointer;
	};



protected:

	//! Идентификатор типа хранимого объекта
	Type type;

	/** @brief Хранимый объект
	  *
	  * Атомарные типы хранятся в непосредственном виде, строки и
	  * дата/время, которые не помещаются в стандартные 8 байт, хранятся в
	  * виде указателя на объект
	  */
	VariantAtom value;

	void init (const Variant & other);
	inline void init ( const int & value );
	inline void init ( const real & value );
	inline void init ( const char & value );
	inline void init ( const std::string & value );
	inline void init ( const UTCDateTime & value );
	void init ( const std::map < int, Variant > & value );
	real convertToDouble() const;
	int convertToInt() const;
	bool isLessThan(const Variant & second) const;

public:

	//Конструкторы

	/** @brief Пустой конструктор
	  *
	  * Создаваемый конструктором объект имеет тип NULL, и требует
	  * инициализации перед использованием
	  */
	inline Variant ();

	/** @brief Создаёт неинициализированный объект заданного типа
	  *
	  * @param desired Требуемый тип объекта
	  */
	inline Variant ( Type desired )
	{
		type=desired;
	}


	//! Копирующий конструктор
	Variant (const Variant & other);

	//! Конструктор для хранения целого числа
	inline Variant ( const int & value );

	//! Конструктор для хранения числа с плавающей точкой двойной точности
	inline Variant ( const real & value );

	//! Конструктор для хранения одного символа
	inline Variant ( const char & value );

	//! Конструктор для хранения строки
	inline Variant ( const std::string & value );

	//! Конструктор из C-строки
	inline Variant ( const char * value );

	//! Конструктор для хранения даты и времени
	inline Variant ( const UTCDateTime & value );

	/** @brief Создание объекта  DBVariant из массива объектов DBVariant.
	  *
	  * Конструктор принимает ассоциативный массив, отображающий индексы
	  * массива на элементы массива.
	  *
	  * @param value Ассоциативный массив с доступом по индексу.
	  */
	Variant ( const std::map < int, Variant > & value );


	//Деструкторы
	~Variant ();

	//! Оператор, присваивающий объекту целое значение
	inline Variant & operator= ( const int & other )
	{
		this->~Variant();
		init (other);
		return *this;
	}

	//! Оператор, присваивающий объекту дробное значение двойной точности
	inline Variant & operator= ( const real & other )
	{
		this->~Variant();
		init (other);
		return *this;
	}

	//! Оператор, присваивающий объекту значение одного символа
	inline Variant & operator= ( const char & other )
	{
		this->~Variant();
		init (other);
		return *this;
	}

	//! Оператор, присваивающий объекту строковое значение
	inline Variant & operator= ( const std::string & other )
	{
		this->~Variant();
		init (other);
		return *this;
	}

	//! Оператор, присваивающий объекту значение даты и времени
	inline Variant & operator= ( const UTCDateTime & other )
	{
		this->~Variant();
		init (other);
		return *this;
	}

	//! Оператор, присваивающий объекту значение массива
	Variant & operator= (const std::map <int, Variant> & other);

	//! Оператор, присваивающий объекту значение другого объекта
	Variant & operator= (const Variant & other);


//	template < typename T > DBVariant & operator= ( const T & other )
//	{
//		this->~DBVariant();
//		this->DBVariant ( other );
//	}

	//Операторы сравнения

	//! Оператор проверки равенства двух объектов
	inline bool operator==(const Variant & second) const;

	//! Оператор, вводящий частичный порядок на множестве объектов
	inline bool operator< (const Variant & second) const;

	inline bool operator> (const Variant & second) const
	{
		return second<(*this);
	}

	inline bool operator<= (const Variant & second) const
	{
		return !(second<(*this));
	}

	inline bool operator>= (const Variant & second) const
	{
		return !((*this)<second);
	}

	inline bool operator!=(const Variant & second) const
	{
		return !((*this)==second);
	}

	//Функции чтения содержимого

	//! Метод, возвращающий целочисленный идентификатор типа объекта
	inline const Type & getType() const
	{
		return type;
	}

	//! Метод, проверяющий хранит ли данный объект какое-либо значение
	inline bool inNull() const
	{
		return (type==TYPE_NULL);
	}

	//! Метод преобразования объекта в тип int, если возможно
	inline int toInt() const
	{
		if (type==TYPE_INT)
			return value.intg;
		else
			return convertToInt();

	}

	//! Метод преобразования объекта в тип double, если возможно
	inline real toDouble() const
	{
		if (type==TYPE_DOUBLE)
			return value.dbl;
		else
			return convertToDouble();
	}

	//! Метод преобразования объекта в тип char, если возможно
	char toChar() const
	{
		if (type==TYPE_CHAR)
			return value.chr;

		if (type==TYPE_INT)
			return value.intg;

		if (type==TYPE_NULL)
			return '\0';

		if (type==TYPE_DOUBLE)
			throw TypeMismatchException("double", "char");

		if (type==TYPE_STRING)
		{
			return value.str->at(0);
		}

		if (type==TYPE_ARRAY)
			throw TypeMismatchException("array", "char");

		if (type==TYPE_DATETIME)
			throw TypeMismatchException("datetime","char");

		throw TypeMismatchException("unknown", "char");

	}

	/**
	 * @brief Преобразование числа в строку в заданном формате
	 * @param format Строка форматирования для функции printf
	 * @return Строковое представление числа
	 *
	 * Если Variant хранит не число, то будет сгенерирована ошибка
	 * @ref TypeMismatchException .
	 */
	std::string toString(const std::string & format) const;

	//! Метод преобразования объекта в тип string, если возможно
	std::string toString() const
	{
		return type->toString(*this);
	}

	//! Преобразование в массив
	inline std::map<int, Variant> toArray() const
	{
		if (type == TYPE_ARRAY)
			return *(value.arr);
		else
		{
			std::map<int,Variant> result;
			result[0] = *this;
			return result;
		}
	}

	//! Возвращает хранимый массив
	inline std::map<int,Variant> & getArray()
	{
		if (type == TYPE_ARRAY)
			return *(value.arr);
		else
			throw TypeMismatchException(type->getName(),TYPE_ARRAY->getName());
	}


	//! Метод преобразования объекта в тип даты и времени, если возможно
	UTCDateTime toUTCDateTime() const
	{
		if (type==TYPE_DATETIME)
			return (value.dt);

		if (type==TYPE_INT)
			throw TypeMismatchException("int", "datetime");

		if (type==TYPE_DOUBLE)
			throw TypeMismatchException("double", "datetime");

		if (type==TYPE_CHAR)
			throw TypeMismatchException("char", "datetime");

		if (type==TYPE_STRING)
			throw TypeMismatchException("string", "datetime");

		if (type==TYPE_ARRAY)
			throw TypeMismatchException("array", "datetime");

		if (type==TYPE_NULL)
			throw TypeMismatchException("null", "datetime");

		throw TypeMismatchException("unknown", "datetime");

	}

	//! Оператор обращения к элементу массива, если объект хранит массив
	Variant & operator[] (const int index);

	//! Статический метод, возвращающий строковое название типа объекта
	inline static std::string getTypeName ( Type type )
	{
		return type->getName();
	}

	//! Метод, возвращающий строковое название типа хранимого объекта
	inline std::string getTypeName () const
	{
		return getTypeName(type);
	}

	//! Метод, создающий Variant заданного типа из строки
	static Variant fromString
		(Type desiredType, const std::string & str );

};

/** @brief Вектор с быстрым способом занесения элементов
 *
 * @ingroup core
  *
  * Иногда требуется занести небольшое количество элементов в вектор и
  * использовать его сразу же. Обычно для этого требуется использовать код
  *
  * \code
	vector < SomeType > vec;
	vec.push_back(element1);
	vec.push_back(element2);
	...
  \endcode
  * У данного класса добавлен оператор << для быстрого внесения элементов во
  * временный вектор без необходимости объявления переменной:
  * \code
	OperatorPushableVector()<<element1<<element2<<...
  \endcode
  * Такое выражение можно сразу передать в функцию, которой требуется вектор
  * элементов соответствующего типа.
  */
template <typename A> class OperatorPushableVector : public std::vector < A >
{
public:
	inline OperatorPushableVector & operator<< (const A & el)
	{
        this->push_back(el);
		return *this;
	}
};

//! @brief Колонка таблицы задаётся типом колонки и её именем
typedef std::pair < Variant::Type, std::string > Column;

//! @brief Вектор колонок таблицы с оператором быстрого внесения
typedef OperatorPushableVector < Column > Columns;

class Variant;

/** @brief Массив значений произвольных типов
 *
 * @ingroup core
  *
  * В работе с БД удобнее всего использовать тип Variant, позволяющий легко
  * унифицировать работу с различными типами данных. Для удобства работы
  * DBTuple создаётся на основе вектора с оператором быстрого внесения данных
  * для возможности быстро указывать значения ключей для доступа к данным из
  * таблиц.
  *
  */
class Tuple : public OperatorPushableVector <Variant>
{
public:
	Tuple ()
		:OperatorPushableVector < Variant > ()
	{

	}

	Tuple (const OperatorPushableVector < Variant > & another)
		:OperatorPushableVector < Variant > (another)
	{

	}

	/** @brief Запись всех значений из массива с заданным разделителем
	  *
	  * Возвращает объединение строк, представляющих элементы массива.
	  * При объединении строки разделяются заданным разделителем.
	  *
	  * @param separator Разделитель фрагментов строки
	  */
	inline std::string join (const std::string & separator) const
	{
		std::stringstream result_s;
		for (unsigned int i=0; i<size(); ++i)
		{
			if (i>0)
				result_s<<separator;
			result_s<<(*this)[i].toString();
		}
		return result_s.str();
	}

	inline bool operator< (const Tuple & other ) const
	{
		for (unsigned int i=0; i<size(); i++)
		{
			if (at(i) == other[i])
				continue;
			if (at(i)<other[i])
				return true;
			return false;
		}
		return false;
	}
};

/**
 * @brief Исключение возникает при выборе опции, не заданной ранее
 *
 * Для преобразования строки в тип CTypeSelect строки возможных значений
 * должны быть определены заранее. Если строка, преобразуемая в CTypeSelect,
 * не была добавлена в список вариантов, генерируется данное исключение
 *
 * @ingroup except
 *
 */
class CTypeSelectOptionNotFound : public StrException
{
public:
	CTypeSelectOptionNotFound(const std::string & option,
							  const std::string &type);
};

/** @brief Скелет типа переменной, принимающей значение из заданного набора
 *
 * @ingroup core
  *
  * Для упрощения хранения в структуре Variant каждому строковому значению из
  * заданного набора присваивается номер и хранится в @ref Variant::value.intg .
  *
  * При создании типа указывается его имя и список возможных значений, которые
  * могут принимать переменные данного типа. Список возможных вариантов затем
  * можно пополнять. Например:
  \code
	CTypeSelect * sel = CType::getCType("заголовок");
	sel->addOption("новый_вариант");
  \endcode
  *
  */
class CTypeSelect : public CType
{
private:
	int current_id;
	std::map < std::string, int > strint;
	std::map < int, std::string > intstr;
public:

	/**
	 * @brief Конструктор выборного типа данных
	 * @param name Имя нового типа
	 * @param options Набор опций, доступных для выбора
	 * @param defaultvalue Индекс значения по умолчанию
	 */
	CTypeSelect (const std::string & name, const Tuple & options ,
				 int defaultvalue);

	/**
	 * @brief Добавить новый вариант выбора
	 * @param option Строка, обозначающая новый вариант выбора
	 */
	void addOption ( const std::string & option );

	/**
	 * @brief Удалить вариант выбора
	 * @param option Удаляемый вариант выбора
	 */
	void removeOption ( const std::string & option );

	//! Соответствие вариантов выбора их индексам
	const std::map < std::string, int > & getOptions ();

	//! Соответствие индексов вариантам выбора
	const std::map < int, std::string > & getOptionsRev ();

	//! Преобразовать строку в выборный тип
	virtual Variant fromString ( const std::string & str) const;

	//! Получить строку, представляющую выбранное значение
	virtual std::string toString ( const Variant & v) const;

	virtual void initVariant(Variant & target, const Variant & other);
	virtual int compare(const Variant & a, const Variant & b) const;
	inline int toInt (const Variant & v) const
	{
		if (v.getType() == this)
			return v.value.intg;
		if (v.getType() == Variant::TYPE_STRING)
		{
			map<std::string,int>::const_iterator it = strint.find(v.toString());
			if (it == strint.end())
				throw CTypeSelectOptionNotFound(v.toString(), getName());
			return it->second;
		}
		throw TypeMismatchException(v.getType()->getName(),
									this->getName());
	}

	/**
	 * @brief Указатель на тип, реализующий выбор из опций Yes или No
	 */
	static CTypeSelect * yesOrNo ();

	static Variant yes();

	static Variant no();
};

// inline - реализация

inline Variant::Variant()
{
	type=TYPE_NULL;
}

inline void Variant::init(const char &value)
{
	type=TYPE_CHAR;
	this->value.chr = value;
}

inline Variant::Variant(const char &value)
{
	init (value);
}

inline void Variant::init (const UTCDateTime &value)
{
	type=TYPE_DATETIME;
	//this->value.dt = new UTCDateTime;
	(this->value.dt) = value;
}

inline Variant::Variant(const UTCDateTime &value)
{
	init (value);
}

inline void Variant::init(const real &value)
{
	type = TYPE_DOUBLE;
	this->value.dbl = value;
}

inline Variant::Variant(const real &value)
{
	init (value);
}

inline void Variant::init(const int &value)
{
	type = TYPE_INT;
	this->value.intg = value;
}

inline Variant::Variant(const int &value)
{
	init (value);
}

inline void Variant::init (const std::string &value)
{
	this->value.str = new std::string (value);
	type = TYPE_STRING;
	//*(this->value.str) = value;
}

Variant::Variant(const std::string &value)
{
	init (value);
}

Variant::Variant(const char *value)
{
	init (string(value));
}

/** @brief Исключение при сравнении несравнимых типов
  *
  * Исключение возникает при попытке сравнить два значения, имеющие
  * несовместимые типы.
  *
  * @ingroup except
  *
  */
class IncomparableTypesException : public StrException
{
public:
	IncomparableTypesException ( const std::string & type1,
				     const std::string & type2)
		: StrException ("IncomparableTypesException",
						"Невозможно сравнивать объекты двух типов: "+
				type1+" и "+type2+".")
	{

	}
};

inline bool Variant::operator==(const Variant & second) const
{
	if (type==TYPE_INT)
	{
		//Тип int можно сравнивать с тремя типами
		if (second.getType() == TYPE_INT)
			return value.intg == second.toInt();
		if (second.getType() == TYPE_DOUBLE)
			return (double)(value.intg) == second.toDouble();
		if (second.getType() == TYPE_CHAR)
			return value.intg == second.toChar();
	}

	if (type==TYPE_DOUBLE)
	{
		//Тип double можно сравнивать с тремя типами
		if (second.getType() == TYPE_DOUBLE)
			return value.dbl == second.toDouble();
		if (second.getType() == TYPE_INT)
			return value.dbl == (double)(second.toInt());
		if (second.getType() == TYPE_CHAR)
			return value.dbl == (double)(second.toChar());
	}

	if (type==TYPE_CHAR)
	{
		//Тип char можно сравнивать с тремя типами
		if (second.getType() == TYPE_CHAR)
			return value.chr == second.toChar();
		if (second.getType() == TYPE_INT)
			return (int)(value.chr) == second.toInt();
		if (second.getType() == TYPE_DOUBLE)
			return (double)value.chr == second.toDouble();
	}

	if (type==TYPE_STRING)
	{
		if (second.getType() == TYPE_STRING)
			return *(value.str)==*(second.value.str);
	}

	if (type==TYPE_DATETIME)
	{
		if (second.getType() == TYPE_DATETIME)
			return (this->value.dt) == (second.value.dt);
	}

	if (type==TYPE_NULL)
		return (second.getType() == TYPE_NULL);

	if (second.getType() == TYPE_NULL)
		return (type == TYPE_NULL);

	//Неизвестно, для какого из двух типов реализован мультиметод сравнения
	try
	{
		return (getType()->compare(*this,second) == 0);
	}
	catch (const IncomparableTypesException & e)
	{
		return (second.getType()->compare(*this,second) == 0);
	}

}

inline bool Variant::operator< (const Variant & second) const
{
	//С помощью inline-включения ускорить сравнение наиболее важных типов
	//int и double.
	if ((type==TYPE_INT)&&(second.getType()==TYPE_INT))
		return value.intg < second.value.intg;

	if ((type==TYPE_DOUBLE)&&(second.getType()==TYPE_DOUBLE))
		return value.dbl < second.value.dbl;

	return isLessThan(second);
}

inline std::string trim(const std::string & s)
{
	int p1 = s.find_first_not_of(" \n\r\t");
	int p2 = s.find_last_not_of(" \n\r\t");
	if (p1==-1)
		return "";
	return s.substr(p1,p2-p1+1);
}

/**
 * @brief Разделить строку на части с помощью разделителя
 * @param s Исходная строка
 * @param delim Разделитель
 * @return Вектор подстрок
 */
inline vector<string> split(const string &s, char delim)
{
	vector < string > result;
	istringstream ss(s);
	string item;
	while (std::getline(ss, item, delim))
		if (item!="")
			result.push_back(item);
	return result;
}

/**
 * @brief Возвращает строку ровно из N символов данной строки
 * @param src Исходная строка
 * @param N Требуемое число символов
 * @param fill Символ для дополнения строки
 * @return N символов исходной строки.
 *
 * Если исходная строка короче N символов, она дополняется символом fill.
 * Если исходная строка длиннее, то она обрезается.
 */
inline string takeNChars(const string &src, int N, char fill=' ')
{
	string result = src.substr(0,N);
	result+=string(N-result.size(), fill);
	return result;
}

}

#endif

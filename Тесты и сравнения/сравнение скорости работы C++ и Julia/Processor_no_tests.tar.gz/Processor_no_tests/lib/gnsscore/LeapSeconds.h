#ifndef LEAPSECONDS_H_
#define LEAPSECONDS_H_

#include <DBError.h>
#include <DBTable.h>
#include <DBTableCollection.h>

namespace libgnss
{

/**
 * @brief Ошибка отсутствия информации о секундах координации
 *
 * \ingroup except
 *
 * Секунды координации известны начиная с какой-то наименьшей даты, записанной
 * в таблице. При вызове метода @ref LeapSeconds::getLeapSeconds для более
 * ранних дат будет сгенерировано данное исключение.
 */
class LeapSecondsLowerBoundException:public StrException
{
public:
	LeapSecondsLowerBoundException(real taij2000);
};

/**
 * @brief Таблица секунд координации
 *
 * @ingroup core
 *
 * Ключ: double taij2000 - число секунд от 01.01.2000 12:00 в шкале TAI
 *
 * Данные: int tai_utc - разность между шкалами TAI и UTC в секундах
 *
 * Например, если секунда координации вводится 2008-12-31_23:59:60.000, то это
 * соответствует 284040033 сек. TAI2000 и 284040000 сек. UTC.
 * Далее, 2009-01-01_00:00:00.000 соответствует 284040034 TAI2000 и
 * 284040000 сек. UTC.
 *
 * Таблица секунд координации хранится является статической, то есть
 * при наличии нескольких сеансов обработки в одном процессе они используют
 * одну и ту же таблицу.
 *
 */
class LeapSeconds : public DBTable
{
public:
	LeapSeconds (DBTableCollection * base);

	~LeapSeconds();

public:

	/**
	 * @brief Возвращает число секунд координации на заданный момент времени
	 * @param taij2000 Момент времени, секунды TAI от 01.01.2000 12:00
	 * @return Число секунд координации на заданную дату
	 * @warning Класс не имеет никаких средств указания срока устаревания
	 * данных таблицы - если введённая в реальности секунда координации не была
	 * введена в таблицу, с точки зрения программы это невозможно определить.
	 */
	inline int getLeapSeconds(real taij2000)
	{
		try
		{
			return lower_bound(Tuple()<<Variant(taij2000))[0].toInt();
		}
		catch(EndIteratorException e)
		{
			throw LeapSecondsLowerBoundException(taij2000);
		}
	}
};

}

#endif

#include <DBError.h>
#include <ephemeris.h>
#include <jpleph.h>
#include <climits>
#include <iostream>

using namespace libgnss;

static real curtimemoment = 1e-50;
static kinematic < real, 3, defaultInert > coordinates[14];

void * eph = NULL;

kinematic<real,3,defaultInert> getCelestialBodyEphemerides (
		unsigned int bodyID, real tai )
{
	if (curtimemoment == tai)
	{
		if (!(isnan(coordinates[bodyID].length<0,2>())))
			return coordinates[bodyID];
	}
	else
	{
		curtimemoment = tai;
		for (unsigned int i=0; i<14; i++)
			coordinates[i] = kinematic<real,3,defaultInert>(
						numeric_limits<real>::quiet_NaN());
	}
	if (eph == NULL)
	{
		eph = jpl_init_ephemeris("JPLEPH",0,0);
		if (eph == NULL)
		{
			cerr<<"Не найден файл эфемерид JPLEPH"<<endl;
			exit(0);
		}
	}

	double A[6];
	double et = (tai+32.184)/86400.0 + 2451545.0;
	jpl_pleph(eph, et, bodyID, 3, &(A[0]), 0);
	kinematic<real,3,defaultInert> result;
	result[0] = A[0]*astrounit;
	result[1] = A[1]*astrounit;
	result[2] = A[2]*astrounit;
	coordinates[bodyID] = result;
	return result;
}

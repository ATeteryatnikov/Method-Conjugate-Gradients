/*
 * ephemeris.h
 *
 *  Created on: 27.09.2010
 *      Author: yuron
 */

#ifndef EPHEMERIS_H_
#define EPHEMERIS_H_

#include <Kinematic.h>
#include <Types.h>
#include <Consts.h>
#include <Frames.h>

/**
 *  @file
 *
 *  @brief С-интерфейс к процедурам вычисления эфемерид планет
 */

/**
  *
  * Функция, вычисляющая эфемериды космического тела в заданный момент времени.
  * Для идентификации космического тела используется следующий список:
  *
  *  1 - Меркурий,
  *
  *  2 - Венера,
  *
  *  3 - Земля,
  *
  *  4 - Марс,
  *
  *  5 - Юпитер,
  *
  *  6 - Сатурн,
  *
  *  7 - Уран,
  *
  *  8 - Нептун,
  *
  *  9 - Плутон,
  *
  * 10 - Луна,
  *
  * 11 - Солнце,
  *
  * 12 - барицентр Солнечной системы,
  *
  * 13 - барицентр системы Земля-Луна.
 *
 * @param t Количество секунд в шкале TAI с J2000.0
 * @param planetID Номер тела Солнечной системы
 * @param result Положение тела Солнечной системы в СК GCRS в км.
 */
extern "C" void ephemerides_( double*t, int*planetID, double*result );

/** @brief Функция, возвращающая эфемериды космического тела
 * @param t Количество секунд в шкале TAI с J2000.0
 * @param bodyID Номер тела Солнечной системы (см. функцию ephemerides_(). )
  */
libgnss::kinematic<libgnss::real,3,libgnss::defaultInert>
		getCelestialBodyEphemerides (unsigned int bodyID, libgnss::real tai );

inline libgnss::real angleSunEarthObject (
	const libgnss::kinematic<libgnss::real,3,libgnss::defaultInert>&ObjectPos,
		libgnss::real tai )
{
	double t = tai+32.184;
	libgnss::kinematic<libgnss::real,3,libgnss::defaultInert> OE, OS;
	OE=-1./ObjectPos.length<0,2>()*ObjectPos;
	OS=getCelestialBodyEphemerides( 11, t )-ObjectPos; OS=1./OS.length<0,2>()*OS;
	return acos(OS*OE);
}

#endif /* EPHEMERIS_H_ */

#ifndef DBINTERPOLATE_H_
#define DBINTERPOLATE_H_

#include <vector>
#include <map>
#include <string>
#include <limits>
#include <cmath>

using namespace std;

/** @file DBInterpolate.h
 *
 * В файле собраны функции для аппроксимации данных по таблице. Для этого ключ
 * таблицы должен иметь последнее поле типа double. Значение аппроксимируемой
 * величины вычисляются для каждого подключа, получаемого выкидыванием из ключа
 * последнего поля.
 */

#include <DBTable.h>


namespace libgnss
{

/**
 * @brief Исключение, возникающее, когда таблица не подходит для аппроксимации
 *
 * @ingroup except
 *
 * Это обозначает, что последнее поле ключа таблицы имеет тип не double.
 */
class TableInappropriateForInterpolation : public StrException
{
public:
	TableInappropriateForInterpolation (const string & details);
};

/**
 * @brief Ошибка аппроксимации
 *
 * @ingroup except
 *
 * Исключение возникает, когда невозможно подобрать ни одной вершины
 * аппроксимации, удовлетворяющей всем требованиям (@ref getNeighbourhood() ).
 */
class ApproximationError : public StrException
{
public:
	ApproximationError();
};

/** @brief Выбрать множество узлов для интерполяции
 *
 * @ingroup approximation
  *
  * Если вид ключа таблицы отвечает условиям, требуемым функциями interpolate(),
  * то данная функция выбирает множество строк данных из таблицы, по которым
  * можно проводить интерполяцию значения некоторых столбцов при данном значении
  * ключевого столбца. Множество строк возвращается в виде вектора указателей
  * на строки.
  *
  * Если таблица не соответствует требованиям, генерируется исключение
  * TableInappropriateForInterpolation().
  *
  * @param[out] args Найденный набор вершин интерполяции
  * @param[out] vals Значения столбца в вершинах интерполяции
  * @param table Таблица, по полям которой проводится интерполяция
  * @param discontinuities Список разрывов табличной функции
  * @param key0 Значения всех ключевых полей кроме последнего
  * @param x0 Значение последнего ключевого поля
  * @param valueColumnIndex Индекс интерполируемой колонки
  * @param interpolateOrder Число узлов интерполяции
  * @param allowextrapolate Ограничение экстраполяции
  * @param maxstep Ограничение на шаг между найденными узлами
  *
  * @return Множество узлов интерполяции вида (Аргумент, Указатель на значения)
  *
  * Разрывы функции учитываются при поиске узлов интерполяции: узлы выбираются
  * между теми двумя соседними разрывами (если они есть), между которыми
  * находится точка x0.
  *
  * Параметр interpolateOrder имеет особые значения:
  * @li < 0 возвращается пустой массив
  * @li 0 возвращается один узел интерполяции с моментов времени, меньшим или
  *  равным требуемому моменту времени x0, и ближайшим к x0 (т.е. находится с
  *  помощью алгоритма lower_bound), если такой узел существует. В противном
  *  случае возвращает ближайший имеющийся.
  * @li 1 возвращается один узел интерполяции с ближайшим к x0 моментов времени
  *  (используется алгоритм lower_bound, затем выбирается следующий узел и
  *   проверяется, какой из них ближе к x0). Если левый и правый узлы находятся
  *  на одинаковом расстоянии от X0, то будет выбран правый.
  * @li > 1 возвращается несколько узлов интерполяции. Их количество равно либо
  *  количеству всех существующих узлов, либо указанному числу interpolateOrder,
  *  в зависимости от того, что меньше. При этом узлы выбираются так, чтобы
  *  разности между x0 и моментами времени крайних узлов были как можно меньше.
  *  Из двух равноудалённых от x0 узлов каждый раз будет выбираться правый.
  *
  * Если allowextrapolate не указано (или < 0), то будут найдены ближайшие
  * подходящие узлы интерполяции, в том числе, если точка x0 будет лежать за
  * пределами интервала между крайними узлами интерполяции.
  *
  * Ограничение экстраполяции есть максимальное допустимое расстояние от x0 до
  * ближайшего узла, если x0 лежит вне интервала, покрываемого найденными
  * найденными узлами.
  *
  * Ограничение влияет на выбор узлов. Например, если ближайший найденный
  * i-й узел интерполяции находится слева от x0, и расстояние между ними больше,
  * чем allowextrapolate, то правый, (i+1)-й узел будет добавлен в создаваемое
  * множество узлов в любом случае, даже если (i-1)-й узел ближе к x0.
  *
  * Если maxstep не указано (или <0), то будут выбраны ближайшие удовлетворяющие
  * остальным ограничениям узлы интерполяции, причем интервал между соседними
  * узлами интерполяции может быть любой.
  *
  * Ограничение maxstep есть наибольший допустимый шаг между возвращаемыми
  * функцией узлами интерполяции. Параметр влияет на выбор узлов. Например,
  * если встаёт выбор, i-й узел добавить слева, или j-й справа, причем
  * расстояние между i-м и (i+1)-м узлами меньше maxstep, а между j-м и
  * (j-1)-м - больше maxstep, то будет добавлен i-й узел, даже если он дальше
  * от x0, чем j-й.
  *
  * Если требуемого количества узлов, удовлетворяющим всем ограничениям, не
  * удалось найти, будет возвращено столько узлов, сколько нашлось.
  *
  * Если не существует ни одного узла с данным значением подключа, то будет
  * сгенерировано исключение @ref KeyNotFoundException .
  *
  * Если узлы с данным значением подключа существуют, но ни один из них не
  * удовлетворяет налагаемым ограничениям, то генерируется исключение
  * @ref ApproximationError .
  *
  */
template < typename real_t >
void getNeighbourhood(
		vector < real_t > & args,
		vector < real_t > & vals,
		const DBTable & table,
		const DBTable * discontinuities,
		const Tuple & key0,
		real x0,
		int valueColumnIndex,
		int interpolateOrder,
		real allowextrapolate = -1.0,
		real maxstep = -1.0)
{
	unsigned int N = key0.size();

	//Границы, устанавливаемые разрывами (выбранные узлы интерполяции будут
	//лежать между разрывами).
	real leftdisc = -numeric_limits<real>::max(),
			rightdisc = numeric_limits<real>::max();
	if (discontinuities != 0)
		if (discontinuities->count() >0)
		{
			Tuple key1(key0);
			key1<<x0;
			DBTable::DBConstIterator it_l = discontinuities->lower_bound(key1);
			if (it_l != discontinuities->const_end())
			{
				leftdisc = it_l.keyColumnValue(N).toDouble();

				//Если x0 приходится точно на точку разрыва
				if (leftdisc >= x0)
				{
					//Проверить, что существует соответствующая вершина
					//аппроксимации; иначе, значение в точке x0 не определено.
					DBTable::DBConstIterator it_v = table.find(key1,
															   x0 * (1e-15));
					if (it_v == table.const_end())
						throw ApproximationError();
					//Вернуть единственную вершину
					args.push_back((real_t)it_v.keyColumnValue(N).toDouble());
					vals.push_back((real_t)
						(it_v[valueColumnIndex].toDouble()));
					return;
				}
				it_l.subinc(N,N-1);
				if (it_l != discontinuities->const_end())
					rightdisc = it_l.keyColumnValue(N).toDouble();
			}
			else
			{
				DBMap::DBConstIterator it_r=discontinuities->upper_bound(key1);
				//В данном случае существование разрыва, совпадающего с x0, уже
				//исключено, так как он был бы найден функцией lower_bound()
				//выше.
				if (it_r!=discontinuities->const_end())
					rightdisc = it_r.keyColumnValue(N).toDouble();
			}

		}

	//Если интерполяция не требуется, будет возвращён 0
	if (interpolateOrder < 0)
		return;

	//! @todo Обеспечить дополнительную информацию в сообщении об ошибке
	//1) Проверить, что последний ключевой столбец имеет тип double
	if (table.getKeyColumns()[N].first != Variant::TYPE_DOUBLE)
		throw TableInappropriateForInterpolation("");

	//2) Найти нижнюю грань
	Tuple key1 (key0);
	key1.push_back((real)x0);

	DBTable::DBConstIterator it1 = table.lower_bound(key1);

	//Если нижней грани нет, взять верхнюю грань
	if (it1 == table.const_end())
	{
		it1 = table.upper_bound(key1);
		if (it1 == table.const_end())
			throw KeyNotFoundException(key0);
	}

	//Убедиться, что найденная вершина удовлетворяет ограничениям разрывов
	real x1 = it1.keyColumnValue(N).toDouble();
	if (x1<leftdisc)
	{
		it1.subinc(N, N-1);
		if (it1 == table.const_end())
			throw ApproximationError();
		x1 = it1.keyColumnValue(N).toDouble();
	}

	if (x1>rightdisc)
	{
		if (it1!=table.find(key0))
			it1.subdec(N,N-1);
		else
			throw ApproximationError();
		x1 = it1.keyColumnValue(N).toDouble();
	}


	//Если требуется найти точную нижнюю грань
	if (interpolateOrder == 0)
	{
		if (allowextrapolate >= 0)
			if (fabs(it1.keyColumnValue(N).toDouble()-x0) > allowextrapolate)
				throw ApproximationError();
		args.push_back((real_t)(x1));
		vals.push_back((real_t)
					(it1[valueColumnIndex].toDouble()));
		return ;
	}

	if (interpolateOrder == 1)
	{
		//Добавить ближайшую вершину в результат
		DBTable::DBConstIterator it11(it1);
		it11.subinc(N,N-1);
		if ((it11==table.const_end())
				|| (it11.keyColumnValue(N).toDouble() > rightdisc))
		{
			args.push_back((real_t)(x1));
			vals.push_back((real_t)
						(it1[valueColumnIndex].toDouble()));

		}
		else
		{
			real x1p = it11.keyColumnValue(N).toDouble();
			real DT11 = fabs(x1p - x0), DT1 = fabs(x1 - x0);
			if (allowextrapolate >= 0)
				if ((DT11 > allowextrapolate) && (DT1 > allowextrapolate))
					throw ApproximationError();
			if (DT11>DT1)
			{
				args.push_back((real_t)(x1));
				vals.push_back((real_t)
							(it1[valueColumnIndex].toDouble()));
			}
			else
			{
				args.push_back((real_t)(x1p));
				vals.push_back((real_t)
							(it11[valueColumnIndex].toDouble()));
			}
		}
		return;
	}

	args.push_back((real_t)(x1));
	vals.push_back((real_t)
				(it1[valueColumnIndex].toDouble()));

	real prevLeftT = x1;
	real prevRightT = prevLeftT;

	//Итератор, указывающий на нижнюю границу доступных узлов
	//DBTable::DBConstIterator checkBegin = table.find(key0);
	//Итератор it1 будет обозначать левую границу окрестности,
	//итератор it2 будет правой границей окрестности
	DBTable::DBConstIterator it2 (it1);
	//Флаги existDown и existUp показывают, существуют ли (независимо от
	//прочих ограничений, заложенных в аргментах) точки для расширения
	//окрестности влево и вправо

	bool existDown = true, existUp = true;

	it1.subdec(N,N-1);
	if (it1.isReverseEnd())
		existDown = false;

	it2.subinc(N,N-1);
	if (it2.isEnd())
		existUp = false;

	for (int i=0; i<interpolateOrder-1; i++)
	{
		// Возможность расширить окрестность влево и вправо в соответствии с
		// ограничениями
		bool goDown = existDown;
		bool goUp = existUp;

		//Моменты времени пробных вершин слева и справа, если существуют
		real xl, xr;

		//Проверить ограничения, накладываемые разрывами
		if (goDown == true)
		{
			xl = it1.keyColumnValue(N).toDouble();
			if (xl < leftdisc)
				goDown = false;
		}

		if (goUp == true)
		{
			xr = it2.keyColumnValue(N).toDouble();
			if (xr > rightdisc)
				goUp = false;
		}

		//Проверить, не накладывают ли ограничение ширина шага между узлами
		if (maxstep >= 0)
		{
			if (goDown)
			{
				if (fabs(prevLeftT-xl) > maxstep)
					goDown = false;
			}
			if (goUp)
			{
				if (fabs(xr-prevRightT) > maxstep)
					goUp = false;
			}
		}

		//Проверить, не накладывает ли ограничение экстраполяции запрет на выбор
		//одного из узлов
		if (allowextrapolate >= 0)
		{
			if (prevRightT < x0 - allowextrapolate)
			{
				goDown = false;
				if (goUp == false)
					throw ApproximationError ();
			}

			if (prevLeftT > x0 + allowextrapolate)
			{
				goUp = false;
				if (goDown == false)
					throw ApproximationError ();
			}
		}

		//Если нельзя выбрать ни одного нового узла интерполяции,
		//вернуть то, что удалось получить
		if (!(goDown||goUp))
			return;

		//Если допустимы оба варианта, оставить из них только один, наилучший
		if (goDown && goUp)
		{
			if (fabs(xl - x0) < fabs(xr - x0))
				goUp = false;
			else
				goDown = false;
		}

		//Если можно выбрать узел интерполяции только с меньшим
		//значением ключевого поля, выбрать его
		if (goDown && (!goUp))
		{
			//Внести вершину в выбранную окрестность
//			it1 = it1;//.subdec(N,N-1);
			prevLeftT = xl;
			args.push_back((real_t)(xl));
			vals.push_back((real_t)
						(it1[valueColumnIndex].toDouble()));
			//Проверить возможность расширения окрестности ещё левее
			it1.subdec(N,N-1);
			if (it1.isReverseEnd())
				existDown = false;
		}

		//Если можно выбрать узел интерполяции только с большим
		//значением ключевого поля, выбрать его
		if ((!goDown) && goUp)
		{
			//Внести выбранную вершину в окрестность
//			it2 = it2;//.subinc(N,N-1);
			prevRightT = xr;
			args.push_back((real_t)(xr));
			vals.push_back((real_t)
						(it2[valueColumnIndex].toDouble()));
			//Проверить возможность расширения окрестности ещё правее
			it2.subinc(N,N-1);
			if (it2.isEnd())
				existUp = false;
		}
	}

	return;

}

/** @brief Интерполяция значений одного столбца таблицы
 *
 * @ingroup approximation
  *
  * Пусть таблица имеет последний ключевой столбец типа TYPE_DOUBLE, и несколько
  * полей данных типа TYPE_DOUBLE. Тогда можно, зафиксировав все ключевые
  * столбцы, кроме последнего, расценивать значения последнего ключевого столбца
  * как аргументы, а значения некоторых столбцов данных - как значения функций
  * от этих аргументов.
  *
  * Данная функция выполняет интерполяцию заданной таким образом табличной
  * функции.
  *
  * @param table Таблица, по которой проводится интерполяция
  * @param key0 Значения всех ключевых полей, кроме последнего
  * @param x0 Значение аргумента для функции, заданной таблично
  * @param valueColumnIndex Номер столбца интерполируемых данных
  * @param interpolateOrder Порядок интерполяции (число узлов)
  *
  * Алгоритм выбора узлов интерполяции см. @ref getNeighbourhood().
  *
  */
real interpolate (
		const DBTable & table,
		const DBTable * discontinuities,
		const Tuple & key0,
		real x0,
		unsigned int valueColumnIndex,
		int interpolateOrder,
		real allowextrapolate = -1.0,
		real maxstep = -1.0
		);

/** @brief Аппроксимация значений и производных одного столбца таблицы
 *
 * @ingroup approximation
  *
  * Пусть таблица имеет последний ключевой столбец типа TYPE_DOUBLE, и несколько
  * полей данных типа TYPE_DOUBLE. Тогда можно, зафиксировав все ключевые
  * столбцы, кроме последнего, расценивать значения последнего ключевого столбца
  * как аргументы, а значения некоторых столбцов данных - как значения функций
  * от этих аргументов.
  *
  * Данная функция выполняет интерполяцию заданной таким образом табличной
  * функции.
  *
  * @param table Таблица, по которой проводится интерполяция
  * @param discontinuities Список разрывов табличной функции
  * @param key0 Значения всех ключевых полей, кроме последнего
  * @param x0 Значение аргумента для функции, заданной таблично
  * @param valueColumnIndex Номер столбца интерполируемых данных
  * @param numpoints Число узлов аппроксимации
  * @param approximateOrder Степень аппроксимирующего полинома
  * @param derivs Число вычисляемых производных
  * @param allowextrapolate Ограничение экстраполяции
  * @param maxstep Ограничение на шаг между найденными узлами
  *
  * Алгоритм выбора узлов интерполяции см. @ref getNeighbourhood().
  *
  */

/**
 * @brief approximate
 * @return
 */
vector <real> approximate (
		const DBTable & table,
		const DBTable * discontinuities,
		const Tuple & key0,
		real x0,
		unsigned int valueColumnIndex,
		int numpoints,
		int approximateOrder,
		int derivs,
		real allowextrapolate = -1.0,
		real maxstep = -1.0
				 );

}

#endif

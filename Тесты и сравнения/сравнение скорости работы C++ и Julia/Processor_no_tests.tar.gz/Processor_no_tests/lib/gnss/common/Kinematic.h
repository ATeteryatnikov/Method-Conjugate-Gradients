
#ifndef KINEMATIC
#define KINEMATIC

//! @file

//#include "types.h"
#include <precmath.h>
#include <dtostr_nolocale.h>


namespace libgnss
{

inline double arcsin(double x){
	if(x>1) return asin(1);
	if(x<-1) return asin(-1);
	return asin(x);
}

//Будем использовать одну точность измерения времени для всех систем
//времени. Хранить время будем в 
/** @file
  * @brief Содержит шаблоны векторов Евклидова пространства
  */



/** @class kinematic Kinematic.h Kinematic.h
  * @brief Точка в фазовом пространстве
  *
  * @ingroup coordsys
  * @ingroup core
  *
  * Данный шаблон класса реализует основные операции над вектором.
  * Размерность указывается в параметре к шаблону.
  * 
  * @param scalar Тип данных, реализующий понятие скаляра и операции
  * над ним. Возможно, всегда будет double.
  * @param dim Размерность вектора
  * @param kinematicType Номер системы координат. Используется для статической
  * проверки типа на этапе компиляции.
  *
  * @todo Реализовать необходимые функции перевода координат
  */
template <typename scalar, int dim, int kinematicType> class kinematic
{
	private:
		scalar elems[dim]; //!< Элементы вектора
	public:
		
		//! Пустой конструктор
		kinematic ()
		{
			for (int i=0; i<dim; i++)
				elems[i] = 0;
		}

		//! Конструктор, создающий вектор из массива скаляров
		kinematic (const scalar*other)
		{
			for (int i=0; i<dim; i++)
				elems[i] = other[i];
		}

		//! Конструктор, создающий вектор из массива скаляров
		kinematic (const scalar & other)
		{
			for (int i=0; i<dim; i++)
				elems[i] = other;
		}

		/**  @brief Копирующий конструктор
		  *  @param other  Вектор, копию которого нужно создать.
		 **/
		kinematic (const kinematic<scalar, dim, kinematicType> & other)
		{
			for (int i=0; i<dim; i++)
			//!!!
				elems[i] = other[i];
		}

		/**  Оператор присваивания
		  *  @param other  Вектор, который нужно присвоить данному.
		 **/
		kinematic<scalar, dim, kinematicType>&operator=
			(const kinematic<scalar, dim, kinematicType>&other)
		{
			for (int i=0; i<dim; i++)
				elems[i] = other.elems[i];
			return (*this);
		}
	
		/** @brief Оператор сравнения
		  * @param rhs  Вектор, с которым нужно сравнить данный
		 **/
		bool operator==(const kinematic<scalar, dim, kinematicType>&rhs)
		const
		{
			bool eq = true;
			for (int i=0; i<dim; i++)
				eq = eq&&(elems[i]==rhs[i]);
			return eq;
		}
	
		/** @brief Оператор сложения
		 *  @param right  Вектор, который нужно сложить с данным.
		 *  Данный вектор не меняется, вместо этого создается новый.
		**/
		kinematic<scalar, dim, kinematicType> operator+
			(const kinematic<scalar,dim,kinematicType>&right) const
		{
			kinematic result;
			for (int i=0; i<dim; i++)
				result[i] = elems[i]+right.elems[i];
			return result;
		}

		/** @brief Оператор вычитания
		 *  @param right  Вектор, который нужно сложить с данным
		 *  Данный вектор не меняется, вместо этого создается новый.
		**/
		kinematic<scalar, dim, kinematicType> operator-
		(const kinematic<scalar, dim, kinematicType>&right) const
		{
			kinematic result;
			for (int i=0; i<dim; i++)
				result[i] = elems[i]-right.elems[i];
			return result;
		}


		/** @brief Оператор прибавления
		  * @param right  Вектор, который нужно прибавить к данному
		  * Данный вектор при этом меняется, нового не создается.
		 **/
		kinematic<scalar, dim, kinematicType>&operator+=
		(const kinematic<scalar, dim, kinematicType>&right)
		{
			for (int i=0; i<dim; i++)
				elems[i]+=right[i];
			return (*this);
		}
	
		/** @brief Оператор умножения вектора на скаляр
		 * @param alpha  Скаляр, на который нужно умножить данный вектор
		 * Данный вектор не меняется,  вместо этого создается новый.
		**/
		kinematic<scalar, dim, kinematicType> operator*
						(const scalar&alpha) const
		{
			kinematic result;
			for (int i=0; i<dim; i++)
				result[i] = elems[i]*alpha;
			return result;
		}
	
		/** @brief Оператор домножения на скаляр
		 * @param beta  Скаляр, на который нужно домножить данный вектор
		 * Данный вектор меняется, нового вектора не создается.
		**/
		kinematic<scalar, dim, kinematicType>&operator*=
						(const scalar&beta)
		{
			for (int i=0; i<dim; i++)
				elems[i]*=beta;
			return (*this);
		}
	
		/** @brief Оператор скалярного произведения
		 * @param beta Второй множитель
		 *  Данный вектор не меняется.
		**/
		scalar operator*
			(const kinematic<scalar, dim, kinematicType>&beta) const
		{
			scalar result=0;
			for (int i=0; i<dim; i++)
				result += elems[i]*beta[i];
			return result;
		}
		
		/** @brief Константный оператор индексации элементов вектора
		 * @param index  Индекс, по которому нужно обратиться.
		 *
		 *  Возвращенный элемент доступен для записи.
		**/
		const scalar&operator[] (int index) const
		{
		//!@ToDo В шаблоне kinematic отсутствует защита от дурака!
			return elems[index];
		}

		/** @brief Неконстантный оператор индексации элементов вектора
		 * @param index  Индекс, по которому нужно обратиться.
		 *
		 * Возвращенный элемент доступен для записи.
		**/
		scalar&operator[] (int index)
		{
		//!@ToDo В шаблоне kinematic отсутствует защита от дурака!
			return elems[index];
		}

		/** @brief Функция вычисления длины вектора
		 *
		 *  Вычисление длины осуществляется только по указанным в
		 * параметрах координатам
		 *
		 * @return Длина вектора
		**/
		template<int n0, int n1> scalar length () const
		{
			scalar result=0;
			for (int i=n0; i<=n1; i++)
			{
				scalar c=(*this)[i];
				result+=c*c;
			}
			return sqrt(result);
		}

		/** @brief Функция получения определённых компонент из вектора
		**/
		template<int n0, int n1> kinematic<scalar,n1-n0+1,kinematicType>
								subset() const
		{
			return kinematic<scalar,n1-n0+1,kinematicType>
								(&(elems[n0]));
		}
		
		/** @brief Функция присоединения одного вектора к другому
		* @param rhs Присоединяемый вектор
		* @return Конкатенация (this)(rhs)
		*/
		template<int dim1> kinematic<scalar,dim+dim1,kinematicType>
		concat (const kinematic<scalar,dim1,kinematicType> & rhs) const
		{
			kinematic<scalar,dim+dim1,kinematicType> result;
			for (int i=0; i<dim; i++)
				result[i] = (*this)[i];
			for (int i=0; i<dim1; i++)
				result[dim+i] = rhs[i];
			return result;
		}
		
		/** @brief Функция нахождения углового расстояния

		 * Находит угловое расстояние между двумя точками относительно
		 * данной точки.
		 *
		 *  @param A Координаты первой точки
		 *  @param B Координаты второй точки
		 *  @return Угол между точками A и B с центром в данной точке
		 */
		scalar angleDist (const kinematic<scalar,dim,kinematicType>&A,
				  const kinematic<scalar,dim,kinematicType>&B)
		const
		{
			kinematic<scalar,dim,kinematicType> OA = A-(*this);
			kinematic<scalar,dim,kinematicType> OB = B-(*this);
			return arccos(OA*OB/(OA.length<0,dim-1>()*
							OB.length<0,dim-1>()));
		}

		/** @brief Оператор векторного произведения.
		 *
		 *  Возвращает значение. Исходный вектор не меняется.
		 * Определён только для векторов размерности 3.
		 *
		 *	@param rhs Второй сомножитель
		 */
		kinematic<scalar,3,kinematicType> crossProduct
			(const kinematic<scalar,3,kinematicType>& rhs) const
		{
			kinematic<scalar,dim,kinematicType> result;
			if (dim==3)
			{
				result[0] = elems[1]*rhs[2]-elems[2]*rhs[1];
				result[1] = elems[2]*rhs[0]-elems[0]*rhs[2];
				result[2] = elems[0]*rhs[1]-elems[1]*rhs[0];
			}
			return result;
		}

		//! Метод, делящий вектор на его норму
		kinematic<scalar,dim,kinematicType> normalize() const
		{
			scalar mynorminv = 1/length<0,dim-1>();
			kinematic<scalar,3,kinematicType> result;
			for (unsigned int i=0; i<dim; i++)
				result[i] = elems[i]*mynorminv;
			return result;
		}

};


/**
 * @brief Умножение вектора на матрицу
 *
 * @ingroup core
 *
 * @tparam scalar Тип скаляров в векторах и матрицах
 * @tparam dim_in Размерность входного вектора
 * @tparam dim_out Размерность выходного вектора
 * @tparam kinematicType_in Тип системы координат входного вектора
 * @tparam kinematicType_out Тип системы координат выходного вектора
 * @tparam Matrix Класс для хранения матрицы
 * @param v Вектор
 * @param m Матрица
 *
 * Класс Matrix должен быть реализован так, чтобы можно было извлекать
 * элемент i-й строки j-го столбца оператором с помощью квадратных скобок:
 * m[i][j].
 *
 * Матрица должна иметь dim_in строк и dim_out столбцов.
 */
template<typename scalar, int dim_in, int dim_out, int kinematicType_in,
		 int kinematicType_out, typename Matrix>
kinematic<scalar, dim_out, kinematicType_out> mulVM(
		const kinematic<scalar,dim_in,kinematicType_in> & v,
		const Matrix & m)
{
	kinematic<scalar,dim_out,kinematicType_out> result;
	for (unsigned int i=0; i<dim_out; i++)
	{
//		result[i] = (scalar)(0); //Вектор создаётся уже нулевой
		for (unsigned int j=0; j<dim_in; j++)
			result[i] += v[j]*m[j][i];
	}
	return result;
}

/**
 * @brief Умножение матрицы на вектор
 *
 * @ingroup core
 *
 * @tparam scalar Тип скаляров в векторах и матрицах
 * @tparam dim_in Размерность входного вектора
 * @tparam dim_out Размерность выходного вектора
 * @tparam kinematicType_in Тип системы координат входного вектора
 * @tparam kinematicType_out Тип системы координат выходного вектора
 * @tparam Matrix Класс для хранения матрицы
 * @param v Вектор
 * @param m Матрица
 *
 * Класс Matrix должен быть реализован так, чтобы можно было извлекать
 * элемент i-й строки j-го столбца оператором с помощью квадратных скобок:
 * m[i][j].
 *
 * Матрица должна иметь dim_out строк и dim_in столбцов.
 */
template<typename scalar, int dim_in, int dim_out, int kinematicType_in,
		 int kinematicType_out, typename Matrix>
kinematic<scalar, dim_out, kinematicType_out> mulMV(
		const Matrix & m,
		const kinematic<scalar,dim_in,kinematicType_in> & v
		)
{
	kinematic<scalar,dim_out,kinematicType_out> result;
	for (unsigned int i=0; i<dim_out; i++)
	{
//		result[i] = (scalar)(0); //Вектор создаётся уже нулевой
		for (unsigned int j=0; j<dim_in; j++)
			result[i] += v[j]*m[i][j];
	}
	return result;
}


template <typename scalar, int dim, int kinematicType>
kinematic<scalar, dim, kinematicType> operator*
(const scalar&a, const kinematic<scalar, dim, kinematicType>&b)
{
	kinematic<scalar, dim, kinematicType> result;
	for (int i=0; i<dim; i++)
		result[i] = a*b[i];
	return result;
}

template < typename streamtype, typename scalar, int dim, int kinematicType > streamtype & operator<<(streamtype & str,
												      const kinematic<scalar,dim,kinematicType>&vec)
{
	for (unsigned int i=0; i<dim; i++)
	{
		if (i>0)
			str<<" ";
		str<<floattostr<scalar>(vec[i]);
	}
	return str;
}

}

#endif

#include <sstream>
#include <set>

//! @file

#include <gnssconfig.h>

#ifdef WithQT
#include <QScriptEngine>
#include <QScriptValue>
#include <QDebug>
#endif

#include <StdTables.h>
#include <BuiltIn.h>

namespace libgnss
{


CelestialBodies::CelestialBodies(DBTableCollection *base)
	: DBTable (Columns()
		   <<Column(Variant::TYPE_INT, "body_id"),
		   Columns()
		   <<Column(Variant::TYPE_STRING, "caption")
		  <<Column(Variant::TYPE_DOUBLE, "grav_parameter")
		 <<Column(Variant::TYPE_DOUBLE, "radius")
		<<Column(Variant::TYPE_DOUBLE, "flattening"))
{
	base->addTable("celestial_bodies", this);
	Base = base;
}

void CelestialBodies::loadDefaultValues()
{
	string data=
			"celestial_bodies	1	меркурий	22039.807416	2439.7	0.0006\n"
			"celestial_bodies	2	венера	324937.3218	6051.8	0\n"
			"celestial_bodies	3	земля	398600.4418	6378.1366	0.00345713060397332\n"
			"celestial_bodies	4	марс	42838.86618	3386.2	0.00589\n"
			"celestial_bodies	5	юпитер	126717880.08	66854	0.06487\n"
			"celestial_bodies	6	сатурн	37940612.088	54364	0.09796\n"
			"celestial_bodies	7	уран	5795544.2952	25559	0.02293\n"
			"celestial_bodies	8	нептун	6836465.004	24767	0.0171\n"
			"celestial_bodies	9	плутон	870.99354	1195	0\n"
			"celestial_bodies	11	солнце	132712400000	696000	9e-06\n"
			"celestial_bodies	10	луна	4902.799186	1738	0.00125\n";
	istringstream is(data);
	ostringstream s1;
	try
	{
		Base->readFromStream(is,s1);
	}
	catch (DuplicateKeyException e)
	{

	}
}

#ifdef WithQT
QScriptValue addstd(QScriptContext * ctx, QScriptEngine * eng)
{
	if (!(ctx->argument(0).isQObject()))
	{
		qDebug()<<"Not a QObject!";
	}
	QObject * obj = ctx->argument(0).toQObject();
	DBTableCollection * c = (DBTableCollection *)(obj);
	Settings * sets = new Settings (c);
	LeapSeconds * leaps = new LeapSeconds (c);
	SatelliteHistory * shis = new SatelliteHistory (c);
	CelestialBodies * cbd = new CelestialBodies (c);
	cbd->loadDefaultValues();
	return QScriptValue();
}

BuiltIn addstd_ ("addStdTables", 1, addstd);
#endif


//-----------ПРИЕМНИКИ-ПЕРЕДАТЧИКИ----------------------//

NavigationSystem::NavigationSystem(DBTableCollection *base)
	: DBTable(Columns()
			  <<Column(Variant::TYPE_CHAR, "system_letter"),
			  Columns()
			  <<Column(Variant::TYPE_STRING, "system_title")
			 <<Column(Variant::TYPE_STRING, "operator"))
{
	base->addTable("navigation_systems", this);
}

SatelliteHistory::SatelliteHistory(DBTableCollection *base)
	: NumeratedTable (Columns()
					  <<Column(Variant::TYPE_CHAR, "system_letter")
					  <<Column(Variant::TYPE_INT, "satellite_id")
					 <<Column(Variant::TYPE_INT, "new_slot")
					<<Column(Variant::TYPE_DATETIME, "since_datetime")
					 <<Column(Variant::TYPE_DATETIME, "till_datetime"))
{
	base->addTable("satellite_history", this);
	createIndex("sys_slot_since", OperatorPushableVector<string>()
				<<"system_letter"<<"new_slot"<<"since_datetime");
	createIndex("sys_id_since", OperatorPushableVector<string>()
				<<"system_letter"<<"satellite_id"<<"since_datetime");
}

string SatelliteHistory::getShortSatName(int history_id) const
{
	const Tuple * detail = &(read(history_id));
	char sysletter = (*detail)[0].toChar();
	int slot = (*detail)[2].toInt();
	string s_slot = Variant(slot).toString();
	if (s_slot.length() == 1)
		s_slot = "0"+s_slot;
	return string(1,sysletter)+s_slot;
}

int SatelliteHistory::getSatHistoryID(char system, int prn, const UTCDateTime&dt)
const
{
	//Попытаться найти НКУ для данной даты и номера слота
	DBTable::DBConstIterator it0 = idx_lower_bound("sys_slot_since",
		Tuple()<<system<<prn<<dt);
	
	//Если не найден, то вернуть ошибку
	if (it0 == const_end())
		throw
		NoPRNForDateException(toShortSatelliteName(system,prn),
							  dt.getUTCDateTimeString());

	//Если требуемая дата не укладывается в интервал, вернуть ошибку
	if (it0[4].toUTCDateTime() < dt)
		throw
		NoPRNForDateException(toShortSatelliteName(system,prn),
							  dt.getUTCDateTimeString());
		
	//Если всё нормально, вернуть результат
	return it0.keyColumnValue(0).toInt();
}

int SatelliteHistory::getSatHistoryID(char system, int prn, real tai) const
{
	return getSatHistoryID(system,prn, UTCDateTime::fromTAIJ2000(tai));
}

int SatelliteHistory::getSatHistoryID(const string&sys_prn, const UTCDateTime&dt)
const
{
	pair < char, int > sysprn = fromShortSatelliteName(sys_prn);
	return getSatHistoryID(sysprn.first, sysprn.second, dt);
}

int SatelliteHistory::getSatHistoryID (const string & sys_prn, real tai )
const
{
	return getSatHistoryID(sys_prn, UTCDateTime::fromTAIJ2000(tai));
}

void SatelliteHistory::chooseSatellites(const Tuple &nameslist)
{
	set<string> names_set;
	for (Tuple::const_iterator it=nameslist.begin(); it!=nameslist.end(); ++it)
		names_set.insert((*it).toString());
	DBTable::DBConstIterator it = const_begin();
	while (true)
	{
		if (it == const_end())
			break;
		int sat_history_id = it.keyColumnValue(0).toInt();
		it++;
		int sat_history_id_1;
		if (it != const_end())
			sat_history_id_1 = it.keyColumnValue(0).toInt();
		else
			sat_history_id_1 = - 1;

		string thissatname = getShortSatName(sat_history_id);
		if (names_set.find(thissatname) == names_set.end())
			deleteRows(Tuple()<<sat_history_id);

		it = find(sat_history_id_1);
	}
}

#ifdef WithQT
int SatelliteHistory::getSatelliteHistoryID (const QString & sys_prn,
											 double tai) const
{
	return getSatHistoryID(sys_prn.toStdString(), tai);
}

QString SatelliteHistory::getShortSatelliteName(int history_id) const
{
	return QString::fromStdString(getShortSatName(history_id));
}

void SatelliteHistory::chooseSatellites(const QVariantList & nameslist)
{
	chooseSatellites(variantListToTuple(nameslist));
}

#endif


Receivers::Receivers(DBTableCollection *base)
	:NumeratedTable(Columns()<<Column(Variant::TYPE_STRING,"serial_number")
					<<Column(Variant::TYPE_STRING,"description")
							 <<Column(Variant::TYPE_STRING,"model"))
{
	base->addTable("receivers", this);
	createIndex("serial_number",OperatorPushableVector<string>()
				<<"serial_number");
}

int Receivers::getReceiverID(const string serial_number) const
{
	DBConstIterator it=idx_find("serial_number", Tuple()<<serial_number);
	if (it.isEnd())
		return -1;
	else
		return it.keyColumnValue(0).toInt();
}

AntennaModels::AntennaModels(DBTableCollection *base)
	: NumeratedTable(Columns()
					 <<Column(Variant::TYPE_STRING, "model")
					 <<Column(Variant::TYPE_INT, "installation")
					<<Column(Variant::TYPE_STRING, "description"))
{
	base->addTable("antenna_models", this);
	createIndex("model", OperatorPushableVector<string>()
				<<"model");
}

int AntennaModels::getModelID(const string &model) const
{
	DBConstIterator it = idx_find("model",Tuple()<<model);
	if (it.isEnd())
		return -1;
	else
		return it.keyColumnValue(0).toInt();
}

ReceivingAntennas::ReceivingAntennas(DBTableCollection *base)
	: NumeratedTable(Columns()
					 //Серийный номер антенны
					 <<Column(Variant::TYPE_STRING,"serial_number")
					 //Описание антенны
						<<Column(Variant::TYPE_STRING,"description")
						 //Идентификатор модели антенны
					  <<Column(Variant::TYPE_INT,"antenna_model_id")
						//Идентификатор данных математической модели
						//сдвига фазового центра
			  )
{
	base->addTable("receiving_antennas", this);
	createIndex("serial_number",OperatorPushableVector<string>()
				<<"serial_number");
}

int ReceivingAntennas::getAntennaID(const string &serial_number) const
{
	DBConstIterator it = idx_find("serial_number",Tuple()<<serial_number);
	if (it.isEnd())
		return -1;
	else
		return it.keyColumnValue(0).toInt();
}

Markers::Markers(DBTableCollection *base)
	: NumeratedTable(Columns()<<Column(Variant::TYPE_STRING,"marker_name")
			  <<Column(Variant::TYPE_STRING,"marker_number")
					  <<Column(Variant::TYPE_STRING,"description")
					  <<Column(Variant::TYPE_INT,"marker_type")
					 <<Column(Variant::TYPE_DOUBLE,"approx_pos_x")
					   <<Column(Variant::TYPE_DOUBLE,"approx_pos_y")
						 <<Column(Variant::TYPE_DOUBLE,"approx_pos_z")
						<<Column(Variant::TYPE_DOUBLE, "approx_pos_lon")
					   <<Column(Variant::TYPE_DOUBLE, "approx_pos_lat")
					  <<Column(Variant::TYPE_DOUBLE, "approx_pos_h"))
{
	base->addTable("markers", this);
	createIndex("marker_name",OperatorPushableVector<string>()
				<<"marker_name");
}

int Markers::getMarkerID(const string &marker_name) const
{
	DBConstIterator it = idx_find("marker_name", Tuple()<<marker_name);
	if (it.isEnd())
		return -1;
	else
		return it.keyColumnValue(0).toInt();
}

kinematic < real, 3, defaultNonInert > Markers::getMarkerApproxPosition(int id)
const
{
	kinematic < real, 3, defaultNonInert > result;
	DBTable::DBConstIterator it0 = find(Tuple()<<id);
	if (it0 == const_end())
		throw KeyNotFoundException(Tuple()<<id);
	for (unsigned int i=0; i<3; i++)
		 result[i] = it0[4+i].toDouble();
	return result;
}

kinematic <real,3,defaultGeodetic> Markers::getMarkerApproxGeodeticPosition
(int id) const
{
	kinematic < real, 3, defaultGeodetic > result;
	DBTable::DBConstIterator it0 = find(Tuple()<<id);
	if (it0 == const_end())
		throw KeyNotFoundException(Tuple()<<id);
	for (unsigned int i=0; i<3; i++)
		 result[i] = it0[7+i].toDouble();
	return result;
}

}

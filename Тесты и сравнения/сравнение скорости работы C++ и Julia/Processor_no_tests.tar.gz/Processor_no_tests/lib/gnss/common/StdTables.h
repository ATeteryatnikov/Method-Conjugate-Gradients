#ifndef STDTABLES_H_
#define STDTABLES_H_

#include <string>

using namespace std;

//! @file

#include <Types.h>
#include <DBTable.h>
#include <DBTableCollection.h>
#include <UTCDateTime.h>
#include <Consts.h>
#include <Kinematic.h>
#include <LeapSeconds.h>
#include <Settings.h>

/** @file
  *
  * @brief Файл содержит определения основных таблиц, используемых в обработчике
  */

/**
 * @defgroup stdtbl Модуль справочных таблиц
 *
 * В справочных таблицах хранятся:
 * @li Сведения о космических аппаратах (с привязкой к SVN/GLONASS ID)
 * @li Сведения об истории изменения спутниковой группировки
 * @li Сведения о приёмниках (приёмник - устройство, обрабатывающее сигнал
 * от антенны)
 * @li Сведения об антеннах (антенна - устройство, принимающее спутниковый
 * сигнал)
 * @li Сведения о маркерах (монументах, на которых устанавливаются антенны)
 * @li Сведения о приёмных пунктах (приёмный пункт - это комплекс из
 * одного или нескольких приёмников, одной или нескольких антенн, установленных
 * на бетонном постаменте, "маркере", помещения, в котором находятся все
 * вычислительные устройства и средства сохранения и передачи данных)
 * (Примечание: кажется, информацию о приемных пунктах хранить не обязательно)
 * @li Сведения о математических моделях сдвигов фазового центра антенн
 *
 * Каждая измеренная величина
 * @li Основывается на принимаемом антенной сигнале
 * @li Обрабатывается некоторым приёмником
 * @li Собирается и передаётся с некоторого приёмного пункта
 *
 * Поэтому вводится дополнительная таблица, источник измерения, ассоциирующая
 * с каждой из названных троек конкретный идентификатор.
 */


namespace libgnss
{

class CelestialBodies : public DBTable
{
private:
	DBTableCollection * Base;
public:
	CelestialBodies(DBTableCollection * base);

	inline double getBodyGravParameter (int id)
	{
		return read(Tuple()<<id)[1].toDouble();
	}

	inline double getBodyRadius (int id)
	{
		return read(Tuple()<<id)[2].toDouble();
	}

	inline double getBodyFlattening (int id)
	{
		return read(Tuple()<<id)[3].toDouble();
	}

	void loadDefaultValues();
};

/**
 * @brief Таблица со списком навигационных систем
 *
 * @ingroup stdtbl
 *
 * Ключ: char system_letter - буква G = GPS, R=ГЛОНАСС, E=GALILEO,...
 *
 * Значения:
 * @li system_title Полное название системы
 * @li operator Оператор системы
 *
 * Название: navigation_systems
 */
class NavigationSystem : public DBTable
{
public:
	NavigationSystem(DBTableCollection * base);
};

/**
 * @brief Исключение: prn (слот) на заданный момент времени не присвоен
 *
 * @ingroup except
 */
class NoPRNForDateException : public StrException
{
public:
	NoPRNForDateException ( const string & S_PRN, const string & date )
		: StrException ("NoPRNForDateException",
						"На заданную дату `"+date+"' не задани ни одного НКА "
						"с идентификатором "+S_PRN)
	{

	}
};

/**
 * @brief История изменения положений НКА в космических группировках
 *
 * @ingroup stdtbl
 *
 * Таблица содержит информацию об изменении состава НКА в навигационных
 * системах.
 *
 * Ключ:
 * @li int autoinc - автоматически инкриминируемый ключ
 *
 * Значения:
 * @li char system_letter Буква-идентификатор навигационной системы
 * @li int satellite_id Физический номер НКА
 * @li int new_slot Номер орбитального слота (ГЛОНАСС) или PRN (GPS)
 * @li datetime since_datetime С какого времени обозначенные
 * @li datetime till_datetime До какого момента НКА работал в данном слоте
 *
 * Для поиска информации по номеру слота введён индекс sys_slot_since с полями
 * system_letter, new_slot, since_datetime, и индекс sys_id_since с полями
 * system_letter, satellite_id, since_datetime.
 */
class SatelliteHistory : public NumeratedTable
{
	Q_OBJECT
public:
	/**
	 * @brief Преобразование буквы системы и номер слота в короткое имя НКА
	 * @param system Буква системы: G=GPS, R=GLONASS,  ...
	 * @param slot Слот НКА в системе, от 0 до 99.
	 * @return Имя в формате SNN, где S=system, NN=slot ('0slot', если slot<10)
	 */
	inline static string toShortSatelliteName(char system, int slot)
	{
		stringstream s0;
		s0<<system;
		if (slot<10)
			s0<<"0";
		s0<<slot;
		return s0.str();
	}

	/**
	 * @brief Преобразование короткого имени НКА в пару (буква, номер слота)
	 * @param s Короткое имя НКА вида SNN, S-буква, NN-слот (или 0слот, слот<10)
	 * @return Пара (Буква, Номер слота)
	 */
	inline static pair < char, int > fromShortSatelliteName (const string & s)
	{
		pair < char, int > result;
		result.first = s[0];
		result.second = 10*(int(s[1])-int('0')) + int(s[2])-int('0');
		return result;
	}

public:
	SatelliteHistory ( DBTableCollection * base );

	/**
	 * @brief Получить идентификатор НКА по его слоту на заданную дату
	 *
	 * В каждый момент времени НКА занимает один из орбитальных слотов.
	 * Наоборот, в каждой навигационной системе по номеру слота можно
	 * в каждый момент времени определить, какой НКА его занимает.
	 *
	 * @param system Буква навигационной системы
	 * @param prn Номер слота
	 * @param dt Дата
	 * @return Идентификатор НКА
	 */
	int getSatHistoryID (char system, int prn, const UTCDateTime & dt)
	const;

	/**
	 * @brief Вычислить идентификатор НКА по короткому имени на момент времени
	 *
	 * Короткое имя - строка SNN, где S - буква системы, NN - номер слота (PRN)
	 * спутника.
	 *
	 * @param sys_prn Короткое имя НКА
	 * @param dt Требуемые дата/время
	 * @return Идентификатор НКА
	 */
	int getSatHistoryID (const string & sys_prn, const UTCDateTime & dt)
	const;

	/**
	 * @brief Вычислить идентификатор НКА по короткому имени на момент времени
	 *
	 * Короткое имя - строка SNN, где S - буква системы, NN - номер слота (PRN)
	 * спутника.
	 *
	 * @param sys_prn Короткое имя НКА
	 * @param tai Момент времени, секунды TAI от эпохи J2000
	 * @return Идентификатор НКА
	 */
	int getSatHistoryID (const string & sys_prn, real tai ) const;

	/**
	 * @brief Получить идентификатор НКА по его слоту на момент времени
	 *
	 * В каждый момент времени НКА занимает один из орбитальных слотов.
	 * Наоборот, в каждой навигационной системе по номеру слота можно
	 * в каждый момент времени определить, какой НКА его занимает.
	 *
	 * @param system Номер навигационной системы
	 * @param prn Номер слота
	 * @param tai Момент времени, секунды TAI от эпохи J2000
	 * @return Идентификатор НКА
	 */
	int getSatHistoryID (char system, int prn, real tai) const;

	/**
	 * @brief Возвращает короткое имя НКА (Буква)(Слот)
	 * @param history_id Идентификатор истории НКА
	 * @return (Буква)(Слот), например, G01
	 */
	string getShortSatName (int history_id) const;

	/**
	 * @brief Удалить все НКА, кроме перечисленных в списке
	 * @param Список НКА, которые необходимо оставить
	 *
	 * Все алгоритмы чтения данных сохраняют в таблицы данные только тех НКА,
	 * которые есть в таблице @ref SatelliteHistory . Удалив некоторые НКА из
	 * таблицы, мы, тем самым наложим ограничение на считывание данных из файлов
	 * и их обработку.
	 *
	 * Список НКА представляет с собой массив строк вида <Буква><Слот|PRN>,
	 * например, "G01","G02","G03".
	 */
	void chooseSatellites(const Tuple & nameslist);

#ifdef WithQT
public slots:

	int getSatelliteHistoryID (const QString & sys_prn, double tai) const;
	QString getShortSatelliteName(int history_id) const;
	void chooseSatellites(const QVariantList & nameslist);
#endif

};

/**
 * @brief Таблица с информацией о приёмниках
 *
 * @ingroup stdtbl
 *
 * О приёмниках хранится следующая информация:
 *
 * Ключ:
 * int autoinc - автоматически инкрименируемый ключ
 *
 * Значения:
 * @li string serial_number
 * @li string description
 * @li string model
 *
 * Введен дополнительный индекс "serial_number" по соответствующему полю.
 *
 */
class Receivers : public NumeratedTable
{
public:
	Receivers(DBTableCollection * base);

	/**
	 * @brief Возвращает идентификатор приёмника по серийному номеру
	 * @param serial_number Серийный номер
	 * @return  Числовой идентификатор, или -1, если приёмник не найден
	 */
	int getReceiverID(const std::string serial_number) const;
};

/** @brief Модели антенн
 *
 * @ingroup stdtbl
 * 
 * Ключ: автоматически инкриминируемое поле int autoinc
 * 
 * Значения:
 * @li string model Обозначение модели (обозначения IGS: rcvr_ant.tab)
 * @li int installation 0 - устанавливается на НКА, 1 - устанавливается на БИС
 * @li string description - текстовое описание
 * 
 * Введён дополнительный индекс "model" по полю "model".
 */
class AntennaModels : public NumeratedTable
{
public:
	AntennaModels(DBTableCollection * base);

	/**
	 * @brief Возвращает идентификатор модели антенны по её названию
	 * @param model Название модели антенны
	 * @return  Идентификатор модели, или -1, если модель антены не найдена
	 */
	int getModelID(const std::string & model) const;
};

/**
 * @brief Таблица с информации о приемных антеннах
 *
 * @ingroup stdtbl
 *
 * Ключ: автоматически инкриминируемое поле int autoinc
 * 
 * Значения:
 * @li string serial_number Серийный номер
 * @li string description Описание
 * @li int antenna_model_id Идентификатор модели антенны
 * 
 * Таблица имеет дополнительный индекс "serial_number" по полю "serial_number".
 */
class ReceivingAntennas : public NumeratedTable
{
public:
	ReceivingAntennas (DBTableCollection * base);

	/**
	 * @brief Возвращает идентификатор антенны по серийному номеру
	 * @param serial_number Серийный номер антенны
	 * @return Идентификатор антенны, или -1, если антенна не найдена
	 */
	int getAntennaID(const std::string & serial_number) const;
};

/**
 * @brief Таблица с информацией о маркерах
 *
 * @ingroup stdtbl
 *
 * Маркер - это монумент, на который устанавливается антенна.
 * Различные типы маркеров описывает тип MarkerType, который однозначно
 * соотносится с целыми числами от 0 до 14.
 *
 * Ключ - автоматически инкрименируемое поле int autoinc.
 *
 * Значения:
 * @li string marker_name - 4-х буквенный идентификатор маркера
 * @li string marker_number - серийный номер маркера (содержит цифры и буквы)
 * @li string description - описание маркера
 * @li int marker_type - тип маркера.
 * @li double approx_pos_x - приблизительное положение, координата X
 * @li double approx_pos_y - приблизительное положение, координата Y
 * @li double approx_pos_z - приблизительное положение, координата Z
 * @li double approx_pos_lon - приблизительная долгота, радианы
 * @li double approx_pos_lat - приблизительная широта, радианы
 * @li double approx_pos_h - приблизительное возвышене, километры
 *
 * Приблизительное положение маркера задаётся в геоцентрической гринвичской
 * системе координат. В силу низкой точности задания приблизительного
 * положения (например, в SINEX-файлах задаётся широта/долгота/высота всего
 * 8 значащими цифрами) не имеет смысла хранить информацию о том, в какой
 * именно TRS-системе отсчета задаётся положение.
 *
 * Типы маркера приводятся в описании формата RINEX 3.0. Целые константы для
 * типов задаются в @ref Markers::MarkerType.
 *
 * Имя таблицы в хранилище: "markers".
 *
 * Для быстрого поиска создан дополнительный индекс "marker_name" по
 * единственному полю "marker_name".
 */
class Markers : public NumeratedTable
{
private:
	//Геодезические координаты маркеров
	map < int, kinematic < real, 3, defaultGeodetic > > geocoords;

	//Пересчитать геодезические координаты маркера
	int markerGeodPos(int marker_id);
public:
	enum MarkerType
	{
		MT_GEODETIC = 0,
		MT_NON_GEODETIC = 1,
		MT_NON_PHISICAL = 2,
		MT_SPACEBORNE = 3,
		MT_AIRBORNE = 4,
		MT_WATER_CRAFT = 5,
		MT_GROUND_CRAFT = 6,
		MT_FIXED_BUOY = 7,
		MT_FLOATING_BUOY = 8,
		MT_FLOATING_ICE = 9,
		MT_GLACIER = 10,
		MT_BALLISTIC = 11,
		MT_ANIMAL = 12,
		MT_HUMAN = 13,
		MT_OTHER = 14
	};

	Markers ( DBTableCollection * base);

	/**
	 * @brief Возвращает идентификатор маркера по его имени
	 * @param marker_name Имя маркера (4 символа - заглавные буквы и цифры)
	 * @return Идентификатор маркера, или -1, если маркер не найден
	 */
	int getMarkerID(const std::string & marker_name) const;

	/**
	 * @brief Вернуть приблизительное положение маркера
	 * @param id Идентификатор маркера
	 * @return Координаты маркера во вращающейся системе координат, км.
	 *
	 * В случае, если маркера нет в таблице, будет сгенерировано исключение
	 * KeyNotFoundException.
	 */
	kinematic < real, 3, defaultNonInert > getMarkerApproxPosition(int id)
	const;

	/**
	 * @brief Вернуть приблизительные геодезические координаты маркера
	 * @param id Идентификатор маркера
	 * @return Долгота (рад), Широта (рад), Высота над геоидом WGS84 (км).
	 *
	 * В случае, если маркера нет в таблице, будет сгенерировано исключение
	 * KeyNotFoundException.
	 */
	kinematic < real, 3, defaultGeodetic > getMarkerApproxGeodeticPosition
	(int id) const;
};




//class SatelliteHistory : public DBTable
//{
//public:
//	SatelliteHistory(DBTableCollection * base)
//		: DBTable (Columns()
//			   <<Column(Variant::TYPE_STRING, "caption")
//			  <<Column(Variant::TYPE_DOUBLE, "since"),
//			   Columns()
//			   <<Column(Variant::TYPE_INT, "satellite_id"))
//	{
//		(*base)["satellite_history"] = this;
//	}
//};

}

#endif


#ifndef PRECMATH_H_
#define PRECMATH_H_

/// @file

#include <cmath>
#include <ios>

using namespace std;

inline double arccos(double x){
        if(x>1) return acos(1);
        if(x<-1) return acos(-1);
        return acos(x);
}

inline long double arccos(long double x){
        if(x>1) return acos(1);
        if(x<-1) return acos(-1);
        return acos(x);
}

#ifdef WITH_FLOAT128_

inline __float128 fabs( __float128 x )
{
	return (x>0)?x:(0-x);
}

inline __float128 arccos(__float128 x){
	return (__float128)arccos((long double)x);
}

inline __float128 acos(__float128 x){
	return __float128(acos(double(x)));
}

inline __float128 asin(__float128 x)
{
	return __float128(asin(double(x)));
}

inline ostream & operator<<(ostream & A, const __float128 & x)
{
	return (A<<(long double)x);
}

inline __float128 sqrt(__float128 x)
{
	__float128 s0 = sqrt((long double)x);
	return (s0+(x-s0*s0)/(2.0*s0));
}

inline __float128 cos ( __float128 x )
{
	//! @todo Сделать вычисление функции в float128
	return __float128(cos(double(x)));
}

inline __float128 log ( __float128 x )
{
	//! @todo Сделать вычисление функции в float128
	return __float128(log((double)(x)));
}

inline __float128 floor ( __float128 x )
{
	//! @todo Сделать вычисление функции в float128
	return __float128(floor(double(x)));
}

inline __float128 exp( __float128 x )
{
	return __float128(exp(double (x)));
}

inline __float128 pow( __float128 x, int y )
{
	return __float128(pow(double (x), double(y)));
}

inline __float128 sin( __float128 x )
{
	return __float128(sin(double (x)));
}

#endif

#endif

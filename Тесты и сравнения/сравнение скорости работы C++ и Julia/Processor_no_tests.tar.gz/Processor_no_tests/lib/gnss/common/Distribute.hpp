/** @file
  *
  * Файл содержит функции, созданные для распределения задач
  * между процессами. Все функции данного модуля подразумевают
  * один и тот же способ распределения задач.
  */

#ifndef DISTRIBUTE_HPP___
#define DISTRIBUTE_HPP___

/* Распределение кроликов по клеткам
 *
 *  Пусть у нас имеется набор одинаковых задач с номерами от fist до last,
 *  (включая last, т.е. существует задача с номером last)
 *  параллельная система размером commsize, вызывающий поток имеет номер
 *  commrank. Функция вычисляет задачи с какими номерами должен выполнять
 *  данный поток. Задача аналогична рассаживанию пронумерованных кроликов
 *  по клеткам: кролики с номерами в каком промежутке должны сидеть в клетке
 *  с номером commrank?
 *  
 */

namespace libgnss
{

/** Функция, распределяющая задачи между процессами.
*
*  Имеется набор одинаковых задач с номерами от fist до last (включая last),
*  параллельная система размером commsize, вызывающий поток имеет номер
*  commrank. Функция вычисляет задачи с какими номерами должен выполнять
*  данный поток.
*
*  @param first Наименьший номер задачи.
*  @param last Наибольший номер задачи.
*  @param commsize Число доступных процессов.
*  @param commrank Ранг текущего процесса.
*
*  @return Пара значений (first, second), задачи с номерами от first до second
*  (включительно) выполняются в процессе commrank.
*/
inline pair<unsigned int, unsigned int> distribute(unsigned int first,
		unsigned int last, unsigned int commsize, unsigned int commrank)
{
	unsigned int count = last-first+1;
	pair<unsigned int, unsigned int> result;
	if(count<commsize) {
		if(commrank<=count-1)
		{
			result.first = result.second= first+commrank;
			return result;
		}
		result.first=1;
		result.second=0;
		return result;
	}	
	result.first = commrank * count / commsize + first;
	result.second = ((commrank+1) * count / commsize) + first - 1;
	return result;
}

/*  Узнать какой кролик оказался в какой клетке
  *
  * Пусть задачи с номерами от first до last включительно были распределены
  * между commsize процессами с помощью функции @ref distribute. Какой процесс
  * будет выполнять задачу с заданным номером taskNumber?
  */

/** Функция определяет какой процесс будет выполнять задачу с заданным номером
*
* Задачи с номерами от first до last включительно были распределены между
* commsize процессами с помощью функции @ref distribute. Данная функция
* определяет, какой процесс будет выполнять задачу с заданным номером
* taskNumber.
*
* @param first Наименьший номер задачи.
* @param last Наибольший номер задачи.
* @param commsize Число доступных процессов.
* @param taskNumber Номер интересующей задачи.
*
* @return Номер процесса, который будет выполнять задачу с запрошенным номером.
*/
inline unsigned int whichProcess (unsigned int first, unsigned int last,
				 unsigned int commsize, unsigned int taskNumber)
{
	for (unsigned int i=0; i<commsize; i++)
	{
		pair <unsigned int, unsigned int> tp =
					distribute(first,last,commsize,i);
		if ((tp.first <= taskNumber) && (tp.second>=taskNumber))
			return i;
	}

	return -1;
}

}
#endif

#include <cmath>

using namespace std;

//! @file

#include <BuiltIn.h>
#include <DBInterpolate.h>
#include <Interpolate.hpp>
#include <derivate.hpp>
#include <basis.h>
#include <limits>

namespace libgnss
{

ApproximationError::ApproximationError()
	: StrException("ApproximationError","Ошибка аппроксимации")
{

}

TableInappropriateForInterpolation::TableInappropriateForInterpolation
		(const string &details)
	:StrException("TableInappropriateForInterpolation",
				  "Таблица не подходит для интерполяции: "+details)
{

}

real interpolate (
		const DBTable & table,
		const DBTable * discontinuities,
		const Tuple & key0,
		real x0,
		unsigned int valueColumnIndex,
		int interpolateOrder,
		real allowextrapolate,
		real maxstep
		)
{
	//Выбрать узлы интерполяции
	vector < real > args;
	vector < real > vals;
	args.reserve(interpolateOrder);
	vals.reserve(interpolateOrder);
	getNeighbourhood<real>(args, vals, table, discontinuities, key0, x0,
					 valueColumnIndex, interpolateOrder, allowextrapolate,
					 maxstep);
	return interpolateLagrange(args,vals,x0);
}

vector <real> approximate (const DBTable & table,
							  const DBTable * discontinuities,
		const Tuple & key0,
		real x0,
		unsigned int valueColumnIndex,
		int numpoints,
		int approximateOrder,
		int derivs,
		real allowextrapolate,
		real maxstep
							  )
{
	vector < double > args;
	vector < double > values;
	args.reserve(numpoints);
	values.reserve(numpoints);
	getNeighbourhood<double>(args,values,table,discontinuities,key0,x0,
					 valueColumnIndex,numpoints, allowextrapolate, maxstep);

	//Выбрать правильно порядок аппроксимации
	int appord = approximateOrder;  //Степень полинома должна быть меньше
									//числа узлов
	if (appord>=args.size())
		appord = args.size() - 1;

	//Степень полинома должна быть не меньше числа производных
	if (appord < derivs)
		throw ApproximationError();

	//Создать многочлен, аппроксимирующий значения
	DifferentiableFit<PowerOfX,double> df(args,values, 
										  powerBasis(appord+1));
	
	vector< real > result;
	result.push_back(df.operator()(x0));
	for (unsigned int i=0; i<derivs; i++)
		result.push_back(df.derivative(i+1,x0));

	return result;
}

}

#include <gnssconfig.h>

#ifdef WithQT
#include <BuiltIn.h>
#include <ephemeris.h>

namespace libgnss
{

//--------------------Встроенные функции для внешних библиотек----------------//

//--------------------JPLEPH--------------------------------------------------//

QScriptValue jpleph(QScriptContext * ctx, QScriptEngine * eng)
{
	int bodyid = ctx->argument(0).toInt32();
	real t = ctx->argument(1).toNumber();
	kinematic<real,3,defaultInert> pos = getCelestialBodyEphemerides(bodyid,t);
	QVariantList result;
	result<<QVariant(double(pos[0]))<<QVariant(double(pos[1]))
											<<QVariant(double(pos[2]));
	return eng->toScriptValue<QVariantList>(result);
}

QScriptValue soe(QScriptContext * ctx, QScriptEngine * eng)
{
	kinematic < real, 3, defaultInert > pos;
	QVariantList l = ctx->argument(0).toVariant().toList();
	pos[0]=l[0].toDouble(); pos[1]=l[1].toDouble(); pos[2]=l[2].toDouble();
	real t = ctx->argument(1).toNumber();
	real soe = angleSunEarthObject(pos,t);
	return eng->toScriptValue<double>((double)(soe));
}

BuiltIn jpleph_ ("getCelestialBodyEphemerides", 2, jpleph);
BuiltIn soe_ ("angleSunEarthObject", 2, soe);

}

#endif

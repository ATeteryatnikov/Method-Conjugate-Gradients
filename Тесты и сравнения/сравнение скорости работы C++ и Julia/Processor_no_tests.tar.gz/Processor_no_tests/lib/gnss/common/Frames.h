#ifndef FRAMES_H_
#define FRAMES_H_

#include <limits>
#include <map>
#include <set>
#include <string>

using namespace std;

//! @file

#include <Types.h>
#include <Kinematic.h>
#include <DBTable.h>
#include <DBError.h>
#include <Consts.h>

namespace libgnss
{

typedef kinematic<real,3,defaultNonInert> PosNonInert;
typedef kinematic<real,3,defaultGeodetic> PosGeodetic;

class ERPStorage;
class ITRFTranslation;
class Settings;
class DBTableCollection;


// Файл содержит подпрограммы для работы с различными системами координат

/** @brief Ошибка, которая возникает, когда данные о запрашиваемой системе
  * координат не найдены в таблице
  *
  * @ingroup except
  */
class InvalidFrameException : public StrException
{
public:
	InvalidFrameException ( int frame_id );
};

/** @brief Ошибка, которая возникает, когда для перевода координат недостаточно
  * данных
  *
  * @ingroup except
  */
class CannotConvertFrameException : public StrException
{
public:
	CannotConvertFrameException ( string frame0, string frame1 );
};


/** @brief Класс, ответственный за переходы между системами координат
 *
 * @ingroup coordsys
  *
  * Хранит о системах координат следующую информацию:
  * 
  * Ключ:
  * int frame_id - идентификатор системы координат
  * 
  * Значения:
  * @li int frame_type - тип системы координат
  * @li string frame_title - строковый заголовок системы координат
  * 
  * Кратко о работе с координатами в Обработчике.
  *
  * Обработчик принимает разных системах координат. При этом, необходимо
  * выделить одну наземную систему координат и соответствующую ей инерциальную
  * систему координат типа GCRS. Различные GCRS-системы координат внутри
  * Обработчика не различаются.
  *
  * Основная функция данного класса - сохранять соотношения между системами
  * координат и координатами, используемых в траекториях. Каждая система
  * координат относится к одному из типов: наземная (Frames::FT_ITRS),
  * геоцентрическая инерциальная (Frames::FT_ECIF), геодезическая
  * (Frames::FT_Geodesic), орбитальные элементы (Frames::FT_Elements)
  * и фиктивная система координат (Frames::FT_Fake).
  *
  * Фиктивная система координат используется для предоставления вместе
  * с траекторией дополнительной информации.
  *
  * Каждая система координат имеет своё имя и связанный с ней набор координат
  * (таблица CoordinateTypes). Каждая координата имеет идентификатор, различный
  * в разных системах координат. Кроме того, каждая координата имеет свой номер
  * в пределах данной системы координат (например, X - 0, Y - 1, ...). При этом,
  * координаты в разных системах координат могут иметь одинаковые номера.
  *
  * Данный класс предоставляет возможность перевода координат из произвольной
  * системы в систему координат GCRS.
  *
  * Если исходно координаты заданы в системе координат GCRS, то преобразование
  * тождественно.
  *
  * Если исходные координаты заданы в наземной TRS-системе координат, то для
  * их перевода могут потребоваться следующие данные:
  * @li Если исходная TRS-система не совпадает с основной наземной системой,
  * то требуются параметры Гельмерта. Параметры Гельмерта и скорости их
  * изменения хранятся в таблице класса ITRFTranslation.
  * @li Требуются параметры вращения земли в основной наземной системе
  * координат. Если таблица ПВЗ (класс ERPStorage) отсутвтвует, то будет
  * сгенерирована ошибка. Если таблица есть, но пуста, будут использованы
  * нулевые ПВЗ.
  *
  */
class Frames : public NumeratedTable
{
	Q_OBJECT
public:
	static CTypeSelect * frameSelectorType ();

	//! Номер основной неинерциальной системы для быстрого доступа
	unsigned int defaultNonInertFrame() const;

private:

	unsigned int defnifr;

	//! Хранилище таблиц, в котором хранится данная таблица
	DBTableCollection * Base;

	//! Таблица настроек
	Settings * sets;

	//! Ссылка на таблицу для перевода между ITRS-системами координат
	ITRFTranslation * itrftranslator;

	//! Ссылка на таблицу ПВЗ для перехода между ITRS и ECI-системами
	ERPStorage * erpstorage;

	/** @brief Структура, хранящая номера координат для каждой системы
	  *
	  * Требутся для каждой системы координат уметь быстро находить
	  * упорядоченный набор координат, относящихся к данной системе.
	  * Делать это постоянным доступом в таблицу долго, поэтому удобно
	  * иметь "дополнительный индекс".
	  *
	  */
	map < int, vector < int > > coordinatesCaches;

	//! Метод, который строит индекс coordinatesCaches
	void cacheCoordinateTypes();

	//! Метод, который проверяет готовность внешних данных
	void checkExternal();

	//! Метод, который генерирует ошибку невозможности перехода между СК
	void cannotConvert ( int frame0, int frame1) const;

public:
	virtual void clearCoordinatesCache();

	enum FrameType
	{
		FT_ITRS = 0,
		FT_ECIF = 1,
		FT_Geodesic = 2,
		FT_Elements = 3,
		FT_Fake = 4
	};

	//! Создание объекта класса Frames и его регистрация в коллекции таблиц
	Frames(DBTableCollection * base);

	/** @brief Метод, возвращающий набор координат для данной системы
	  * @param frame_id Номер системы координат
	  */
	vector < int > getFrameCoordinates ( int frame_id ) const;

	/** @brief Метод, возвращающий полный набор координат, в котором лежит
	  * данная координата.
	  *
	  * Идентификаторы координат в различных системах координат различны.
	  * Данный метод по данному идентификатору находит систему координат,
	  * к которой относится, а затем возвращает полный набор координат
	  * для данной системы.
	  *
	  * @brief coordinate_id Номер координаты
	  *
	  */
	vector < int > getFullCoordinateSet ( int coordinate_id ) const;

	/** @brief Метод возвращает тип системы координат
	  *
	  * @param frame_id
	  */
	inline FrameType getFrameType ( int frame_id) const
	{
		//Поскольку метод с модификатором const, при отсутствии
		//информации о данной системе координат будет возвращена ошибка.
		return (FrameType)((*this)[Tuple()<<frame_id][0].toInt());
	}

	/** @brief Перевод координат точки из одной СК в GCRS
	  *
	  * Исходные координаты точки принимаются в системе координат,
	  * идентификатор которой указан в параметрах.
	  *
	  * @param pos Кинематические параметры точки в исходной СК
	  * @param src Идентификатор исходной СК
	  * @param t Момент времени
	  *
	  * @return Координаты точки в СК GCRS
	  */
	kinematic < real, 3, defaultInert > posInert
	( const vector < real > & pos, unsigned int src, real t) const;

	kinematic < real, 6, defaultInert > posVelInert
	( const vector < real > & pos, unsigned int src, real t) const;

	kinematic < real, 9, defaultInert > posVelAccelInert
	( const vector < real > & pos, unsigned int src, real t) const;

	int getCoordinateFrameID(const string & coordframetitle) const;

#ifdef WithQT
public slots:

	QVariantList getFrameCoordinatesSet (int frame_id) const;
	QVariantList completeCoordinatesSet (int coordinate_id) const;
	QString getTypeOfFrame (int frame_id) const;
	QVariantList getInertialFramePosition ( const QVariantList & pos,
											int src_frame_id, double t) const;
	QVariantList getInertialFramePositionVelocity
			( const QVariantList & pos, int src_frame_id, double t) const;
	QVariantList getInertialFramePositionVelocityAcceleration
			( const QVariantList & pos, int src_frame_id, double t) const;
	int getCoordFrameID (const QString & coordframetitle) const;
#endif
};

/** @brief Таблица, содержащая список возможных координат
 *
 * @ingroup coordsys
  *
  * Ключ:
  * int coordinate_id - идентификатор координаты
  *
  * Значения:
  * @li int frame_id Идентификатор системы координат
  * @li int coordinate_number Номер координаты (X=0,Y=1,Z=2,Vx=3,Vy=4,Vz=5,...).
  *
  *
  * В каждой системе координат вектор можно представить как вектор из нескольких
  * компонент. Будем называть координатой пару (Система координат,
  * номер компоненты).
  *
  * Для компактности такие пары нумеруются. Назовём номер такой пары
  * идентификатором координаты. Данная таблица содержит список координат,
  * используя в качестве ключа идентификатор. Это позволяет быстро найти по
  * идентификатору номер системы координат и номер компоненты, а также сохранять
  * порядок компонент в векторе.
  *
  * В различных таблицах положения тел указываются в виде:
  *
  * {(<Идентификатор координаты>, <Значение компоненты>)}
  *
  * Это позволяет гибко варировать число хранимых компонент, а также хранить
  * компоненты, соответствующие фиктивным системам координат, например, цвета,
  * или сужения произвольных векторных полей на траекторию КА, и т.д..
  *
  */
class CoordinateTypes : public NumeratedTable
{
public:
	CoordinateTypes (DBTableCollection * base);

	/** @brief Для данной координаты найти систему координат
	  *
	  * Координаты в различных системах координат могут иметь одинаковые
	  * номера, но имеют разные идентификаторы. По данному идентификатору
	  * можно определить, к какой системе координат относится координата.
	  *
	  * @param coordinate_id Идентификатор координаты
	  * @return Номер системы координат
	  */
	inline int getCoordinateFrame (int coordinate_id) const
	{
		//Поскольку метод с модификатором const, при отсутствии
		//информации о данной координате будет возвращена ошибка.
		return (*this)[Tuple()<<coordinate_id][0].toInt();
	}
};

#include <Types.h>
#include <Kinematic.h>

/** @brief Модуль перевода координат между разными ITRS-системами
 *
 * @ingroup coordsys
  *
  * Таблица, которую создаёт данный класс, хранит параметры Гельмерта для
  * перехода от одной ITRS-системе к другой. Сами параметры Гельмерта
  * предназначены только для перевода координат, но имея ещё скорости их
  * изменения, можно с помощью дифференцирования получить формулы для перевода
  * также и скоростей.
  *
  * Параметры Гельмерта, хранимые в данном классе, включают:
  * @li Сдвиг центра масс Земли одной системы координат относительно другой, км.
  * @li Коэффициент масштабирования одной системы координат относительно другой.
  * @li Параметры поворота осей координат
  * @li Момент времени, в который были зафиксированы величины (1-3).
  * @li Скорости изменения величин (1-3).
  *
  * Скорости изменения величин считаются постоянными на весь период
  * использования системы координат. Это даёт возможность вычислить мгновенные
  * значения параметров Гельмерта в каждый момент времени.
  *
  * Название таблицы: itrf_transformation
  */
class ITRFTranslation : public DBTable
{
private:

	/** @brief Структура, хранящая для одного момента времени параметра
	  * Гельмерта и скорости их изменения.
	  *
	  * Для корректной обработки случая, когда для выполнения заданного
	  * перевода координат параметров в таблице нет, изначально
	  * структура заполняется числом nan.
	  *
	  */
	struct TRANSPARAMS
	{
		double tx;
		double ty;
		double tz;
		double sc;
		double rx;
		double ry;
		double rz;
		double r_tx;
		double r_ty;
		double r_tz;
		double r_sc;
		double r_rx;
		double r_ry;
		double r_rz;
		inline TRANSPARAMS ()
		{
			tx = numeric_limits<double>::quiet_NaN();
			ty = numeric_limits<double>::quiet_NaN();
			tz = numeric_limits<double>::quiet_NaN();
			sc = numeric_limits<double>::quiet_NaN();
			rx = numeric_limits<double>::quiet_NaN();
			ry = numeric_limits<double>::quiet_NaN();
			rz = numeric_limits<double>::quiet_NaN();
		}
	};

	/** @brief Метод возвращает параметры Гельмерта
	  *
	  * @param t Момент времени, на который вычисляются параметры
	  * @param src Система координат, из которой осуществляется переход
	  * @param dst Система координат, в которую осуществляется переход
	  *
	  */
	TRANSPARAMS getTranslationParams (real t,
					  int src,
					  int dst) const;

	//! Метод, который генерирует параметры гельмерта по принципу транзитивности
	void genTransitive();

public:

	//! @brief Конструктор, осуществляющий регистрацию таблицы в коллекции
	ITRFTranslation(DBTableCollection * base);

	/** @brief Перевод координат точки из одной ITRS-системы в другую
	  *
	  * Метод вычисляет координаты точки, заданной в одной фиксированной
	  * с Землёй (ITRS-) системе координат, в другой ITRS-системе координат.
	  *
	  * @param pos Координаты точки, заданные в исходной ITRS-системе
	  * @param sourceFrameID Идентификатор ITRS-системы, в которой заданы
	  * координаты
	  * @param destinationFrameID Идентификатор ITRS-системы, в которой
	  * необходимо найти координаты точки
	  * @param t Момент времени
	  */
	kinematic < real, 3, defaultNonInert > translateITRF
		(const kinematic < real, 3, defaultNonInert > & pos,
		 int sourceFrameID,
		 int destinationFrameID,
		 real t) const;

	/** @brief Перевод координат и скорости из одной ITRS-системы в другую
	  *
	  * Метод вычисляет в требуемой ITRS-системе координат координаты и
	  * скорость точки, координаты и скорость которой заданы в другой
	  * ITRS-системе координат.
	  *
	  * @param posvel Исходные координаты и скорость точки
	  * @param sourceFrameID Идентификатор ITRS-системы, в которой заданы
	  * координаты и скорость
	  * @param destinationFrameID Идентификатор ITRS-системы, в которой
	  * необходимо найти координаты точки
	  * @param t Момент времени
	  */
	kinematic < real, 6, defaultNonInert > translateITRF
		(const kinematic < real, 6, defaultNonInert > & posvel,
		 int sourceFrameID,
		 int destinationFrameID,
		 real t) const;
		 
	/** @brief Перевод координат и скорости из одной ITRS-системы в другую
	  *
	  * Метод вычисляет в требуемой ITRS-системе координат координаты и
	  * скорость точки, координаты и скорость которой заданы в другой
	  * ITRS-системе координат.
	  * 
	  * Для перевода координат из одной TRS-системы в другую используется 
	  * следующая формула (http://en.wikipedia.org/wiki/Helmert_transformation):
	  *
	  * \f[ \left(\begin{array}{l}x\\y\\z\end{array}\right)_{1} = 
	   \left(\begin{array}{l}t_x\\t_y\\t_z\end{array}\right) + 
	   (1+s)\left(\begin{array}{lll}1&-r_z&r_y\\r_z&1&-r_x\\-r_y&r_x&1
	   \end{array}\right)\cdot\left(\begin{array}{l}x\\y\\z\end{array}
	   \right)_{2}, \f]
	  * 
	  * где \f$ \left(\begin{array}{l}x\\y\\z\end{array}\right)_2 \f$ - 
	  * координаты в исходной системе координат, 
	  * \f$ \left(\begin{array}{l}x\\y\\z\end{array}\right)_2 \f$ -
	  * координаты в новой системе координат, 
	  * \f$ t_x,~t_y,~t_z,~s,~r_x,~r_y,~r_z \f$ - параметры Гельмерта.
	  * 
	  * Формулы трансформации скорости и ускорения получаются по правилам
	  * дифференцирования. Для точности и перепроверяемости они выведены в
	  * системе Mathematica.
	  * 
	  \verbatim
(*Трансформация Гельмерта (до преобразования в строку нельзя использовать
  обозначения, вводимые в C++-коде)*)
Transform = {tx[t], ty[t], 
   tz[t]} + (1 + 
     sc[t])*{{1, -rz[t], ry[t]}, {rz[t], 1, -rx[t]}, {-ry[t], rx[t], 
      1}}.{posvel0[t], posvel1[t], posvel2[t]}
      
(*Трансформация Гельмерта после замены обозначений*)
StringReplace[
 ToString[InputForm[Transform]], {"posvel0[t]" -> "posvel[0]", 
  "posvel1[t]" -> "posvel[1]", "posvel2[t]" -> "posvel[2]", 
  "ry[t]" -> "p.ry", "rx[t]" -> "p.rx", "rz[t]" -> "p.rz", 
  "sc[t]" -> "p.sc", "tx[t]" -> "p.tx", "ty[t]" -> "p.ty", 
  "tz[t]" -> "p.tz"}]
  
(*Производная от трансформации Гельмерта после замены обозначений*)  
StringReplace[
 ToString[InputForm[Evaluate[D[Transform, t]]]], {"posvel0[t]" -> 
   "posvel[0]", "posvel1[t]" -> "posvel[1]", 
  "posvel2[t]" -> "posvel[2]", "ry[t]" -> "p.ry", "rx[t]" -> "p.rx", 
  "rz[t]" -> "p.rz", "sc[t]" -> "p.sc", "tx[t]" -> "p.tx", 
  "ty[t]" -> "p.ty", "tz[t]" -> "p.tz", 
  "Derivative[1][posvel0][t]" -> "posvel[3]", 
  "Derivative[1][posvel1][t]" -> "posvel[4]", 
  "Derivative[1][posvel2][t]" -> "posvel[5]", 
  "Derivative[1][tx][t]" -> "p.r_tx", 
  "Derivative[1][ty][t]" -> "p.r_ty", 
  "Derivative[1][tz][t]" -> "p.r_tz", 
  "Derivative[1][rx][t]" -> "p.r_rx", 
  "Derivative[1][ry][t]" -> "p.r_ry", 
  "Derivative[1][rz][t]" -> "p.r_rz", 
  "Derivative[1][sc][t]" -> "p.r_sc"}]

(*Вторая производная от трансформации Гельмерта после замены обозначений.
Считается, что вторая производная от всех параметров Гельмерта равны нулю.
*)  
StringReplace[ToString[InputForm[Evaluate[
    D[Transform, t, t] /. {D[rx[t], t, t] -> 0, D[ry[t], t, t] -> 0, 
      D[rz[t], t, t] -> 0, D[sc[t], t, t] -> 0, D[tx[t], t, t] -> 0, 
      D[ty[t], t, t] -> 0, D[tz[t], t, t] -> 0}]]], {"posvel0[t]" -> 
   "posvel[0]", "posvel1[t]" -> "posvel[1]", 
  "posvel2[t]" -> "posvel[2]", "ry[t]" -> "p.ry", "rx[t]" -> "p.rx", 
  "rz[t]" -> "p.rz", "sc[t]" -> "p.sc", "tx[t]" -> "p.tx", 
  "ty[t]" -> "p.ty", "tz[t]" -> "p.tz", 
  "Derivative[1][posvel0][t]" -> "posvel[3]", 
  "Derivative[1][posvel1][t]" -> "posvel[4]", 
  "Derivative[1][posvel2][t]" -> "posvel[5]", 
  "Derivative[1][tx][t]" -> "p.r_tx", 
  "Derivative[1][ty][t]" -> "p.r_ty", 
  "Derivative[1][tz][t]" -> "p.r_tz", 
  "Derivative[1][rx][t]" -> "p.r_rx", 
  "Derivative[1][ry][t]" -> "p.r_ry", 
  "Derivative[1][rz][t]" -> "p.r_rz", 
  "Derivative[1][sc][t]" -> "p.r_sc", 
  "Derivative[2][posvel0][t]" -> "posvel[6]", 
  "Derivative[2][posvel1][t]" -> "posvel[7]", 
  "Derivative[2][posvel2][t]" -> "posvel[8]"}]  
	  \endverbatim
	  *
	  *
	  * @param posvelaccel Исходные координаты, скорость и ускорение точки
	  * @param sourceFrameID Идентификатор ITRS-системы, в которой заданы
	  * координаты и скорость
	  * @param destinationFrameID Идентификатор ITRS-системы, в которой
	  * необходимо найти координаты точки
	  * @param t Момент времени
	  */
	kinematic < real, 9, defaultNonInert > translateITRF
		(const kinematic < real, 9, defaultNonInert > & posvelaccel,
		 int sourceFrameID,
		 int destinationFrameID,
		 real t) const;
};

/**
 * @brief Исключение: неверные геодезические координаты
 *
 * @ingroup except
 */
class WrongGeodeticCoordinates : public StrException
{
public:
	WrongGeodeticCoordinates();
};

/**
 * @brief Преобразовать геодезические координаты в геоцентрические
 *
 * @ingroup coordsys
 *
 * @param pos Геодезические координаты: долгота (рад), широта (рад), высота (км)
 * @return Геоцентрические координаты
 *
 * Для преобразования координат используется модель эллипсоида WGS84.
 */
kinematic < real, 3, defaultNonInert > geodeticToGeocentric
(const kinematic < real, 3, defaultGeodetic > & pos);

/**
 * @brief Преобразовать геоцентрические координаты в геодезические
 *
 * @ingroup coordsys
 *
 * @param pos Геоцентрические координаты
 * @return Геодезические координаты: долгота (рад), широта (рад), высота (км)
 *
 * Для преобразования координат используется модель эллипсоида WGS84.
 */
kinematic < real, 3, defaultGeodetic > geocentricToGeodetic
(const kinematic < real, 3, defaultNonInert > & pos);

/**
 * @brief Процедура вычисляет направления на север, на восток и вверх для точки
 *
 * @ingroup coordsys
 *
 * @param pos Передаваемое положение точки
 * @param north Вычисляемое нормированное направление на север
 * @param east Вычисляемое нормированное направление на восток
 * @param up Вычисляемое нормированное направление вверх
 *
 * Для точки на поверхности Земли (подразумевается, для БИС) вычисляются вектора
 * во вращающейся системе коордиат, указывающие на север, на восток и вверх.
 * При вычислении направлений используется предположение, что Земля является
 * идеальным шаром. Это предположение приводит к некоторой погрешности, однако,
 * поскольку в спецификациях (формат Antex-файлов и др.) не указано, какое
 * направление они принимают за "вверх" - вверх в гравитационном поле, или
 * перпендикулярно поверхности геоида, такая погрешность является допустимой.
 */
void getNorthEastUp (const kinematic < real, 3, defaultNonInert> & pos,
					 kinematic < real, 3, defaultNonInert> & north,
					 kinematic < real, 3, defaultNonInert> & east,
					 kinematic < real, 3, defaultNonInert> & up);

/**
 * @brief Вычислить пару Зенитный угол/Угол азимута относительно приёмника
 *
 * @ingroup coordsys
 *
 * @param stapos Координаты приёмника
 * @param satpos Координаты НКА
 * @param north Нормированное направление на север
 * @param east Нормированное направление на восток
 * @param up Нормированное направление вверх
 * @return Пара (Зенитный угол, Угол азимута).
 */
pair < real, real > getZenithAzimuth (const kinematic < real, 3, defaultNonInert > & stapos,
					const kinematic < real, 3, defaultNonInert > & satpos,
					const kinematic<real, 3, defaultNonInert> &north,
					const kinematic<real, 3, defaultNonInert> &east,
					const kinematic<real, 3, defaultNonInert> &up);

/**
 * @brief Вычислить пару Зенитный угол/Угол азимута относительно приёмника
 *
 * @ingroup coordsys
 *
 * @param stapos Координаты приёмника
 * @param satpos Координаты НКА
 * @param north Нормированное направление на север
 * @param east Нормированное направление на восток
 * @param up Нормированное направление вверх
 * @return Пара (Зенитный угол, Угол азимута).
 */
pair < real, real > getZenithAzimuth (
					const kinematic < real, 3, defaultInert > & stapos,
					const kinematic < real, 3, defaultInert > & satpos,
					const kinematic < real, 3, defaultInert > & north,
					const kinematic < real, 3, defaultInert > & east,
					const kinematic < real, 3, defaultInert > & up
		);

}

#endif

/*

*/

#include <sstream>
#include <cmath>

using namespace std;

//! @file

#include <BuiltIn.h>
#include <Frames.h>
#include <DBError.h>
#include <InterpolatedParameterStorage.h>
#include <ParameterStorage.h>
#include <ERPStorage.h>
#include <StdTables.h>

namespace libgnss
{

InvalidFrameException::InvalidFrameException(int frame_id)
	: StrException ("InvalidFrameException",
					"Некорректный номер системы координат: "+
			Variant(frame_id).toString())
{

}

CannotConvertFrameException::CannotConvertFrameException(string frame0,
														 string frame1)
	: StrException ("CannotConvertFrameException",
					"Невозможно совершить переход из системы "
			"координат "+frame0+ " в систему "+frame1)
{

}

CTypeSelect * Frames::frameSelectorType()
{
	static CTypeSelect trsselect("TRSSelect", Tuple()
					  <<string("Internal")<<string("IGS08")
					  <<string("ITRF08")<<string("ITRF05")
					  <<string("ITRF00")<<string("ITRF97")
					  <<string("ITRF96")<<string("ITRF94")
					  <<string("ITRF93")<<string("ITRF92")
					  <<string("ITRF91")<<string("ITRF90")
					  <<string("ITRF89")<<string("NAD83")
					  <<string("WGS-05")<<string("WGS84")
					  <<string("ПЗ-90")<<string("ПЗ-90.02")
					  <<string("ПЗ-90.11")<<string("IGS05"),0);
	return &trsselect;
}

Settings::Enumerator defaultTRS("Coordinate_Systems", "Frame_Converter",
				"Default_TRS", Frames::frameSelectorType(),
				"Геоцентрическая неинерциальная система "
				"координат по умолчанию", string("IGS08"));

unsigned int Frames::defaultNonInertFrame() const
{
	if (sets==0)
	{
		((Frames*)(this))->sets =
			(Settings*)(Base->getTable("settings"));
		string syst = sets->getSettings(defaultTRS).toString();
		((Frames*)(this))->defnifr = getCoordinateFrameID(syst);
	}

	return defnifr;
}

Frames::Frames(DBTableCollection *base)
	: NumeratedTable(Columns()
		  <<Column(Variant::TYPE_INT, "frame_type")
		  <<Column(Variant::TYPE_STRING, "frame_title")
		  )
{
	Base = base;
	base->addTable("coordinate_frames", this);
	//defaultNonInertFrame = 0xffffffff;
	itrftranslator = 0;
	sets = 0;
	erpstorage = 0;

}

CoordinateTypes::CoordinateTypes(DBTableCollection *base)
	:NumeratedTable(
		  Columns()
		  <<Column(Variant::TYPE_INT, "frame_id")
		  <<Column(Variant::TYPE_INT, "coordinate_number")
		  )
{
	base->addTable("coordinate_types", this);
}

void Frames::cacheCoordinateTypes()
{
	if (coordinatesCaches.empty())
	{
		DBConstIterator fit = const_begin();
		for (; fit!=const_end(); fit++)
		{
			int frame_id = fit.keyColumnValue(0).toInt();
			//Используем map, чтобы упорядочить номера координат
			//по номеру компоненты в данной системе координат
			map < int, int > coordCache;

			DBTable * ct =
				Base->getTable("coordinate_types");

			DBConstIterator it = ct->const_begin();
			for (; it!=ct->const_end(); it++)
				if (frame_id == it[0].toInt())
					coordCache[it[1].toInt()]=
						it.keyColumnValue(0).toInt();

			for (map < int, int >::iterator it0 =coordCache.begin();
			     it0!=coordCache.end(); it0++)
				coordinatesCaches[frame_id].push_back
								(it0->second);
		}
	}
}

void Frames::clearCoordinatesCache()
{
	coordinatesCaches.clear();
}

vector < int > Frames::getFrameCoordinates ( int frame_id ) const
{
	//Насильственным путем обойти модификатор const
	if (coordinatesCaches.empty())
		((Frames*)(this))->cacheCoordinateTypes();

	map < int, vector < int > > :: const_iterator it0 =
					coordinatesCaches.find(frame_id);
	if (it0 == coordinatesCaches.end())
		throw InvalidFrameException (frame_id);
	return it0->second;
}

vector < int > Frames::getFullCoordinateSet ( int coordinate_id ) const
{
	const DBTable * ct = Base->getTable("coordinate_types");
	//Найти к какой системе координат относится данная координата
	int frame_id = (*ct)[Tuple()<<coordinate_id][0].toInt();
	return getFrameCoordinates(frame_id);

}

int Frames::getCoordinateFrameID(const string &coordframetitle) const
{
	string line1 = coordframetitle;
	line1.erase(line1.find_last_not_of(' ')+1);
	for (DBConstIterator it = const_begin(); it!=const_end(); it++)
		if (it[1].toString() == line1)
			return it.keyColumnValue(0).toInt();

	return 0xffffffff;
}

#ifdef WithQT
QVariantList Frames::getFrameCoordinatesSet (int frame_id) const
{
	vector<int> result_=getFrameCoordinates(frame_id);
	QVariantList result;
	for (unsigned int i=0; i<result_.size(); i++)
		result.push_back(QVariant::fromValue<int>(result_[i]));
	return result;
}

QVariantList Frames::completeCoordinatesSet (int coordinate_id) const
{
	vector<int> result_=getFullCoordinateSet(coordinate_id);
	QVariantList result;
	for (unsigned int i=0; i<result.size(); i++)
		result.push_back(QVariant::fromValue<int>(result_[i]));
	return result;
}

QString Frames::getTypeOfFrame (int frame_id) const
{
	FrameType ft = getFrameType(frame_id);
	if (ft==FT_ITRS)
		return "ITRS";
	else if (ft==FT_ECIF)
		return "ECIF";
	else if (ft==FT_Geodesic)
		return "Geodesic";
	else if (ft==FT_Elements)
		return "Elements";
	else if (ft==FT_Fake)
		return "Fake";
	else
		return "Unknown";
}

QVariantList Frames::getInertialFramePosition ( const QVariantList & pos,
										int src_frame_id, double t) const
{
	vector<real> pos_ (pos.size());
	for (int i=0; i<pos.size(); i++)
		pos_[i] = pos[i].toInt();
	kinematic<real, 3, defaultInert> result_ = posInert(pos_,src_frame_id,t);
	QVariantList result;
	for (unsigned int i=0; i<3; i++)
		result.push_back((double)result_[i]);
	return result;
}

QVariantList Frames::getInertialFramePositionVelocity
		( const QVariantList & pos, int src_frame_id, double t) const
{
	vector<real> pos_ (pos.size());
	for (int i=0; i<pos.size(); i++)
		pos_[i] = pos[i].toInt();
	kinematic<real, 6, defaultInert> result_ = posVelInert(pos_,src_frame_id,t);
	QVariantList result;
	for (unsigned int i=0; i<6; i++)
		result.push_back((double)(result_[i]));
	return result;
}

QVariantList Frames::getInertialFramePositionVelocityAcceleration
		( const QVariantList & pos, int src_frame_id, double t) const
{
	vector<real> pos_ (pos.size());
	for (int i=0; i<pos.size(); i++)
		pos_[i] = pos[i].toInt();
	kinematic<real,9,defaultInert>result_=posVelAccelInert(pos_,src_frame_id,t);
	QVariantList result;
	for (unsigned int i=0; i<9; i++)
		result.push_back((double)result_[i]);
	return result;
}

int Frames::getCoordFrameID (const QString & coordframetitle) const
{
	return getCoordinateFrameID(coordframetitle.toStdString());
}
#endif

ITRFTranslation::ITRFTranslation(DBTableCollection *base)
	: DBTable (Columns()
		   <<Column(Variant::TYPE_INT, "from_frame")
		   <<Column(Variant::TYPE_INT, "to_frame"),
		   Columns()
		   <<Column(Variant::TYPE_DOUBLE, "sync_time")//секунды от j2000
		   <<Column(Variant::TYPE_DOUBLE, "translate_x") // км.
		   <<Column(Variant::TYPE_DOUBLE, "translate_y") // км.
		   <<Column(Variant::TYPE_DOUBLE, "translate_z") // км.
		   <<Column(Variant::TYPE_DOUBLE, "scale")	// доля от миллиарда
		   <<Column(Variant::TYPE_DOUBLE, "rotate_x") //угловая миллисекунда
		   <<Column(Variant::TYPE_DOUBLE, "rotate_y") //угловая миллисекунда
		   <<Column(Variant::TYPE_DOUBLE, "rotate_z") //угловая миллисекунда
		   <<Column(Variant::TYPE_DOUBLE, "rate_translate_x") // км/год
		   <<Column(Variant::TYPE_DOUBLE, "rate_translate_y") // км/год
		   <<Column(Variant::TYPE_DOUBLE, "rate_translate_z") // км/год
		   <<Column(Variant::TYPE_DOUBLE, "rate_scale") // доля от миллиарда/год
		   <<Column(Variant::TYPE_DOUBLE, "rate_rotate_x") //угл. мс/год
		   <<Column(Variant::TYPE_DOUBLE, "rate_rotate_y") //угл. мс/год
		   <<Column(Variant::TYPE_DOUBLE, "rate_rotate_z") //угл. мс/год
	      )
{
	base->addTable("itrf_transformation", this);
}

ITRFTranslation::TRANSPARAMS ITRFTranslation::getTranslationParams
				(real t, int src, int dst) const
{
	//Заполненный nan-ом результат
	ITRFTranslation::TRANSPARAMS result;
	DBConstIterator d = find(Tuple()<<src<<dst);

	//Если коэффициентов перехода не найдено, попробовать сгенерировать
	//коэффициенты за счет транзитивности и антисимметричности.
	if (d==const_end())
	{
		//Генерация коэффициентов нарушает константность
		((ITRFTranslation*)(this))->genTransitive();
		d = find(Tuple()<<src<<dst);
		if (d==const_end())
		{
			string id1 = Variant(src).toString();
			string id2 = Variant(dst).toString();
			throw CannotConvertFrameException("id="+id1, "id="+id2);
		}
	}
	real dt = (t - d[0].toDouble())/(365.25*86400);
	result.r_tx = d[8 ].toDouble();
	result.r_ty = d[9 ].toDouble();
	result.r_tz = d[10].toDouble();
	result.r_sc = d[11].toDouble();
	result.r_rx = d[12].toDouble();
	result.r_ry = d[13].toDouble();
	result.r_rz = d[14].toDouble();
	result.tx = d[1].toDouble() + dt * result.r_tx;
	result.ty = d[2].toDouble() + dt * result.r_ty;
	result.tz = d[3].toDouble() + dt * result.r_tz;
	result.sc = d[4].toDouble() + dt * result.r_sc;
	result.rx = d[5].toDouble() + dt * result.r_rx;
	result.ry = d[6].toDouble() + dt * result.r_ry;
	result.rz = d[7].toDouble() + dt * result.r_rz;
	return result;
}

void ITRFTranslation::genTransitive()
{
	while (true)
	{
		bool added=false;
		for (DBTable::DBConstIterator it0=const_begin();it0!=const_end();++it0)
		{
			int sys0 = it0.keyColumnValue(0).toInt();
			int sys1 = it0.keyColumnValue(1).toInt();

			//Проверить наличие обратного перевода
			if (find(Tuple()<<sys1<<sys0)==const_end())
			{
				Tuple newtransform;
				newtransform<<it0[0]; //Время синхронизации систем координат
				for (unsigned int i=1; i<15; i++)
					newtransform<<(-it0[i].toDouble());
				insertRow(Tuple()<<sys1<<sys0, newtransform);
				added = true;

				//После вставки текущие итераторы недействительны
				break;
			}

			for (DBTable::DBConstIterator it1 = const_begin(); it1!=const_end();
				 ++it1)
			{
				int sys2 = it1.keyColumnValue(0).toInt();
				int sys3 = it1.keyColumnValue(1).toInt();

				//Проверить транзитивность переходов
				if ((sys2 == sys1) && (sys0 != sys3) &&
						(find(Tuple()<<sys0<<sys3)==const_end()))
				{
					//Вычислить новый момент синхронизации
					real synctime = max(it0[0],it1[0]).toDouble();

					//Разность моментов синхронизаций в секундах
					real delta0 = synctime - it0[0].toDouble();
					real delta1 = synctime - it1[0].toDouble();

					//Перевести разность моментов синхронизации в года
					delta0/=(365.24*86400.0);
					delta1/=(365.24*86400.0);

					Tuple t0 = *it0;
					Tuple t1 = *it1;

					Tuple newtransform;
					newtransform<<synctime;
					for (unsigned int i=1; i<8; i++)
						newtransform
								<<t0[i].toDouble()+t0[i+7].toDouble()*delta0+
								  t1[i].toDouble()+t1[i+7].toDouble()*delta1;
					for (unsigned int i=8; i<15; i++)
						newtransform<<t0[i].toDouble()+t1[i].toDouble();
					insertRow(Tuple()<<sys0<<sys3,newtransform);

					//После вставки текущие итераторы недействительны
					added = true;
					break;
				}
				if (added == true)
					break;
			}

		}

		//Если все возможные переводы СК добавлены, завершить
		if (added == false)
			break;
	}
}

void Frames::cannotConvert(int frame0, int frame1) const
{
	string frame0name = "СК_"+Variant(frame0).toString();
	string frame1name = "СК_"+Variant(frame1).toString();;

	DBConstIterator it0 = find(Tuple()<<frame0);
	DBConstIterator it1 = find(Tuple()<<frame1);
	if (it0!=const_end())
		frame0name = it0[1].toString();
	if (it1!=const_end())
		frame1name = it1[1].toString();

	throw CannotConvertFrameException(frame0name, frame1name);
}

kinematic < real, 3, defaultNonInert > ITRFTranslation::translateITRF
	(const kinematic < real, 3, defaultNonInert > & pos,
	 int sourceFrameID,
	 int destinationFrameID,
	 real t) const
{
	ITRFTranslation::TRANSPARAMS p = getTranslationParams(t, sourceFrameID,
						  destinationFrameID);

	kinematic < real, 3, defaultNonInert > res;

	const double marcs2rad = 4.8481368110953594e-9;
	
	res[0] = p.tx + (1.0 + p.sc * 1e-9 ) * ( pos[0] - p.rz * marcs2rad * pos[1] 
													+ p.ry *marcs2rad* pos[2]);
	res[1] = p.ty + (1.0 + p.sc * 1e-9 ) * ( pos[1] + p.rz * marcs2rad * pos[0] 
													- p.rx *marcs2rad* pos[2]);
	res[2] = p.tz + (1.0 + p.sc * 1e-9 ) * ( pos[2] - p.ry * marcs2rad * pos[0] 
													+ p.rx *marcs2rad* pos[1]);

	return res;
}

kinematic < real, 6, defaultNonInert > ITRFTranslation::translateITRF
	(const kinematic < real, 6, defaultNonInert > & posvel,
	 int sourceFrameID,
	 int destinationFrameID,
	 real t
	) const
{
	const double marcs2rad = 4.8481368110953594e-9;
	ITRFTranslation::TRANSPARAMS p = getTranslationParams(t, sourceFrameID,
						  destinationFrameID);
	
	//Перевод угловых милисекунд в радианы
	p.rx*=marcs2rad;
	p.ry*=marcs2rad;
	p.rz*=marcs2rad;
	p.r_rx*=marcs2rad;
	p.r_ry*=marcs2rad;
	p.r_rz*=marcs2rad;

	//Перевод миллиардных долей в доли единицы
	p.sc*=1e-9;
	p.r_sc*=1e-9;

	//Перевод скоростей из единиц/год в единицы/с.
	p.r_rx/=(365.24*86400.0);
	p.r_ry/=(365.24*86400.0);
	p.r_rz/=(365.24*86400.0);
	p.r_sc/=(365.24*86400.0);
	p.r_tx/=(365.24*86400.0);
	p.r_ty/=(365.24*86400.0);
	p.r_tz/=(365.24*86400.0);

	kinematic < real, 6, defaultNonInert > res;


	//Перевод координат
	res[0] = (posvel[0] + posvel[2]*p.ry - posvel[1]*p.rz)*(1 + p.sc) + p.tx;
	res[1] = (posvel[1] - posvel[2]*p.rx + posvel[0]*p.rz)*(1 + p.sc) + p.ty;
	res[2] = (posvel[2] + posvel[1]*p.rx - posvel[0]*p.ry)*(1 + p.sc) + p.tz;

	//Перевод скоростей - простое использование формул дифференцирования
	res[3]=(1 + p.sc)*(posvel[3] - p.rz*posvel[4] + p.ry*posvel[5] + 
		posvel[2]*p.r_ry - posvel[1]*p.r_rz) + (posvel[0] + posvel[2]*p.ry - 
		posvel[1]*p.rz)*p.r_sc + p.r_tx;
	
	res[4]=(1 + p.sc)*(p.rz*posvel[3] + posvel[4] - p.rx*posvel[5] - 
		posvel[2]*p.r_rx + posvel[0]*p.r_rz) + (posvel[1] - posvel[2]*p.rx +
		posvel[0]*p.rz)*p.r_sc + p.r_ty;
	
	res[5]=(1 + p.sc)*(-(p.ry*posvel[3]) + p.rx*posvel[4] + posvel[5] +
		posvel[1]*p.r_rx - posvel[0]*p.r_ry) + (posvel[2] + posvel[1]*p.rx -
		posvel[0]*p.ry)*p.r_sc + p.r_tz;
		
	return res;

}

kinematic< real, 9, defaultNonInert > ITRFTranslation::translateITRF(
	const kinematic< real, 9, defaultNonInert >& posvel,
	int sourceFrameID,
	int destinationFrameID,
	real t
) const
{
	
	const double marcs2rad = 4.8481368110953594e-9;
	ITRFTranslation::TRANSPARAMS p = getTranslationParams(t, sourceFrameID,
						  destinationFrameID);

	//Перевод угловых милисекунд в радианы
	p.rx*=marcs2rad;
	p.ry*=marcs2rad;
	p.rz*=marcs2rad;
	p.r_rx*=marcs2rad;
	p.r_ry*=marcs2rad;
	p.r_rz*=marcs2rad;

	//Перевод миллиардных долей в доли единицы
	p.sc*=1e-9;
	p.r_sc*=1e-9;

	//Перевод скоростей из единиц/год в единицы/с.
	p.r_rx/=(365.24*86400.0);
	p.r_ry/=(365.24*86400.0);
	p.r_rz/=(365.24*86400.0);
	p.r_sc/=(365.24*86400.0);
	p.r_tx/=(365.24*86400.0);
	p.r_ty/=(365.24*86400.0);
	p.r_tz/=(365.24*86400.0);


	kinematic < real, 9, defaultNonInert > res;

	//Перевод координат
	res[0] = (posvel[0] + posvel[2]*p.ry - posvel[1]*p.rz)*(1 + p.sc) + p.tx;
	res[1] = (posvel[1] - posvel[2]*p.rx + posvel[0]*p.rz)*(1 + p.sc) + p.ty;
	res[2] = (posvel[2] + posvel[1]*p.rx - posvel[0]*p.ry)*(1 + p.sc) + p.tz;

	//Перевод скоростей - простое использование формул дифференцирования
	res[3]=(1 + p.sc)*(posvel[3] - p.rz*posvel[4] + p.ry*posvel[5] + 
		posvel[2]*p.r_ry - posvel[1]*p.r_rz) + (posvel[0] + posvel[2]*p.ry - 
		posvel[1]*p.rz)*p.r_sc + p.r_tx;
	
	res[4]=(1 + p.sc)*(p.rz*posvel[3] + posvel[4] - p.rx*posvel[5] - 
		posvel[2]*p.r_rx + posvel[0]*p.r_rz) + (posvel[1] - posvel[2]*p.rx +
		posvel[0]*p.rz)*p.r_sc + p.r_ty;
	
	res[5]=(1 + p.sc)*(-(p.ry*posvel[3]) + p.rx*posvel[4] + posvel[5] +
		posvel[1]*p.r_rx - posvel[0]*p.r_ry) + (posvel[2] + posvel[1]*p.rx -
		posvel[0]*p.ry)*p.r_sc + p.r_tz;
	
	//Перевод ускорения - более сложное использование формул дифференцирования
	res[6]=2*(posvel[3] - p.rz*posvel[4] + p.ry*posvel[5] + posvel[2]*p.r_ry -
			posvel[1]*p.r_rz)*p.r_sc + (1 + p.sc)*(2*posvel[5]*p.r_ry -
			2*posvel[4]*p.r_rz + posvel[6] - p.rz*posvel[7] + p.ry*posvel[8]);
		
	res[7]=2*(p.rz*posvel[3] + posvel[4] - p.rx*posvel[5] - posvel[2]*p.r_rx +
			posvel[0]*p.r_rz)*p.r_sc + (1 + p.sc)*(-2*posvel[5]*p.r_rx +
			2*posvel[3]*p.r_rz + p.rz*posvel[6] + posvel[7] - p.rx*posvel[8]);
	
	res[8]=2*(-(p.ry*posvel[3]) + p.rx*posvel[4] + posvel[5] + posvel[1]*p.r_rx
			- posvel[0]*p.r_ry)*p.r_sc + (1 + p.sc)*(2*posvel[4]*p.r_rx - 
			2*posvel[3]*p.r_ry - p.ry*posvel[6] + p.rx*posvel[7] + posvel[8]);

	return res;
}


void Frames::checkExternal()
{

	if (itrftranslator == 0)
	{
		map < string, DBTable * > :: iterator it =
				Base->find("itrf_transformation");
		if (it!=Base->end())
			itrftranslator = (ITRFTranslation *)(it->second);
	}

	if (erpstorage == 0)
	{
		map < string, DBTable * > :: iterator it =
				Base->find("ERP");

		if (it!=Base->end())
			erpstorage = static_cast<ERPStorage*>
				(static_cast<InterpolatedParameterStorage*>
				(static_cast<ParameterStorage*>
					(it->second)));
	}
}



#include <ERPStorage.h>

kinematic < real, 3, defaultInert > Frames::posInert
		(const vector<real> &pos, unsigned int src, real t) const
{
	FrameType ft = getFrameType(src);
	if ((ft == FT_Elements) || (ft == FT_Geodesic))
	{
		stringstream e;
		e<<"Перевод из СК "<<(*this)[Tuple()<<(int)src][1].toString()
				<<" в СК GCRS";
		throw NotImplementedException(e.str());
	}

	kinematic < real, 3, defaultInert > result;
	if (ft==FT_ECIF)
	{
		result[0] = pos[0];
		result[1] = pos[1];
		result[2] = pos[2];
		return result;
	}
	if (ft==FT_ITRS)
	{
		kinematic < real, 3, defaultNonInert > nipos;
		nipos[0] = pos[0];
		nipos[1] = pos[1];
		nipos[2] = pos[2];

		//Обновить данные, связанные с переводом между различными
		//ITRS-системами.
		((Frames*)(this))->checkExternal();

		int df = defaultNonInertFrame();

		//Если данные даны в наземной системе координат,
		//отличной от основной, перевести данные в основную.
		if (src!=df)
		{
			if (itrftranslator != 0)
				nipos = itrftranslator->translateITRF
					(nipos,src,df,t);
			else
				nipos[0] = numeric_limits<real>::quiet_NaN();

			if (isnan(nipos[0]))
				cannotConvert(src,df);

		}

		//Перевести в систему координат GCRS.
		//Попробовать использовать ПВЗ, если они есть.
		if (erpstorage == 0)
			throw TableNotFoundException("ERP");

		result = erpstorage->ITRFtoGCRS(nipos, t);
		return result;
	}
	throw NotImplementedException("Frames::posInert() (FrameType="
				      +Variant(ft).toString()+")");
}

kinematic < real, 6, defaultInert > Frames::posVelInert
	( const vector < real > & pos, unsigned int src, real t) const
{
	FrameType ft = getFrameType(src);
	if ((ft == FT_Elements) || (ft == FT_Geodesic))
	{
		stringstream e;
		e<<"Перевод из СК "<<(*this)[Tuple()<<(int)src][1].toString()
				<<" в СК GCRS";
		throw NotImplementedException(e.str());
	}

	kinematic < real, 6, defaultInert > result;
	if (ft==FT_ECIF)
	{
		for (unsigned int i=0; i<6; i++)
			result[i] = pos[i];
		return result;
	}
	if (ft==FT_ITRS)
	{
		kinematic < real, 6, defaultNonInert > nipos;
		for (unsigned int i=0; i<6; i++)
			nipos[i] = pos[i];

		//Обновить данные, связанные с переводом между различными
		//ITRS-системами.
		((Frames*)(this))->checkExternal();

		int df = defaultNonInertFrame();

		//Если данные даны в наземной системе координат,
		//отличной от основной, перевести данные в основную.
		if (src!=df)
		{
			if (itrftranslator != 0)
				nipos = itrftranslator->translateITRF
					(nipos,src,df,t);
			else
				nipos[0] = numeric_limits<real>::quiet_NaN();

			if (isnan(nipos[0]))
				cannotConvert(src,df);

		}

		//Перевести в систему координат GCRS.
		//Попробовать использовать ПВЗ, если они есть.
		if (erpstorage == 0)
			throw TableNotFoundException("ERP");

		result = erpstorage->ITRFtoGCRS(nipos, t);
		return result;
	}

	throw NotImplementedException("Frames::posVelInert() (FrameType="
				      +Variant(ft).toString()+")");
}

kinematic< real, 9, defaultInert > Frames::posVelAccelInert
	(const vector< real >& pos, unsigned int src, real t) const
{
	FrameType ft = getFrameType(src);
	if ((ft == FT_Elements) || (ft == FT_Geodesic))
	{
		stringstream e;
		e<<"Перевод из СК "<<(*this)[Tuple()<<(int)src][1].toString()
				<<" в СК GCRS";
		throw NotImplementedException(e.str());
	}

	kinematic < real, 9, defaultInert > result;
	if (ft==FT_ECIF)
	{
		for (unsigned int i=0; i<9; i++)
			result[i] = pos[i];
		return result;
	}
	if (ft==FT_ITRS)
	{
		kinematic < real, 9, defaultNonInert > nipos;
		for (unsigned int i=0; i<9; i++)
			nipos[i] = pos[i];

		//Обновить данные, связанные с переводом между различными
		//ITRS-системами.
		((Frames*)(this))->checkExternal();

		int df = defaultNonInertFrame();

		//Если данные даны в наземной системе координат,
		//отличной от основной, перевести данные в основную.
		if (src!=df)
		{
			if (itrftranslator != 0)
				nipos = itrftranslator->translateITRF
					(nipos,src,df,t);
			else
				nipos[0] = numeric_limits<real>::quiet_NaN();

			if (isnan(nipos[0]))
				cannotConvert(src,df);

		}

		//Перевести в систему координат GCRS.
		//Попробовать использовать ПВЗ, если они есть.
		if (erpstorage == 0)
			throw TableNotFoundException("ERP");

		result = erpstorage->ITRFtoGCRS(nipos, t);
		return result;
	}

	throw NotImplementedException("Frames::posVelInert() (FrameType="
				      +Variant(ft).toString()+")");
}

#ifdef WithQT
QScriptValue addFrames(QScriptContext * ctx, QScriptEngine * eng)
{
	DBTableCollection * c = (DBTableCollection *)(ctx->argument(0).toQObject());
	Frames * es = new Frames (c);
	CoordinateTypes * ct = new CoordinateTypes (c);
	ITRFTranslation * it = new ITRFTranslation (c);
	return QScriptValue();
}

BuiltIn addframes_ ("addFramesReference", 1, addFrames);
#endif

WrongGeodeticCoordinates::WrongGeodeticCoordinates()
	: StrException("WrongGeodeticCoordinates",
				   "Неверные геодезические координаты.")
{

}

kinematic < real, 3, defaultNonInert > geodeticToGeocentric
(const kinematic < real, 3, defaultGeodetic > & pos)
{
	double lon = pos[0];
	double lat = pos[1];
	double h = pos[2] * 1000; //Перевести в метры
	double geodetic[3];
	int res;
	int wgsellipsoid = 1;
	if(iauGd2gc(wgsellipsoid,lon,lat,h,geodetic)!=0)
	//libsofa::iau_gd2gc_(&wgsellipsoid,&lon,&lat,&h,&(geodetic[0]),&res);
	//if (res != 0)
		throw WrongGeodeticCoordinates();
	kinematic < real, 3, defaultNonInert > result;
	result[0] = geodetic[0]*0.001; //Перевести в километры
	result[1] = geodetic[1]*0.001;
	result[2] = geodetic[2]*0.001;
	return result;
}

kinematic<real, 3, defaultGeodetic> geocentricToGeodetic(
		const kinematic<real, 3, defaultNonInert> &pos)
{
	kinematic<real, 3, defaultGeodetic> result;
	if (pos.length<0,2>()<numeric_limits<real>::epsilon()*3)
		return result;
	double lon, lat, h;
	double xyz[3];
	//Перевести в метры
	xyz[0] = pos[0]*1000;
	xyz[1] = pos[1]*1000;
	xyz[2] = pos[2]*1000;
	int wgsellipsoid = 1;
	int res;
	if (iauGc2gd(wgsellipsoid,xyz,&lon,&lat,&h) != 0)
	//libsofa::iau_gc2gd_(&wgsellipsoid,&(xyz[0]),&lon,&lat,&h,&res);
	//if (res != 0)
		throw StrException ("geocentricToGeodetic",
							"Невозможно определить геодезические координаты.");
	result[0] = lon;
	result[1] = lat;
	result[2] = h * 0.001;
	return result;
}

void getNorthEastUp (const kinematic < real, 3, defaultNonInert> & pos,
					 kinematic < real, 3, defaultNonInert> & north,
					 kinematic < real, 3, defaultNonInert> & east,
					 kinematic < real, 3, defaultNonInert> & up)
{
	if (pos.length<0,2>() == 0)
	{
		north = kinematic < real, 3, defaultNonInert>();
		east = kinematic < real, 3, defaultNonInert>();
		up = kinematic < real, 3, defaultNonInert>();
		return;
	}
	up = pos.normalize();
	east[0] = -pos[1];
	east[1] = pos[0];
	east[2] = 0;
	east = east.normalize();
	north = up.crossProduct(east);
}

pair < real, real > getZenithAzimuth (
					const kinematic < real, 3, defaultNonInert > & stapos,
					const kinematic < real, 3, defaultNonInert > & satpos,
					const kinematic < real, 3, defaultNonInert > & north,
					const kinematic < real, 3, defaultNonInert > & east,
					const kinematic < real, 3, defaultNonInert > & up
		)
{
	if (up.length<0,2>() == 0)
		return pair < real, real> (numeric_limits<real>::quiet_NaN(),
										 numeric_limits<real>::quiet_NaN());
	pair < real, real > result;
	//Направление
	kinematic<real,3,defaultNonInert> direction = (satpos-stapos).normalize();
	//Зенитный угол - это угол между направлением вверх и направлением,
	//от 0 до Pi/2
	real coszen = up * direction;//Косинус зенитного угла
	result.first = acos(coszen); //Сам зенитный угол
	//Проекция направления на плоскость (north, east).
	kinematic < real, 3, defaultNonInert > proj = direction - coszen * up;
	//Угол азимута - это угол между проекцией направления на плоскость
	//(north; east) и направлением на север, измеренный в направлении от Севера
	//к востоку
	real COS = proj * north;
	real SIN = proj * east;
	result.second = atan2(SIN,COS);
	return result;
}

pair < real, real > getZenithAzimuth (
					const kinematic < real, 3, defaultInert > & stapos,
					const kinematic < real, 3, defaultInert > & satpos,
					const kinematic < real, 3, defaultInert > & north,
					const kinematic < real, 3, defaultInert > & east,
					const kinematic < real, 3, defaultInert > & up
		)
{
	// Численно алгоритм тот же самый, что и в неинерциальной системе координат
	kinematic < real, 3, defaultNonInert > stapos_, satpos_, north_, east_, up_;

	for (unsigned int i=0; i<3; i++)
	{
		stapos_[i] = stapos[i];
		satpos_[i] = satpos[i];
		north_[i] = north[i];
		east_[i] = east[i];
		up_[i] = up[i];
	}
	return getZenithAzimuth(stapos_, satpos_, north_, east_, up_);
}
}

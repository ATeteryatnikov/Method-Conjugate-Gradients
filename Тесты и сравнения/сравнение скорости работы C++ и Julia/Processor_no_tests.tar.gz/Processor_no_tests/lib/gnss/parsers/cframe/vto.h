/*
 * vto.h
 *
 *  Created on: 20.04.2010
 *      Author: Golenok A.I.
 *		email:	greenwood1814@gmail.com			
 */

#ifndef _VTO_H_
#define _VTO_H_
//-------------------------------------------------------------------------------------------------			
#define				MAXSAT				24
#define				MAXSAT_GLO			24
#define				MAXSAT_GPS			32
#define				GLO_SIGNAL_COUNT	5
#define				MAX_SIGNAL_COUNT	5
#define				V_C					299792458.0
//-------------------------------------------------------------------------------------------------
#ifndef SYS_GLO
#define SYS_GLO 0x00
#endif

#ifndef SYS_GPS
#define SYS_GPS 0x01
#endif

#ifndef SYS_GLO_GPS
#define SYS_GLO_GPS 0x0A
#endif

#define				VtEn

//-------------------------------------------------------------------------------------------------

#define 			CT              0x00				// цифр.информац, код стандартной точности
#define 			VT              0x01				// цифр.информац, код высокой точности
#define 			L3              0x02				// цифр.информац, код высокой точности
#define 			NI_COUNT        0x03				// цифр.информац, код высокой точности
//#pragma pack (push, 1)
//-------------------------------------------------------------------------------------------------			
const unsigned int 	C1  =            0x00;
const unsigned int 	C2  =            0x01;
const unsigned int 	V1  =            0x02;
const unsigned int 	V2  =            0x03;
const unsigned int 	C3  =            0x04;

//-------------------------------------------------------------------------------------------------

static const unsigned char  SignalNI[] = { CT, CT, VT, VT, L3};
//ADD MMV 2014.04.02
static unsigned int		const MAXTIME = 30;		//время накопления статистики (измерений)
static unsigned int		const MAXDIFFPSVD = 50;		//максимальное отклонение псевдодальности (метры)
//ADD MMV 2014.07.07
static unsigned int		const PSVDSIGW	=500000;
static unsigned int		const PSVDSIGA	=2000;
static unsigned int		const DOPSIGW	=2000; 
static unsigned int		const DOPSIGA	=500;
static unsigned int		const FAZESIGW	=100000; 
static unsigned int		const FAZESIGA	=5000;
static unsigned int		const CRDPNTSIGW=100000;
static unsigned int		const CRDPNTSIGA=100;

static unsigned int		const KOEFSIGF	= 10000;

//-------------------------------------------------------------------------------------------------	
typedef	struct	_tblHdr									// обновление каждую секунду
{
	unsigned short	length;								// = sizeof(struct)
	unsigned char	num;								// номер системной точки
	unsigned char	lit;								// литера - для глонасс
	unsigned char	sys;								// = SYS_GLO/SYS_GPS
	unsigned char	modification; // 0 --- ГЛОНАСС; 1 --- ГЛОНАСС-М; 2 --- ГЛОНАСС-К; 
	unsigned char	badNavInfCt;						// see "sat_t::tblHdr_upx0c" GLO "0x0n" - call nku+ln(str  num 2), "0x10" hem or num str,  "0x20" ln = 1 W STROKE ZA ISKL. 2 STROKI, "0x30" W STROKE OBNARUVENO NE OPUSTIMOE ZNA^ENIE PARAMETRA
	unsigned char	badNavInfVt;						//
	unsigned char	badNavInfL3;
	unsigned char	badNavInf[NI_COUNT]; // was MAX_SIGNAL_COUNT
	double			az;
	double			um;
} tblHdr_t, *ptblHdr_t;

//-------------------------------------------------------------------------------------------------			
typedef	struct	_tblObs									// обновление каждую секунду	
{
	unsigned short	length;								// = sizeof(struct)
	unsigned int	tmVto;								// время измерения от 01.01.2000г в ШВ ГЛОНАСС
	unsigned char 	actual[MAX_SIGNAL_COUNT];			// флаги актуальности
	double			psvd	[MAX_SIGNAL_COUNT];			// псевдодальность
	double			dop		[MAX_SIGNAL_COUNT];			// частота допплера
	double			faze	[MAX_SIGNAL_COUNT];			// фаза
	unsigned int  	ampl	[MAX_SIGNAL_COUNT];			// амплитуда
} tblObs_t, ptblObs_t;
//-------------------------------------------------------------------------------------------------			
typedef	struct	_tblAddInf     							// обновление каждую секунду	
{
	unsigned short	length;								// = sizeof(struct)
	unsigned char	actual;								// флаг актуальности
	unsigned char	ch;									// канал МРК
	unsigned char	is_not_equal_inf_L1L2;				// флаг совпадения данных по L1/L2
	unsigned char	set_ext;							// флаг внешнего управления
	unsigned char	actualParam	[MAX_SIGNAL_COUNT];			// флаги актуальности
	double			ckoFaze			[MAX_SIGNAL_COUNT];		// ско фазы
	unsigned char	apv					[MAX_SIGNAL_COUNT];	//
} tblAddInf_t, *ptblAddInf_t;
//-------------------------------------------------------------------------------------------------			
//-------------------------------------------------------------------------------------------------			
//-------------------------------------------------------------------------------------------------			
//	вся навигационная информация w|~q:: MOVET PERESTATX OBNOWLQTXSQ ESLI W NEJ BYL WSTRE^EN PRIZNAK ln = 1 ILI bn != 0 , SM. F. "NavInf_t::upx0c
//-------------------------------------------------------------------------------------------------			
typedef	struct	_tblOprGlo		// OBNOWLENIE PO FAKTU GOTOWNOSTI 1,2,3,4 STROKI POdKAdRA
{
	unsigned short	length;			// = sizeof(struct)
	unsigned char	actual;			// флаг актуальности, если 0, все что ниже не актуально
	unsigned char	data[8][10];	// если CT, 1,2,3,4, если VT - 1..8
	unsigned int	tb;				// секунды
	unsigned int	tk;				// секунды
	double			v[3];			// скорость, metr/sek
	double			a[3];			// ускорение, metr/sek^2
	double			c[3];			// координата, metr
	double			gmma;			// gamma_n(t_b), отклонение по частоте
	double			tau;			// t_n(t_b), сдвиг шкалы времени КА относительно шкалы ГЛОНАСС
	double			dL2_L1;			// аппаратная задержка в НКА L1 относительно L2, необходима для учета в расчете ионосферной поправки
	double			Ft;				// прогнозируемая точность при значении больше 1000м считается недейсвительным
	unsigned short	Nt;				// номер суток в четырехлетнем периоде к которым относится оперативная информ.		
	unsigned char	m;				// модификация НКА, сейчас все НКА ГЛОНАСС М однако после появления ГЛОНАСС К поле становится актуальным
} tblOprGlo_t, *ptblOprGlo_t;
//-------------------------------------------------------------------------------------------------			
typedef	struct	_tblTmPrmGlo							// OBNOWLENIE PO FAKTU GOTOWNOSTI 5 STROKI IZ L@BOGO PO KA RA I 14 STROKI 5 PO KA RA
{
	unsigned short	length;								// = sizeof(struct)
	unsigned char	actual;
	unsigned int	na;									// дата данных в таблице, день в четырехлетнем цикле
	unsigned int	n4;									// дата данных в таблице, число четырехлетних циклов от 1996г
	double			tauc;   							// смещение времени ГЛОНАСС относительно UTC	
	double			taugps;	                            // смещение времени GPS относительно времени ГЛОНАСС (дробная часть)
	double			b1;									// см. ИКД
	double			b2;                                 // см. ИКД
	unsigned char	kr;									// см. ИКД
} tblTmPrmGlo_t, *ptblTmPrmGlo_t;
//-------------------------------------------------------------------------------------------------			
typedef	struct	_tblAlmGlo_1
{
	unsigned short	length;								//
	unsigned char	onErrData;							// "1" обнаружены ошибки в данных, данные для этого НКА не актуальны
	unsigned char	onEmpty;							// "1" --- признак НКА, с литерой 24 (недействительная частота), исключается из прогноза внесистемных НКА. "2" --- признак пустого НКА (все поправки в альманахе нулевые), но частота действительная
	unsigned char	onSystem;							// 0 - не в системе, 1 - в системе
	unsigned char	num;								// system number sat
	unsigned char	lit;                                // номер литерной частоты см. ИКД
	double			lambda;								// гринвичская долгота восходящего узла орбиты, радианы
	double			lambdaT;							// мдв прохождения восходящего узла орбиты, ближайшее к началу суток с номером Na, секунды
	double			dI;									// поправка к среднему значению наклонения орбиты, радианы
	double			dT;									// поправка к среднему значению драконического периода обращения
	double			ddT;								// скорость изменения поправки
	double			e;									// эксцентриситет орбиты
	double			omega;								// аргумент перигея, радианы
	double			tau;
} tblAlmGlo_1_t, *ptblAlmGlo_1_t;

typedef	struct	_tblAlmGlo								// OBNOWLENIE PO FAKTU GOTOWNOSTI STROKI IZ SUPERKAdRA содержащих ALXMANAH
{
	unsigned short	length;
	unsigned char	actual;
	unsigned int	na;									// дата данных в таблице, день в четырехлетнем цикле	
	unsigned int	n4;									// дата данных в таблице, число четырехлетних циклов от 1996г
	tblAlmGlo_1_t 	sat[MAXSAT_GLO]; // 24
	unsigned int	tmVtoRsvd;							// время приема альманаха,  от 01.01.2000г в ШВ ГЛОНАСС
} tblAlmGlo_t, *ptblAlmGlo_t;

//-------------------------------------------------------------------------------------------------			
typedef	struct _tblSatGlo
{
	tblHdr_t*		hdr;
	tblObs_t*		obs;	
	tblAddInf_t*	add;
	tblOprGlo_t*    opr    [NI_COUNT];
	tblTmPrmGlo_t*  timePrm[NI_COUNT];
	tblAlmGlo_t*    alm    [NI_COUNT];
} tblSatGlo_t, *ptblSatGlo_t;


//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------	
//-------------------------------------------------------------------------------------------------


typedef	struct	_tblOprGps
{
	unsigned short	length;								// = sizeof(struct)
	unsigned char	actual;								// Флаг актуальности
	unsigned char	data[3][30];
	unsigned char	healS;
	unsigned short	wn;
	double			af0;
	double			af1;
	double			af2;
	unsigned int	t0c;
	unsigned int	t0e;
	double			sqrtA;
	double			cus;
	double			e;
	double			cuc;
	double			m0; 								// rad
	double			dn;                 				// rad
	double			crs;
	double			idot;
	double			omegaD;
	double			w;
	double			crc;
	double			i0;
	double			cis;
	double			omega0;
	double			cic;
	double			ura;								// точность сигнала
	double			tgd;
	unsigned char	iodc8Lsb;
	unsigned char	iode;	
} tblOprGps_t, *ptblOprGps_t;
//-------------------------------------------------------------------------------------------------			
typedef	struct	_tblTimePrmGps
{
	unsigned short	length;								// = sizeof(struct)
	unsigned char	actual;
	double			a1;
	double			a0;
	unsigned int	t0t;								// секунды
	unsigned int	wnt;
			 int	dtls;		
	unsigned int	wnlsf;
	unsigned int	dn;	
			 int	dtlsf;					
} 	tblTmPrmGps_t, *ptblTmPrmGps_t;
//-------------------------------------------------------------------------------------------------			
typedef	struct	_tblAlmGps_1
{
	unsigned short	length;
	unsigned char	onEmpty;							// "1" healt - S из 4 или 5 строки равно "111111" или sv id строки равно "0"
	unsigned char	healL;							
	unsigned int	t0a;								 
	unsigned char	num;
	double			af0;
	double			af1;
	double			m0;
	double			w;
	double			omega0;
	double			sqrtA;
	double			omegaD;
	double			di;
	double			e;
} tblAlmGps_1_t, *ptblAlmGps_1_t;
typedef	struct	_tblAlmGps
{
	unsigned short	length;
	unsigned char	actual;
	unsigned int	t0a;								// из 5 строка 25 страница
	unsigned int	wna;								// (длина 10 бит) 8LSB из 5 строка 25 страница, 2 MSB из 1 строки, учтено расположен. wn и wna в разных неделях
	tblAlmGps_1_t 	sat[MAXSAT_GPS]; // 32
	unsigned int	tmVtoRsvd;							// время приема альманаха
} tblAlmGps_t, *ptblAlmGps_t;
//-------------------------------------------------------------------------------------------------			
typedef	struct	_tblIonGps
{
	unsigned short	length;
	unsigned char	actual;
	double			alfa[4];							//  
	double			beta[4];			
} tblIonGps_t, *ptblIonGps_t;
//-------------------------------------------------------------------------------------------------			
typedef	struct _tblSatGps
{
	tblHdr_t*		hdr;
	tblObs_t*		obs;	
	tblAddInf_t*	add;
	tblOprGps_t*	opr;			
	tblTmPrmGps_t*	timePrm;
	tblAlmGps_t*	alm;			
	tblIonGps_t*	ion;				
} tblSatGps_t, *ptblSatGps_t;


//-------------------------------------------------------------------------------------------------
typedef struct _tblMeteo
{
	unsigned char actual;
	double temp;			//grad Cels
	double humid;			//?
	double press;			//millibar
} tblMeteo_t, *ptblMeteo_t;
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------


typedef	struct _lsttblSat
{
	tblSatGlo_t*	lstglo;
	unsigned int	nglo;
	tblSatGps_t*	lstgps;
	unsigned int	ngps;
	tblMeteo_t*		tblmeteo;
} lsttblSat_t, *plsttblSat_t;


//-------------------------------------------------------------------------------------------------	
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------

typedef	struct _tblPrgSat
{
	unsigned char	num; // номер системной точки
	unsigned char	lit; // литера - для глонасс
	unsigned char	sys; // = SYS_GLO/SYS_GPS
	double			delay;
	double			dop;	
	double			az;
	double			um;
	unsigned char	onSys;	// актуально только для ГЛОНАСС, указывает НКА в системе "1" или нет "0"
	double			c[3];
	double			v[3];
} tblPrgSat_t, *ptblPrgSat_t;
//-------------------------------------------------------------------------------------------------			
typedef	struct _lsttblPrgSat
{
	unsigned short	length;
	tblPrgSat_t*	lst;
	unsigned int	nSat;								// nSat не равно MAXSAT, максим. 30	
	unsigned int	tmPrgns; 		
	double			crdPos[3]; 
	unsigned char 	typeCrd;   
	unsigned char	typeEllps; 
	unsigned char	um_min;     
} lsttblPrgSat_t, *plsttblPrgSat_t;
//-------------------------------------------------------------------------------------------------			
typedef	struct _tblgpsutc
{
	unsigned char	actual;	
	int				gpsutc;
} tblgpsutc_t, *ptblgpsutc_t;


//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//	координаты/скорость ГЛОНАСС ПЗ-90
//	координаты/скорость GPS     WGS-84
//-------------------------------------------------------------------------------------------------


typedef	struct _tblCrdSat
{
	unsigned char	num;
	unsigned char	lit;
	unsigned char	sys;
	double			c[3];
	double			v[3];
	double			a[3];
	double			psvd;
	double			dop;
	unsigned char	bad;
} tblCrdSat_t, *ptblCrdSat_t;
//-------------------------------------------------------------------------------------------------			
typedef	struct _lsttblCrdSat
{
	unsigned short	length;
	tblCrdSat_t*	lst;
	unsigned int	nSat;							// 	nSat макс. 24
	unsigned int	tmCrd; 		
} lsttblCrdSat_t, *plsttblCrdSat_t;

//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------

typedef	struct _tblCrdPnt
{
	unsigned short	length;
	unsigned char	actual;	
	unsigned char	sys;	
	unsigned char	nsatGlo;		
	unsigned char	numsatGlo[24];
	unsigned char	nsatGps;		
	unsigned char	numsatGps[24];
	double			crd[3];
	double			dt;
	unsigned short	gf;
	double			dtGloGps; // Расхожение ШВ между ГЛОНАСС и GPS, актуально только при решении НВЗ по двум системам
} tblCrdPnt_t, *ptblCrdPnt_t;

//-------------------------------------------------------------------------------------------------
typedef struct _tblPosSystems
{
	unsigned short		length;
	unsigned char		actual;
	double				blhPosGlo[3];
	double				xyzPosGlo[3];
	double				blhPosGps[3];
	double				xyzPosGps[3];
} tblPosSystems_t, *ptblPosSystems_t;

typedef struct _tblStats
{
	unsigned short		length;
	unsigned char		actual;
	double				times; //Время наблюдения за НКА или время последовательного нахождения НКА в кадре
	unsigned int		timeVto[MAXTIME]; //Время ВТО, когда НКА находился в кадре
	double				psvd[MAXTIME]; //Массив для накопления псевдодальности за MAXTIME секунд
	double				diffPsvd[MAXTIME]; //Массив для накопления статистики за MAXTIME секунд
	double				doph[MAXTIME]; //Массив для накопления Доплера за MAXTIME секунд
	//double	phase[MAXTIME]; //Массив для накопления фазовой псевдодальности за MAXTIME секунд
	double				meanDiffPsvd; //Накопление статистики по НКА
	double				sigDiffPsvd; //Накопление статистики по НКА
	double				meanXi; //Накопление статистики по НКА Кси квадрат
	double				probInteg;
	double				diffPsvdUnbiased;
}tblStats_t, *ptblStats_t;

typedef struct _lstStats
{
	tblStats_t lstStatsGlo[MAXSAT_GLO];
	tblStats_t lstStatsGps[MAXSAT_GPS];
}lstStats_t, *plstStats_t;

typedef struct _tblCrdStaticFilter
{
	unsigned short	length;
	unsigned char	actual;
	double			minKoefF[5];	//минимальные значения коэффициентов фильтра
	unsigned int	maxStep;		//число шагов сходимости фильтра
	unsigned int	maxGf;			//максимальный геометрический фактор * 10
	double			crdBis[3];		//координаты БИС в ПЗ90.02 с точностью не более 30 м.
	unsigned int	timeVto;		//текущее время ВТО
	unsigned int	timeVtoStart;	//время ВТО начала работы фильтра
	double			crd[5];			//отфильтрованные 3 координаты и 2 ШВ
	unsigned char	sys;			//система решения НВЗ
}tblCrdFilter_t, *ptblCrdFilter_t;

typedef struct _tblKalman2
{
	unsigned short	length;
	unsigned char	actual;
	unsigned char	typeFilter;	//Тип фильтра
	unsigned int	timeVto;
	unsigned int	timeVtoStart;
	//Вектор состояния 
	double			state[2]; //Первый элемент - это оцениваемый параметр, второй элемент - скорость изменения оцениваемого параметра
	//коэффициенты усиления фильтра Калмана
	double			matrK[2];
	//Ковариационная матрица Калмана
	double			matrP[4];
	//число ошибок
	short int		error;
}tblKalman2_t, *ptblKalman2_t;
//TODO: перевести все фильтры к единой структуре tblFilter_t
typedef struct _tblFilter
{
	unsigned short	length;
	unsigned char	actual;
	unsigned char	type;	//Тип фильтра
	unsigned char	order;	//порядок фильтра
	unsigned int	timeVto;
	unsigned int	timeVtoStart;
	//Вектор состояния 
	double			*state; //Первый элемент - это оцениваемый параметр, второй элемент - скорость изменения оцениваемого параметра
	//коэффициенты усиления фильтра Калмана
	double			*matrK;
	//Ковариационная матрица 
	double			*matrP;
	//число ошибок
	short int		error;
}tblFilter_t, *ptblFilter_t;


typedef struct _tblKalmanObs
{
	unsigned short	length;
	unsigned char	actual;
	//unsigned char	update;
	unsigned char	sys;
	unsigned char	num;
	unsigned int	timeVto;
	unsigned char	actualParam[MAX_SIGNAL_COUNT];
	tblKalman2_t	psvdKlmn[MAX_SIGNAL_COUNT];
	tblKalman2_t	dopKlmn	[MAX_SIGNAL_COUNT];
	tblKalman2_t	fazeKlmn[MAX_SIGNAL_COUNT];
}tblKalmanObs_t, *ptblKalmanObs_t;

typedef struct _lstKalmanObs
{
	unsigned short	length;
	tblKalmanObs_t *lst;
	unsigned int	nSat;
}lstKalmanObs_t, *plstKalmanObs_t;

typedef struct _lstKalmanCrdPnt
{
	unsigned short	length;
	tblKalman2_t	lst[5];
	double			sigIzmCrd;
	double			sigModCrd;
	double			sigIzmSv;
	double			sigModSv;
}lstKalmanCrdPnt_t, *plstKalmanCrdPnt_t;

typedef struct _tblKalmanCrdSat
{
	unsigned short	length;
	unsigned char	actual;
	unsigned char	sys;
	unsigned char	num;
	unsigned int	timeVto;
	tblKalman2_t*	c[3];	//Координаты
	tblKalman2_t*	v[3];	//Скорости
}tblKalmanCrdSat_t, *ptblKalmanCrdSat_t;

typedef struct _tblNavSpeedTask
{
	unsigned short	length;
	unsigned char	actual;
	unsigned char	sys;
	unsigned int	timeVto;
	double			v[3];	//скорости перемещения антенны БИС
	double			df;		//отклонение частоты опорного генератора
	double			df2;	//отклонение частоты опорного генератора при скорости перемещения антенны БИС=0
}tblNavSpeedTask_t, *ptblNavSpeedTask_t;

//-------------------------------------------------------------------------------------------------
//#pragma pack (pop)
//-------------------------------------------------------------------------------------------------
#endif


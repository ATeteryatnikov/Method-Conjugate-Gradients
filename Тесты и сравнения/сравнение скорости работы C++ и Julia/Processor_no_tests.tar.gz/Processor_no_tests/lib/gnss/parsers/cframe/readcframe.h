#ifndef READCFRAME_H_
#define READCFRAME_H_

#include <gnssconfig.h>



#include <map>
#include <iostream>
#include "vto.h"
#ifdef Win32
#include <windef.h>
#endif

#include <DBError.h>

namespace libgnss
{

class SatelliteHistory;
class GLONASSFrequencySlots;
class DBTableCollection;
class GLONASSNavDataLoader;
class ObservablesLoader;
class MeteoDataLoader;
class SVAntennas;
class AntennaModels;
class PhaseCentreOffsetFrequency;
class SVPhaseCentreModels;
class GLONASSModels;
class ObservableTypes;


class WrongCFrameFormat : public StrException
{
public:
	WrongCFrameFormat(const std::string & what);
};

class NoVTODLL : public StrException
{
public:
	NoVTODLL();
};

typedef	int* (*cnvx0c_init)(void);
typedef	void (*cnvx0c_finit)(int*);
typedef	int* (*prgns_init)(void);
typedef	void (*prgns_finit)(int*);
typedef	int* (*crdsat_init)(void);
typedef	void (*crdsat_finit)(int*);
typedef	int* (*crdpnt_init)(void);
typedef	void (*crdpnt_finit)(int*);
typedef	lsttblSat_t* (*cnvx0c_upx0c)(int*, unsigned char*);
typedef	void (*crdpnt_set)(int*, int);
typedef	tblgpsutc_t* (*cnvx0c_getTblGpsUtc)(int*);
typedef unsigned int (*getTmVto)(lsttblSat_t*);
typedef void (*tmVtoToDate)(unsigned int, unsigned int*);
typedef tblAlmGlo_t* (*prgns_getAlmanGlo)(int*, lsttblSat_t*);
typedef tblAlmGps_t* (*prgns_getAlmanGps0)(int*, lsttblSat_t*);
typedef lsttblPrgSat_t* (*prgns_get2)(int*, tblAlmGlo_t*, tblAlmGps_t*,
									  unsigned int, int);
typedef lsttblCrdSat_t* (*crdsat_getGlo)(int*, lsttblSat_t*, unsigned int);
typedef lsttblCrdSat_t* (*crdsat_getGps)(int*, lsttblSat_t*, unsigned int, int);
typedef lsttblCrdSat_t* (*crdsat_getGps)(int*, lsttblSat_t*, unsigned int, int);
typedef lsttblCrdSat_t* (*crdsat_get)  (int* , lsttblSat_t* , unsigned int ,
										int , unsigned int);
typedef lsttblCrdSat_t* (*crdsat_get2) (int* , lsttblSat_t* , unsigned int ,
										int , unsigned int,unsigned int );
typedef tblCrdPnt_t* (*crdpnt_get)(int*, lsttblCrdSat_t*);
typedef tblCrdPnt_t* (*crdpnt_get)(int*, lsttblCrdSat_t*);
typedef tblCrdPnt_t* (*prgns_set)(int*, double*, int, int, int);
typedef void (*crdsat_setPnt)(int*, double*, int, int, int);
typedef void (*crdsat_setMeteo_)( int* , double , double , double );

/**
 * @brief Набор функций библиотеки vto, используемый в обработчике
 *
 * Для использования функций vto нужно создать объект данного класса.
 * При этом происходит загрузка библиотеки vto.dll и нахождение адресов всех
 * нужных нам функций.
 */
struct VtoFuncs
{
	cnvx0c_init	cinit;
	prgns_init	prg_init;
	crdsat_init	crds_init;
	crdpnt_init	crdp_init;

	cnvx0c_finit cfinit;
	prgns_finit prg_finit;
	crdsat_finit crds_finit;
	crdpnt_finit crdp_finit;

	cnvx0c_upx0c cupx0c;
	crdpnt_set set_crdpnt_sys;
	cnvx0c_getTblGpsUtc get_GpsUtc;
	getTmVto get_TmVto;
	tmVtoToDate time_VtoToDate;
	prgns_getAlmanGlo get_AlmGlo;
	prgns_getAlmanGps0 get_AlmGps;
	prgns_get2 get_prgns;
	prgns_set set_prgns;
	crdpnt_get get_crdpnt;
	crdsat_get get_crdsat;
	crdsat_get2 get_crdsat2;
	crdsat_getGlo get_crdsatGlo;
	crdsat_getGps get_crdsatGps;
	crdsat_setPnt setpnt_crdsat;
	crdsat_setMeteo_ crdsat_setMeteo;
	bool ok;
#ifdef Win32
	HINSTANCE handle;
#else
	void * handle;
#endif

	VtoFuncs();

	~VtoFuncs();
};

/** @brief Базовый класс обработки оперативных данных GPS из C-кадра
  *
  * Функция чтения бинарного файла C-кадров последовательно читает C-кадры из
  * файла и для каждого кадра обращается к объектам, обрабатывающим оперативные
  * и измерительные данные.
  *
  * По умолчанию объект данного класса ничего не делает, и его оператор()
  * должен быть перегружен.
  */
class CFrameGPSNavDataParser
{
public:
	virtual void operator() (tblHdr_t*hdr, tblTmPrmGps_t*tmprm,
							tblOprGps_t*oper );
};

/** @brief Функция проверяет наличие библиотеки чтенис C-кадров
 * 
 * Функция пробует загрузить библиотеку vto.
 * Название библиотек: vto.dll (win32), libvto32.so (linux i686),
 * libvto64.so (linux x64).
 * 
 * @return true, если библиотека vto найдена, и нужные функции загружены.
 */
bool checkBlob();

/**
 * @brief Класс, осуществляющий разбор C-кадра (парсер)
 *
 * Объект данного класса осуществляет связь с библиотекой vto для разбора
 * C-кадров и передаче данных объектам-загрузчикам.
 *
 * Объекты-загрузчики определяются при создании парсера. Возможно получение из
 * C-кадра следующей информации:
 *
 * @li Оперативная информация ГЛОНАСС и GPS
 * @li Измерительные данные ГЛОНАСС и GPS
 * @li Метеорологические данные: давление, влажность, метпература.
 *
 * Парсер можно перегружать, чтобы переопределить поведение некоторых функций,
 * например, добавить обработку или игнорирование ошибок в данных.
 * Для использования парсера без перегрузки можно использовать функцию
 * parseCFrames().
 */
class CFramesParser
{
private:
	DBTableCollection * tcol;
	ObservablesLoader * gloobsparser;
	ObservablesLoader * gpsobsparser;
	GLONASSNavDataLoader * glonavdataparser;
	CFrameGPSNavDataParser * gpsnavdataparser;
	MeteoDataLoader * meteoldr;

	SatelliteHistory * history;
	GLONASSFrequencySlots * gfs;
	AntennaModels * antmods;
	SVAntennas * svant;
	PhaseCentreOffsetFrequency * pcofreq;
	SVPhaseCentreModels * svpcm;
	GLONASSModels * gsm;
	ObservableTypes * otypes;
	std::map<int,real> obsdata; //Переменные для передачи базовому классу
	std::map<int,int> flags;

	//Типы измерений из C-кадра
	int g_l1c, g_l2c, g_l1p, g_l2p,
	g_c1c, g_c2c, g_c1p, g_c2p,
	g_d1c, g_d2c, g_d1p, g_d2p,
	r_l1c, r_l2c, r_l1p, r_l2p,
	r_c1c, r_c2c, r_c1p, r_c2p,
	r_d1c, r_d2c, r_d1p, r_d2p;

protected:
	virtual void loadObservables(tblObs_t *obs, tblHdr_t *hdr,
						 tblAddInf_t *add, tblOprGlo_t *oprglo);

	/**
	 * @brief Метод проверяет соответствие модели НКА из С-кадра и из таблиц
	 * @param orb_slot Орбитальный слот
	 * @param t Момент времени, секунды от 12:00 01-01-2000 TAI
	 * @param modification Модификация
	 *
	 * Коды модификаций: 0 - ГЛОНАСС, 1 - ГЛОНАСС-М, 2 - ГЛОНАСС-К1
	 *
	 * Метод находит модификацию НКА, которая в данный момент значится в
	 * таблицах, и, если она не совпадает с модификацией modification,
	 * создаёт новые записи в таблицах, как при чтении ANTEX-файла. Поскольку
	 * в C-кадрах отсутствует информация о номера НКУ, эти номера будут
	 * выбираться из неиспользованных ранее номеров.
	 *
	 * @li Создаётся новая запись истории НКА. В качесте идентификатора НКУ
	 * satellite_id указывается незанятый ранее satellite_id. В качестве времени
	 * начала и конца интервала действия записи указывается эпоха t и текущий
	 * момент времени.
	 * @li Если ещё не создана, то создаётся новая строка в antenna_models.
	 * При этом в качестве модели указывается строка "GLONASS", "GLONASS-M",
	 * "GLONASS-K1", ...
	 * @li Создаётся новая запись в sv_antennas. В качестве идентификатора
	 * модели задаётся
	 * @li Создаётся новая запись в таблице phase_centre_offset_frequency.
	 * В ней в полях dnorth, deast, dheight указываются стандартные значения
	 * (ниже), в качестве grid_id пишется -1 - сети поправок нет.
	 * @li Создаётся строка в таблице sv_phase_centre_models, в которой
	 * antenna_model_id и sat_history_id взято из предыдущих пунктов, valid_from
	 * и valid_until - эпоха t и текущее время. В качестве phase_centre_model_id
	 * указывается идентификатор записи из предыдущего пункта.
	 */
	virtual void checkSatelliteModification(char navsys,
			int orb_slot, real t, int modification);

	VtoFuncs vto;
	int * hvto;
	int * hprgnz;
	int * hcrdsat;

public:
	CFramesParser(ObservablesLoader * gloobsparser,
				  ObservablesLoader * gpsobsparser,
				  GLONASSNavDataLoader * glonavdataparser,
				  CFrameGPSNavDataParser * gpsnavdataparser,
				  MeteoDataLoader * meteoldr);

	~CFramesParser();

	/**
	 * @brief Выполняет разбор нескольких C-кадров
	 * @param buffer Буфер с C-кадрами
	 * @param ncframes Число кадров в буфере
	 */
	virtual void parseCFrame(unsigned char *buffer, int ncframes);

	/**
	 * @brief Прочитать все C-кадры из файла
	 * @param filename Имя файла
	 */
	virtual void read(const std::string & filename);

	/**
	 * @brief Что делать, если встретился кадр неизвестного типа
	 * @param type Тип кадра
	 */
	virtual void unknownFrameType(char type);

};

/**
 * @brief Разбор C-кадров из файла стандартным парсером
 * @param filename Имя файла с C-кадрами
 * @param gloobsparser Загрузчик измерительных данных ГЛОНАСС
 * @param gpsobsparser Загрузчик измерительных данных GPS
 * @param glonavdataparser Загрузчик оперативной информации ГЛОНАСС
 * @param gpsnavdataparser Загрузчик оперативной информации GPS
 * @param meteoldr Загрузчик метеорологических данных.
 */
void parseCFrames (const std::string & filename,
				   ObservablesLoader * gloobsparser,
				   ObservablesLoader * gpsobsparser,
				   GLONASSNavDataLoader * glonavdataparser,
				   CFrameGPSNavDataParser * gpsnavdataparser,
				   MeteoDataLoader * meteoldr);

}

#endif

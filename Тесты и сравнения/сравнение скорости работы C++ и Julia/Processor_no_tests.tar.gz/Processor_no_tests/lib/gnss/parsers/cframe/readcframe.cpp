#define _FILE_OFFSET_BITS 64
#include <readcframe.h>
#include <DBError.h>
#include <string>
#include <DBTableCollection.h>
#include <observables.h>
#include <readRINEXMeteo.h>
#include <readRINEXNavGLO.h>
#include <PhaseCentre.h>

#ifdef Win32
#include <tchar.h>
#include <windows.h>
#else
#include <dlfcn.h>
#endif

#include <cstdio>
#include "vto.h"

using namespace std;

namespace libgnss
{


WrongCFrameFormat::WrongCFrameFormat(const string &what)
	: StrException("WrongCFrameFormat", "Некорректный формат C-кадра: "+what)
{

}

NoVTODLL::NoVTODLL()
	: StrException("NoVTODLL", "Библиотека vto.dll не найдена.")
{

}

CFramesParser::CFramesParser(ObservablesLoader *gloobsparser,
							 ObservablesLoader *gpsobsparser,
							 GLONASSNavDataLoader *glonavdataparser,
							 CFrameGPSNavDataParser *gpsnavdataparser,
							 MeteoDataLoader *meteoldr)
{
	hvto = vto.cinit();
	hprgnz = vto.prg_init();
	hcrdsat = vto.crds_init();
	this->glonavdataparser = glonavdataparser;
	this->gloobsparser = gloobsparser;
	this->gpsnavdataparser = gpsnavdataparser;
	this->gpsobsparser = gpsobsparser;
	this->meteoldr = meteoldr;
	tcol=0;

	if (gloobsparser!=0)
		tcol = gloobsparser->getTableCollection();
	if (gpsobsparser!=0)
	{
		DBTableCollection * tcol2 = gpsobsparser->getTableCollection();
		if (tcol2!=tcol)
			throw NotImplementedException("Загрузка измерений GPS и ГЛОНАСС из"
										" C-кадра в разные коллекции таблиц");
	}

	if (tcol!=0)
	{
		history = (SatelliteHistory*)(tcol->getTable("satellite_history"));
		otypes =
				(ObservableTypes*)(tcol->getTable("observable_types"));
		gfs = (GLONASSFrequencySlots*)
				(tcol->getTable("glonass_frequency_slots"));
		antmods = (AntennaModels*)
				(tcol->getTable("antenna_models"));
		svant = (SVAntennas*)
				(tcol->getTable("sv_antennas"));
		pcofreq = (PhaseCentreOffsetFrequency*)
				(tcol->getTable("phase_centre_offset_frequency"));
		svpcm = (SVPhaseCentreModels*)
				(tcol->getTable("sv_phase_centre_models"));
		gsm = (GLONASSModels*)
				(tcol->getTableIfExists("glonass_models"));

		g_l1c = otypes->getObservableTypeID('G',0,ObservableTypes::MTYPE_L,'C');
		g_l2c = otypes->getObservableTypeID('G',1,ObservableTypes::MTYPE_L,'C');
		g_l1p = otypes->getObservableTypeID('G',0,ObservableTypes::MTYPE_L,'P');
		g_l2p = otypes->getObservableTypeID('G',1,ObservableTypes::MTYPE_L,'P');
		g_c1c = otypes->getObservableTypeID('G',0,ObservableTypes::MTYPE_C,'C');
		g_c2c = otypes->getObservableTypeID('G',1,ObservableTypes::MTYPE_C,'C');
		g_c1p = otypes->getObservableTypeID('G',0,ObservableTypes::MTYPE_C,'P');
		g_c2p = otypes->getObservableTypeID('G',1,ObservableTypes::MTYPE_C,'P');
		g_d1c = otypes->getObservableTypeID('G',0,ObservableTypes::MTYPE_D,'C');
		g_d2c = otypes->getObservableTypeID('G',1,ObservableTypes::MTYPE_D,'C');
		g_d1p = otypes->getObservableTypeID('G',0,ObservableTypes::MTYPE_D,'P');
		g_d2p = otypes->getObservableTypeID('G',1,ObservableTypes::MTYPE_D,'P');
		r_l1c = otypes->getObservableTypeID('R',3,ObservableTypes::MTYPE_L,'C');
		r_l2c = otypes->getObservableTypeID('R',4,ObservableTypes::MTYPE_L,'C');
		r_l1p = otypes->getObservableTypeID('R',3,ObservableTypes::MTYPE_L,'P');
		r_l2p = otypes->getObservableTypeID('R',4,ObservableTypes::MTYPE_L,'P');
		r_c1c = otypes->getObservableTypeID('R',3,ObservableTypes::MTYPE_C,'C');
		r_c2c = otypes->getObservableTypeID('R',4,ObservableTypes::MTYPE_C,'C');
		r_c1p = otypes->getObservableTypeID('R',3,ObservableTypes::MTYPE_C,'P');
		r_c2p = otypes->getObservableTypeID('R',4,ObservableTypes::MTYPE_C,'P');
		r_d1c = otypes->getObservableTypeID('R',3,ObservableTypes::MTYPE_D,'C');
		r_d2c = otypes->getObservableTypeID('R',4,ObservableTypes::MTYPE_D,'C');
		r_d1p = otypes->getObservableTypeID('R',3,ObservableTypes::MTYPE_D,'P');
		r_d2p = otypes->getObservableTypeID('R',4,ObservableTypes::MTYPE_D,'P');
	}

}

CFramesParser::~CFramesParser()
{
	//Уничтожить все созданные временные объекты
	vto.cfinit(hvto);
	vto.prg_finit(hprgnz);
	vto.crds_finit(hcrdsat);
}

void CFramesParser::loadObservables(tblObs_t *obs,
									tblHdr_t *hdr, tblAddInf_t *add,
									tblOprGlo_t *oprglo)
{
	ObservablesLoader * ldr;
	if (hdr->sys == SYS_GLO)
		ldr=gloobsparser;
	else if (hdr->sys == SYS_GPS)
		ldr=gpsobsparser;
	else
		ldr = 0;

	if (ldr==0)
		return;

	char navsys = ldr->getNavSystem();

	//Момент времени
	real tvto = obs->tmVto;
	UTCDateTime dt =  UTCDateTime::fromUTCJ2000(tvto - 15*3600);
	real taij2000 = dt.getTAIJ2000();

	//Идентификатор НКА
	int prn = hdr->num;
	if ((navsys == 'G') && (prn==0))
		prn=32;

	int sat_history_id=history->getSatHistoryID(navsys,prn,taij2000);

	//Частоты для перевода фазы в километры
	real f1, f2;
	if (navsys=='G')
	{
		f1 = 1.57542e+9;
		f2 = 1.22760e+9;
	}
	else
	{
		int letter = hdr->lit;
		if (letter>20) letter-=32;

		//Проверить, что частотный слот занесён в таблицу слотов
		try
		{
			int slot_ = gfs->getLetter(prn, dt);
			if (slot_!=letter)
				throw UnknownSlot(prn,dt);
		}
		catch (const UnknownSlot & e)
		{
			gfs->setLetter(prn, dt, letter);
		}

		f1 = 1.602e+9+letter*5.625e+5;
		f2 = 1.246e+9+letter*4.375e+5;
	}


	map<int, real> obsdata;
	map<int, int> flag;

	if (navsys == 'G')
	{
		if (obs->actual[0])
		{
			obsdata[g_l1c] = obs->faze[0] * lightSpeed / f1;
			obsdata[g_c1c] = obs->psvd[0] / (real)1000;
			obsdata[g_d1c] = obs-> dop[0] * lightSpeed / f1;
		}
		if (obs->actual[1])
		{
			obsdata[g_l2c] = obs->faze[1] * lightSpeed / f2;
			obsdata[g_c2c] = obs->psvd[1] / (real)1000;
			obsdata[g_d2c] = obs-> dop[1] * lightSpeed / f2;
		}
		if (obs->actual[2])
		{
			obsdata[g_l1p] = obs->faze[2] * lightSpeed / f1;
			obsdata[g_c1p] = obs->psvd[2] / (real)1000;
			obsdata[g_d1p] = obs-> dop[2] * lightSpeed / f1;
		}
		if (obs->actual[3])
		{
			obsdata[g_l2p] = obs->faze[3] * lightSpeed / f2;
			obsdata[g_c2p] = obs->psvd[3] / (real)1000;
			obsdata[g_d2p] = obs-> dop[3] * lightSpeed / f2;
		}
	}
	if (navsys == 'R')
	{
		if (obs->actual[0])
		{
			obsdata[r_l1c] = obs->faze[0] * lightSpeed / f1;
			obsdata[r_c1c] = obs->psvd[0] / (real)1000;
			obsdata[r_d1c] = obs-> dop[0] * lightSpeed / f1;
		}
		if (obs->actual[1])
		{
			obsdata[r_l2c] = obs->faze[1] * lightSpeed / f2;
			obsdata[r_c2c] = obs->psvd[1] / (real)1000;
			obsdata[r_d2c] = obs-> dop[1] * lightSpeed / f2;
		}
		if (obs->actual[2])
		{
			obsdata[r_l1p] = obs->faze[2] * lightSpeed / f1;
			obsdata[r_c1p] = obs->psvd[2] / (real)1000;
			obsdata[r_d1p] = obs-> dop[2] * lightSpeed / f1;
		}
		if (obs->actual[3])
		{
			obsdata[r_l2p] = obs->faze[3] * lightSpeed / f2;
			obsdata[r_c2p] = obs->psvd[3] / (real)1000;
			obsdata[r_d2p] = obs-> dop[3] * lightSpeed / f2;
		}
	}
	obsdata.erase(-1);

	//C-кадр не хранит ни каких флагов.
	for (map<int,real>::iterator it = obsdata.begin();
		 it!=obsdata.end(); ++it)
		flags[it->first] = 0;

	ldr->loadObservables(sat_history_id,taij2000,obsdata,flags);
}

void CFramesParser::checkSatelliteModification(char navsys,int orb_slot, real t,
											   int modification)
{
	if (gsm == 0)
		return;

	string thismodel = gsm->read(modification)[0].toString();

	int sat_history_id = -1;
	try
	{
		sat_history_id = history->getSatHistoryID(navsys,orb_slot,t);
		int satellite_id = history->read(sat_history_id)[1].toInt();
		int antenna_model_id = antenna_model_id=svant->find(
					Tuple()<<navsys<<satellite_id)[0].toInt();
		string model = antmods->read(antenna_model_id)[0].toString();
		if (thismodel == model)
			return;
	}
	catch (StrException & e)
	{

	}

	if (sat_history_id != -1)
		history->updateCell(Tuple()<<sat_history_id,4,
							UTCDateTime::fromTAIJ2000(t));

	//Найти новый идентификатор борта
	int new_sat_id=
			svant->getMaximalKeyElementValue(Tuple()<<navsys,-1).toInt()+1;
	//1) Вставить запись в таблицу истории
	sat_history_id = history->insertRow(Tuple()<<navsys<<new_sat_id
								<<orb_slot<<UTCDateTime::fromTAIJ2000(t)
														<<UTCDateTime::now());

	//2) Проверить, есть ли уже запись для AntennaModels
	DBTable::DBConstIterator it = antmods->idx_find("model",Tuple()<<thismodel);
	int ant_model_id;
	if (it.isEnd())
		ant_model_id = antmods->insertRow(Tuple()<<thismodel<<0
										  <<"Вставлено при чтении C-кадра");
	else
		ant_model_id = it.keyColumnValue(0).toInt();

	//3) Добавить новую запись в SVAntennas
	svant->insertRow(Tuple()<<navsys<<new_sat_id, Tuple()<<ant_model_id);

	//4) Добавить новую запись в таблице phase_centre_offset_frequency
	int new_pcm_id = pcofreq->getMaximalKeyElementValue(Tuple(),-1).toInt()+1;
	DBTable::DBConstIterator it_gsm = gsm->find(modification);
	//Для каждой частоты добавить соответствующую запись в таблицу
	//phace_centre_offset_frequency
	for (DBTable::DBConstIterator it2 = otypes->const_begin();
		 it2.isEnd() == false; ++it2)
	{
		char obs_navsys= it2[1].toChar();
		if (obs_navsys!=navsys)
			continue;
		int freq = it2[2].toInt();
		if (pcofreq->find(Tuple()<<new_pcm_id<<freq).isEnd())
			pcofreq->insertRow(Tuple()<<new_pcm_id<<freq,
							   Tuple()<<it_gsm[1]<<it_gsm[2]<<it_gsm[3]
							   <<(int)-1);
	}

	//5) Добавить запись в таблицу SVPhaseCentreModels
	svpcm->insertRow(Tuple()<<ant_model_id<<sat_history_id<<t,
					 Tuple()<<new_pcm_id<<UTCDateTime::now().getTAIJ2000());
}

void CFramesParser::parseCFrame(unsigned char *buffer, int ncframes)
{
	for (unsigned int i=0; i<ncframes; i++)
	{
		char type = buffer[0];
		unsigned short int size = *((unsigned short int *)(&(buffer[1])));
		if ((type==0xA5)||(type==0x25))
		{
			buffer+=size;
			continue;
		}
		if ((type!=0x0C) && (type!=0x1C))
		{
			buffer+=size;
			unknownFrameType(type);
			continue;
		}
		// Возвращает структуру по секундному Цкадру
		lsttblSat_t * lsat=(lsttblSat_t*) vto.cupx0c(hvto,buffer);

		if ((meteoldr!=0) && (lsat->tblmeteo->actual))
		{
			real tvto = numeric_limits<real>::quiet_NaN();
			if (lsat->nglo==0)
			{
				if (lsat->ngps==0)
					continue;
				else
					//Момент времени
					tvto = lsat->lstgps[0].obs->tmVto;
			}
			else
				tvto = lsat->lstglo[0].obs->tmVto;

			if (isnan(tvto)==false)
			{
				UTCDateTime dt =  UTCDateTime::fromUTCJ2000(tvto - 15*3600);
				real taij2000 = dt.getTAIJ2000();

		#define qn numeric_limits<real>::quiet_NaN()
				meteoldr->loadMeteoData(taij2000,lsat->tblmeteo->press,
										lsat->tblmeteo->temp,
										lsat->tblmeteo->humid,
										qn,qn,qn,qn,qn,qn,false);
			}
		}
		for (unsigned int i=0; i<lsat->nglo; i++)
			if ((glonavdataparser!=0)&&(lsat->lstglo[i].opr[0]->actual)
					&&(lsat->lstglo[i].alm[0]->actual))
			{
				int slot = lsat->lstglo[i].hdr->num;
				tblOprGlo_t * o = lsat->lstglo[i].opr[0];
				real tai = UTCDateTime::fromGLONASSNavData(
						lsat->lstglo[i].opr[0]->tb,
						lsat->lstglo[i].opr[0]->Nt,
						lsat->lstglo[i].alm[0]->n4).getTAIJ2000();
				int modification = o->m;
				checkSatelliteModification('R',slot,tai,modification);
				int letter = lsat->lstglo[i].hdr->lit;
				if (letter>20)
					letter-=32;
				glonavdataparser->loadNavData(slot,tai,o->dL2_L1,o->gmma,
											  o->tau,
						o->c[0] * ((real)1/(real)1000),
						o->c[1] * ((real)1/(real)1000),
						o->c[2] * ((real)1/(real)1000),
						o->v[0] * ((real)1/(real)1000),
						o->v[1] * ((real)1/(real)1000),
						o->v[2] * ((real)1/(real)1000),
						o->a[0] * ((real)1/(real)1000),
						o->a[1] * ((real)1/(real)1000),
						o->a[2] * ((real)1/(real)1000),
						letter, o->actual!=0,
						0, modification,
						o->Ft*0.001);

			}
		for (unsigned int i=0; i<lsat->ngps; i++)
			if (gpsnavdataparser!=0)
				(*gpsnavdataparser)(lsat->lstgps[i].hdr,
									lsat->lstgps[i].timePrm,
									lsat->lstgps[i].opr);
		for (unsigned int i=0; i<lsat->nglo; i++)
			if (gloobsparser!=0)
				loadObservables(
						lsat->lstglo[i].obs,
						 lsat->lstglo[i].hdr,
						 lsat->lstglo[i].add,
						lsat->lstglo[i].opr[0]);
		for (unsigned int i=0; i<lsat->ngps; i++)
			if (gpsobsparser!=0)
				loadObservables(
						lsat->lstgps[i].obs,
						 lsat->lstgps[i].hdr,
						 lsat->lstgps[i].add,0);
	}
}

void CFramesParser::unknownFrameType(char type)
{
	throw WrongCFrameFormat("Неожиданный тип кадра: "+
							Variant((int)(type)).toString());
}

void CFramesParser::read(const string &filename)
{
	//Действуем по-сишному, поскольку для этого приспособлен модуль vto.dll
	FILE *fpbin = fopen(filename.c_str(), "rb");
	if(fpbin == 0)
		throw StrException("readCFrame", "Файл C-кадров не найден");
	unsigned char data[4096];
	unsigned char typekrd[1];
	unsigned short int head[1];

	fseek(fpbin, 0, SEEK_END);
	fseek(fpbin, 0, SEEK_SET);
	while(!feof(fpbin))
	{
		// Иногда вместе с Цкадром записывается 25 кадр, который необходимо
		//пропустить
		if (fread(data,1,1,fpbin) < 1)
			break; //Выйти, если неожиданный конец файла

		if ((data[0]==0xA5) || (data[0]==0x25))
		{
			fseek(fpbin,57,SEEK_CUR);
//			fread(data,1,1,fpbin);
			continue;
		}
		if ((data[0]!=0x0C) && (data[0]!=0x1C))
		{
			fclose(fpbin);
			throw WrongCFrameFormat("Неожиданный тип кадра: "+
									Variant((int)(data[0])).toString());
		}
		//Чтение C-кадра
		if (fread(&(data[1]),2,1,fpbin)<1)
			break; //Выйти, если неожиданный конец файла
		unsigned short int size = *((unsigned short int *)(&(data[1])));
		fread(&(data[3]),1,size-3,fpbin);

		parseCFrame(data,1);

		// Возвращает структуру по секундному Цкадру
		//lsttblSat_t * lsat=(lsttblSat_t*) vto.cupx0c(hvto,data);

	}

	fclose(fpbin);
}


void parseCFrames (const std::string & filename,
				   ObservablesLoader * gloobsparser,
				   ObservablesLoader * gpsobsparser,
				   GLONASSNavDataLoader * glonavdataparser,
				   CFrameGPSNavDataParser * gpsnavdataparser,
				   MeteoDataLoader * meteoldr)
{
	CFramesParser p(gloobsparser,gpsobsparser,glonavdataparser,
					gpsnavdataparser,meteoldr);
	p.read(filename);
}



void CFrameGPSNavDataParser::operator() (tblHdr_t*hdr, tblTmPrmGps_t*tmprm,
									tblOprGps_t*oper )
{

}

VtoFuncs::VtoFuncs()
{
	ok = false;
#ifdef Win32
	handle = LoadLibrary(TEXT("vto.dll"));
	if (handle == NULL)
	{
		LPVOID lpMsgBuf;
		LPVOID lpDisplayBuf;
		DWORD dw = GetLastError();

		FormatMessage(
			FORMAT_MESSAGE_ALLOCATE_BUFFER |
			FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			dw,
			MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US),
			(LPTSTR) &lpMsgBuf,
			0, NULL );


		_tprintf( TEXT("%s\n"), lpMsgBuf );

		LocalFree(lpMsgBuf);
		throw NoVTODLL();
	}

	cinit = (cnvx0c_init)GetProcAddress(handle, "cnvx0c_init");
	prg_init = (prgns_init)GetProcAddress(handle, "prgns_init");
	crds_init = (crdsat_init)GetProcAddress(handle, "crdsat_init");
	crdp_init = (crdsat_init)GetProcAddress(handle, "crdpnt_init");

	cfinit = (cnvx0c_finit)GetProcAddress(handle, "cnvx0c_finit");
	prg_finit = (prgns_finit)GetProcAddress(handle, "prgns_finit");
	crds_finit = (crdsat_finit)GetProcAddress(handle, "crdsat_finit");
	crdp_finit = (crdpnt_finit)GetProcAddress(handle, "crdpnt_finit");

	cupx0c = (cnvx0c_upx0c)GetProcAddress(handle, "cnvx0c_upx0c");
	set_crdpnt_sys = (crdpnt_set)GetProcAddress(handle, "crdpnt_set");
	get_GpsUtc = (cnvx0c_getTblGpsUtc)GetProcAddress(handle, "cnvx0c_getTblGpsUtc");
	get_TmVto = (getTmVto)GetProcAddress(handle, "getTmVto");
	time_VtoToDate = (tmVtoToDate)GetProcAddress(handle, "tmVtoToDate");
	get_AlmGlo = (prgns_getAlmanGlo)GetProcAddress(handle, "prgns_getAlmanGlo");
	get_AlmGps = (prgns_getAlmanGps0)GetProcAddress(handle, "prgns_getAlmanGps0");
	get_prgns = (prgns_get2)GetProcAddress(handle, "prgns_get2");
	set_prgns = (prgns_set)GetProcAddress(handle, "prgns_set");
	get_crdpnt = (crdpnt_get)GetProcAddress(handle, "crdpnt_get");
	get_crdsat = (crdsat_get)GetProcAddress(handle, "crdsat_get");
	get_crdsat2 = (crdsat_get2)GetProcAddress(handle, "crdsat_get2");
	get_crdsatGlo = (crdsat_getGlo)GetProcAddress(handle, "crdsat_getGlo");
	get_crdsatGps = (crdsat_getGps)GetProcAddress(handle, "crdsat_getGps");
	setpnt_crdsat = (crdsat_setPnt)GetProcAddress(handle, "crdsat_setPnt");
	crdsat_setMeteo = (crdsat_setMeteo_)GetProcAddress(handle, "crdsat_setMeteo");
#else

	handle;
	if (sizeof(long int) == 4)
		handle = dlopen("libvto32.so", RTLD_LAZY);
	else
		handle = dlopen("libvto64.so", RTLD_LAZY);

	if (handle==NULL)
	{
		cout<<dlerror()<<endl;
		throw NoVTODLL();
	}

	cinit = (cnvx0c_init)dlsym(handle, "cnvx0c_init");
	prg_init = (prgns_init)dlsym(handle, "prgns_init");
	crds_init = (crdsat_init)dlsym(handle, "crdsat_init");
	crdp_init = (crdsat_init)dlsym(handle, "crdpnt_init");

	cfinit = (cnvx0c_finit)dlsym(handle, "cnvx0c_finit");
	prg_finit = (prgns_finit)dlsym(handle, "prgns_finit");
	crds_finit = (crdsat_finit)dlsym(handle, "crdsat_finit");
	crdp_finit = (crdpnt_finit)dlsym(handle, "crdpnt_finit");

	cupx0c = (cnvx0c_upx0c)dlsym(handle, "cnvx0c_upx0c");
	set_crdpnt_sys = (crdpnt_set)dlsym(handle, "crdpnt_set");
	get_GpsUtc = (cnvx0c_getTblGpsUtc)dlsym(handle, "cnvx0c_getTblGpsUtc");
	get_TmVto = (getTmVto)dlsym(handle, "getTmVto");
	time_VtoToDate = (tmVtoToDate)dlsym(handle, "tmVtoToDate");
	get_AlmGlo = (prgns_getAlmanGlo)dlsym(handle, "prgns_getAlmanGlo");
	get_AlmGps = (prgns_getAlmanGps0)dlsym(handle, "prgns_getAlmanGps0");
	get_prgns = (prgns_get2)dlsym(handle, "prgns_get2");
	set_prgns = (prgns_set)dlsym(handle, "prgns_set");
	get_crdpnt = (crdpnt_get)dlsym(handle, "crdpnt_get");
	get_crdsat = (crdsat_get)dlsym(handle, "crdsat_get");
	get_crdsat2 = (crdsat_get2)dlsym(handle, "crdsat_get2");
	get_crdsatGlo = (crdsat_getGlo)dlsym(handle, "crdsat_getGlo");
	get_crdsatGps = (crdsat_getGps)dlsym(handle, "crdsat_getGps");
	setpnt_crdsat = (crdsat_setPnt)dlsym(handle, "crdsat_setPnt");
	crdsat_setMeteo = (crdsat_setMeteo_)dlsym(handle, "crdsat_setMeteo");
#endif
	ok = true;
}

VtoFuncs::~VtoFuncs()
{
#ifdef Win32
	FreeLibrary(handle);
#else
	dlclose(handle);
#endif

}

bool checkBlob()
{
	VtoFuncs vto;
	return vto.ok;
}

}

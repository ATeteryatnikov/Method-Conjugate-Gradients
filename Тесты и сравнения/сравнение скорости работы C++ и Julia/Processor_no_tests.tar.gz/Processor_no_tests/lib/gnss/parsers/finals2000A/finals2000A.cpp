#include <cstdlib>
#include <fstream>

//! @file

using namespace std;

#include <DBTableCollection.h>
#include <Types.h>
#include <finals2000A.h>
#include <UTCDateTime.h>
#include <StdTables.h>
#include <ERPStorage.h>
#include <DBTable.h>
#include <StdTables.h>
#include <BuiltIn.h>



namespace libgnss
{

Settings::Enumerator sdups("Parsers","finals2000A","SkipDuplicates",
			   Variant::TYPE_INT,
		"Пропускать дубликаты при чтении finals2000A.data (0/1)",0);

Settings::Enumerator bull("Parsers","finals2000A","Bulletin",
			   Variant::TYPE_CHAR,
			   "Бюллетень для загрузки из finals2000A.data (A/B)",
			   Variant('B'));


using namespace std;

void readFinals2000A ( DBTableCollection * tables, istream & str )
{

	ERPStorage * erp = (ERPStorage *)(tables->getTable("ERP"));

	//Переменные настроек алгоритма чтения

	//Границы интервала чтения - по умолчанию заданы так, чтобы
	//в мыслимом прошлом и будущем не нарушались
	real timeLowerBound = -1.0e+50;
	real timeUpperBound = 1.0e+50;

	//Считываемые данные: бюлленеть A или B.
	char bulletin = 'A';

	//Игнорировать дубликаты в erp
	bool ignoreDupKeys = false;

	//Попробовать найти таблицу секунд координации
	LeapSeconds*ls=(LeapSeconds*)(tables->getTable("leap_seconds"));

	//Попробовать найти таблицу настроек
	map < string, DBTable * > :: iterator it = tables->find("settings");
	//Если таблица найдена, считать настройки
	if (it != tables->end())
	{
		Settings * s = (Settings*)(it->second);
		ignoreDupKeys = ((s->
				  getSettings(sdups)).toInt() == 1);

		bulletin = (s->
			     getSettings(bull)).toChar();

		bool success = false;
		real sttai;
		real endtai;
		double pm_interval;
		double ut1_interval;
		try
		{
			sttai = s->getSettings("Session","Processor",
					       "start_tai").toDouble();
			endtai = s->getSettings("Session","Processor",
						"end_tai").toDouble();
			pm_interval = 1/(s->getSettings("Parameters_settings",
					"ERP", "PM_Sampling").toDouble());
			ut1_interval = 1/(s->getSettings("Parameters_settings",
					"ERP", "TAI_UT1_Sampling").toDouble());
			success = true;
		}
		catch (DefaultValueForbiddenException e)
		{

		}
		catch (SettingsNotDefinedException e)
		{

		}

		if (success == true)
		{
			double interval = max(pm_interval, ut1_interval);
			int int_order = 0;
			int k = erp->getInterpolateOrder(Tuple()<<
							 ERPStorage::ERP_PM_X);
			if (k>int_order)
				int_order = k;

			k = erp->getInterpolateOrder(Tuple()<<
							 ERPStorage::ERP_PM_Y);
			if (k>int_order)
				int_order = k;


			k = erp->getInterpolateOrder(Tuple()<<
						ERPStorage::ERP_TAI_UT1);
			if (k>int_order)
				int_order = k;


			k = erp->getInterpolateOrder(Tuple()<<
							 ERPStorage::ERP_DX);
			if (k>int_order)
				int_order = k;


			k = erp->getInterpolateOrder(Tuple()<<
							 ERPStorage::ERP_DY);
			if (k>int_order)
				int_order = k;

			int_order/=2;

			timeLowerBound = sttai-int_order*interval;
			timeUpperBound = endtai+int_order*interval;

		}

	}

	//Настройки считаны, можно начинать чтение файла.
	string line1;
	while(true)
	{
		getline(str, line1);

		//trim
		line1.erase(line1.find_last_not_of(' ')+1);

		if (line1.length() < 15)
			break;

		string pm_x, pm_y, dx, dy, ut1_utc_s;

		string mjdutc = line1.substr(7, 8);
		real tai = UTCDateTime::fromUTCJ2000(
			  (atof(mjdutc.c_str())-DJM00)*86400.0).getTAIJ2000();

		//Если данные ПВЗ относятся к моменту времени за пределами
		//рассматриваемого интервала, пропустить их.
		if ((tai<timeLowerBound) || (tai>timeUpperBound))
			continue;

		//Считать данные в зависимости от того, выбраны бюллетень A или
		//B
		if (bulletin=='A')
		{
			if (line1.length()<125)
				break;
			pm_x = line1.substr(18,9);
			pm_y = line1.substr(37,9);
			ut1_utc_s = line1.substr(58,10);
			dx = line1.substr(97,9);
			dy = line1.substr(116,9);
		}
		else
		{
			if (line1.length()<184)
				break;
			pm_x = line1.substr(134,10);
			pm_y = line1.substr(144,10);
			ut1_utc_s = line1.substr(154,11);
			dx = line1.substr(165,10);
			dy = line1.substr(175,10);
		}

		//Ковертировать ut1_utc в tai_ut1
		real ut1_utc = Variant::fromString(Variant::TYPE_DOUBLE,
											 ut1_utc_s).toDouble();

					atof(ut1_utc_s.c_str());
		int leapsecs = UTCDateTime::getLeapSeconds(tai);
		real tai_ut1 = (double)(leapsecs)-ut1_utc;

		//Запись считанных ПВЗ в таблицу. Поскольку ПВЗ, кроме TAI_UT1,
		//были считаны в виде строк, для увеличения скорости обработки
		//при дальнейшим обращениям к ним в таблице их нужно перевести
		//в double.

		try
		{
			erp->insertRow(Tuple()<<ERPStorage::ERP_PM_X<<tai,
					    Tuple()<<Variant::fromString(
					       Variant::TYPE_DOUBLE, pm_x));
			erp->insertRow(Tuple()<<ERPStorage::ERP_PM_Y<<tai,
					    Tuple()<<Variant::fromString(
					       Variant::TYPE_DOUBLE, pm_y));
			erp->insertRow(Tuple()<<ERPStorage::ERP_DX<<tai,
					    Tuple()<<Variant::fromString(
					       Variant::TYPE_DOUBLE, dx));
			erp->insertRow(Tuple()<<ERPStorage::ERP_DY<<tai,
					    Tuple()<<Variant::fromString(
					       Variant::TYPE_DOUBLE, dy));
			erp->insertRow(Tuple()<<ERPStorage::ERP_TAI_UT1<<tai,
				       Tuple()<<real(tai_ut1));

		}
		catch (DuplicateKeyException e)
		{
			if (ignoreDupKeys==false)
				throw e;
		}

	}


}

#ifdef WithQT
QScriptValue parsefinals2000a(QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		DBTableCollection * c = (DBTableCollection *)(ctx->argument(0).toQObject());
		QString filename = ctx->argument(1).toString();
		ifstream strm (filename.toStdString().c_str());
		if (strm.is_open())
			readFinals2000A(c,strm);
		else
			throw StrException("readFinals2000A", "Файл невозможно открыть");
		return QScriptValue();
	}
	catch (StrException &e)
	{
		returnError(eng, string("Ошибка чтения файла ПВЗ: ")+e.what());
	}
}

BuiltIn parsefinals2000a_("readFinals2000A", 2, parsefinals2000a);
#endif

}

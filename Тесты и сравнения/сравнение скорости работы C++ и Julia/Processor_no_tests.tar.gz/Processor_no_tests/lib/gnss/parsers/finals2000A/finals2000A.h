#ifndef FINALS2000APARSER_H_
#define FINALS2000APARSER_H_

//! @file

#include <map>


namespace libgnss
{

class DBTableCollection;

class NoERPTableToWriteException : public StrException
{
public:
	inline NoERPTableToWriteException ()
		: StrException ("NoERPTableToWriteException",
			  "Невозможно прочитать файл ПВЗ в коллекцию, "
				"так как в коллекции нет таблицы ERP.")
	{

	}

};

/** @brief Функция для чтения файла finals2000A.data в таблицу erp
  *
  * Функция работает с существующей коллекцией таблиц tables.
  * Требуется, чтобы в коллекции были таблицы:
  *
  * - leap_seconds (используется для перевода меток времени в шкалу TAI и для
  * перевода поправки ut1_utc в форму tai_ut1)
  *
  * - settings: используются настройки:
  * -- Session->Processor->start_tai (начало интервала обработки)
  * -- Session->Processor->finish_tai (конец интервала обработки)
  * -- Parameters_settings->ERP->PM_Sampling (плотность узлов интерполяции
  *    параметра сдвига полюсов)
  * -- Parameters_settings->ERP->TAI_UT1_Sampling (плотность узлов интерполяции
  *    параметра неравномерности вращения Земли)
  * -- Parsers->finals2000A->SkipDuplicates (пропускать дубликаты, то есть,
  *    возможно, уже существующие записи в таблице ERP с теми же значениями
  *    типа параметра и времени; по умолчанию false, то есть при втрече дубли-
  *    ката будет сгенерирована ошибка). Значения TRUE или FALSE.
  * -- Parsers->finals2000A->Bulletin - бюллетень, данные которого нужно счи-
  *    тать. A или B.
  *
  * - ERP (в таблицу ERP будет проводиться запись данных)
  *
  * Если заданы настройки сеанса, а также плотность узлов интерполяции, то
  * будет проводиться считывание не всего файла, а только в установленных
  * временных границах [start_tai - N/PM_Sampling; end_tai + 2N/PM_Sampling]
  * и [start_tai - N/TAI_UT1_Sampling; end_tai + N/TAI_UT1_Sampling], где
  * число узлов для интерполяции соответствующего параметра (рассчитывается п
  * таблице InterpolateOrders внутри таблицы ERP) равно 2N или 2N+1.
  *
  * @param tables Целевая коллекция таблиц
  * @param str Поток, из которого будет происходить чтение данных
  */
void readFinals2000A ( DBTableCollection * tables, istream & str );

}

#endif


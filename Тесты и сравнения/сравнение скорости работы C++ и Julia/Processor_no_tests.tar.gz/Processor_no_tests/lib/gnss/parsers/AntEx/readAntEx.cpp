#include <fstream>
#include <string>
#include <set>

using namespace std;

#include <observables.h>
#include <Types.h>
#include <DBTableCollection.h>
#include <PhaseCentre.h>
#include <readAntEx.h>
#include <BuiltIn.h>

#ifdef WithQT
#include <QScriptEngine>
#include <QScriptValue>
#endif

namespace libgnss
{


UnsupportedAntexVersion::UnsupportedAntexVersion(const string& version):
	StrException("UnsupportedAntexVersion",
				 "Неподдерживаемая версия формата Antex: "+version)
{

}

WrongAntexFormat::WrongAntexFormat(const string &what)
	:StrException("WrongAntexFormat",
				  "Попытка чтения некорректного Antex-файла: "+what)
{

}

UnrecognisedAntennaType::UnrecognisedAntennaType(const string& antmodel)
	: StrException("UnrecognisedAntennaType",
				   "Невозможно установить, является ли антенна данной модели "
		"приёмной на БИС или передающей на НКА: "+antmodel)
{

}

CannotMatchSatIDSVNForAntenna::CannotMatchSatIDSVNForAntenna(
	const string& antennamodel,
	int slot,
	int sat_id,
	UTCDateTime t0,
	UTCDateTime t1
)
	: StrException ("CannotMatchSatIDSVNForAntenna","На промежуток времени "+
	t0.getUTCDateTimeString() + " - " + t1.getUTCDateTimeString()+
	"невозможно соотнести модель антенны "
	+antennamodel + ", Номер НКУ/SVN = "
	+Variant(sat_id).toString()+ " и слот/PRN = "
	+Variant(slot).toString()
	)
{

}


//! Запись в Antex-файле для одной антенны для одной частоты
struct AntexFreqRecord
{
	//! Частота
	int freq;
	
	//! Смещение от опорной точки антенны до среднего фазового центра
	real north, east, up;
	
	/** @brief Вариации фазового центра
	 * 
	 * Вариации фазового центра представляются в сеточном виде по
	 * азимуту и углу места.
	 * 
	 * net[i].first - угол азимута
	 * net[i].second[j].first - зенитный угол
	 * net[i].second[j].second - значение поправки к псевдодальности для
	 * заданных углов, мм. Знак поправки см. @ref PhaseCentreVariationGrid.
	 */
	vector < pair < real, vector < pair < real, real > > > > net;
	
	void clear()
	{
		freq = -1;
		north = east = up = 0.0;
		net.clear();
	}
};

//! Одна запись в Antex-файле
struct AntexRecord
{
	//! Тип антенны
	string antenna_type;

	/** @brief Информация о НКА или БИС?
	 *
	 * Если true, то прочитанная информация об НКА,
	 * если false - то прочитанная информация о БИС
	 */
	bool satellite_ant;

	//! Навигационная система НКА
	char nav_sys;

	//! Слот / prn
	int slot;

	//! Номер НКУ / SVN
	int sat_id;

	//! Шаг по азимуту
	real dazi;
	
	//! Пределы и шаг по зенитному углу
	real zen1, zen2, dzen;
	
	//! Идентификатор антенны БИС
	string antenna_sn;
	
	//! С какого момента времени информация действительна (секунды TAI от j2000)
	real valid_from;
	
	//! До какого момента времени информация действительна(секунды TAI от j2000)
	real valid_until;
	
	//! Зависимые от частоты поправки к фазовому центру
	vector <AntexFreqRecord> freqData;
	
	void clear ()
	{
		antenna_type = "";
		valid_from=UTCDateTime::fromUTCDateTime(1980,1,1,0,0,0).getTAIJ2000();
		valid_until=UTCDateTime::now().getTAIJ2000();
		nav_sys = '\0';
		slot = -1;
		sat_id = -1;
		antenna_sn = "";
		freqData.clear();
	}
};

int AntExReader::insertNewGrid(
		const vector<pair<real, vector<pair<real, real> > > > &grid)
{
	//Получить наименьший доступный grid_id
	int grid_id;
	if (pcvar->count() == 0)
		grid_id = 0;
	else
	{
		DBTable::DBConstIterator it1 = pcvar->const_end();
		it1--;
		grid_id = it1.keyColumnValue(0).toInt()+1;
	}

	Tuple pcoftuple;
	pcoftuple
		<<(int)0 //0 - Идентификатор сетки
		<<0.0l //1 - азимут в радианах
		<<0.0l //2 - зенитный угол в радианах
		  ;

	Tuple pcofval;
	pcofval<<0.0l;

	//Занести саму сетку
	for (unsigned int j = 0; j<grid.size();
		 ++j)
		for (unsigned int k = 0; k<grid[j].second.size(); ++k)
		{
			pcoftuple[0] = (int)(grid_id);
			pcoftuple[1] = grid[j].first * Pi/180.0;
			pcoftuple[2] = grid[j].second[k].first * Pi/180.0;
			pcofval[0] = (grid[j].second[k].second *1e-6);
			pcvar->insertRow(pcoftuple, pcofval);
		}

	return grid_id;
}

void AntExReader::read(DBTableCollection &tables, istream &str)
{
	tcol = &tables;

	Tuple pcofval;
	pcofval<<0.0l;
	
	//Запросить все необходимые таблицы
	
	//Таблица моделей антенн
	antmodels = (AntennaModels *)
				(tables.getTable("antenna_models"));

	//Таблица истории НКА
//	SatelliteHistory * history = (SatelliteHistory *)
//				(tables.getTable("satellite_history"));
				
	//Список приёмных антенн
	recant = (ReceivingAntennas *)
				(tables.getTable("receiving_antennas"));
	
	//Модели антенн на НКА
	svants=(SVAntennas*)(tables.getTable("sv_antennas"));

	pcfreq = (PhaseCentreOffsetFrequency *)
		(tables.getTable("phase_centre_offset_frequency"));

	pcvar = (PhaseCentreVariationGrid *)
		(tables.getTable("phase_centre_variation_grid"));

	svpcm = (SVPhaseCentreModels*)
		(tables.getTable("sv_phase_centre_models"));

	rapcm=(ReceivingAntennaPhaseCentreModels*)
		(tables.getTable("receiving_antenna_phase_centre_models"));

	string line;

	//Текущая читаемая запись
	AntexRecord currecord;
	
	//Текущая читаемая запись для частоты
	AntexFreqRecord curfreqrecord;
	
	//Тип файла (буква навигационной системы или M = Mixed)
	char syst;
	
	//Поддерживаемые версии Antex-формата
	set < string > supportedVersions;
	supportedVersions.insert("1.4");
	
	while (true)
	{
		if (str.eof())
			break;
		
		getline(str, line);
		if (line.size() == 0)
			continue;

		string label = "";
		if (line.size()>60)
			label = trim(line.substr(60,20));
		
		//Версия Antex и навигационная система
		if (label=="ANTEX VERSION / SYST")
		{
			//Проверить, поддерживается ли версия Antex
			string version = trim(line.substr(0,8));
			if (supportedVersions.find(version) == supportedVersions.end())
				throw UnsupportedAntexVersion(version);
				
			//Считать тип файла G, R, M:
			syst = line[20];
			
			continue;
		}
		
		//Тип поправок - поддерживаются только абсолютные поправки
		if (label=="PCV TYPE / REFANT")
		{
			char ftype = line[0];
			if (ftype!='A')
				throw NotImplementedException("Чтение Antex-файла с "
				"относительными поправками");
			continue;
		}
		
		//Комментарий игнорируется
		if (label=="COMMENT")
		{
			continue;
		}
		
		//Конец заголовка - не влияет на алгоритм чтения
		if (label=="END OF HEADER")
		{
			continue;
		}
		
		//Начало записи для антенны
		if (label=="START OF ANTENNA")
		{
			//Очистить структуру
			currecord.clear();
			continue;
		}
		
		//Тип антенны/серийный номер
		if (label=="TYPE / SERIAL NO")
		{
			currecord.antenna_type = trim(line.substr(0,20));
			if (line.length() >20)
			{
				currecord.nav_sys = line[20];
				currecord.antenna_sn = trim(line.substr(20,20));
				
				//Попробовать интерпетировать последующие символы, как слот НКА
				if (line.size()>22)
				{
					size_t idx = 0;
					try
					{
						currecord.slot = Variant::fromString(Variant::TYPE_INT, 
													line.substr(21,2)).toInt();
					}
					catch (exception e)
					{
						currecord.slot = -1;
					}
				}
				
				//Попробовать интерпретировать последующие символы как
				//номер НКУ
				if ((line.size()>43) && (currecord.slot != -1))
				{
					size_t idx = 0;
					try
					{
						currecord.sat_id=Variant::fromString(Variant::TYPE_INT,
									line.substr(41,3)).toInt();
					}
					catch (exception e)
					{
						throw WrongAntexFormat("Неверное задание номера НКУ "
											   "в строке:\n"+line);
					}
					currecord.satellite_ant = true;
				}
			}
			continue;
		}
		
		//Метод получения Antex-данных пока игнорируется
		if (label=="METH / BY / # / DATE")
		{
			continue;
		}
		
		//Шаг по углу азимута
		if (label=="DAZI")
		{
			try
			{
				currecord.dazi = Variant::fromString(Variant::TYPE_DOUBLE,
						line.substr(2,6)).toDouble();
			}
			catch (exception e)
			{
				throw WrongAntexFormat("Неверное задание шага по углу азимута "
									   "в строке:\n"+line);
			}
			continue;
		}
		
		//Определение сетки по зенитному углу
		if (label=="ZEN1 / ZEN2 / DZEN")
		{
			try
			{
				currecord.zen1 = Variant::fromString(Variant::TYPE_DOUBLE, 
												 line.substr(2,6)).toDouble();
				currecord.zen2 = Variant::fromString(Variant::TYPE_DOUBLE, 
												 line.substr(8,6)).toDouble();
				currecord.dzen = Variant::fromString(Variant::TYPE_DOUBLE, 
												 line.substr(14,6)).toDouble();
			}
			catch (exception e)
			{
				throw WrongAntexFormat("Неверное задание сетки по зенитному "
									   "углу в строке:\n"+line);
			}

			continue;
		}
		
		//Число частот игнорируется
		if (label=="# OF FREQUENCIES")
		{
			continue;
		}
		
		//С какого момента времени данные считаются действителььными
		if (label=="VALID FROM")
		{
			int year, month, day, hour, minute;
			real second;
			try
			{
				year = Variant::fromString(Variant::TYPE_INT, 
											   line.substr(0,6)).toInt();
				month = Variant::fromString(Variant::TYPE_INT, 
											   line.substr(6,6)).toInt();
				day = Variant::fromString(Variant::TYPE_INT, 
											   line.substr(12,6)).toInt();
				hour = Variant::fromString(Variant::TYPE_INT, 
											   line.substr(18,6)).toInt();
				minute = Variant::fromString(Variant::TYPE_INT, 
											   line.substr(24,6)).toInt();
				second = Variant::fromString(Variant::TYPE_DOUBLE, 
											   line.substr(30,6)).toDouble();
			}
			catch (exception e)
			{
				throw WrongAntexFormat("Неверное задание даты в строке:\n"+
									   line);
			}
			currecord.valid_from = UTCDateTime::fromUTCDateTime(year,month,day,
											hour,minute,second).getTAIJ2000();
			continue;
		}
		
		//До какого момента времени данные считаются действителььными
		if (label=="VALID UNTIL")
		{
			int year, month, day, hour, minute;
			real second;
			try
			{
				year = Variant::fromString(Variant::TYPE_INT, 
											   line.substr(0,6)).toInt();
				month = Variant::fromString(Variant::TYPE_INT, 
											   line.substr(6,6)).toInt();
				day = Variant::fromString(Variant::TYPE_INT, 
											   line.substr(12,6)).toInt();
				hour = Variant::fromString(Variant::TYPE_INT, 
											   line.substr(18,6)).toInt();
				minute = Variant::fromString(Variant::TYPE_INT, 
											   line.substr(24,6)).toInt();
				second = Variant::fromString(Variant::TYPE_DOUBLE, 
											   line.substr(30,6)).toDouble();
			}
			catch (exception e)
			{
				throw WrongAntexFormat("Неверное задание даты в строке:\n"+
									   line);
			}
			currecord.valid_until = UTCDateTime::fromUTCDateTime(year,month,day,
											hour,minute,second).getTAIJ2000();
			continue;
		}

		//Код SINEX пока игнорируется
		if (label=="SINEX CODE")
		{
			continue;
		}
		
		//Начало частоты - очистить структуру для частоты
		if (label=="START OF FREQUENCY")
		{
			curfreqrecord.clear();
			curfreqrecord.freq = ObservableTypes::getFrequencyFromAntex(
															line.substr(3,3));
			if (curfreqrecord.freq == -1)
				unsupportedFrequency(line.substr(3,3));
			continue;
		}

		//Смещение среднего фазового центра относительно опорной точки антенны
		if (label=="NORTH / EAST / UP")
		{
			try
			{
				curfreqrecord.north = Variant::fromString(Variant::TYPE_DOUBLE,
							line.substr(0,10)).toDouble();
				curfreqrecord.east = Variant::fromString(Variant::TYPE_DOUBLE,
							line.substr(10,10)).toDouble();
				curfreqrecord.up = Variant::fromString(Variant::TYPE_DOUBLE,
							line.substr(20,10)).toDouble();
			}
			catch (exception e)
			{
				throw WrongAntexFormat("Неверное задание смещения среднего "
									   "фазового центра в строке:\n"+
									   line);
			}
			continue;
		}
		
		//Конец информации о частоте - добавить текущую запись частоты в
		//структуру currecord
		if (label=="END OF FREQUENCY")
		{
			currecord.freqData.push_back(curfreqrecord);
			continue;
		}
		
		//Раздел среднеквадратических отклонений пропускается
		if (label=="START OF FREQ RMS")
		{
			while (label!="END OF FREQ RMS")
			{
				getline(str,line);
				label = trim(line.substr(60,20));
			}
			continue;
		}
		
		//Конец раздела антенны - записать новые данные в таблицы
		if (label=="END OF ANTENNA")
		{
			//1) Решить, антенна установлена на НКА и на БИС
			bool antdecided = false;
			
			//1.1) Проверить по таблице
			DBTable::DBConstIterator it0 = antmodels->idx_find("model",
					Tuple()<<currecord.antenna_type);
			if (it0 != antmodels->const_end())
			{
				antdecided = true;
				currecord.satellite_ant = (it0[1].toInt() == 0);
				
				//Если антенна на БИС, проверить, что не выполнены условия для
				//антенны НКА
				if (currecord.satellite_ant == false)
					if (currecord.sat_id != -1)
						throw WrongAntexFormat("Не удалось определить "
											   "принадлежность антенны БИС или "
											   "НКА.");
			}
			
			//1.2) Проверить по считанным номеру слота и номеру НКУ
			if ((currecord.sat_id != -1) && (currecord.slot != -1) && 
				(antdecided == false))
			{
				antdecided = true;
				currecord.satellite_ant = true;
			}
			if ((currecord.sat_id == -1)&&(antdecided == false))
			{
				antdecided = true;
				currecord.satellite_ant = false;
			}
			
			if (antdecided == false)
				throw UnrecognisedAntennaType(currecord.antenna_type);


			//Идентификатор модели антенны
			int antenna_model_id;

			//Проверить наличие модели антенны в таблице
			antenna_model_id = getAntennaModelID(currecord.antenna_type,
												 currecord.satellite_ant);
				
			//Если запись для НКА, то найти все соответствующие ей записи в
			//истории изменения космической группировки
			//Индексы истории НКА, мнтервалы активности для которых
			//пересекаются с интервалом, указанном в Antex-файле

			//Идентификаторы записей истории НКА
			vector < int > sat_history_id;

			//Если антенна БИС, найти идентификатор антенны (или -1)
			int receiving_antenna_id;

			int cursatid = currecord.sat_id;
			
			//2) Если антенна НКА, то найти sat_history_id и убедиться, что
			// satellite_id связан с antenna_model_id через SVAntennas,
			// если satellite_id != -1.
			if (currecord.satellite_ant)
			{
				getSatelliteHistoryIDs(currecord.nav_sys,
									   currecord.sat_id,
									   currecord.slot,
									   currecord.antenna_type,
									   currecord.valid_from,
									   currecord.valid_until,
									   sat_history_id,
									   cursatid);
				
				//Если текущая антенна относится не ко всем НКА
				//с данной моделью антенны, то занести эту антенну
				//в SVAntennas.
				//Если в ANTEX-файле не приводится номер НКУ, то эта связь не
				//может быть восстановлена без дополнительных действий.
				if (cursatid != -1)
					if (svants->find(Tuple()<<currecord.nav_sys
						<<cursatid) == svants->const_end())
						svants->insertRow(Tuple()<<currecord.nav_sys
							<<cursatid, Tuple()<<antenna_model_id);
			}
			
			//3) Если антенна БИС, найти receiving_antenna_id
			else
			{
				if (currecord.antenna_sn == "")
					receiving_antenna_id = -1;
				else
				{
					DBTable::DBConstIterator it2=recant->idx_find(
							"serial_number", Tuple()<<currecord.antenna_sn);
					if (it2 == recant->const_end())
						receiving_antenna_id = recant->insertRow(Tuple()
							<<currecord.antenna_sn
							<<string("Антенна добавлена при чтении Antex-файла")
							<<antenna_model_id
						);
				}
			}


			//Занести ссылки на сетки в таблицы phase_centre_offset_frequency
			//и phase_centre_variation_grid
			
			//Получить новый идентификатор phase_centre_model_id
			int phase_centre_model_id;
			if (pcfreq->count() == 0)
				phase_centre_model_id = 0;
			else
			{
				DBTable::DBConstIterator it1 = pcfreq->const_end();
				it1--;
				phase_centre_model_id = it1.keyColumnValue(0).toInt()+1;
			}

			for (unsigned int i=0; i<currecord.freqData.size(); i++)
			{
				//Занести сетку поправок и получить её идентификатор
				int grid_id = insertNewGrid(currecord.freqData[i].net);


				if (currecord.freqData[i].freq == -1)
					continue;
				//Занести ссылку на сетку (перевести из мм в км)
				pcfreq->insertRow(
					Tuple()
					<<phase_centre_model_id
					<<currecord.freqData[i].freq,
					Tuple()
					<<(currecord.freqData[i].north*1e-6)
					<<(currecord.freqData[i].east*1e-6)
					<<(currecord.freqData[i].up*1e-6)
					<<(int)(grid_id));
				
			}

			if (currecord.satellite_ant)
			{
				//Для антенны НКА занести ссылки в таблицу
				//SVPhaseCentreModels
				for (unsigned int i=0; i<sat_history_id.size(); i++)
					svpcm->insertRow(Tuple()<<antenna_model_id
						<<sat_history_id[i]<<currecord.valid_from,
					  Tuple()<<phase_centre_model_id<<currecord.valid_until);
			}
			else
				//Для антенны БИС занести ссылку в таблицу
				//ReceivingAntennaPhaseCentreModels
				rapcm->insertRow(Tuple()<<antenna_model_id
					<<receiving_antenna_id<<currecord.valid_from,
					 Tuple()<<phase_centre_model_id<<currecord.valid_until);

			//Перейти к чтению следующих записей Antex
			continue;
		}

		//Чтение сети поправок
		//Если чтение дошло до этого места, то по методу исключения единственная
		//возможность для данной строки - строка содержит сетку поправок к
		//псевдодальности. Считать её.

		//В начале строки указывается азимут, или noazi
		real curazimuth;
		if (line.substr(3,5)=="NOAZI")
			curazimuth = -1.0;
		else
			curazimuth = Variant::fromString(Variant::TYPE_DOUBLE,
				line.substr(0,8)).toDouble();

		//Записи для данного значения угла азимута быть не должно, добавить его.
		curfreqrecord.net.push_back(
				pair < real, vector < pair < real, real > > > (
						curazimuth, vector < pair < real, real > >()
				));
		
		int curfreqn = curfreqrecord.net.size()-1;
		
		//Теперь считать сетку согласно разбивке, задаваемой в строке
		//ZEN1 / ZEN2 / DZEN
		int count = (currecord.zen2 - currecord.zen1)/currecord.dzen + 1;
		for (unsigned int i=0; i<count; i++)
			curfreqrecord.net[curfreqn].second.push_back(pair<real, real>
				(currecord.zen1 + currecord.dzen * i,
					Variant::fromString(Variant::TYPE_DOUBLE,
						line.substr(8*(i+1),8)).toDouble()));
	}
}

int AntExReader::getAntennaModelID(const string &antenna,
								   bool satellite_ant)
{
	//Таблица моделей антенн
	AntennaModels * antmodels = (AntennaModels *)
				(getTableCollection()->getTable("antenna_models"));
	DBTable::DBConstIterator it = antmodels->idx_find("model",
		Tuple()<<antenna);
	if (it==antmodels->const_end())
		return antmodels->insertRow(Tuple()
			<<antenna
			<<((satellite_ant)?(0):(1))<<string(
				"Модель антенны добавлена при чтении Antex-файла"));
	else
		return it.keyColumnValue(0).toInt();
}

void AntExReader::getSatelliteHistoryIDs(char nav_sys, int sat_id, int slot,
										 const std::string& antenna_type,
										 real valid_from, real valid_until,
										 vector<int> &sat_history_id,
											int & cursatid)
{
	//Номера НКУ - для контроля того, что по ошибке Antex-запись
	//не была ассоциирована с разными номерами НКУ. Если так случиться,
	//невозможно определить, какой номер НКУ правильный, поэтому
	//будет сгенерирована ошибка.
	vector < int > sat_id_;

	SatelliteHistory * history = (SatelliteHistory*)
			(getTableCollection()->getTable("satellite_history"));

	//Если антенна не зависит от НКА, то внести -1
	if ((sat_id == -1) && (slot == -1))
		sat_history_id.push_back(-1);
	else
	{
		// Перебрать всю историю НКА и сравнить номера слотов и НКУ
		for (DBTable::DBConstIterator it0 = history->begin();
			 it0!=history->const_end(); ++it0)
		{
			//Если в данной записи другой номер слота, или номер
			//НКУ (если номера слотов и НКУ указаны в Antex-записи),
			//пропустить данную запись
			if (((nav_sys != it0[0].toChar()))
				||((sat_id != it0[1].toInt())
					&&(sat_id != -1))
				||((slot != it0[2].toInt())
					&&(slot != -1)))
				continue;

			//Проверить, что либо один интервал лежит в другом,
			//либо они пересекаются.
			real t0 = it0[3].toUTCDateTime().getTAIJ2000();
			real t1 = it0[4].toUTCDateTime().getTAIJ2000();

			//1) Интервал из Antex-файла лежит в интервале из
			//	истории, то использовать только одну запись
			// в истории
			if ((valid_from>= t0)
				&&(valid_until <= t1))
			{
				//Какие бы интервалы работы НКА не были уже найдены,
				//они не должны перекрываться. На всякий случай,
				//удалить лишние интервалы, и использовать один,
				//покрывающий весь промежуток для записи Antex-
				//файла
				cursatid = it0[1].toInt();
				sat_id_.clear();
				sat_id_.push_back(it0[1].toInt());
				sat_history_id.clear();
				sat_history_id.push_back(
					it0.keyColumnValue(0).toInt());
				break;
			}

			//2) Интервал из Antex-файла содержит интервал
			//из истории, или частично перекрывается
			if (((valid_from <= t0)  //t0\in[from;until]
				&&(t0 <= valid_until))
				||
				((valid_from <= t1)  //t1\in[from;until]
				&&(t1 <= valid_until)))
			{
				//Проверять, что все выбираемые записи истории НКА
				//имеют один номер НКУ/SVN (они могут быть разные,
				//если в Antex-записи не указан SVN)
				//Если разные НКУ, сгенерировать ошибку
				if (sat_history_id.size()>0)
					if (sat_id_[sat_history_id.size()-1]!=
						it0[1].toInt())
						throw CannotMatchSatIDSVNForAntenna(
							antenna_type,
							slot,
							sat_id,
							UTCDateTime::fromTAIJ2000(
										valid_from),
							UTCDateTime::fromTAIJ2000(
								valid_until));

				sat_history_id.push_back(
					it0.keyColumnValue(0).toInt());
				sat_id_.push_back(it0[1].toInt());
				cursatid = it0[1].toInt();
			}
		}

		//Если не нашлось ни одной записи в истории, добавить
		//запись.
		if (sat_history_id.size() == 0)
		{
			if ((slot!=-1)&&(sat_id!=-1))
				sat_history_id.push_back(
				history->insertRow(Tuple()<<nav_sys
					<<sat_id<<slot
				<<UTCDateTime::fromTAIJ2000(valid_from)
				<<UTCDateTime::fromTAIJ2000(valid_until))
				);
			else
				throw CannotMatchSatIDSVNForAntenna(
					antenna_type,slot,sat_id,
					UTCDateTime::fromTAIJ2000(valid_from),
				UTCDateTime::fromTAIJ2000(valid_until));
		}
	}
}

void AntExReader::unsupportedFrequency(const string &freq)
{

}

#ifdef WithQT
QScriptValue readantex (QScriptContext*ctx, QScriptEngine * eng)
{
	try
	{
		DBTableCollection*tc=(DBTableCollection *)
				(ctx->argument(0).toQObject());
		QString filename = ctx->argument(1).toString();
		string fname_std = filename.toStdString();
		ifstream fstr(fname_std.c_str());
		if (!(fstr.is_open()))
			return QScriptValue(eng, "Файл "+filename+" не удалось прочитать.");
		AntExReader().read(*tc, fstr);
		fstr.close();
	}
	catch (const StrException  & e)
	{
		eng->abortEvaluation(QString::fromStdString(string("Ошибка: ")
														+e.what()));
	}
	return QScriptValue();
}

BuiltIn rantex("readAntexFile", 2, readantex);
#endif

}

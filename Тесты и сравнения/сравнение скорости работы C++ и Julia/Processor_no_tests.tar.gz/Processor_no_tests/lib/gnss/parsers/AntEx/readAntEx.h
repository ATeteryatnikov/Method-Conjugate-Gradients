#ifndef READANTEX_H_
#define READANTEX_H_

#include <string>
#include <DBError.h>
#include <UTCDateTime.h>
#include <DBVariant.h>

namespace libgnss
{

class UnsupportedAntexVersion : public StrException
{
public:
    UnsupportedAntexVersion(const std::string& version);
};

class WrongAntexFormat : public StrException
{
public:
	WrongAntexFormat(const std::string & what);
};

class UnrecognisedAntennaType : public StrException
{
public:
    UnrecognisedAntennaType(const std::string& antmodel);
};

class CannotMatchSatIDSVNForAntenna : public StrException
{
public:
    CannotMatchSatIDSVNForAntenna(const string & antennamodel,
								  int slot, int sat_id, UTCDateTime t0,
								  UTCDateTime t1);
};



class DBTableCollection;
class AntennaModels;
class ReceivingAntennas;
class SVAntennas;
class PhaseCentreOffsetFrequency;
class PhaseCentreVariationGrid;
class SVPhaseCentreModels;
class ReceivingAntennaPhaseCentreModels;

/**
 * @brief Класс для чтения ANTEX-файлов
 *
 * Класс создан для того, чтобы переопределить действия в разных ситуациях.
 * Эти действия определяются перегрузкой методов.
 *
 * Что можно переопределить:
 * @li Что делать в случае ошибок - пропустить проблемные данные или выйти
 * @li Добавлять ли новые НКА и БИС, или пропустить данные, или выйти
 */
class AntExReader
{
private:
	DBTableCollection * tcol;
protected:
	AntennaModels * antmodels;
	ReceivingAntennas * recant;
	SVAntennas * svants;
	PhaseCentreOffsetFrequency * pcfreq;
	PhaseCentreVariationGrid * pcvar;
	SVPhaseCentreModels * svpcm;
	ReceivingAntennaPhaseCentreModels*rapcm;

public:

	inline DBTableCollection * getTableCollection()
	{
		return tcol;
	}

	/**
	 * @brief Найти идентификатор антенны по её модели
	 * @param antenna Модель/тип антенны
	 * @param satellite_ant Признак принадлежности антенны НКА
	 * @return Идентификатор
	 *
	 * По умолчанию, если модели антенны нет в таблице, метод добавляет
	 * антенну в таблицу.
	 *
	 * Метод будет вызван после чтения строки TYPE / SERIAL NO и должен внести
	 * новую антенну в таблицу или получить идентификатор существующей.
	 */
	virtual int getAntennaModelID(const std::string & antenna,
								  bool satellite_ant);


	/**
	 * @brief Найти список идентификаторов НКА с данным номером слота и НКУ
	 * @param nav_sys Навигационная система
	 * @param sat_id Номер НКУ
	 * @param slot Номер слота
	 * @param antenna_type Тип антенны
	 * @param valid_from Начало временнОго интервала
	 * @param valid_until Конец временнОго интервала
	 * @param sat_history_id Возвращаемые значения: список идентификаторов НКА
	 * @param cursatid Возвращаемое значение: найденный НКУ, если не был указан
	 *
	 * По умолчанию, находит все идентификаторы НКА в таблице satellite_history,
	 * у которых номера НКУ и слота совпадают с заданными на заданном
	 * временнОм интервале (или с частичным перекрытием временного интервала).
	 * Если таких идентификаторов не находится, идентификатор добавляется.
	 */
	virtual void getSatelliteHistoryIDs(char nav_sys, int sat_id, int slot,
										const string &antenna_type,
										real valid_from, real valid_until,
										vector<int> & sat_history_id,
										int &cursatid);

	/**
	 * @brief Метод определяет, что делать, если задана нестандартная частота
	 * @param freq Имя частоты
	 *
	 * По умолчанию, метод ничего не делает - тогда данная частота будет
	 * просто пропущена.
	 *
	 * Можно перегрузить метод так, чтобы он генерировал исключение
	 * WrongAntexFormat(), что прервёт загрузку файла, либо так, чтобы он
	 * передавал предупреждение о пропущенной частоте.
	 */
	virtual void unsupportedFrequency(const std::string & freq);

	/**
	 * @brief Вносит в таблицу поправку, зависящую от направления
	 * @param grid Сеть поправок, зависящих от направления
	 * @return Идентификатор вновь добавленной сети.
	 */
	virtual int insertNewGrid(const
			vector < pair < real, vector < pair < real, real > > > > & grid);



	/**
	 * @brief Чтение информации об антеннах из AntEx-формата
	 * @param tables Коллекция таблиц, в которую считываются данные
	 * @param str Поток, из которого читаются данные
	 *
	 * Функция читает записи из Antex-файла и заносит их в коллекцию таблиц.
	 * Под записью понимается набор данных между двумя ближайшими последовательно
	 * расположенными строками START OF ANTENNA и END OF ANTENNA. После того,
	 * как одна запись полностью считана и распознана, она заносится в таблицы.
	 *
	 * Сетки поправок, зависимых от азимута и зенитного угла, заносятся в таблицу
	 * @ref PhaseCentreVariationGrid, при этом запоминается их grid_id.
	 *
	 * В таблицу @ref PhaseCentreOffsetFrequency заносится запись Antex-файла, по
	 * одной строке таблицы на каждую частоту; при этом правильно указывается
	 * grid_id; идентификатор phase_centre_model_id запоминается.
	 *
	 * Если данной модели антенны нет в таблице @ref AntennaModels, то модель
	 * добавляется в таблицу, и запоминается идентификатор.
	 *
	 * Дальнейшие действия различаются для антенн БИС и НКА.
	 *
	 * Для антенн НКА:
	 *
	 * @li Если запись для НКА, и указаны номер слота и номер НКУ, а в таблице
	 * @ref SatelliteHistory нет соответствующей строки, обозначающей работу НКА с
	 * данным номером НКУ с данным номером слота, то соответствующая запись
	 * добавляется в таблицу @ref SatelliteHistory; в любом случае, для каждой
	 * записи Antex-файла находится несколько соответствующих ей строк в таблице
	 * @ref SatelliteHistory (уже существующих, или добавляемых при чтении), и
	 * запоминаются их идентификаторы (см. примечание 2). Если номера слота и
	 * НКУ не указаны, то вместо идентификатора @ref SatelliteHistory используется
	 * -1, показывающий в таблице @ref SVPhaseCentreModels, что запись относится
	 * ко всем антеннам данной модели.
	 *
	 * @li Если в таблице @ref SVAntennas нет записи о том, антенна какой модели
	 * установлена на НКА с данным номером НКУ, то соответствующая запсь добавляется
	 * в таблицу @ref SVAntennas.
	 *
	 * @li Для каждого идентификатора таблицы @ref SatelliteHistory,
	 * соответствующего данной записи Antex-файла (см. примечание 2), в таблицу
	 * @ref SVPhaseCentreModels заносится соответствие номера модели антенны,
	 * идентификатора таблицы истории @ref SatelliteHistory и идентификатора
	 * phase_centre_model_id.
	 *
	 * Для антенн БИС:
	 *
	 * @li Если для записи Antex-файла указан серийный номер антенны, то антенна
	 * будет внесена в таблицу @ref ReceivingAntennas и запоминается её
	 * идентификатор. Если серийный номер не указан, вместо идентификатора будет
	 * использоваться -1 (см. @ref ReceivingAntennaPhaseCentreModels).
	 *
	 * @li В таблицу @ref ReceivingAntennaPhaseCentreModels заносится соответствие
	 * идентификатора модели антенны (ключ таблицы @ref AntennaModels),
	 * идентификатора антенны (ключ таблицы @ref ReceivingAntennas) и идентификатора
	 * phase_centre_model_id.
	 *
	 * Примечания.
	 *
	 * 1) Не во всех записях Antex-файла можно правильно различить, относится ли
	 * запись антенны к НКА или БИС. Делается это по следующему алгоритму:
	 * @li Если удалось прочитать из файла слот и идентификатор НКА в записи
	 * "TYPE / SERIAL NO", то антенна - для НКА.
	 * @li В противном случае, если данная модель антенны есть в таблице
	 * @ref AntennaModels, то принадлежность антенны определяется по таблице.
	 * @li В противном случае, если 3-е и 4-е поля в строке "TYPE / SERIAL NO"
	 * пусты, то считается, что антенна установлена на БИС.
	 * @li Во всех остальных случаях возникает исключение
	 * @ref UnrecognisedAntennaType.
	 *
	 * 2) Интервалы занятия космическим аппаратом определенного орбитального слота,
	 * считанные из Antex-файлов и из других источников информации, из которых
	 * заполняется таблица @ref SatelliteHistory, могут отличаться. Поэтому
	 * используется следующий принцип заполнения таблиц: одна запись Antex-файла
	 * соответствует нескольким записям в таблице @ref SVPhaseCentreModels, по одной
	 * записи для каждой пары (Идентификатор частоты; Идентификатор истории),
	 * причём идентификаторов истории может быть несколько. Если номера НКУ и номера
	 * слота нет в Antex-записи, используется единственный идентификатор, -1. Если
	 * есть, то берутся те идентификаторы истории, в которых номер слота и НКУ
	 * равны соответствующим номерам в записи Antex-файла, а интервалы работы
	 * в @ref SatelliteHistory совпадает с интервалом, на который действительна
	 * Antex-запись (указывается в строках VALID FROM и VALID UNTIL).
	 */
	void read(DBTableCollection & tables, istream & str);
};

#define readAntEx(d,a) AntExReader().read(d,a)

}

#endif

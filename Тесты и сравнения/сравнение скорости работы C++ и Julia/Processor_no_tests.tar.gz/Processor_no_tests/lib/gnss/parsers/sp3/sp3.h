#ifndef SP3_H_
#define SP3_H_

//! @file

#include <DBTableCollection.h>
#include <UTCDateTime.h>

namespace libgnss
{


class SP3FileFormatException : public StrException
{
public:
	inline SP3FileFormatException (const std::string & line,
								   const std::string & what)
		: StrException ("SP3FileFormatException", "В строке: '"+line+"' "
			"ошибка: "+what)
	{

	}
};

class FrameNotAvailableException : public StrException
{
public:
	string coordSystem;
	inline FrameNotAvailableException(const string & coordsys)
		: StrException("FrameNotAvailableException",
			  "Ошибка при загрузке траектории НКА. "
				   "Для загрузки траектории НКА необходима "
			       "таблица coordinate_frames с описанием "
				   "системы координат "+coordsys+" .")
//		  coordSystem(coordsys)
	{
		coordSystem = coordsys;
	}

	~FrameNotAvailableException() throw()
	{

	}
};

class NoTrajectoryTableException : public StrException
{
public:
	inline NoTrajectoryTableException()
		: StrException ("NoTrajectoryTableException",
						"Невозможно прочитать SP3-файл в коллекцию, "
				"поскольку коллекция не содержит таблицы "
				"trajectory.")
	{

	}
};

class NoSatelliteTableException : public StrException
{
public:
	inline NoSatelliteTableException()
		: StrException("NoSatelliteTableException",
			  "Невозможно прочитать SP3-файл в коллекцию, "
			       "поскольку коллекция не содержит таблицы "
			       "satellite_history.")
	{

	}
};


/** @brief Чтение SP3-файла
  *
  * Процедура читает sp3-файл и заносит его в таблицу trajectory. При этом также
  * используются следующие таблицы:
  *
  * @li coordinate_frames и coordinate_types хранят информацию о системах
  * координат
  * @li leap_seconds - секунды координации используются для преобразования
  * шкал времени
  *
  * В SP3-файле НКА нумеруются с помощью буквы нав. системы и номера слота.
  * Если на заданный момент времени в базе данных нет информации о данном
  * номере слота, будет сгенерировано исключение @ref NoPRNForDateException .
  *
  */
void readSP3 ( DBTableCollection & tables, istream & str );

}

#endif

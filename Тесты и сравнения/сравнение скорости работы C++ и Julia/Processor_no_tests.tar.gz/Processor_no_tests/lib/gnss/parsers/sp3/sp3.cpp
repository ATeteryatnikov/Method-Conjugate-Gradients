#include <cstdlib>
#include <fstream>

using namespace std;

//! @file

#include <gnssconfig.h>

#ifdef WithQT
#include <QScriptEngine>
#include <QScriptValue>
#endif

#include <sp3.h>
#include <Frames.h>
#include <ParamTrajectory.h>
#include <StdTables.h>
#include <BuiltIn.h>

namespace libgnss
{


void readSP3 ( DBTableCollection & tables, istream & str )
{

	//Найти все необходимые таблицы
	ParamTrajectory * tr = (ParamTrajectory *)
			(tables.getTable("trajectory"));
	Frames * frames = (Frames *)
			(tables.getTable("coordinate_frames"));
	SatelliteHistory*history= (SatelliteHistory*)
			(tables.getTable("satellite_history"));


	string line1;

	UTCDateTime firstEpoch;

//-------------РАЗБОР ПЕРВОЙ СТРОКИ ЗАГОЛОВКА SP3-файла---------------------//
	//Из первой строки берётся версия SP3-файла для проверки - поддержива-
	//ется только версия C, - и система координат.
	getline(str, line1);
	if (line1.size() < 50)
		throw SP3FileFormatException(line1,"Неверный формат первой строки"
										   "SP3-файла.");
	char sp3ver = line1[1];
	string coordsystem = line1.substr(46,5);


	int frameid = frames->getCoordinateFrameID(coordsystem);
	try{frames->read(Tuple()<<frameid);}
	catch (KeyNotFoundException e)
	{
		throw FrameNotAvailableException(coordsystem);
	}

	//Теперь получить с какими идентификаторами заносить координаты КА
	//в таблицу trajectory
	vector < int > coordinate_ids = frames->getFrameCoordinates(frameid);


	int year = Variant(line1.substr(3,4)).toInt();
	int month = Variant(line1.substr(8,2)).toInt();
	int day = Variant(line1.substr(11,2)).toInt();

	firstEpoch = UTCDateTime::fromUTCDateTime(year,month,day,0,0,0);

//Вторая строка SP3-файла пропускается

	getline(str,line1);
	if (str.eof())
		throw SP3FileFormatException("","Неожиданный конец файла");

//-------------РАЗБОР ТРЕТЬЕЙ-СЕДЬМОЙ СТРОК ЗАГОЛОВКА SP3-файла-------------//

	//Разбор третьей и четвертой строк нужен только для того, чтобы
	//проверить, что все КА из файла известны в таблице satellite_history.

	getline(str,line1);
	if (line1.size()<50)
		throw SP3FileFormatException(line1,"Неверный формат третьей строки");
	if (str.eof())
		throw SP3FileFormatException("","Неожиданный конец файла");
	unsigned int satcount;
	try
	{
		satcount = Variant(line1.substr(4,2)).toInt();
	}
	catch (const StrException&e)
	{
		throw SP3FileFormatException(line1, e.what());
	}

	if (satcount>85)
		throw SP3FileFormatException(line1, "В строке указано больше 85 НКА,"
											"что не предусмотрено форматом.");

	//Узнать сколько строк содержат ID космических аппаратов
	//и сколько ID в каждой строке?
	unsigned int linescount[5]={0,0,0,0,0};
	for (unsigned int k=0; k<5; k++)
	{
		linescount[k] = 17;
		if (satcount<(k+1)*17)
		{
			linescount[k] = satcount % 17;
			break;
		}
	}

	//Проверить все КА на просутствие информации в таблице
	//satellite_history
	for (unsigned int k = 0; k<5; k++)
	{
// 		for (unsigned int i = 0; i<linescount[k]; i++)
// 		{
// 			char navsys = line1[9+i*3];
// 			int slot = Variant(line1.substr(10+i*3,2)).toInt();
// 
// 			//Если такого PRN на данный момент времени не известно, будет
// 			//сгенерировано исключение NoPRNForDateException.
// 			history->getSatHistoryID(navsys,slot, firstEpoch);
// 		}
		getline(str,line1);
		if (str.eof())
			throw SP3FileFormatException("", "Неожиданный конец файла");

	}

	//Сейчас в line1 находится восьмая строка SP3-файла.
	//Пропускаем информацию об accuracy - считываем за зря
	//строки 9-12
	for (unsigned int k=0; k<5; k++)
	{
		getline(str,line1);
		if (str.eof())
			throw SP3FileFormatException("","Неожиданный конец файла");
	}

	string timesystem = "GPS";
	if (line1.size()<12)
		throw SP3FileFormatException(line1,"В строке должна быть указанна "
										   "шкала времени.");

	//Сейчас в line1 находится тринадцатая строка SP3-файла
	if (sp3ver == 'c')
		timesystem = line1.substr(9,3);

	if (timesystem == "GLO")
		throw NotImplementedException("UTCDateTime::fromGLODateTime()");
	if (timesystem == "GAL")
		throw NotImplementedException("UTCDateTime::fromGALDateTime()");

	//Перейти к 23-й стркое
	for (unsigned int i=0; i<10; i++)
	{
		getline(str, line1);
		if (str.eof())
			throw SP3FileFormatException("","Неожиданный конец файла");
	}

	int hour, minute, second;
	while (line1!="EOF")
	{
		if (line1.size()<25)
			throw SP3FileFormatException(line1,"Ожидалось указание эпохи");
		//Сейчас курсор в файле указывает на эпоху.
		try
		{
			year = Variant(line1.substr(3,4)).toInt();
			month = Variant(line1.substr(8,2)).toInt();
			day = Variant(line1.substr(11,2)).toInt();

			hour = Variant(line1.substr(14,2)).toInt();
			minute = Variant(line1.substr(17,2)).toInt();
			second = Variant(line1.substr(20,11)).toDouble();
		}
		catch (const StrException & e)
		{
			throw SP3FileFormatException(line1, "Ожидалось указание эпохи");
		}

		UTCDateTime epoch;
		if (timesystem == "UTC")
			epoch = UTCDateTime::fromUTCDateTime(year,month,day,
						hour,minute,second);

		if (timesystem == "GPS")
			epoch = UTCDateTime::fromGPSDateTime(year,month,day,
						hour,minute,second);

		if (timesystem == "TAI")
			epoch = UTCDateTime::fromTAIDateTime(year,month,day,
						hour,minute,second);

		real epoch_j2000 = epoch.getTAIJ2000();

		while (true)
		{
			getline(str, line1);
			if (str.eof())
				throw SP3FileFormatException("","Неожиданный конец файла");
			line1 = trim(line1);

			//Новая эпоха
			if (line1[0] == '*')
				break;

			//Конец файла
			if (line1 == "EOF")
				break;

			//Строки с корреляциями пропускаем
			if (line1[0] == 'E')
				continue;

			int slot;
			char sys;
			real CX, CY, CZ;
			try
			{
				sys = line1[1];
				slot = Variant(line1.substr(2,2)).toInt();

				if (line1.size()<60)
					throw StrException("readSP3", "Неверная строка данных");

				CX = Variant(line1.substr(4, 14)).toDouble();
				CY = Variant(line1.substr(18, 14)).toDouble();
				CZ = Variant(line1.substr(32, 14)).toDouble();
			}
			catch (const StrException & e)
			{
				throw SP3FileFormatException(line1, e.what());
			}



			int TX, TY, TZ;
			if (line1[0] == 'P')
			{
				TX = coordinate_ids[0];
				TY = coordinate_ids[1];
				TZ = coordinate_ids[2];
			}

			if (line1[0] == 'V')
			{
				TX = coordinate_ids[3];
				TY = coordinate_ids[4];
				TZ = coordinate_ids[5];
			}

			//Найти идентификатор НКА
			int hisid;
			try
			{
				hisid = history->getSatHistoryID(sys,slot,epoch_j2000);
			}
			catch(NoPRNForDateException e)
			{
				//Если данный PRN отсутствует в базе на данную дату, просто
				//пропустить его
				continue;
			}

			//int satid = (*history)[Tuple()<<hisid][1].toInt();

			if ((CX!=0)&&(CY!=0)&&(CZ!=0))
			{
				tr->insertRow(Tuple()<<hisid<<TX<<epoch_j2000,
					      Tuple()<<CX);
				tr->insertRow(Tuple()<<hisid<<TY<<epoch_j2000,
					      Tuple()<<CY);
				tr->insertRow(Tuple()<<hisid<<TZ<<epoch_j2000,
					      Tuple()<<CZ);
			}

		}
	}
}

#ifdef WithQT
QScriptValue parsesp3(QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		DBTableCollection * c = (DBTableCollection *)
				(ctx->argument(0).toQObject());
		QString filename = ctx->argument(1).toString();
		ifstream strm (filename.toStdString().c_str());
		if (!(strm.is_open()))
			FileNotFoundException(filename.toStdString());
		readSP3(*c,strm);
		return QScriptValue();
	}
	catch (StrException & e)
	{
		returnError(eng, string("Не удалось прочитать SP3-файл: ")+e.what());
	}
}

BuiltIn parsesp3_("readSP3", 2, parsesp3);
#endif
}

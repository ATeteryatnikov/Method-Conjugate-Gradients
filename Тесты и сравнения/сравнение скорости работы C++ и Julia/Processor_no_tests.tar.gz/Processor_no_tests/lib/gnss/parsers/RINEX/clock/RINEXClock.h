#ifndef RINEXCLOCK_H_
#define RINEXCLOCK_H_

#include <string>


namespace libgnss
{
class DBTableCollection;

class WrongRINEXClockFormat : public StrException
{
public:
	WrongRINEXClockFormat (int linenumber, const string & what);
};

/**
 * @brief Чтение файла RINEX Clock
 * @param tables Коллекция таблиц, в которую считывается информация
 * @param str Поток, из которого считываются данные
 *
 * Из файла читаются:
 * @li Координаты БИС, реализующие систему координат, в которой уточнялся уход
 * часов (нужно, чтобы координаты БИС и уход часов был согласован). Координаты
 * пишутся в таблицу @ref Markers. Если в таблице нет данного маркера, он
 * добавляется. Если в таблице есть данный маркер, то его координаты будут
 * переписаны, если установлена настройка "Parsers", "RINEX_Clock",
 * "overwhiteMarkerPos".
 * @li Уход часов НКА и БИС пишется в таблицу @ref TimeShift. Заметим, что в
 * таблице уход часов относится к БИС, то есть к совокупности Маркер,
 * Антенна, Приёмник, а в RINEX-файле уход часов относится к маркеру, что
 * непонятно. Для записи в таблицу будут выбираться все идентификаторы БИС,
 * в которых в поле marker_id (таблица @ref ObservationSources) стоит
 * идентификатор данного маркера (идентификатор будет искаться по таблице
 * @ref Markers), и для них будет записываться один и тот же считанный для
 * данного маркера уход часов. Правильно заполнить таблицу ObservationSources
 * можно, либо прочитав заранее заготовленную таблицу из текстового файла,
 * потока или БД, либо предварительно прочитав все RINEX-файлы, которые
 * потребуется обработать.
 */
void readRINEXClock(DBTableCollection * tables, istream & str,
					bool addnewmarkers=true, bool overwritemarkers=true);

}

#endif

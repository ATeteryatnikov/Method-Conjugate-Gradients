#ifndef READRINEXMETEO_H_
#define READRINEXMETEO_H_

#include <Types.h>

namespace libgnss
{

class DBTableCollection;
class ParamTroposphere;

/**
 * @brief Абстрактный загрузчик метеоданных
 */
class MeteoDataLoader
{
public:

	/**
	 * @brief Метод, принимающий метеоданные от парсера
	 * @param tai Метка времени, секунды от 12:00 01.01.2000 TAI
	 * @param pr Давление, миллибар
	 * @param td Температура, градусы Цельсия
	 * @param rh Относительная влажность в процентах
	 * @param zw Влажная зенитная задержка, км.
	 * @param zd Сухая зенитная задержка, км.
	 * @param zt Полная зенитная задержка, км.
	 * @param wd Азимут направления, откуда дует ветер
	 * @param ws Скорость ветра, м/с
	 * @param ri Уровень осадков с момента предыдущего измерения
	 * @param hail Ненулевое значение обозначает град
	 */
	virtual void loadMeteoData(real tai, real pr, real td, real rh, real zw,
			real zd, real zt, real wd, real ws, real ri, bool hail) = 0;
};

/**
 * @brief Класс используется для загрузки метеоданных в таблицу тропосферы
 *
 * Данные копируются в таблицу Troposphere.
 */
class MeteodataReader : public MeteoDataLoader
{
private:
	ParamTroposphere * trop;
	int obs_src_id;
	int pr_t, td_t,rh_t,zw_t,zd_t,zt_t;
public:

	/**
	 * @brief Конструктор загрузчика
	 * @param tcol Коллекция таблиц, в которую будут записаны зенитные задержки
	 */
	MeteodataReader(DBTableCollection * tcol);

	void loadMeteoData(real tai, real pr, real td, real rh, real zw,
					   real zd, real zt, real wd, real ws, real ri, bool hail);

	inline void setObsSrcID(int newid)
	{
		obs_src_id = newid;
	}

	inline int getObsSrcID()
	{
		return obs_src_id;
	}
};

}

#endif

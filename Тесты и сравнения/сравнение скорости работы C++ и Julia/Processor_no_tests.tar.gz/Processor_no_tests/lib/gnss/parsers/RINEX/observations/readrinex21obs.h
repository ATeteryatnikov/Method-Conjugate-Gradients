#ifndef READRINEX21OBS_H_
#define READRINEX21OBS_H_

#include <map>
#include <observables.h>
#include <StdTables.h>
#include <string>

namespace libgnss
{

/** @file
 * 
 * Функции чтения RINEX-файлов
 */

class WrongRINEXFileTypeException : public StrException
{
public:
	inline WrongRINEXFileTypeException (const string & what = string())
		: StrException ("WrongRINEXFileTypeException",
						"Неверный формат RINEX OBSERVATION DATA. "+what)
	{

	}
};

class UnknownObservationTypeException : public StrException
{
public:
	inline UnknownObservationTypeException ( const std::string & denot )
		: StrException ("UnknownObservationTypeException",
						"Нет информации о типе измерений, обозначаемом "
						+ denot)
	{

	}
};

class RepeatedObservationListException : public StrException
{
	inline RepeatedObservationListException ( const std::string sysname )
		: StrException ("RepeatedObservationListException",
						"Повторно указаны типы измерений навигационной системы:"
						+sysname)
	{

	}
};

class UnknownNavigationSystemInRINEXException : public StrException
{
public:
	inline UnknownNavigationSystemInRINEXException(char c)
		: StrException ("UnknownNavigationSystemInRINEXException",
						"При чтении RINEX произошла ошибка: неизвестная буква "
						"навигационной системы: "+std::string(1,c))
	{

	}
};

/**
 * @brief Подготовить список типов измерительных данных стандарта RINEX 2.1
 *
 * Функция загружает в таблицу ObservationTypes список типов измерительных
 * данных, которые встречаются в стандарте RINEX 2.1. Типы вносимых измерений
 * можно указать с помощью флагов obstypes (см. @ref ObsTypesFlags).
 *
 * @param tables Коллекция таблиц, в которой подготавливается список
 * @param obstypes Флаги типов измерений (по умолчанию вносятся все измерения)
 */
void loadRINEX21ObservationCodes (DBTableCollection & tables);

/**
 * @brief Подготовить список типов измерительных данных стандарта RINEX 3.0
 *
 * Функция загружает в таблицу ObservationTypes список типов измерительных
 * данных, которые встречаются в стандарте RINEX 3.0
 *
 * @param tables Коллекция таблиц, в которой подготавливается список
 */
void loadRINEX3ObservationCodes ( DBTableCollection & tables);


enum ObsTypesFlags
{
	ObsType_StdPseudorange = 1,
	ObsType_HighPrecPseudorange = 2,
	ObsType_Phase = 4,
	ObsType_Doppler = 8,
	ObsType_SignalStrength = 16,
	NavSys_GPS = 32,
	NavSys_GLONASS = 64,
	NavSys_Galileo = 128,
	NavSys_SBAS = 256,
	ObsFreq_L1 = 512, //G1, R1, E2-L1-E1
	ObsFreq_L2 = 1024, //G2, R2
	ObsFreq_L5 = 2048, //G5, E5a
	ObsFreq_L6 = 4096, //E6
	ObsFreq_L7 = 8192, //E5b
	ObsFreq_L8 = 16384 //E5a+E5b
};

void parseRINEXObsData(const std::map<char,ObservablesLoader * > & loaders,
					int obscodes, istream & str);

/**
 * @brief Чтение измерительных данных из RINEX-файла
 * @param tables Набор таблиц, в который производится чтение
 * @param str Поток, из которого читается RINEX
 * @param obstypes Флаги типов измерительных данных, которые надо загрузить
 * 
 * Поддерживаемые версии RINEX: 2.10.
 * 
 * Запись измерительных данных осуществляется в таблицу "observables"
 * @ref Observables . Кроме того, если в заголовке встречаются не занесенные
 * ранее в таблицы антенны, маркеры и приёмники, информация о них также
 * собирается.
 * 
 * Теги в RINEX-файле и таблицы, в которые записываются данные:
 * 
 * В таблицу "markers" @ref Markers:
 * @li MARKER NAME
 * @li MARKER NUMBER
 * @li MARKER TYPE
 * @li APPROX POSITION XYZ
 * 
 * В таблицу "receivers" @ref Receivers
 * @li REC # / TYPE / VERS
 * 
 * В таблицу "receiving_antennas" @ref ReceivingAntennas
 * @li ANT # / TYPE
 * @li ANTENNA: DELTA H/E/N
 *
 * Теги используются, но нигде не сохраняются:
 * @li RINEX VERSION / TYPE - используется только для контроля формата
 * @li WAVELENGTH FACT L1/2 - используюстя при преобразовании данных
 * @li SYS / # / OBS TYPES (RINEX 3) - используются для расшифровки формата
 * @li # / TYPES OF OBSERV (RINEX 2) - используются для расшифровки формата
 * @li SYS / DCBS APPLIED - отмена поправок не реализована, вызывает исключение
 * @li SYS / PCVS APPLIED - отмена поправок не реализована, вызывает исключение
 * @li SYS / SCALE FACTOR - используется для преобразования данных
 * 
 * Не сохраняемые:
 * @li PGM / RUN BY / DATE
 * @li COMMENT
 * @li OBSERVER / AGENCY
 * @li ANTENNA: PHASECENTER
 * @li ANTENNA: B.SIGHT XYZ
 * @li ANTENNA: ZERODIR AZI
 * @li ANTENNA: ZERODIR XYZ
 * @li CENTER OF MASS: XYZ
 * @li PRN / # OF OBS
 * @li INTERVAL
 * @li TIME OF FIRST OBS
 * @li RCV CLOCK OFFS APPL
 * @li LEAP SECONDS
 * @li # OF SATELLITES
 * @li SIGNAL STRENGTH UNIT
 *  
 * Если типа измерительных данных нет в таблице @ref ObservationSource, или
 * если указанный слот НКА не занят в данный момент времени, то соответствующие
 * измерительные данные пропускаются, исключение не генерируется.
 * 
 */
void readRINEXObservations ( DBTableCollection & tables, istream & str,
							 int obstypes=32767);

/**
 * @brief Функция читает заголовок RINEX-файла
 * @param tables Коллекция таблиц
 * @param str Поток, из которого следует читать файл
 * @param obstypes Типы считываемых измерительных данных
 *
 * Данный метод читает заголовок RINEX-файла, но не считывает его содержимого.
 * Это может быть использовано для создания одинаковых справочников в нескольких
 * MPI-процессах, в то время как сами данные будут считаны распределенно (т.е.
 * разные RINEX-файлы в разных процессах).
 *
 * Договорённости по хранению данных из заголовка - см. документацию к функции
 * @ref readRINEXObservations
 */
void readRINEXObservationsHeader ( DBTableCollection & tables, istream & str,
					   int obstypes=32767);

}

#endif

#include <DBTableCollection.h>
#include <Troposphere.h>
#include <readRINEXMeteo.h>

namespace libgnss
{

MeteodataReader::MeteodataReader
(DBTableCollection * tcol)
{
	trop = (ParamTroposphere*)(tcol->getTable("troposphere"));
	obs_src_id = -1;
	pr_t = ParamTroposphere::getParameterType("PRESS");
	td_t = ParamTroposphere::getParameterType("TEMDRY");
	rh_t = ParamTroposphere::getParameterType("HUMREL");
	zw_t = ParamTroposphere::getParameterType("TROWET");
	zd_t = ParamTroposphere::getParameterType("TRODRY");
	zt_t = ParamTroposphere::getParameterType("TROTOT");
}

void MeteodataReader::
loadMeteoData(real tai, real pr, real td, real rh, real zw, real zd, real zt,
				   real wd, real ws, real ri, bool hail)
{
	if (obs_src_id == -1)
		throw StrException("MeteodataReader::loadMeteoData",
						   "Не указан идентификатор БИС");
	if (isnan(pr)==false)
		trop->insertRow(Tuple()<<obs_src_id
						<<pr_t
						<<tai, Tuple()<<pr);
	if (isnan(td)==false)
		trop->insertRow(Tuple()<<obs_src_id
						<<td_t
						<<tai, Tuple()<<td);
	if (isnan(rh)==false)
		trop->insertRow(Tuple()<<obs_src_id
						<<rh_t
						<<tai, Tuple()<<rh);
	if (isnan(zw)==false)
		trop->insertRow(Tuple()<<obs_src_id
						<<zw_t
						<<tai, Tuple()<<zw);
	if (isnan(zd)==false)
		trop->insertRow(Tuple()<<obs_src_id
						<<zd_t
						<<tai, Tuple()<<zd);
	if (isnan(zt)==false)
		trop->insertRow(Tuple()<<obs_src_id
						<<zt_t
						<<tai, Tuple()<<zt);
	//Остальные параметры игнорируются, так как не имеют
}

}

#include <set>
#include <string>
#include <vector>
#include <iostream>

//! @file

using namespace std;

#include <GravityPotential.h>
#include <readRINEXNavGLO.h>
#include <ParamTrajectory.h>
#include <StdTables.h>
#include <Frames.h>
#include <Kinematic.h>
#include <ERPStorage.h>
#include <NewtonGravity.h>
#include <YawAttitude.h>
#include <PhaseCentre.h>
#include <ephemeris.h>
#include <TimeShift.h>
#include <observables.h>
#include <sp3.h>
#include <ExtrapolateEphemeris.h>
#include <ERPStorage.h>
#include <YawAttitude.h>

namespace libgnss
{


GLONASSNavDataReader::GLONASSNavDataReader(DBTableCollection * tcol,
										   bool read_traj,
										   bool read_clk,
										   bool gfreqslot, const string &frame)
{
	this->read_clk = read_clk;
	this->read_traj = read_traj;
	this->gfreqslot = gfreqslot;
	history = (SatelliteHistory*)(tcol->getTable("satellite_history"));
	if (gfreqslot)
		gfs = (GLONASSFrequencySlots*)
				(tcol->getTable("glonass_frequency_slots"));
	if (read_traj)
	{
		traj = (ParamTrajectory *)(tcol->getTable("trajectory"));
		frames = (Frames *)(tcol->getTable("coordinate_frames"));
		frameid = frames->getCoordinateFrameID(frame);
		if (frameid==0xffffffff)
			throw FrameNotAvailableException(frame);
		coordinate_ids = frames->getFrameCoordinates(frameid);
		svphcm = (SVPhaseCentreModels*)
				(tcol->getTable("sv_phase_centre_models"));
		pcofreq = (PhaseCentreOffsetFrequency*)
				(tcol->getTable("phase_centre_offset_frequency"));
	}
	if (read_clk)
		clk = (ClockBias*)(tcol->getTable("time_shift"));

}

int GLONASSNavDataReader::getSatHistoryID(int orb_slot, real t)
{
	try
	{
		return history->getSatHistoryID('R',orb_slot,t);
	}
	catch (const NoPRNForDateException & e)
	{
		return -1;
	}
}

kinematic<real,6,defaultNonInert> GLONASSNavDataReader::phaseCentreOffset(
		const kinematic<real, 6, defaultNonInert> &posvel,
		int sat_history_id, real tai)
{
	ERPStorage*erp = (ERPStorage*)(getExtrapolateCollection()->getTable("ERP"));
	kinematic<real,6,defaultInert> posvel_inert=erp->ITRFtoGCRS(posvel,tai);
	kinematic<real,3,defaultInert> axis[3];
	kinematic<real,3,defaultInert> axisdot[3];
	kinematic<real,3,defaultInert> sun = getCelestialBodyEphemerides(11,tai);
	nominalOrientation(posvel_inert.subset<0,2>(),sun,axis);
	nominalOrientationDot(posvel_inert,sun,axisdot);
	int phcmodelid = svphcm->getPhaseCentreModelID(tai, sat_history_id);
	DBTable::DBConstIterator it3 = pcofreq->find(Tuple()<<phcmodelid<<(int)23);
	real dnorth = it3[0].toDouble(), deast = it3[1].toDouble(), dup = it3[2].toDouble();
	return erp->GCRStoITRF(dnorth*(axis[0].concat(axisdot[0]))
			+deast*(axis[1].concat(axisdot[1]))
			+dup*(axis[2].concat(axisdot[2])), tai);
}

void GLONASSNavDataReader::noCoordinates(int slot, real tai)
{
	cout<<"Предупреждение: нет или неполный набор координат для КА R"
	<<slot<<" на момент времени "
	<<UTCDateTime::fromTAIJ2000(tai).getUTCDateTimeString()<<endl;
}

void GLONASSNavDataReader::noVelocity(int slot, real tai)
{
	cout<<"Предупреждение: нет или неполный набор компонент скорости для КА R"
	<<slot<<" на момент времени "
	<<UTCDateTime::fromTAIJ2000(tai).getUTCDateTimeString()<<endl;
}

void GLONASSNavDataReader::noAcceleration(int slot, real tai)
{
	cout<<"Предупреждение: нет или неполный набор компонент ускорения для КА R"
	<<slot<<" на момент времени "
	<<UTCDateTime::fromTAIJ2000(tai).getUTCDateTimeString()<<endl;
}

void GLONASSNavDataReader::insertCoordinates(int history_id, real epoch,
											 real x, real y, real z)
{
	traj->insertRow(Tuple()<<history_id<<coordinate_ids[0]<<epoch,
		Tuple()<<x);
	traj->insertRow(Tuple()<<history_id<<coordinate_ids[1]<<epoch,
		Tuple()<<y);
	traj->insertRow(Tuple()<<history_id<<coordinate_ids[2]<<epoch,
		Tuple()<<z);
}

void GLONASSNavDataReader::insertVelocity(int history_id, real epoch,
											 real vx, real vy, real vz)
{
	traj->insertRow(Tuple()<<history_id<<coordinate_ids[3]<<epoch,
		Tuple()<<vx);
	traj->insertRow(Tuple()<<history_id<<coordinate_ids[4]<<epoch,
		Tuple()<<vy);
	traj->insertRow(Tuple()<<history_id<<coordinate_ids[5]<<epoch,
		Tuple()<<vz);
}

void GLONASSNavDataReader::insertAcceleration(int history_id, real epoch,
											 real ax, real ay, real az)
{
	traj->insertRow(Tuple()<<history_id<<coordinate_ids[6]<<epoch,
		Tuple()<<ax);
	traj->insertRow(Tuple()<<history_id<<coordinate_ids[7]<<epoch,
		Tuple()<<ay);
	traj->insertRow(Tuple()<<history_id<<coordinate_ids[8]<<epoch,
		Tuple()<<az);
}

void GLONASSNavDataReader::insertClockBias(int sat_history_id, real tai,
										   real bias, real vel)
{
	clk->insertRow(Tuple()<<1<<sat_history_id<<0<<tai,
				   Tuple()<<-bias);
	clk->insertRow(Tuple()<<1<<sat_history_id<<1<<tai,
				   Tuple()<<-vel);
}

void GLONASSNavDataReader::duplicateRecord(int slot, real t)
{
	cout<<"Предупреждение: на момент времени "<<
		  UTCDateTime::fromTAIJ2000(t).getUTCDateTimeString()<<
		  " для КА R"<<slot<<" повторная запись с координатами!"<<endl;
}

void GLONASSNavDataReader::insertFreqSlot(int slot, real t, int freqslot)
{
	gfs->setLetter(slot,UTCDateTime::fromTAIJ2000(t), freqslot);
}

void GLONASSNavDataReader::insertDiscontinuity(int sat_history_id, real t)
{
	traj->addDiscontinuity(Tuple()<<sat_history_id<<coordinate_ids[0]<<t);
	traj->addDiscontinuity(Tuple()<<sat_history_id<<coordinate_ids[1]<<t);
	traj->addDiscontinuity(Tuple()<<sat_history_id<<coordinate_ids[2]<<t);
}

void GLONASSNavDataReader::loadNavData(int orb_slot, real epoch, real delta_tau,
		real gamma_n, real tau_n, real x, real y, real z, real vx, real vy,
		real vz, real ax, real ay, real az, int freq_n, bool BN, int E, int m,
									   real Ft)
{
	int history_id = getSatHistoryID(orb_slot,epoch);

	if ((read_traj) && (history_id>=0))
	{
		if (x*y*z == 0.0l)
			noCoordinates(orb_slot, epoch);

		if (vx*vy*vz == 0.0l)
			noVelocity(orb_slot, epoch);

		if (ax*ay*az == 0.0l)
			noAcceleration(orb_slot, epoch);
		try
		{
			//Заносить в таблицу только ненулевые данные

			kinematic<real,6,defaultNonInert> p;
			p[0] = x; p[1] = y; p[2] = z; p[3] = vx; p[4] = vy; p[5] = vz;


			//Подсчитать смещение фазового центра
			kinematic<real,6,defaultNonInert> pc = phaseCentreOffset(p,
																  history_id,
																  epoch);

			//Занести в таблицу положения НКА
			if ((coordinate_ids.size()>=3)&&(x*y*z!=0.0))
				insertCoordinates(history_id,epoch,x-pc[0],y-pc[1],z-pc[2]);

			//Занести в таблицу скорости НКА
			if ((coordinate_ids.size()>=6)&&(vx*vy*vz!=0.0))
				insertVelocity(history_id,epoch,vx-pc[3],vy-pc[4],vz-pc[5]);

			//Занести в таблицу ускорения НКА
			if ((coordinate_ids.size()>=9)&&(ax*ay*az!=0.0))
				insertAcceleration(history_id,epoch,ax,ay,az);

		}
		catch (DuplicateKeyException e)
		{
			duplicateRecord(orb_slot,epoch);
		}
	}

	if (read_clk)
		insertClockBias(history_id,epoch,tau_n,gamma_n);

	if (gfreqslot)
		insertFreqSlot(orb_slot,epoch,freq_n);
}

void parseRINEXNavigationGLONASS (GLONASSNavDataLoader * ldr,
								   istream & str)
{
	set<string> supportedVersions;
	supportedVersions.insert("2.10");
	supportedVersions.insert("2.11");

	real corr_m_tauc = 0.0;

	//Прочитать заголовок
	while (true)
	{
		string line;
		getline(str,line);
		string label = trim(line.substr(60,20));

		//Проверить, что это файл навигационных сообщений ГЛОНАСС
		if (label == "RINEX VERSION / TYPE")
		{
			string version = trim(line.substr(0,9));
			if ((supportedVersions.find(version) == supportedVersions.end())
					||(line[20]!='G'))
				throw StrException("readRINEXNavigationGLONASS",
								   "Данные не содержат навигационной информации"
								   " ГЛОНАСС в формате RINEX");
		}

		//Игнорировать информацию о создании файла
		if (label == "PGM / RUN BY / DATE")
		{
			continue;
		}

		//Коментарии игнорируются
		if (label == "COMMENT")
		{
			continue;
		}

		//Информация о расхождении шкал ГЛОНАСС и UTC(SU)
		if (label == "CORR TO SYSTEM TIME")
		{
			corr_m_tauc = Variant::fromString(Variant::TYPE_INT,
											  line.substr(21,19)).toInt();
			continue;
		}

		//Секунды координацим игнорируются
		if (label == "LEAP SECONDS")
		{
			continue;
		}

		//Выход из цикла чтения заголовка
		if (label == "END OF HEADER")
			break;

	}

	//Чтение навигационных сообщений
	while (true)
	{
		string line;
		if (str.eof())
			break;
		//1) Чтение эпохи
		getline(str,line);
		if (line=="")
			break;

		int slot = Variant::fromString(Variant::TYPE_INT,
									   line.substr(0,2)).toInt();
		int year = Variant::fromString(Variant::TYPE_INT,
									   line.substr(3,2)).toInt();
		if (year>=80)
			year = 1900+year;
		else
			year = 2000+year;
		int month = Variant::fromString(Variant::TYPE_INT,
									   line.substr(6,2)).toInt();
		int day = Variant::fromString(Variant::TYPE_INT,
									   line.substr(9,2)).toInt();
		int hour = Variant::fromString(Variant::TYPE_INT,
									   line.substr(12,2)).toInt();
		int minute = Variant::fromString(Variant::TYPE_INT,
									   line.substr(15,2)).toInt();
		real second = Variant::fromString(Variant::TYPE_DOUBLE,
										line.substr(17,5)).toDouble();
		real mtaun = Variant::fromString(Variant::TYPE_DOUBLE,
										 line.substr(22,19)).toDouble();
		real gamman = Variant::fromString(Variant::TYPE_DOUBLE,
										  line.substr(41,19)).toDouble();
		//Остальные поля игнорируются

		//Перевести время в TAI от J2000
		real epoch = UTCDateTime::fromUTCDateTime(year, month, day, hour,
									minute, second).getTAIJ2000() + corr_m_tauc;
		//1) Чтение X
		getline(str,line);
		real x = Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(3,19)).toDouble();
		real vx = Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(22,19)).toDouble();
		real ax = Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(41,19)).toDouble();
		real BN_ = Variant::Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(60,19)).toDouble();
		
		//2) Чтение Y
		getline(str,line);
		real y = Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(3,19)).toDouble();
		real vy = Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(22,19)).toDouble();
		real ay = Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(41,19)).toDouble();
		real freqn_ = Variant::Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(60,19)).toDouble();


		//2) Чтение Z
		getline(str,line);
		real z = Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(3,19)).toDouble();
		real vz = Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(22,19)).toDouble();
		real az = Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(41,19)).toDouble();
		real E_ = Variant::Variant::fromString(Variant::TYPE_DOUBLE,
			line.substr(60,19)).toDouble();

		ldr->loadNavData(slot, epoch, numeric_limits<real>::quiet_NaN(),
						 gamman, -mtaun, x, y, z, vx, vy, vz,
						 ax, ay, az, (int)(floor(freqn_)),
						 (BN_==0.0l), (int)(floor(E_)), -1,
						 numeric_limits<real>::quiet_NaN());
	}
}

GLONASSNavDataExtrapolator::GLONASSNavDataExtrapolator(
		DBTableCollection *tcol, bool read_traj, bool read_clk, bool gfreqslot,
		const string &frame)
	: GLONASSNavDataReader(tcol,read_traj,read_clk,gfreqslot,frame)
{
	this->extrclk = read_clk;
	this->extrtraj = read_traj;
	this->extrfreql = gfreqslot;
	step = numeric_limits<real>::quiet_NaN();
}

void GLONASSNavDataExtrapolator::ExtrapolateEphemeris(real sat_history_id,
													  real t)
{
	//Выбор шага: если шаг задан, то использовать его.
	//Если шаг не задан, выбрать шаг не меньше 300 секунд и так, чтобы сетка
	//была равномерной.
	int nsteps;
	real _step;
	real T0 = prev_t[sat_history_id];
	real T1 = t;
	if (T1-T0>3600)
		T1=T0+3600;
	if (isnan(this->step))
	{
		nsteps = (T1-T0)/300;
		if (nsteps==0)
			nsteps = 1;
		_step = (T1-T0)/nsteps;
		if (T1==t)
		{
			nsteps--;
			T1-=_step;
		}
	}
	else
	{
		nsteps = (T1-T0)/step;
		while (T0+nsteps*step >= T1)
			nsteps--;
		T1 = T0+nsteps*step;
		_step = step;
	}

	const vector<real> & C = savecoords[sat_history_id];
	vector<vector<real> > ephemeris =extrapolateGLONASSEphemeris(
			T0, T1, nsteps, C[0],C[1],C[2],C[3],C[4],C[5],C[6],C[7],
			C[8]);
	for (unsigned int i=0; i<ephemeris.size(); i++)
	{
		insertCoordinates(sat_history_id,T0+i*_step,ephemeris[i][0],
				ephemeris[i][1],ephemeris[i][2]);
		if (ephemeris[i].size()<6)
			continue;
		if (isnan(ephemeris[i][3] + ephemeris[i][4] + ephemeris[i][6])==false)
			insertVelocity(sat_history_id,T0+i*_step,ephemeris[i][3],
										ephemeris[i][4],ephemeris[i][5]);
	}
	insertDiscontinuity(sat_history_id,t-0.9l);

}

void GLONASSNavDataExtrapolator::setStep(real step)
{
	this->step = step;
}

void GLONASSNavDataExtrapolator::loadNavData(
		int orb_slot, real t, real delta_tau, real gamma_n, real tau_n, real x,
		real y, real z, real vx, real vy, real vz, real ax, real ay, real az,
		int freq_n, bool BN, int E, int m, real Ft)
{
	int sat_history_id = getSatHistoryID(orb_slot,t);

	if (prev_t.find(sat_history_id) == prev_t.end())
	{
		prev_t[sat_history_id] = -1e+50;
		savecoords[sat_history_id].resize(9);
	}

	if ((extrtraj) && (sat_history_id>0))
	{

		//Если новая эпоха эфемерид, выполнить размножение по
		//предыдущей эпохе
		if (prev_t[sat_history_id] < t)
		{
			//Для размножения эфемерид нужны скорость и координаты
			if ((x*y*z==0.0l) || isnan(x*y*z))
			{
				noCoordinates(orb_slot,t);
				return;
			}
			if ((vx*vy*vz==0.0l) || isnan(vx*vy*vz))
			{
				noVelocity(orb_slot,t);
				return;
			}

			if (prev_t[sat_history_id]>-1e+40)
				ExtrapolateEphemeris(sat_history_id, t);

			vector<real> & C = savecoords[sat_history_id];

			kinematic<real,6,defaultNonInert> p;
			p[0] = x; p[1] = y; p[2] = z; p[3] = vx; p[4] = vy; p[5] = vz;


			//Подсчитать смещение фазового центра
			kinematic<real,6,defaultNonInert> pc = phaseCentreOffset(p,
																 sat_history_id,
																 t);

			//Запомнить данные эфемериды
			C[0] = x-pc[0];
			C[1] = y-pc[1];
			C[2] = z-pc[2];
			C[3] = vx-pc[3];
			C[4] = vy-pc[4];
			C[5] = vz-pc[5];
			C[6] = ax;
			C[7] = ay;
			C[8] = az;
		}
	}

	if ((extrclk) && (prev_t[sat_history_id]<t))
		insertClockBias(sat_history_id,t,tau_n,gamma_n);

	if ((extrfreql) && (prev_t[sat_history_id]<t))
		insertFreqSlot(orb_slot,t,freq_n);

	prev_t[sat_history_id] = t;

}

void GLONASSNavDataExtrapolator::finish(int orb_slot, real t)
{
	loadNavData(orb_slot,t,0,0,0,0,0,0,0,0,0,0,0,0,0,true,0,0,0);
	savecoords.erase(orb_slot);
	saveclkbias.erase(orb_slot);
	prev_t.erase(orb_slot);
}

void GLONASSNavDataExtrapolator::finish(real t)
{
	while (true)
	{
		map<int,real>::iterator it = prev_t.begin();
		if (it==prev_t.end())
			break;
		int orb_slot = it->first;
		finish(orb_slot,t);
	}
}

void readRINEXNavigationGLONASS (DBTableCollection & tables,
								 istream & str,
								 bool read_trajectory,
								 bool read_clk, bool
								 read_freqslots)
{
	GLONASSNavDataReader ldr (&tables,read_trajectory,
							  read_clk,read_freqslots);
	parseRINEXNavigationGLONASS(&ldr, str);
}

GLONASSModels::GLONASSModels(DBTableCollection *tcol)
	: DBTable(Columns()
			  <<Column(Variant::TYPE_INT, "model_icd_code"),
			  Columns()
			  <<Column(Variant::TYPE_STRING, "model_name")
			<<Column(Variant::TYPE_DOUBLE, "dx")
		   <<Column(Variant::TYPE_DOUBLE, "dy")
		  <<Column(Variant::TYPE_DOUBLE, "dz"))
{
	createIndex("model_name", OperatorPushableVector<string>()<<"model_name");
	tcol->addTable("glonass_models", this);
}

}

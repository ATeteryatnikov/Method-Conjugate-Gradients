#include <set>
#include <string>
#include <cmath>
#include <algorithm>
#include <limits>
#include <fstream>

using namespace std;

#ifdef WithQT
#include <QScriptEngine>
#include <QScriptValue>
#endif

#include <Frames.h>
#include <RINEXClock.h>
#include <StdTables.h>
#include <observables.h>
#include <TimeShift.h>
#include <BuiltIn.h>

namespace libgnss
{

WrongRINEXClockFormat::WrongRINEXClockFormat(int linenumber, const string &what)
	: StrException("WrongRINEXClockFormat","Некорректный формат RINEX: строка="
				   +Variant(linenumber).toString()
				   +". Проблема: "+what)
{

}

Settings::Enumerator overwriteMarkerPos("Parsers", "RINEX_Clock",
										"overwhiteMarkerPos",
										CTypeSelect::yesOrNo(),
			"Заменять координаты БИСов координатами из RINEX Clock-файла?",
										string("Yes"));

void readRINEXClock(DBTableCollection * tables, istream & str,
					bool addnewmarkers, bool overwritemarkers)
{
	//Взять указатели на требуемые таблицы
	ObservationSource * source = (ObservationSource*)
			(tables->getTable("observation_source"));
	SatelliteHistory * history = (SatelliteHistory*)
			(tables->getTable("satellite_history"));
	Markers * markers = (Markers*)(tables->getTable("markers"));
	ClockBias*timeshift = (ClockBias*)(tables->getTable("time_shift"));

	set < string > supportedVersions;
	supportedVersions.insert("2.00");
	supportedVersions.insert("3.00");

	string line;
	int linenumber = -1;
	char navsystem = 'G';

	bool replacecoords=overwritemarkers;

	//Чтение заголовка
	while (true)
	{
		if (str.eof())
			throw WrongRINEXClockFormat(linenumber,"Неожиданный конец файла");

		getline(str, line);
		if (trim(line).size() == 0)
			continue;
		++linenumber;
		string label = trim(line.substr(60,20));

		//Проверка типа и версии RINEX-Clock-файла
		if (label == "RINEX VERSION / TYPE")
		{
			//Проверить поддерживаемую версию
			string version = trim(line.substr(0,9));
			if (supportedVersions.find(version)==supportedVersions.end())
				throw WrongRINEXClockFormat(linenumber, "Неподдерживаемая "
											"версия формата RINEX Clock.");

			char C = line[20];
			if (C!='C')
				throw WrongRINEXClockFormat(linenumber,"Файл не является "
								" файлом типа RINEX Clock.");

			if (version == "3.00")
				navsystem = line[40];
			if (navsystem == ' ')
				navsystem = 'G';
		}

		//Считать координаты файлов
		if (label == "SOLN STA NAME / NUM")
		{

			string marker_name = line.substr(0,4);
			transform(marker_name.begin(), marker_name.end(),
					  marker_name.begin(), ::toupper);
			string marker_number = line.substr(5,9);
			int marker_type = Markers::MT_GEODETIC;
			kinematic < real, 3, defaultNonInert > XYZ;

			XYZ[0] = Variant::fromString(Variant::TYPE_DOUBLE,
										  line.substr(25,11)).toDouble();
			XYZ[1] = Variant::fromString(Variant::TYPE_DOUBLE,
										  line.substr(25+12,11)).toDouble();
			XYZ[2] = Variant::fromString(Variant::TYPE_DOUBLE,
										  line.substr(25+24,11)).toDouble();
			XYZ[0]*=1e-6; XYZ[1]*=1e-6; XYZ[2]*=1e-6;
			kinematic < real, 3, defaultGeodetic > geod =
					geocentricToGeodetic(XYZ);
			DBTable::DBIterator it = markers->idx_find("marker_name",
													Tuple()<<marker_name);
			if (it!=markers->const_end())
			{
				if (replacecoords == false)
					continue;
				string comment = it[2].toString();
				comment+="(координаты исправлены при чтении RINEX-Clock-файла)";
				it.updateCell(2,Variant(comment));
				it.updateCell(4,Variant(XYZ[0]));
				it.updateCell(5,Variant(XYZ[1]));
				it.updateCell(6,Variant(XYZ[2]));
				it.updateCell(7,Variant(geod[0]));
				it.updateCell(8,Variant(geod[1]));
				it.updateCell(9,Variant(geod[2]));

			}
			else if (addnewmarkers)
				markers->insertRow(Tuple()<<marker_name<<marker_number
						<<string("Маркер добавлен при чтении RINEX-clock-файла")
							<<Variant(marker_type)<<XYZ[0]<<XYZ[1]<<XYZ[2]
								   <<geod[0]<<geod[1]<<geod[2]);
			continue;
		}

		//Читать до окончания секции заголовка
		if (label == "END OF HEADER")
			break;
	}

	string datatype = "";
	string objname = "";
	int strnum = -1; //Номер строки
	//UTCDateTime timestamp;
	real epoch;

	//Чтение данных
	while(true)
	{
		if (str.eof())
			break;

		getline(str, line);
		linenumber++;
		if (trim(line)=="")
			continue;

		string datatype_s = line.substr(0,2);

		//Если в строке начинается новая запись данных, то считать всю
		//начальную информацию по этим данным
		if ((datatype_s == "AR")||(datatype_s == "AS")||(datatype_s == "CR")
				||(datatype_s == "DR")||(datatype_s == "MS"))
		{
			strnum = -1;
			datatype = datatype_s;
			int year = Variant::fromString(Variant::TYPE_INT,
								line.substr(8,4)).toInt();
			int month = Variant::fromString(Variant::TYPE_INT,
								line.substr(12,3)).toInt();
			int day = Variant::fromString(Variant::TYPE_INT,
								line.substr(15,3)).toInt();
			int hour = Variant::fromString(Variant::TYPE_INT,
								line.substr(18,3)).toInt();
			int minute = Variant::fromString(Variant::TYPE_INT,
								line.substr(21,3)).toInt();
			real sec = Variant::fromString(Variant::TYPE_DOUBLE,
								line.substr(24,10)).toDouble();

			real gpsj2000;
			UTCDateTime::dateTimeToSec2000(year,month,day,hour,
										   minute,sec,gpsj2000);
			epoch = UTCDateTime::GPSJ2000ToTAIJ2000(gpsj2000);
//			timestamp = UTCDateTime
//					::fromGPSDateTime(year,month,day,hour,minute,sec);
//			epoch = timestamp.getTAIJ2000();

			objname = trim(line.substr(3,4));
			transform(objname.begin(), objname.end(),
					  objname.begin(), ::toupper);
		}
		strnum++;

		//Кроме данных об уходе часов БИС и НКА ничего считывать не надо
		if ((datatype != "AR") && (datatype != "AS"))
			continue;


		real shift;
		real srate;
		real saccel;

		//Теперь считать данные - в зависимости от номера строки.
		//В первой строке находится сам уход часов
		if (strnum == 0)
			shift = Variant::fromString(Variant::TYPE_DOUBLE,
							line.substr(40,19)).toDouble();
		if (strnum == 1)
		{
			try
			{
				srate = Variant::fromString(Variant::TYPE_DOUBLE,
										line.substr(0,19)).toDouble();
			}
			catch (exception e)
			{
				srate = numeric_limits<real>::quiet_NaN();
			}
			try
			{
				saccel = Variant::fromString(Variant::TYPE_DOUBLE,
										line.substr(38,19)).toDouble();
			}
			catch (exception e)
			{
				saccel = numeric_limits<real>::quiet_NaN();
			}
		}

		//Уточнённые часы БИС
		if (datatype == "AR")
		{
			//Требуется пробежать таблицу БИСов и найти все БИСы,
			//у которых совпадает номер маркера
			DBTable::DBConstIterator it0 =
				markers->idx_find("marker_name", Tuple()<<objname);
			//Если маркера нет в таблице Markers, то продолжить
			if (it0 == markers->const_end())
				continue;
			int marker_id = it0.keyColumnValue(0).toInt();

			for (DBTable::DBConstIterator it1 = source->const_begin();
				 it1!=source->const_end(); ++it1)
			{
				if (it1[0].toInt()!=marker_id)
					continue;
				int observation_source_id = it1.keyColumnValue(0).toInt();

				//Из нулевой строки занести уход часов
				if (strnum == 0)
					timeshift->insertRow(Tuple()<<int(0)<<observation_source_id
									 <<int(0)<<epoch, Tuple()<<shift);
				if (strnum == 1)
				{
					if (srate != numeric_limits<real>::quiet_NaN())
						timeshift->insertRow(Tuple()<<int(0)
								<<observation_source_id<<int(1)<<epoch,
											 Tuple()<<srate);
					if (saccel != numeric_limits<real>::quiet_NaN())
						timeshift->insertRow(Tuple()<<int(0)
								<<observation_source_id<<int(2)<<epoch,
											 Tuple()<<saccel);
				}
			}
		}

		//Уточненные часы НКА
		if (datatype == "AS")
		{
			//Искать идентификатор НКА в списке
			int sat_history_id = -1;
			try
			{
				sat_history_id = history->getSatHistoryID(objname, epoch);
			}
			catch (NoPRNForDateException e)
			{
				//Если данный НКА на данный момент времени не найден,
				//продолжить выполнение
				continue;
			}

			if (strnum == 0)
				timeshift->insertRow(Tuple()<<int(1)<<sat_history_id
								 <<int(0)<<epoch, Tuple()<<shift);
			if (strnum == 1)
			{
				if (srate != numeric_limits<real>::quiet_NaN())
					timeshift->insertRow(Tuple()<<int(1)
							<<sat_history_id<<int(1)<<epoch,
										 Tuple()<<srate);
				if (saccel != numeric_limits<real>::quiet_NaN())
					timeshift->insertRow(Tuple()<<int(1)
							<<sat_history_id<<int(2)<<epoch,
										 Tuple()<<saccel);
			}
		}

		//Другие типы данных не считываются

	}
}

#ifdef WithQT
QScriptValue rdRINEXClk(QScriptContext*ctx,
						QScriptEngine * eng)
{
	try
	{
		DBTableCollection * tc = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		string filename = ctx->argument(1).toString().toStdString();
		ifstream rinexfile(filename.c_str());
		if (!(rinexfile.is_open()))
			throw StrException("readRINEXClock",
							   "Не удалось открыть файл");
		readRINEXClock(tc,rinexfile);
		rinexfile.close();
	}
	catch (StrException & e)
	{
		returnError(eng, string("Невозможно прочитать RINEX-Clock-файл: ")+
					e.what());
	}
	return QScriptValue();
}

BuiltIn rrclk("readRINEXClock", 2, rdRINEXClk);
#endif

}

#include <iostream>
#include <set>
#include <algorithm>
#include <fstream>

using namespace std;

#include <StdTables.h>
#include <SiteDisplacement.h>
#include <readrinex21obs.h>
#include <observables.h>
#include <Consts.h>
#include <BuiltIn.h>

//! @file

namespace libgnss
{


struct RINEXObsReader
{

	map<char, ObservablesLoader * > obsloaders;

	DBTableCollection * tables;
	
    //Список поддерживаемых версий RINEX
    set<std::string> supportedVersions;
    
    string RINEXversion;
    
	//Таблица настроек
	Settings * settings;

	//Таблица маркеров
	Markers * markers;

	//Модели антенн
	AntennaModels * antmodels;

	//Таблица антенн
	ReceivingAntennas * ants;

	//Навигационные системы
	NavigationSystem * systems;

	//Приёмники
	Receivers * receivers;

	//История орбитальных слотов
	SatelliteHistory * history;

	//Типы измерений
	ObservableTypes * types;

	//Таблица настроек
	Settings*sets;

	ObservationSource * obssource;
	
	//Собственно, измерительные данные
	Observables * obsdata;

	//Частотные слоты ГЛОНАСС
	GLONASSFrequencySlots * freqslots;

	char ObsType; //G = GPS, R=GLONASS, S=Geostationary, T=Transit, M=Mixed
	
	string time_system;

	int observation_source_id;

	istream * str;

	//Wave length factor для каждого НКА
	map < char, map < int, pair <int, int > > > wlfactor;

	//Типы измерительных данных
	//Для каждой навигационной системы и для каждого её НКА хранится
	//список типов измерительных данных.
	map < char, vector < int > > obstypes;

	UTCDateTime firstObs, lastObs;

	bool rcvclockoffset;

	//Отображение буквы системы и идентификатора измерения в множитель
	map < char, map < int, int > > scalefactor;

	string markername;
	string markernumber;
	int markertype;
	real markerX, markerY, markerZ;
	string receivernumber;
	string receivertype;
	string antennanumber;
	string antennadesc;
	int antennamodel;
	real dheight, deast, dnorth;
	int loadobstypes;

	//Интервал между измерениями - используется для отмены коррекции ухода часов
	real epoch_interval;

	RINEXObsReader(const map<char,ObservablesLoader*> &loaders, istream & str1,
				   int lobs)
	{
		epoch_interval = numeric_limits<real>::quiet_NaN();
		obsloaders = loaders;
		loadobstypes = lobs;
		time_system = "GPS";
		tables = loaders.begin()->second->getTableCollection();
		
        //Поддерживаемые версии RINEX
		supportedVersions.insert("2");
		supportedVersions.insert("2.1");
        supportedVersions.insert("2.10");
		supportedVersions.insert("2.11");
        //supportedVersions.insert("3.00");
        
		//Таблица настроек
		settings = (Settings*)(tables->getTable("settings"));

		//Таблица маркеров
		markers = (Markers*)(tables->getTable("markers"));

		//Модели антенн
		antmodels = (AntennaModels*)
				(tables->getTable("antenna_models"));

		//Таблица антенн
		ants=(ReceivingAntennas*)
				(tables->getTable("receiving_antennas"));

		//Приёмники
		receivers = (Receivers*)(tables->getTable("receivers"));


		//История орбитальных слотов
		history = (SatelliteHistory*)
				(tables->getTable("satellite_history"));

		//Таблица настроек
		sets = (Settings*)(tables->getTable("settings"));

		//Измерительные данные
		obsdata = (Observables*)(tables->getTable("observables"));

		//Типы измерительных данных
		types=(ObservableTypes*)(tables->getTable("observable_types"));

		//Список БИСов (источников измерительных данных)
		obssource = (ObservationSource*)
					(tables->getTable("observation_source"));

		systems = (NavigationSystem*)
				(tables->getTable("navigation_systems"));

		freqslots = (GLONASSFrequencySlots *)
				(tables->getTable("glonass_frequency_slots"));

		str = &str1;

		//Заполнить единицами таблицу множителей частоты НКА
		for (DBTable::DBConstIterator it1 = history->const_begin();
			 it1!=history->const_end(); ++it1)
		{
			char navsys = it1[0].toChar();
			if (obstypes.find(navsys) == obstypes.end())
				obstypes[navsys] = vector < int > ();
			wlfactor[navsys][it1[2].toInt()] = pair <int, int> (1,1);
		}


		for (DBTable::DBConstIterator it2 = types->const_begin();
				it2!=types->const_end(); ++it2)
			scalefactor[it2[1].toChar()]
						[it2.keyColumnValue(0).toInt()] = 1;

		rcvclockoffset = false;


		markername = "";
		markernumber = "NOT DEFINED";
		markertype = 0;
		receivernumber = "NOT DEFINED";
		receivertype = "NOT DEFINED";
		antennanumber = "NOT DEFINED";
		antennadesc = "Добавлена при чтении RINEX";
		antennamodel;
		dheight = 0.0; deast = 0.0; dnorth = 0.0;

		observation_source_id = -1;
	}

	void readHeader(int maxheadrecs = 0)
	{
		//Если в RINEX-файле используется маркер, которого нет в таблице
		//маркеров, его необходимо внести. Сначала в цикле чтения заголовка
		//будет собрана вся доступная информация о маркере, а после окончания
		//чтения заголовка она будет внесена в таблицу
		bool newmarkeradded = false;
		//Аналогично, будет собираться информация о приёмнике
		bool newreceiveradded = false;
		//и об антенне
		bool newantennaadded = false;

		std::string line="";
		for (unsigned int nrecs = 0; (nrecs < maxheadrecs)||(maxheadrecs == 0);
             nrecs ++)
		{
			getline(*str, line);
			std::string label = line.substr(60,20);
			label = trim(label);

			//Конец заголовка
			//RINEX 2, 3
			if (label == "END OF HEADER")
				break;

			//Проверка версии и типа RINEX-файла
			//RINEX 2, 3
			if (label == "RINEX VERSION / TYPE")
			{
                RINEXversion = trim(line.substr(0,9));
                if (supportedVersions.find(RINEXversion)==
                    supportedVersions.end())
					throw WrongRINEXFileTypeException
						("Версия не поддерживается");
				ObsType = line[40];
				if (ObsType==' ')
					ObsType = 'G';
				continue;
			}

			//Информация о программе, агентстве и дате создания игнорируется
			//RINEX 2, 3
			if (label == "PGM / RUN BY / DATE")
			{
				continue;
			}

			//Комментарий игнорируется
			//RINEX 2, 3
			if (label == "COMMENT")
			{
				continue;
			}

			//Получить идентификатор маркер
			//RINEX 2, 3
			if (label == "MARKER NAME")
			{
				markername = line.substr(0,60);

				markername = trim(markername);

				//Некоторые маркеры носят более длинные названия, чем
				//хотелось бы
				markername = markername.substr(0,4);

				transform(markername.begin(), markername.end(),
						  markername.begin(), ::toupper);


				//Удалить лишние пробелы (должно остаться 4 символа)
				markername.erase(markername.find_last_not_of(" \n\r\t")+1);

				//Найти маркер в таблице приёмников
				DBTable::DBConstIterator it0=markers->idx_find("marker_name",
														Tuple()<<markername);

				//Если маркера нет в списке, запомнить, что его нужно внести.
				if (it0==markers->end())
					newmarkeradded = true;

				continue;
			}

			//Получить номер маркера, если есть
			//RINEX 2, 3
			if (label == "MARKER NUMBER")
			{
				markernumber = line.substr(0,20);

				//Удалить лишние пробелы (должно остаться 4 символа)
				markernumber = trim(markernumber);
				continue;
			}

			//Получить тип маркера, если есть
			//RINEX 3
			if (label == "MARKER TYPE")
			{
				string markertype_s = line.substr(0,20);

				//Удалить лишние пробелы (должно остаться 4 символа)
				markertype_s = trim(markertype_s);

				//Выбрать числовой код

				markertype = Markers::MT_GEODETIC;

				if (markertype_s == "GEODETIC")
					markertype = Markers::MT_GEODETIC;

				if (markertype_s == "NON_GEODETIC")
					markertype = Markers::MT_NON_GEODETIC;

				if (markertype_s == "NON_PHISICAL")
					markertype = Markers::MT_NON_PHISICAL;

				if (markertype_s == "SPACEBORNE")
					markertype = Markers::MT_SPACEBORNE;

				if (markertype_s == "AIRBORNE")
					markertype = Markers::MT_AIRBORNE;

				if (markertype_s == "WATER_CRAFT")
					markertype = Markers::MT_WATER_CRAFT;

				if (markertype_s == "GROUND_CRAFT")
					markertype = Markers::MT_GROUND_CRAFT;

				if (markertype_s == "FIXED_BUOY")
					markertype = Markers::MT_FIXED_BUOY;

				if (markertype_s == "FLOATING_BUOY")
					markertype = Markers::MT_FLOATING_BUOY;

				if (markertype_s == "FLOATING_ICE")
					markertype = Markers::MT_FLOATING_ICE;

				if (markertype_s == "GLACIER")
					markertype = Markers::MT_GLACIER;

				if (markertype_s == "BALLISTIC")
					markertype = Markers::MT_BALLISTIC;

				if (markertype_s == "ANIMAL")
					markertype = Markers::MT_ANIMAL;

				if (markertype_s == "HUMAN")
					markertype = Markers::MT_HUMAN;

				continue;
			}

			//Пропостить информацию об агентстве
			//RINEX 2, 3
			if (label == "OBSERVER / AGENCY")
			{
				continue;
			}

			//Получить информацию о приёмнике
			//RINEX 2, 3
			if (label == "REC # / TYPE / VERS")
			{
				receivernumber = trim(line.substr(0,20));
				receivertype = trim(line.substr(20,20));
				if (receivers->idx_find("serial_number",
						Tuple()<<receivernumber) == receivers->const_end())
					newreceiveradded = true;
				continue;
			}

			//RINEX 2, 3
			if (label == "ANT # / TYPE")
			{
				//Считать информацию об антенне
				antennanumber = trim(line.substr(0,20));
				string ant_model_s = trim(line.substr(20,20));

				//Проверить, есть ли таблица с информацией о модели антенны
				DBTable::DBConstIterator itm =
						antmodels->idx_find("model",Tuple()<<ant_model_s);

				//Если нет, то сразу её добавить
				if (itm==antmodels->end())
				{
					antennamodel = antmodels->insertRow(Tuple()<<ant_model_s
								<<int(0)<<string("Добавлена при чтении RINEX"));
				}
				//Иначе - просто взять найденный номер
				else
					antennamodel = itm.keyColumnValue(0).toInt();

				//Проверить, есть ли информация об антенне
				itm = ants->idx_find("serial_number",Tuple()<<antennanumber);

				if (itm == ants->end())
					newantennaadded = true;

				continue;
			}

			//Считать информацию о приблизительном положении БИС
			//RINEX 2, 3
			if (label == "APPROX POSITION XYZ")
			{
				markerX = Variant(line.substr(0,14)).toDouble()*0.001;
				markerY = Variant(line.substr(14,14)).toDouble()*0.001;
				markerZ = Variant(line.substr(28,14)).toDouble()*0.001;
				continue;
			}

			//Считать информацию о смещении антенны (ARP) относительно
			//маркера
			//RINEX 2, 3
			if (label == "ANTENNA: DELTA H/E/N")
			{
				dheight = Variant(line.substr(0,14)).toDouble();
				deast = Variant(line.substr(14,14)).toDouble();
				dnorth = Variant(line.substr(28,14)).toDouble();
				continue;
			}

			//RINEX 3
			if(label=="ANTENNA: PHASECENTER")
			{
				continue;
			}

			//RINEX 3
			if (label=="ANTENNA: B.SIGHT XYZ")
			{
				continue;
			}

			//RINEX 3
			if (label=="ANTENNA: ZERODIR AZI")
			{
				continue;
			}

			//RINEX 3
			if (label=="ANTENNA: ZERODIR XYZ")
			{
				continue;
			}

			//RINEX 3
			if (label=="CENTER OF MASS: XYZ")
			{
				continue;
			}

			//RINEX 2
			//Считать информацию о множителе частоты
			if (label == "WAVELENGTH FACT L1/2")
			{
				//Считать множители
				int fullcycleambiguity = Variant::fromString(Variant::TYPE_INT,
											trim(line.substr(0,6))).toInt();
				int halfcycleambiguity = Variant::fromString(Variant::TYPE_INT,
											trim(line.substr(0,6))).toInt();

				//Определить, множитель частоты задан для всех НКА или
				//для нескольких НКА
                string nnka_s = trim(line.substr(12,6));
                                            
				if (nnka_s!="")
				{
                    int nnka=
                        Variant::fromString(Variant::TYPE_INT,nnka_s).toInt();
					if (nnka > 0)
					{
						//Запомнить множители для выбранных НКА
						if (nnka>7)
							throw WrongRINEXFileTypeException
								("Неверная информация о множителях частоты");
						for (unsigned int i=0; i<nnka; i++)
						{
							char sys = line[21+i*6];
							if (sys==' ')
								sys = 'G';
							int slot = Variant::fromString(Variant::TYPE_INT,
										line.substr(22+i*6,2)).toInt();
							wlfactor[sys][slot] = pair <int,int>(
										fullcycleambiguity, halfcycleambiguity);
						}
					}
				}
				else
					//Запомнить множители для всех НКА
					for (DBTable::DBConstIterator it1 = history->const_begin();
						 it1!=history->const_end(); ++it1)
						wlfactor[it1[0].toChar()][it1[2].toInt()] = 
						pair <int, int>(fullcycleambiguity,halfcycleambiguity);

				continue;
			}

			//RINEX 3
			if (label=="SYS / # / OBS TYPES")
			{
				//Считать букву навигационной системы и число типов данных
				char nav_sys = line[0];
				if (nav_sys==' ')
					nav_sys = 'G';

				//Проверить, имеется ли данная навигационная система в списке
				if (systems->find(Tuple()<<nav_sys) == systems->const_end())
					throw UnknownNavigationSystemInRINEXException(nav_sys);

				//Число типов измерительных данных
				int numobservs = Variant::fromString(Variant::TYPE_INT,
							line.substr(3,3)).toInt();


				if (obstypes[nav_sys].size()>0)


				for (unsigned int i=0; i<numobservs; i++)
				{
					//Найти идентификатор типа измерений в таблице типов
					string obs_denotement = line.substr(7+(i%13)*4,3);
					int obs_id;
					DBTable::DBConstIterator obsit=types->idx_find(
						"system_denotement", Tuple()<<nav_sys<<obs_denotement);

					//Если тип измерительных данных неизвестен, пометить его как
					//-1, чтобы данные не заносились при чтении.
					if (obsit == types->const_end())
						obs_id = -1;
					else
						obs_id = obsit.keyColumnValue(0).toInt();

					obstypes[nav_sys].push_back(obs_id);

					//Если строка закончилась, а типы измерений - нет, прочитать
					//ещё одну строку
					if ((i%13==12)&&(i<numobservs - 1))
						getline(*str, line);
				}
				continue;
			}

			//RINEX 2
			if (label == "# / TYPES OF OBSERV")
			{
				int numobservs = Variant::fromString(Variant::TYPE_INT,
									line.substr(0,6)).toInt();

				int nobservsfound = 0;
				for (unsigned int i=0; i<numobservs; i++)
				{
					//Найти идентификатор типа измерений в таблице типов
					string obs_denotement = trim(line.substr(6+(i%9)*6,6));

					//Добавить этот идентификатор всем спутникам
					//Если к данной навигационной системе не применим данный
					//тип измерений, то вставить -1, которая будет обозначать
					//пропуск данных в этом месте
					for (map<char,vector<int> >::iterator it1=
						 obstypes.begin(); it1!=obstypes.end(); ++it1)
					{
						char navsys = it1->first;

						DBTable::DBConstIterator obsit=types->idx_find(
						"system_denotement",Tuple()<<navsys<<obs_denotement);

						int obs_id = -1;
						if (obsit != types->const_end())
						{
							nobservsfound ++;
							obs_id = obsit.keyColumnValue(0).toInt();
						}
						
						it1->second.push_back(obs_id);
					}

					if ((i%9==8)&&(i<numobservs-1))
						getline(*str,line);
				}
				if (nobservsfound == 0)
					cout<<"Предупреждение: в таблице типов измерений не "
					   "найдено ни одного типа измерения из читаемого RINEX-"
					   "файла."<<endl;
				continue;
			}

			//RINEX 2, 3 - игнорируется, но необходимо промотать список,
			//если он состоит из нескольких строк
			if (label == "PRN / # OF OBS")
			{
				char nav_sys = line[3];
				if (nav_sys==' ')
					nav_sys = 'G';

				//Проверить, имеется ли данная навигационная система в списке
				if (systems->find(Tuple()<<nav_sys) == systems->const_end())
					throw UnknownNavigationSystemInRINEXException(nav_sys);

				int obstypescount = obstypes[nav_sys].size();
				while (obstypescount > 9)
				{
					obstypescount-=9;
					getline(*str,line);
				}
				continue;
			}

			//RINEX 2, 3 - игнорируется, так как учитывается каждая эпоха
			//отдельно
			if (label == "INTERVAL")
			{
				epoch_interval = Variant::fromString(Variant::TYPE_DOUBLE,
											trim(line.substr(0,14))).toDouble();
				continue;
			}

			//RINEX 2, 3
			if (label == "TIME OF FIRST OBS")
			{
				time_system = trim(line.substr(48,3));
				if (time_system == "")
				{
					if (ObsType == 'G')
						time_system = "GPS";
					if (ObsType == 'R')
						time_system = "GLO";
					if (ObsType == 'E')
						time_system = "GAL";
					if (ObsType == 'M')
					{
						cout<<"Предупреждение. В смешанном GPS/ГЛОНАСС-файле "
						"измерительных данных не указана шкала времени. "
						"Используется GPS по умолчанию."
						<<endl;
						time_system = "GPS";
					}
				}
				int year = Variant::fromString(Variant::TYPE_INT,
									line.substr(0,6)).toInt();
				int month = Variant::fromString(Variant::TYPE_INT,
									line.substr(6,6)).toInt();
				int day = Variant::fromString(Variant::TYPE_INT,
									line.substr(12,6)).toInt();
				int hour = Variant::fromString(Variant::TYPE_INT,
									line.substr(18,6)).toInt();
				int minute = Variant::fromString(Variant::TYPE_INT,
									line.substr(24,6)).toInt();
				real sec = Variant::fromString(Variant::TYPE_DOUBLE,
									line.substr(30,13)).toDouble();

				if (time_system=="GPS")
					firstObs = UTCDateTime::fromGPSDateTime(year,
								month,day,hour,minute,sec);
				else
					throw NotImplementedException("Чтение time of first "
												  "obs ("+time_system+")");

				continue;
			}

			//RINEX 2, 3
			if (label == "TIME OF LAST OBS")
			{
				time_system = trim(line.substr(48,3));
				if (time_system == "")
				{
					if (ObsType == 'G')
						time_system = "GPS";
					if (ObsType == 'R')
						time_system = "GLO";
					if (ObsType == 'E')
						time_system = "GAL";
					if (ObsType == 'M')
					{
						cout<<"Предупреждение. В смешанном GPS/ГЛОНАСС-файле "
						"измерительных данных не указана шкала времени. "
						"Используется GPS по умолчанию."
						<<endl;
						time_system = "GPS";
					}
				}
				int year = Variant::fromString(Variant::TYPE_INT,
									line.substr(0,6)).toInt();
				int month = Variant::fromString(Variant::TYPE_INT,
									line.substr(6,6)).toInt();
				int day = Variant::fromString(Variant::TYPE_INT,
									line.substr(12,6)).toInt();
				int hour = Variant::fromString(Variant::TYPE_INT,
									line.substr(18,6)).toInt();
				int minute = Variant::fromString(Variant::TYPE_INT,
									line.substr(24,6)).toInt();
				real sec = Variant::fromString(Variant::TYPE_DOUBLE,
									line.substr(30,13)).toDouble();

				if (time_system=="GPS")
					lastObs = UTCDateTime::fromGPSDateTime(year,
								month,day,hour,minute,sec);
				else
					throw NotImplementedException("Чтение time of first "
												  "obs ("+time_system+")");

				continue;
			}

			//RINEX 2, 3
			if (label == "RCV CLOCK OFFS APPL")
			{
				int rcvappl = Variant::fromString(Variant::TYPE_INT,
										line.substr(0,6)).toInt();
				rcvclockoffset = (rcvappl == 1);
				continue;
			}

			//RINEX 2, 3
			if (label == "LEAP SECONDS")
			{
				//Игнорируются, так как имеются в собственной БД
				continue;
			}

			//RINEX 2, 3
			if (label == "# OF SATELLITES")
			{
				//Игнорируются
				continue;
			}

			//RINEX 3
			if (label=="SIGNAL STRENGTH UNIT")
			{
				//Не используется, игнорируется
				continue;
			}

			//RINEX 3
			if (label=="SYS / DCBS APPLIED")
			{
				if (trim(line.substr(0,60))!="")
					throw NotImplementedException(
							"Отмена поправок DCB при чтении RINEX");
				continue;
			}

			//RINEX 3
			if (label=="SYS / PCVS APPLIED")
			{
				if (trim(line.substr(0,60))!="")
					throw NotImplementedException(
							"Отмена поправок фазового центра при чтении RINEX");
				continue;
			}

			//RINEX 3
			if (label=="SYS / SCALE FACTOR")
			{
				char navsystem = line[0];
				int sfactor = Variant::fromString(Variant::TYPE_INT,
									line.substr(2,4)).toInt();
				int nobss = Variant::fromString(Variant::TYPE_INT,
										line.substr(8,4)).toInt();
				for (unsigned int i=0; i<nobss; i++)
				{
					//Прочитать обозначение типа измерительных данных
					string obsc = line.substr(11+(i%12)*4);

					//Найти его в таблице observation_types
					DBTable::DBConstIterator obsit=types->idx_find(
						"system_denotement", Tuple()<<navsystem<<obsc);
					if (obsit == types->const_end())
						throw UnknownObservationTypeException(obsc);

					//Если существует, найти его id
					int obs_id = obsit.keyColumnValue(0).toInt();
					scalefactor[navsystem][obs_id] = sfactor;

					//Если строка закончилась, а типы измерений - нет, то
					//прочитать очередную строку

					if ((i%12 == 1) && (i<nobss-1))
						getline(*str,line);
				}
				continue;
			}

		}

		//Выбрать только те измерительные данные, которые указаны в параметре
		//вызова obstypes
		for (map < char, vector < int > >::iterator it =  obstypes.begin();
			 it!= obstypes.end(); ++it)
		{
			char navsys = it->first;
			//Первый фильтр по навигационной системе
			if (
					((navsys=='G')&&((loadobstypes & NavSys_GPS) == 0))
					||((navsys=='R')&&((loadobstypes & NavSys_GLONASS) == 0))
					||((navsys=='S')&&((loadobstypes & NavSys_SBAS) == 0))
					||((navsys=='E')&&((loadobstypes & NavSys_Galileo) == 0))
					||(string("GRSE").find(navsys)==string::npos)
				)
			{
				it->second = vector < int > (it->second.size(),-1);
				continue;
			}
			for (unsigned int i=0; i<it->second.size(); i++)
			{
				if (it->second[i] == -1)
					continue;

				Tuple obstypedetail = types->read(Tuple()<<it->second[i]);

				int freqn = obstypedetail[2].toInt();

				//По частоте
				if (
						((navsys == 'G') &&
						(
							((freqn == ObservableTypes::getFrequencyFromAntex("G01"))&&((loadobstypes&ObsFreq_L1) == 0))
							||((freqn == ObservableTypes::getFrequencyFromAntex("G02"))&&((loadobstypes&ObsFreq_L2) == 0))
							||((freqn == ObservableTypes::getFrequencyFromAntex("G05"))&&((loadobstypes&ObsFreq_L5) == 0))
						))
						||
						((navsys == 'R') &&
						(
							((freqn == ObservableTypes::getFrequencyFromAntex("R01"))&&((loadobstypes&ObsFreq_L1) == 0))
							||((freqn == ObservableTypes::getFrequencyFromAntex("R02"))&&((loadobstypes&ObsFreq_L2) == 0))
						))
						||
						((navsys == 'E') &&
						(
							((freqn == ObservableTypes::getFrequencyFromAntex("E01"))&&((loadobstypes&ObsFreq_L1) == 0))
							||((freqn == ObservableTypes::getFrequencyFromAntex("E05"))&&((loadobstypes&ObsFreq_L5) == 0))
							||((freqn == ObservableTypes::getFrequencyFromAntex("E06"))&&((loadobstypes&ObsFreq_L6) == 0))
							||((freqn == ObservableTypes::getFrequencyFromAntex("E07"))&&((loadobstypes&ObsFreq_L7) == 0))
							||((freqn == ObservableTypes::getFrequencyFromAntex("E08"))&&((loadobstypes&ObsFreq_L8) == 0))
						))
						||
						((navsys == 'S') &&
						(
							((freqn == ObservableTypes::getFrequencyFromAntex("S01"))&&((loadobstypes&ObsFreq_L1) == 0))
							||((freqn == ObservableTypes::getFrequencyFromAntex("S05"))&&((loadobstypes&ObsFreq_L5) == 0))
						))
					)
					it->second[i] = -1;

				int obsmt = obstypedetail[3].toInt();
				char obsattr = obstypedetail[4].toChar();
				//По типу измерений
				if (
						((obsmt==ObservableTypes::MTYPE_C)&&(obsattr=='C')&&((loadobstypes&ObsType_StdPseudorange)==0))
						||((obsmt==ObservableTypes::MTYPE_C)&&(obsattr=='P')&&((loadobstypes&ObsType_HighPrecPseudorange)==0))
						||((obsmt==ObservableTypes::MTYPE_L)&&((loadobstypes&ObsType_Phase)==0))
						||((obsmt==ObservableTypes::MTYPE_D)&&((loadobstypes&ObsType_Doppler)==0))
						||((obsmt==ObservableTypes::MTYPE_S)&&((loadobstypes&ObsType_SignalStrength)==0))
						||(obsmt==ObservableTypes::MTYPE_I)||(obsmt==ObservableTypes::MTYPE_X)
					)
					it->second[i] = -1;
			}
		}

		int marker_id;
		int antenna_id;
		int receiver_id;

		//Внести информацию о маркере, если требуется
		if (newmarkeradded)
		{
			kinematic < real, 3, defaultNonInert > c;
			c[0] = markerX; c[1] = markerY; c[2] = markerZ;
			kinematic < real, 3, defaultGeodetic > geod
					= geocentricToGeodetic(c);
			marker_id=markers->insertRow(Tuple()<<markername<<markernumber
					<<string("Маркер добавлен при чтении RINEX")<<markertype
										 <<markerX<<markerY<<markerZ
										 <<geod[0]<<geod[1]<<geod[2]);
		}
		else
			marker_id=markers->idx_find("marker_name",Tuple()
                            <<markername).keyColumnValue(0).toInt();
		
		//Информацию об антенне
		if (newantennaadded)
			antenna_id=ants->insertRow(Tuple()<<antennanumber<<
					string("Антенна добавлена при чтении RINEX")<<
									   antennamodel);
		else
			antenna_id=ants->idx_find("serial_number",
                              Tuple()<<antennanumber).keyColumnValue(0).toInt();

		//3) Приёмник
		if (newreceiveradded)
			receiver_id=receivers->insertRow(Tuple()<<receivernumber
						<<string("Приёмник добавлен при чтении RINEX")
						<<receivertype);
		else
			receiver_id=receivers->idx_find("serial_number",
						Tuple()<<receivernumber).keyColumnValue(0).toInt();

//		if (observation_source_id == -1)
//		{
		//Получить номер источника измерений
		DBTable::DBConstIterator it = obssource->idx_find("3id",
							Tuple()<<marker_id<<receiver_id<<antenna_id);
		if (it == obssource->const_end())
			observation_source_id = obssource->insertRow(Tuple()<<
							marker_id<<receiver_id<<antenna_id);
		else
			observation_source_id = obssource->idx_find("3id", Tuple()<<
			marker_id<<receiver_id<<antenna_id).keyColumnValue(0).toInt();
		for (map<char,ObservablesLoader*>::iterator it = obsloaders.begin();
			 it!=obsloaders.end(); ++it)
		{
			int cursrcid = it->second->getObsSrcID();
			if (cursrcid != observation_source_id)
				it->second->setNewObsSrcID(observation_source_id);
		}
//		}
	}

	/** @brief Структура, хранящая измерение и его флаги
	 * 
	 * Флаг имеет следующий смысл:
	 * flags&255 - флаги эпохи
	 * flags&(255*256)/256 - мощность сигнала
	 * flags&(255*65536)/65536 - LLI
	 */
	struct SingleSatObsData
	{
		real value;
		int flags;
	};
	
	/**
	 * @brief Данные из RINEX на одну эпоху
	 *
	 * Отображение: Идентификатор НКА (autoinc в таблице SatelliteHistory) в
	 * пару: (отображение: (тип измерения, измерение),
	 * отображение: (тип измерения, флаг) ).
	 */
	typedef map < int, pair < map < int, real >, map < int,int> > > EpochData;

	/** @brief Чтение измерительных данных для одной эпохи
	 * 
	 * 
	 * 
	 * @param dest Возвращаемая структура прочитанных данных
	 * @param epoch Возвращаемая J2000-метка времени в секундах 
	 * @return Число последующих заголовочных записей
	 */
	int readEpochData(EpochData & dest, real & epoch)
	{
		dest.clear();
		string line;

		while (true)
		{
			if (str->eof())
				return -1;
			getline(*str,line);
			if (line!="")
				break;
		}
		
		
				//Начать считывание эпохи
		int year, month, day, hour, minute, flags, nsats;
		real sec;
		real clockOffset = 0;

		bool isRINEX2 = RINEXversion[0] == '2';

		if (isRINEX2)
		{
			//Прочитать флаг эпохи и число НКА (число заголовочных записей?)
			flags = Variant::fromString(Variant::TYPE_INT,
							line.substr(28,1)).toInt();
			nsats = Variant::fromString(Variant::TYPE_INT,
										line.substr(29,3)).toInt();

			//Проверит, не указывает ли флаг эпохи на наличие дополнительных
			//заголовочных записей
			if ((flags>=2)&&(flags<=5))
				return nsats;
				
			vector<int> sat_history_ids;
			vector<char> sat_nav_sys;
			//cout<<line<<endl;
			
			//Прочитать и перевести в секунды от J2000 метку времени
			year = Variant::fromString(Variant::TYPE_INT, 
										line.substr(1,2)).toInt();
			month = Variant::fromString(Variant::TYPE_INT,
										line.substr(4,2)).toInt();
			day = Variant::fromString(Variant::TYPE_INT, 
										line.substr(7,2)).toInt();
			hour = Variant::fromString(Variant::TYPE_INT,
										line.substr(10,2)).toInt();
			minute = Variant::fromString(Variant::TYPE_INT,
										line.substr(13,2)).toInt();
			sec = Variant::fromString(Variant::TYPE_DOUBLE,
										line.substr(15,11)).toDouble();

			if (year >= 50)
				year += 1900;
			else
				year += 2000;

			//Пока из шкал, использующихся в RINEX, реализована только шкала
			//GPS. Случаи использования других шкал уже вызвали исключение
			//при чтении заголовка
			if (time_system=="GPS")
			{
				real gpsj2000;
				UTCDateTime::dateTimeToSec2000(year,month,day,hour,minute,
											   sec,gpsj2000);
				epoch = UTCDateTime::GPSJ2000ToTAIJ2000(gpsj2000);
			}
			else
				throw NotImplementedException("Перевод из шкалы времени "
					+ time_system);

			//Чтение ухода часов БИС
			string clockOffset_s;
			try
			{
				clockOffset_s = trim(line.substr(68,12));
			}
			catch(exception e)
			{
				clockOffset_s="";
			}

			if (clockOffset_s != "")
				clockOffset = Variant::fromString(Variant::TYPE_DOUBLE,
					clockOffset_s).toDouble();
								
			//Чтение списка НКА
			for (unsigned int i=0; i<nsats; i++)
			{
				char nav_sys = line[32+3*(i%12)];
				int slot = Variant::fromString(Variant::TYPE_INT,
										line.substr(33+3*(i%12),2)).toInt();
				if (nav_sys == ' ')
					nav_sys = 'G';
				
				int sat_history_id;
				try
				{
					sat_history_id=history->getSatHistoryID(nav_sys,slot,epoch);
				}
				catch (NoPRNForDateException e)
				{
					sat_history_id = -1;
				}
					
				sat_history_ids.push_back(sat_history_id);
				sat_nav_sys.push_back(nav_sys);
				
				//Если спутники не закончились, а строка закончилась-
				//прочитать новую строку
				if ((i%12==11)&&(i<nsats-1))
					getline(*str,line);
			}

			//В RINEX 2.10-2.11 набор измерительных данных для каждой
			//навигационной системы одинаковый. Можно найти список типов
			//измерительных данных одной строкой:
			int obscount = obstypes.begin()->second.size();
			
			//Читать измерительные данные
			for (unsigned int i=0; i<nsats; i++)
			{
				getline(*str,line);

				for (unsigned int j=0; j<obscount; j++)
				{
					real obsvalue;
					int obsflag;
					SingleSatObsData dat1;
					string val_s = "";
					//Код, написанный для считывания с исключениями,
					//работает слишком медленно, когда много данных пропущено.
/*					try
					{
						val_s = trim(line.substr(valuepos,14));
					}
					catch (exception e)
					{
						val_s = "";
					} */
					//Лучше считывать наверняка, без ошибок.
					int valuepos = (j%5)*16;
					if (line.length() >= valuepos)
						val_s = trim(line.substr(valuepos,
										min(14,int(line.length()-valuepos))));

					if (val_s == "")
						obsvalue = 0.0;
					else
						obsvalue=Variant(val_s).toDouble();
					if (line.length() >= 16+(j%5)*16)
					{
						char lli = line[14+(j%5)*16];
						if (string("0123456789").find(lli)==string::npos)
							lli='0';
						char strength = line[15+(j%5)*16];
						obsflag=65536*(lli-'0') + 256*(strength-'0') + flags;
					}
					else
						obsflag = flags;

					//Если НКА был в списке НКА, то записать его измерительные
					//данные
					if ((obstypes.find(sat_nav_sys[i]) != obstypes.end())
							&& (obsvalue !=0.0))
					{
						int obsid = obstypes[sat_nav_sys[i]][j];
						if ((sat_history_ids[i] != -1) && (obsid != -1))
						{
							dest[sat_history_ids[i]].first[obsid] = obsvalue;
							dest[sat_history_ids[i]].second[obsid] = obsflag;
						}
					}
					
					//Если измерительные данные не закончились, а строка
					//закончилась, прочитать ещё одну строку
					if ((j%5==4)&&(j<obscount-1))
						getline(*str,line);
				}
			}
		}
		return 0;
	}
	
	//! Чтение RINEX-файла, начиная с заголовка
	void read ()
	{
		//Прочитать заголовок (не указано число строк, следовательно, будет
		//считывать до END OF HEADER
		readHeader();
		
		EpochData cur_data;
		real cur_epoch;
		real previous_epoch = firstObs.getTAIJ2000();
		
		while(true)
		{
			//Если конец данных, закончить чтение
			if (str->eof())
				break;

			int nheads;
			
			//Читать записи, пока не будет прочитана запись с данными
			while (true)
			{
				nheads = readEpochData(cur_data, cur_epoch);

				if (nheads <0)
					break;
				
				//Если запись содержит данные, выйти из цикла
				if (nheads == 0)
					break;
				
				//В противном случае, прочитать нужное количество заголовочных
				//записей и продолжить чтение.
				readHeader(nheads);
			}

			if (nheads<0)
				break;
			
			//Провести преобразования данных:
			//Коррекция псевдодальностей с эпох, в км.
			real correction=0.0l;
			if (!isnan(epoch_interval))
			{
				real epoch_mod = fmod(cur_epoch - previous_epoch, epoch_interval);
				//В какую сторону изменены часы?
				if (epoch_mod > (epoch_interval - epoch_mod))
					epoch_mod = epoch_mod - epoch_interval;
				epoch_mod = round(1e+6 * epoch_mod) *1e-6;
				//! @bug Нужно найти ошибку в алгоритма поправки!
				if (fabs(epoch_mod)>5e-7)
				{
					correction = - epoch_mod * lightSpeed;
					cur_epoch = cur_epoch - epoch_mod;
				}
			}

			for (EpochData::iterator
				it1 = cur_data.begin(); it1!=cur_data.end(); ++it1)
			{
				int sat_history_id = it1->first;
				char nav_sys = (*history)[sat_history_id][0].toChar();
				map<int,real> & obsvalues = it1->second.first;
				for (map<int,real>::iterator it2 = obsvalues.begin();
					 it2!=obsvalues.end(); ++it2)
				{
					int obstype = it2->first;
					//SYS / SCALE FACTOR
					it2->second *= scalefactor[nav_sys][obstype];

					//Фазу перевести из циклов в километры, а код - из
					//метров в километры
					Tuple obsdetail = types->read(obstype);
					if (obsdetail[3].toInt() == ObservableTypes::MTYPE_L)
					{
						int letter = 0;
						if (nav_sys == 'R')
							letter = freqslots->getLetter(
								(*history)[Tuple()<<(it1->first)][2].toInt(),
								cur_epoch);

						real freq = types->getFrequency(obstype, letter);
						real wavelength = lightSpeed/freq;
						it2->second *= wavelength;
						it2->second += correction;
					}
					if (obsdetail[3].toInt() == ObservableTypes::MTYPE_C)
					{
						it2->second *= 0.001;
						it2->second += correction;
					}
				}
				map<char,ObservablesLoader*>::iterator loader =
						obsloaders.find(nav_sys);
				if (loader != obsloaders.end())
					loader->second->loadObservables(sat_history_id,cur_epoch,
									 it1->second.first,
									 it1->second.second);
			}
			previous_epoch = cur_epoch;
		}
    }
};

void parseRINEXObsData(const std::map<char, ObservablesLoader *> &loaders,
					int obscodes, istream &str)
{
	RINEXObsReader parser(loaders,str,obscodes);
	parser.read();
}

void readRINEXObservations(DBTableCollection & tables, istream & str ,
						   int obstypes)
{
	map <char,ObservablesLoader*> loaders;
	NavigationSystem * navsystems = (NavigationSystem*)
			(tables.getTable("navigation_systems"));
	for (DBTable::DBConstIterator it = navsystems->begin();
		 it!=navsystems->end(); ++it)
	{
		char navsys = it.keyColumnValue(0).toChar();
		loaders[navsys] = new NoPreprocessingObservablesLoader(&tables,0);
	}
	RINEXObsReader reader(loaders, str, obstypes);
	reader.read();
	for (map <char,ObservablesLoader*>::iterator it =
		 loaders.begin(); it!=loaders.end(); ++it)
		delete it->second;
}

void readRINEXObservationsHeader ( DBTableCollection & tables, istream & str,
					   int obstypes)
{
	map <char,ObservablesLoader*> loaders;
	NavigationSystem * navsystems = (NavigationSystem*)
			(tables.getTable("navigation_systems"));
	for (DBTable::DBConstIterator it = navsystems->begin();
		 it!=navsystems->end(); ++it)
	{
		char navsys = it.keyColumnValue(0).toChar();
		loaders[navsys] = new NoPreprocessingObservablesLoader(&tables,0);
	}
	RINEXObsReader reader(loaders, str, obstypes);
	reader.readHeader();
	for (map <char,ObservablesLoader*>::iterator it =
		 loaders.begin(); it!=loaders.end(); ++it)
		delete it->second;
}


void loadRINEX21ObservationCodes(DBTableCollection& tables)
{
	ObservableTypes * types = (ObservableTypes*)(tables.getTable("observable_types"));

	//GPS - частота L1
	types->insertRow(Tuple()<<string("C1")<<'G'<<0<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код GPS на частоте 1575.42"));
	types->insertRow(Tuple()<<string("P1")<<'G'<<0<<ObservableTypes::MTYPE_C<<'P'<<string("Высокоточный код GPS на частоте 1575.42"));
	types->insertRow(Tuple()<<string("L1")<<'G'<<0<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GPS на частоте 1575.42"));
	types->insertRow(Tuple()<<string("D1")<<'G'<<0<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер GPS на частоте 1575.42"));
	types->insertRow(Tuple()<<string("S1")<<'G'<<0<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала GPS на частоте 1575.42"));

	//GPS - частота L2
	types->insertRow(Tuple()<<string("C2")<<'G'<<1<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код GPS на частоте 1227.60"));
	types->insertRow(Tuple()<<string("P2")<<'G'<<1<<ObservableTypes::MTYPE_C<<'P'<<string("Высокоточный код GPS на частоте 1227.60"));
	types->insertRow(Tuple()<<string("L2")<<'G'<<1<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GPS на частоте 1227.60"));
	types->insertRow(Tuple()<<string("D2")<<'G'<<1<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер GPS на частоте 1227.60"));
	types->insertRow(Tuple()<<string("S2")<<'G'<<1<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала GPS на частоте 1227.60"));

	//GPS - частота L5
	types->insertRow(Tuple()<<string("C5")<<'G'<<2<<ObservableTypes::MTYPE_C<<'C'<<string("Код GPS на частоте 1176.45"));
	types->insertRow(Tuple()<<string("L5")<<'G'<<2<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GPS на частоте 1176.45"));
	types->insertRow(Tuple()<<string("D5")<<'G'<<2<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер GPS на частоте 1176.45"));
	types->insertRow(Tuple()<<string("S5")<<'G'<<2<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала GPS на частоте 1176.45"));

	//ГЛОНАСС - частота 1
	types->insertRow(Tuple()<<string("C1")<<'R'<<3<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код ГЛОНАСС на частоте 1602+k*9/16"));
	types->insertRow(Tuple()<<string("P1")<<'R'<<3<<ObservableTypes::MTYPE_C<<'P'<<string("Высокоточный код ГЛОНАСС на частоте 1602+k*9/16"));
	types->insertRow(Tuple()<<string("L1")<<'R'<<3<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения ГЛОНАСС на частоте 1602+k*9/16"));
	types->insertRow(Tuple()<<string("D1")<<'R'<<3<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер ГЛОНАСС на частоте 1602+k*9/16"));
	types->insertRow(Tuple()<<string("S1")<<'R'<<3<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала ГЛОНАСС на частоте 1602+k*9/16"));

	//ГЛОНАСС - частота 2
	types->insertRow(Tuple()<<string("C2")<<'R'<<4<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код ГЛОНАСС на частоте 1246+k*7/16"));
	types->insertRow(Tuple()<<string("P2")<<'R'<<4<<ObservableTypes::MTYPE_C<<'P'<<string("Высокоточный код ГЛОНАСС на частоте 1246+k*7/16"));
	types->insertRow(Tuple()<<string("L2")<<'R'<<4<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения ГЛОНАСС на частоте 1246+k*7/16"));
	types->insertRow(Tuple()<<string("D2")<<'R'<<4<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер ГЛОНАСС на частоте 1246+k*7/16"));
	types->insertRow(Tuple()<<string("S2")<<'R'<<4<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала ГЛОНАСС на частоте 1246+k*7/16"));

	//GALILEO - частота E2-L1-E1 (E01 в Antex)
	types->insertRow(Tuple()<<string("C1")<<'E'<<5<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код GALILEO на частоте 1575.42"));
	types->insertRow(Tuple()<<string("L1")<<'E'<<5<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GALILEO на частоте 1575.42"));
	types->insertRow(Tuple()<<string("D1")<<'E'<<5<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер GALILEO на частоте 1575.42"));
	types->insertRow(Tuple()<<string("S1")<<'E'<<5<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала GALILEO на частоте 1575.42"));

	//GALILEO - частота E5a
	types->insertRow(Tuple()<<string("C5")<<'E'<<6<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код GALILEO на частоте 1176.45"));
	types->insertRow(Tuple()<<string("L5")<<'E'<<6<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GALILEO на частоте 1176.45"));
	types->insertRow(Tuple()<<string("D5")<<'E'<<6<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер GALILEO на частоте 1176.45"));
	types->insertRow(Tuple()<<string("S5")<<'E'<<6<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала GALILEO на частоте 1176.45"));

	//GALILEO - частота E5b
	types->insertRow(Tuple()<<string("C7")<<'E'<<7<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код GALILEO на частоте 1207.14"));
	types->insertRow(Tuple()<<string("L7")<<'E'<<7<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GALILEO на частоте 1207.14"));
	types->insertRow(Tuple()<<string("D7")<<'E'<<7<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер GALILEO на частоте 1207.14"));
	types->insertRow(Tuple()<<string("S7")<<'E'<<7<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала GALILEO на частоте 1207.14"));

	//GALILEO - частота E5a+b (E5a+E5b в Antex)
	types->insertRow(Tuple()<<string("C8")<<'E'<<8<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код GALILEO на частоте 1191.795"));
	types->insertRow(Tuple()<<string("L8")<<'E'<<8<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GALILEO на частоте 1191.795"));
	types->insertRow(Tuple()<<string("D8")<<'E'<<8<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер GALILEO на частоте 1191.795"));
	types->insertRow(Tuple()<<string("S8")<<'E'<<8<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала GALILEO на частоте 1191.795"));

	//GALILEO - частота E6
	types->insertRow(Tuple()<<string("C6")<<'E'<<9<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код GALILEO на частоте 1278.75"));
	types->insertRow(Tuple()<<string("L6")<<'E'<<9<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GALILEO на частоте 1278.75"));
	types->insertRow(Tuple()<<string("D6")<<'E'<<9<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер GALILEO на частоте 1278.75"));
	types->insertRow(Tuple()<<string("S6")<<'E'<<9<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала GALILEO на частоте 1278.75"));

	//SBAS - частота L1
	types->insertRow(Tuple()<<string("C1")<<'S'<<18<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код SBAS на частоте 1575.42"));
	types->insertRow(Tuple()<<string("L1")<<'S'<<18<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения SBAS на частоте 1575.42"));
	types->insertRow(Tuple()<<string("D1")<<'S'<<18<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер SBAS на частоте 1575.42"));
	types->insertRow(Tuple()<<string("S1")<<'S'<<18<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала SBAS на частоте 1575.42"));

	//SBAS - частота L5
	types->insertRow(Tuple()<<string("C5")<<'S'<<19<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код SBAS на частоте 1176.45"));
	types->insertRow(Tuple()<<string("L5")<<'S'<<19<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения SBAS на частоте 1176.45"));
	types->insertRow(Tuple()<<string("D5")<<'S'<<19<<ObservableTypes::MTYPE_D<<'C'<<string("Доплер SBAS на частоте 1176.45"));
	types->insertRow(Tuple()<<string("S5")<<'S'<<19<<ObservableTypes::MTYPE_S<<'C'<<string("Мощность сигнала SBAS на частоте 1176.45"));

}

void loadRINEX3ObservationCodes ( DBTableCollection & tables)
{
	const static string obstype = "CDLSIX";
	const static string band = "125121578612";
	const static string ns = "GGGRREEEEESS";
	const static string attrib = "CPYMNABCIQSLXW";

	const static string attrib_ns[] = {"GR","GRS","G","G","G","E","E","E","GE",
									   "GE","G","G","E","E"};

	ObservableTypes * types = (ObservableTypes*)
			(tables.getTable("observable_types"));
	string den = "   ";
	//Сначала стандартные измерения RINEX
	for (int o = 0; o<obstype.size(); o++)
		for (int b = 0; b<band.size(); b++)
			for (int a = 0; a<attrib.size(); a++)
			{
				den[0] = obstype[o];
				den[1] = band[b];
				den[2] = attrib[a];
				char navsys = ns[b];
				if (attrib_ns[a].find(navsys) == string::npos)
					continue;
				types->insertRow(Tuple()<<den<<ns[b]<<b<<(1+o)<<attrib[a]
								 <<"Описание не реализовано");
			}
	//Теперь измерения с исключенной ионосферой, не включенные в формат RINEX3
	for (int o = 0; o<3; o++)
		for (int a = 0; a<2; a++)
		{
			types->insertRow(Tuple()<<string(1,obstype[o])+"12"
							 +string(1,attrib[a])
							 <<'G'<<(1+o)<<20<<attrib[a]
							 <<"Описание не реализовано");
			types->insertRow(Tuple()<<string(1,obstype[o])+"15"
							 +string(1,attrib[a])
							 <<'G'<<(1+o)<<21<<attrib[a]
							 <<"Описание не реализовано");
			types->insertRow(Tuple()<<string(1,obstype[o])+"25"
							 +string(1,attrib[a])
							 <<'G'<<(1+o)<<22<<attrib[a]
							 <<"Описание не реализовано");
			types->insertRow(Tuple()<<string(1,obstype[o])+"12"
							 +string(1,attrib[a])
							 <<'R'<<(1+o)<<23<<attrib[a]
							 <<"Описание не реализовано");
		}
}

#ifdef WithQT
int obslstToObsCodes (const QVariantList & codeslst)
{
	int result = 0;
	for (int i=0; i<codeslst.size(); i++)
	{
		if (codeslst[i].toString() == "ObsType_StdPseudorange")
			result |= ObsType_StdPseudorange;
		if (codeslst[i].toString() == "ObsType_HighPrecPseudorange")
			result |= ObsType_HighPrecPseudorange;
		if (codeslst[i].toString() == "ObsType_Phase")
			result |= ObsType_Phase;
		if (codeslst[i].toString() == "ObsType_Doppler")
			result |= ObsType_Doppler;
		if (codeslst[i].toString() == "ObsType_SignalStrength")
			result |= ObsType_SignalStrength;
		if (codeslst[i].toString() == "NavSys_GPS")
			result |= NavSys_GPS;
		if (codeslst[i].toString() == "NavSys_GLONASS")
			result |= NavSys_GLONASS;
		if (codeslst[i].toString() == "NavSys_Galileo")
			result |= NavSys_Galileo;
		if (codeslst[i].toString() == "NavSys_SBAS")
			result |= NavSys_SBAS;
		if (codeslst[i].toString() == "ObsFreq_L1")
			result |= ObsFreq_L1;
		if (codeslst[i].toString() == "ObsFreq_L2")
			result |= ObsFreq_L2;
		if (codeslst[i].toString() == "ObsFreq_L5")
			result |= ObsFreq_L5;
		if (codeslst[i].toString() == "ObsFreq_L6")
			result |= ObsFreq_L6;
		if (codeslst[i].toString() == "ObsFreq_L7")
			result |= ObsFreq_L7;
		if (codeslst[i].toString() == "ObsFreq_L8")
			result |= ObsFreq_L8;
	}
	return result;
}

QScriptValue loadRINEX21ObsCodes (QScriptContext*ctx,
										  QScriptEngine * eng)
{
	try
	{
		DBTableCollection * tc = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		loadRINEX21ObservationCodes (*tc);
	}
	catch (StrException & e)
	{
		returnError(eng, string("Невозможно добавить в "
			"коллекцию коды измерений RINEX 2.1: ")+e.what());
	}
	return QScriptValue();
}

QScriptValue readRINEXObs (QScriptContext*ctx,
									QScriptEngine * eng)
//( DBTableCollection & tables, istream & str,
//							 int obstypes=32767)
{
	try
	{
		DBTableCollection * tc = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		string filename = ctx->argument(1).toString().toStdString();
		ifstream rinexfile(filename.c_str());
		if (!(rinexfile.is_open()))
			throw StrException("readRINEXObservations",
							   "Не удалось открыть файл");
		int obstypes = obslstToObsCodes(ctx->argument(2).toVariant().toList());
		readRINEXObservations(*tc, rinexfile, obstypes);
		rinexfile.close();
	}
	catch (StrException & e)
	{
		returnError(eng, string("Невозможно прочитать RINEX-файл: ")+e.what());
	}
	return QScriptValue();
}

QScriptValue readRINEXObsHd (QScriptContext*ctx,
							 QScriptEngine * eng)
{
	try
	{
		DBTableCollection * tc = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		string filename = ctx->argument(1).toString().toStdString();
		ifstream rinexfile(filename.c_str());
		if (!(rinexfile.is_open()))
			throw StrException("readRINEXObservations",
							   "Не удалось открыть файл");
		int obstypes = obslstToObsCodes(ctx->argument(2).toVariant().toList());
		readRINEXObservationsHeader(*tc, rinexfile, obstypes);
		rinexfile.close();
	}
	catch (StrException & e)
	{
		returnError(eng,string("Невозможно прочитать заголовок RINEX-файла: ")
					+e.what());
	}
	return QScriptValue();
}

BuiltIn ldobscodes21("loadRINEX21ObservablesCodes", 1, loadRINEX21ObsCodes);
BuiltIn rRINObs("readObservationRINEX",3, readRINEXObs);
BuiltIn rRINObsHd("readObservationRINEXHeader",3, readRINEXObsHd);
#endif

}

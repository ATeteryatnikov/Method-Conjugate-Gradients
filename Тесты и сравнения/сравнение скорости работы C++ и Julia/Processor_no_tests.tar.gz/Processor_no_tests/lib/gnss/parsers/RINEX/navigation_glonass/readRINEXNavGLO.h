#ifndef READRINEXNAVGLO_H_
#define READRINEXNAVGLO_H_

//! @file

#include <ios>
#include <vector>
#include <Types.h>
#include <Consts.h>
#include <map>
#include <Kinematic.h>

namespace libgnss
{

class DBTableCollection;
class ParamTrajectory;
class Frames;
class SatelliteHistory;
class ClockBias;
class GLONASSFrequencySlots;
class PhaseCentreOffsetFrequency;
class SVPhaseCentreModels;



/**
 * @brief Абстрактный загрузчик оперативной информации ГЛОНАСС
 */
class GLONASSNavDataLoader
{
public:

	/**
	 * @brief Метод, принимающий оперативную информацию ГЛОНАСС
	 * @param orb_slot Орбитальный слот НКА ГЛОНАСС
	 * @param t Момент времени приёма, секунды TAI от 12:00 01.01.2000
	 * @param delta_tau Разница аппаратных задержек на L1 и L2 в секундах
	 * @param gamma_n Относительный сдвиг частоты, безразмерный
	 * @param tau_n Сдвиг шкалы времени НКА, сек.
	 * @param x Координата X фазового центра НКА, км
	 * @param y Координата Y фазового центра НКА, км
	 * @param z Координата Z фазового центра НКА, км
	 * @param vx X-компонента скорости фазового центра НКА, км/сек
	 * @param vy Y-компонента скорости фазового центра НКА, км/сек
	 * @param vz Z-компонента скорости фазового центра НКА, км/сек
	 * @param ax X-компонента ускорения фазового центра НКА, км/сек^2
	 * @param ay Y-компонента ускорения фазового центра НКА, км/сек^2
	 * @param az Z-компонента ускорения фазового центра НКА, км/сек^2
	 * @param freq_n Частотный слот (литера)
	 * @param BN Флаг неисправности
	 * @param E Возраст оперативной информации в днях
	 * @param m Модификация НКА
	 * @param Ft Предполагаемая точность эфемерид, км.
	 *
	 * Для обозначения отсутствующих данных следует использовать:
	 * @li NaN для параметров с плавающей точкой
	 * @li -1 для целочисленных параметров
	 *
	 * @warning Согласно ИКД, \f$tau_n=t_c(t_b)-t_n(t_b)\f$. В таблице
	 * ClockBias поле ухода часов должно заполняться противоположными
	 * значениями, а именно, $t_n(t_b)-t_c(t_b)$, как принято во всех
	 * форматах IGS.
	 */
	virtual void loadNavData(int orb_slot, real t, real delta_tau,
					 real gamma_n, real tau_n, real x, real y, real z,
					 real vx, real vy, real vz, real ax, real ay, real az,
					 int freq_n, bool BN, int E,int m, real Ft) = 0;
};


/**
 * @brief Загрузчик оперативной информации ГЛОНАСС по умолчанию
 *
 * Загрузчик записывает передаваемую ему разобранную оперативную информацию в
 * таблицы: координаты, скорость и ускорение НКА - в таблицу ParamTrajectory,
 * уход часов и отклонение частоты - в табилцу ClockBias, частотный слот - в
 * таблицу GLONASSFrequencySlots.
 *
 * Для правильного внесения координат в таблицу trajectory необходимо также
 * вычислить координаты и скорость центра масс вместо фазового центра.
 *
 */
class GLONASSNavDataReader : public GLONASSNavDataLoader
{
private:
	bool read_traj;
	bool read_clk;
	bool gfreqslot;
	DBTableCollection * tcol;
	ParamTrajectory * traj;
	ClockBias * clk;
	Frames * frames;
	SatelliteHistory * history;
	GLONASSFrequencySlots * gfs;
	int frameid;
	std::vector<int> coordinate_ids;
	SVPhaseCentreModels*svphcm;
	PhaseCentreOffsetFrequency*pcofreq;

protected:

	/**
	 * @brief Возвращает идентификатор НКА по номеру слота
	 * @param orb_slot Номер орбитального слота
	 * @param t Момент времени, секунды TAI от 12:00 01.01.2000.
	 * @return Идентификатор НКА, или -1, если не найден
	 *
	 * Данный виртуальный метод не вызывает исключений. Если требуется прервать
	 * чтение навигационного файла при отсутствии идентификатора НКА, нужно
	 * перегрузить данную функцию.
	 */
	virtual int getSatHistoryID(int orb_slot, real t);

	/**
	 * @brief Вычислить поправку к положению фазового центра
	 * @param posvel Координаты и скорость НКА
	 * @param tai Метка времени
	 * @return Вектор от центра масс к фазовому центру НКА
	 */
	kinematic<real,6,defaultNonInert> phaseCentreOffset(
			const kinematic<real,6,defaultNonInert> & posvel,
			int sat_history_id, real tai);

public:

	/**
	 * @brief Конструктор загрузчика
	 * @param tcol Коллекция таблиц, в которую будет осуществляться запись
	 * @param read_traj Флаг записи траектории НКА
	 * @param read_clk Флаг записи ухода часов НКА
	 * @param gfreqslot Флаг записи частотных слотов
	 * @param frame Система координат, в которой записана траектория
	 */
	GLONASSNavDataReader(DBTableCollection * tcol, bool read_traj,
						 bool read_clk, bool gfreqslot,
						 const std::string & frame="ПЗ-90.02");

	virtual void loadNavData(int orb_slot, real t, real delta_tau,
						real gamma_n, real tau_n, real x, real y, real z,
						real vx, real vy, real vz, real ax, real ay, real az,
						int freq_n, bool BN, int E, int m, real Ft);

	/**
	 * @brief Метод, вызываемый, когда получен неполный набор координат
	 * @param slot Орбитальный слот НКА
	 * @param tai Момент времени, секунды от 12:00 01.01.2000 TAI
	 */
	virtual void noCoordinates(int slot, real tai);

	/**
	 * @brief Метод, вызываемый, когда получен неполный набор компонент скорости
	 * @param slot Орбитальный слот НКА
	 * @param tai Момент времени, секунды от 12:00 01.01.2000 TAI
	 */
	virtual void noVelocity(int slot, real tai);

	/**
	 * @brief Метод, вызываемый, когда получен неполный набор компонент ускорения
	 * @param slot Орбитальный слот НКА
	 * @param tai Момент времени, секунды от 12:00 01.01.2000 TAI
	 */
	virtual void noAcceleration(int slot, real tai);

	/**
	 * @brief Метод, пишущий в таблицу координаты НКА
	 * @param sat_history_id Идентификатор НКА
	 * @param tai Момент времени, секунды от 12:00 01.01.2000 TAI
	 * @param X Координата X НКА
	 * @param Y Координата Y НКА
	 * @param Z Координата Z НКА
	 */
	virtual void insertCoordinates(int sat_history_id, real tai,
								   real X, real Y, real Z);

	/**
	 * @brief Метод, пишущий в таблицу скорость НКА
	 * @param sat_history_id Идентификатор НКА
	 * @param tai Момент времени, секунды от 12:00 01.01.2000 TAI
	 * @param VX X-компонента скорости НКА
	 * @param VY Y-компонента скорости НКА
	 * @param VZ Z-компонента скорости НКА
	 */
	virtual void insertVelocity(int sat_history_id, real tai,
								   real VX, real VY, real VZ);

	/**
	 * @brief Метод, пишущий в таблицу ускорение НКА
	 * @param sat_history_id Идентификатор НКА
	 * @param tai Момент времени, секунды от 12:00 01.01.2000 TAI
	 * @param AX X-компонента ускорения НКА
	 * @param AY Y-компонента ускорения НКА
	 * @param AZ Z-компонента ускорения НКА
	 */
	virtual void insertAcceleration(int sat_history_id, real tai,
								   real AX, real AY, real AZ);

	/**
	 * @brief Метод, пишущий в таблицу уход часов НКА
	 * @param sat_history_id Идентификатор НКА
	 * @param tai Момент времени, секунды от 12:00 01.01.2000 TAI
	 * @param bias Уход часов НКА
	 * @param vel Скорость ухода часов НКА
	 */
	virtual void insertClockBias(int sat_history_id, real tai,
								 real bias, real vel);

	/**
	 * @brief Метод, вызываемый при повторении записи оперативной информации
	 * @param slot  Орбитальный слот НКА
	 * @param t Момент времени, секунды от 12:00 01.01.2000 TAI
	 */
	virtual void duplicateRecord(int slot, real t);

	/**
	 * @brief Метод записывает частотный слот НКА в таблицу
	 * @param slot Орбитальный слот НКА
	 * @param t Момент времени, секунд от 12:00 01.01.2000 TAI
	 * @param freqslot Частотный слот
	 *
	 * Если согласно таблице частотный слот совпадает
	 */
	virtual void insertFreqSlot(int slot, real t, int freqslot);

	/**
	 * @brief Вставка разрыва в траектории
	 * @param sat_history_id Идентификатор НКА
	 * @param t Момент времени, секунды TAI от 12:00 01.01.2000.
	 */
	virtual void insertDiscontinuity(int sat_history_id, real t);
};

class GLONASSNavDataExtrapolator : public GLONASSNavDataReader
{
private:
	std::map<int, std::vector<real> > savecoords;
	std::map<int, std::pair<real,real> > saveclkbias;
	std::map<int, real> prev_t;
	bool extrtraj;
	bool extrclk;
	bool extrfreql;
	real step;
public:

	void setStep(real step);

	/**
	 * @brief Размножить эфемериды НКА до данного момента времени
	 * @param sat_history_id Идентификатор НКА
	 * @param t Момент времени, до которого размножать эфемериды
	 *
	 * Исходный момент времени и начальные условия для него хранятся,
	 * соответственно, в полях prev_t, savecoord. Эфемериды размножаются
	 * между prev_t и t, только если их разность не больше 1 часа. В последнем
	 * случае, эфемериды размножаются только на один час.
	 *
	 * В момент времени t-0.9 сек. устанавливается разрыв траектории. Это
	 * связано с тем, что при использовании стандартного алгоритма размножения
	 * траектория получается разрывной, и эти разрывы могут проявляться близко
	 * к концам в виде артефактов, превосходящих в несколько раз размер разрыва.
	 */
	virtual void ExtrapolateEphemeris(real sat_history_id, real t);

	GLONASSNavDataExtrapolator(DBTableCollection * tcol, bool read_traj,
							   bool read_clk, bool gfreqslot,
							   const std::string & frame="ПЗ-90.02");

	virtual void loadNavData(int orb_slot, real t, real delta_tau,
						real gamma_n, real tau_n, real x, real y, real z,
						real vx, real vy, real vz, real ax, real ay, real az,
						int freq_n, bool BN, int E, int m, real Ft
							 );

	/**
	 * @brief Произвести экстраполяцию последней считанной информации
	 *
	 * Экстраполяция во время чтения производится на интервале [t0,t1] только
	 * тогда, когда уже считана оперативная информация на момент времени t1.
	 * Данный метод производит экстраполяцию дальше, на интервале [t1,t].
	 * Это нужно, когда кончается интервал видимости НКА, а оперативная
	 * информация на последние эпохи измерений ещё не размножена.
	 *
	 * После вызова этого метода буфер для данного НКА будет очищен, так что
	 * последующее размножение будет возможно только после получения двух
	 * эпох оперативной информации.
	 *
	 * @param orb_slot Номер орбитального слота
	 * @param t Конечная эпоха размножения: секунды от 12:00 01.01.2000 (TAI).
	 */
	virtual void finish(int orb_slot, real t);

	/**
	 * @brief Экстраполировать последнюю оперативную информацию для всех НКА
	 * @param t Конечная эпоха размножения: секунды от 12:00 01.01.2000 (TAI).
	 */
	virtual void finish(real t);
};

/**
 * @brief Чтение навигационной информации ГЛОНАСС из RINEX-файлов
 * @param ldr Загрузчик навигационной информации
 * @param str Поток, из которого происходит чтение
 */
void parseRINEXNavigationGLONASS (GLONASSNavDataLoader * ldr,
								   istream & str);

/**
 * @brief Чтение навигационной информации ГЛОНАСС из RINEX-файлов
 *
 * Исходно, согласно ИКД ГЛОНАСС, навигационная информация хранится в системе
 * координrат ПЗ-90.02, однако поскольку для этой системы есть формулы перехода
 * только к системе координат WGS-84 (см. ГОСТ Р 51794-2008), в которой работает
 * GPS, после чтения все координаты переводятся в WGS-84.
 *
 * @param tables Набор таблиц, в которые происходит считывание
 * @param str Поток, из которого происходит чтение
 */
void readRINEXNavigationGLONASS (DBTableCollection & tables,
								 istream & str,
								 bool read_trajectory = true,
								 bool read_clk = false,
								 bool read_freqslots = false);

/**
 * @brief Данные об НКА ГЛОНАСС
 *
 * Таблица используется для замены ANTEX-файла при чтении навигационной
 * информации и файлов измерений.
 *
 * Ключевые поля:
 * @li int model_icd_code Код модификации НКА, согласно ИКД ГЛОНАСС
 *
 * Поля данных:
 * @li string model_name Тип НКА, согласно номенклатуре IGS
 * @li double dx, dy, dz - смещение фазового центра НКА вдоль осей X, Y, Z
 * (см. YawAttitude.cpp).
 */
class GLONASSModels : public DBTable
{
public:
	GLONASSModels(DBTableCollection * tcol);
};


}

#endif

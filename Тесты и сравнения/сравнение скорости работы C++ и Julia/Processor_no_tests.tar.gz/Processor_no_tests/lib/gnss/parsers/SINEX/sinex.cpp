#include <fstream>
#include <string>
#include <set>
#include <vector>
#include <sstream>
#include <algorithm>

using namespace std;

#include <StdTables.h>
#include <sinex.h>
#include <SiteDisplacement.h>
#include <Consts.h>
#include <sofa.h>
#include <Frames.h>
#include <Troposphere.h>
#include <BuiltIn.h>

namespace libgnss
{

WrongSINEXFormatException::WrongSINEXFormatException(int linenumber,
													 const string &what)
	: StrException ("WrongSINEXFormatException",
					"Неверный формат SINEX-файла: строка 0+"+
					Variant(linenumber).toString() + " "+ what)
{

}

Settings::Enumerator SINEX_TRS("Parsers", "SINEX", "SINEX_TRS",
								Frames::frameSelectorType(),
								"Геоцентрическая система координат, "
								"используемая в SINEX-файле", string("IGS08"));

Settings::Enumerator SINEX_ReadSiteID("Parsers", "SINEX", "readSiteID",
						CTypeSelect::yesOrNo(),
						"Считывать раздел SITE/ID из SINEX?",
									  string("Yes"));

Settings::Enumerator SINEX_readSiteEccentricity("Parsers","SINEX",
						"readSiteEccentricity", CTypeSelect::yesOrNo(),
						"Считывать раздел SITE/ECCENTRICITY из SINEX?",
												string("Yes"));

Settings::Enumerator SINEX_ReadMarkerPosition("Parsers","SINEX","readMarkerPos",
						CTypeSelect::yesOrNo(),
						"Считывать уточненные координаты станций из SINEX?",
											  string("Yes"));

class SINEXReader
{
protected:
	string filetitle;
	string fileending;
	Frames * frames;
	Settings * sets;
	set <string> supportedVersions;
	DBTableCollection * Base;
	string title;
	istream * rstream;
	int linenumber;
	int sinexcoordsys;
	string rframename;
	int rframeid;
	bool framedef;

	/**
	 * @brief Перевод метки времени из используемого в SINEX формата в TAI
	 * @param epoch Метка времени в формате SINEX: YY:DDD:SSSSS
	 * @return Метка времени, секунды TAI от эпохи J2000
	 */
	static real SINEXEpoch(const string & epoch)
	{
		int year = Variant::fromString(Variant::TYPE_INT,
									 epoch.substr(0,2)).toInt();
		if (year<80)
			year += 2000;
		else
			year += 1900;
		int day = Variant::fromString(Variant::TYPE_INT,
									  epoch.substr(3,3)).toInt();
		int seconds = Variant::fromString(Variant::TYPE_INT,
												epoch.substr(7,5)).toInt();
		return UTCDateTime::fromUTCJ2000(
					UTCDateTime::fromUTCDateTime(year,1,1,0,0,0.0).getUTCJ2000()
					+(day-1)*86400+seconds).getTAIJ2000();
	}

	/**
	 * @brief Получить угол в радианах из угла в SINEX-формате
	 * @param angle Угол в SINEX-формате: ГГГ ММ СС.С
	 * @return Угол в радианах
	 */
	static double SINEXLatLon (const string & angle)
	{
		const double onesixty = 1.0/60.0;
		int degrees = Variant::fromString(Variant::TYPE_INT,
								angle.substr(1,3)).toInt();
		int minutes = Variant::fromString(Variant::TYPE_INT,
								angle.substr(5,2)).toInt();
		double seconds = Variant::fromString(Variant::TYPE_DOUBLE,
								angle.substr(8,4)).toDouble();
		return ((seconds*onesixty + minutes)*onesixty + degrees) * Pi / 180.0;
	}

	void skipBlock()
	{
		while(true)
		{
			//Выход в конце файла (неожиданный конец)
			if (rstream->eof())
				throw WrongSINEXFormatException(linenumber,
												"Неожиданный конец файла");
			string line;
			getline(*rstream, line);
			linenumber++;

			//Пропустить пустую линию (хотя не должно быть в SINEX-файле)
			if (trim(line)=="")
				continue;

			//Конец нужной секции
			if (trim(line)==("-" + title))
				break;
		}
	}

	void readSiteID()
	{
		Markers * markers;
		try
		{
			markers = (Markers*)(Base->getTable("markers"));
		}
		catch (TableNotFoundException e)
		{
			skipBlock();
		}

		while (true)
		{
			//Выход в конце файла (неожиданный конец)
			if (rstream->eof())
				throw WrongSINEXFormatException(linenumber,
												"Неожиданный конец файла");

			string line;
			getline(*rstream, line);
			linenumber++;

			//Пропустить пустую линию (хотя не должно быть в SINEX-файле)
			if (trim(line)=="")
				continue;
			if (line[0]=='*')
				continue;

			//Конец нужной секции
			if (trim(line)==("-" + title))
				break;

			//Обозначение маркера
			string marker_name = trim(line.substr(1,4));
			DBTable::DBConstIterator it0 = markers->idx_find("marker_name",
														Tuple()<<marker_name);

			//Если маркер уже есть таблице, пропустить строку
			if (it0!=markers->const_end())
				continue;

			//IGS-идентификатор маркера
			string marker_number = trim(line.substr(9,9));

			//IGS-описание маркера
			string description = trim(line.substr(21,22));

			//Тип маркера - геодезический
			int marker_type = Markers::MT_GEODETIC;

			kinematic < real, 3, defaultGeodetic > geod;
			geod[0] = SINEXLatLon(line.substr(43,12));
			geod[1] = SINEXLatLon(line.substr(55,12));
			geod[2] = Variant::fromString(Variant::TYPE_DOUBLE,
								line.substr(68,7)).toDouble() * 0.001;
			kinematic < real, 3, defaultNonInert > xyz;
			try
			{
				xyz = geodeticToGeocentric(geod);
			}
			catch (WrongGeodeticCoordinates e)
			{
				throw WrongSINEXFormatException(linenumber,
								"Некорректные геодезические координаты.");
			}


			//Если при вставке возникло исключение, не обрабатывать его,
			//передать выше.
			markers->insertRow(Tuple()<<marker_name<<marker_number
						   <<description<<marker_type
						   <<(real)(xyz[0])<<(real)(xyz[1])
							   <<(real)(xyz[2])<<geod[0]<<geod[1]<<geod[2]);
		}
	}

	void readSiteEccentricity()
	{
		Markers * markers;
		MarkerEccentricity * ecc;

		try
		{
			markers = (Markers*)(Base->getTable("markers"));
			ecc = (MarkerEccentricity*)
							(Base->getTable("marker_eccentricity"));
		}
		catch (TableNotFoundException e)
		{
			skipBlock();
			return;
		}


		while(true)
		{
			//Выход в конце файла (неожиданный конец)
			if (rstream->eof())
				throw WrongSINEXFormatException(linenumber,
												"Неожиданный конец файла");

			string line;
			getline(*rstream, line);
			linenumber++;

			//Пропустить пустую линию (хотя не должно быть в SINEX-файле)
			if (trim(line)=="")
				continue;
			if (line[0]=='*')
				continue;

			//Конец нужной секции
			if (trim(line)==("-" + title))
				break;

			//Если данная строка - строка данных, то прочитать из неё
			//смещение антенны


			//Найти идентификатор маркера
			string markername = line.substr(1,4);
			DBTable::DBConstIterator it0 = markers->idx_find("marker_name",
														Tuple()<<markername);
			//Если маркер не найден, пропустить строку
			if (it0 == markers->const_end())
				continue;
			int marker_id = it0.keyColumnValue(0).toInt();

			real since;
			real until;
			try
			{
				if (line.substr(16,12) == "00:000:00000")
					since = UTCDateTime::fromUTCDateTime(
								1980,1,1,0,0,0).getTAIJ2000();
				else
					since = SINEXEpoch(line.substr(16,12));

				if (line.substr(29,12) == "00:000:00000")
					until = UTCDateTime::now().getTAIJ2000();
				else
					until = SINEXEpoch(line.substr(29,12));
			}
			catch (exception e)
			{
				throw WrongSINEXFormatException(linenumber, e.what());
			}

			//Прочитать тип координат
			int coord_type = -1;
			string coord_type_s = line.substr(42, 3);
			if (coord_type_s == "---")
				continue;
			if (coord_type_s == "UNE")
				coord_type = 0;
			if (coord_type_s == "XYZ" )
				coord_type = 1;
			if (coord_type == -1)
				throw WrongSINEXFormatException(linenumber, "Система координат "
			"для задания сдвига опорной точки антенны должна быть UNE или XYZ");

			real dx, dy, dz;

			//Прочитать координаты сдвига
			try
			{
				dx = Variant::fromString(Variant::TYPE_DOUBLE,
										line.substr(46,8)).toDouble() * 0.001;
				dy = Variant::fromString(Variant::TYPE_DOUBLE,
										line.substr(55,8)).toDouble() * 0.001;
				dz = Variant::fromString(Variant::TYPE_DOUBLE,
										line.substr(64,8)).toDouble() * 0.001;
			}
			catch (exception e)
			{
				throw WrongSINEXFormatException(linenumber, e.what());
			}

			ecc->deleteRows(Tuple()<<marker_id<<since);
			//Занести сдвиг в таблицу
			ecc->insertRow(Tuple()<<marker_id<<since,
						   Tuple()<<coord_type<<dx<<dy<<dz<<until);

		}
	}

	void readSolutionEstimate()
	{
		Markers * markers;
		MarkerPosition * mpositions;
		ReferenceFrames * rframes;
		try
		{
			markers = (Markers*)(Base->getTable("markers"));
		}
		catch (TableNotFoundException e)
		{
			markers = 0;
		}
		try
		{
			mpositions = (MarkerPosition *)(Base->getTable(
												 "marker_position"));
		}
		catch (TableNotFoundException e)
		{
			mpositions = 0;
		}
		try
		{
			rframes = (ReferenceFrames*)(Base->getTable(
											 "reference_frames"));
		}
		catch (TableNotFoundException e)
		{
			rframes = 0;
		}

		//Сначала считать координаты станций во временную переменную,
		//затем конвертировать в нужную систему координат, и лишь затем
		//записать в таблицу
		map<int,map<real,
								pair<
				kinematic<real,6,defaultNonInert >,
				kinematic<real,6,defaultNonInert >
									>
				> > coords;

		while(true)
		{
			//Выход в конце файла (неожиданный конец)
			if (rstream->eof())
				throw WrongSINEXFormatException(linenumber,
												"Неожиданный конец файла");

			string line;
			getline(*rstream, line);
			linenumber++;

			//Пропустить пустую линию (хотя не должно быть в SINEX-файле)
			if (trim(line)=="")
				continue;
			if (line[0]=='*')
				continue;

			//Конец нужной секции
			if (trim(line)==("-" + title))
				break;

			string parameter=trim(line.substr(7,6));

			//Координаты станций
			if (((parameter=="STAX") || (parameter=="STAY")
				 ||(parameter=="STAZ"))
			&&(sets->getSettings(SINEX_ReadMarkerPosition).toString()=="Yes"))
			{
				//Если таблицы для считывания данных не готовы,
				//пропустить строки
				if ((markers == 0) || (mpositions == 0))
					continue;

				string marker_name = trim(line.substr(14,4));
				DBTable::DBConstIterator it0 = markers->idx_find("marker_name",
														Tuple()<<marker_name);
				//Если маркер не найден, пропустить строку
				if (it0 == markers->const_end())
					continue;
				int marker_id = it0.keyColumnValue(0).toInt();

				//Момент времени
				real t = SINEXEpoch(line.substr(27,12));

				//Значение координаты
				real value = Variant::fromString(Variant::TYPE_DOUBLE,
												line.substr(47,21)).toDouble();

				//Среднеквадратическое отклонение
				real stddev = Variant::fromString(Variant::TYPE_DOUBLE,
												line.substr(69,11)).toDouble();

				//Считывать параметры координат станций (переводить в километры)
				int coord_id=-1;
				if (parameter=="STAX")
					coord_id = 0;
				if (parameter=="STAY")
					coord_id = 1;
				if (parameter=="STAZ")
					coord_id = 2;
				if (parameter=="VELX")
					coord_id = 3;
				if (parameter=="VELY")
					coord_id = 4;
				if (parameter=="VELZ")
					coord_id = 5;
				coords[marker_id][t].first[coord_id]=value*0.001;
				coords[marker_id][t].second[coord_id]=stddev*0.001;
			} // if
		} //while

		//Записать в таблицу координаты маркеров
		if ((markers != 0) && (mpositions != 0))
		{
			ITRFTranslation * trans = (ITRFTranslation *)
					(Base->getTable("itrf_transformation"));

			int defaultTRS = frames->defaultNonInertFrame();

			//Пройти по всем БИС
			for (map<int,map<real,pair<kinematic<real,6,defaultNonInert>,
					kinematic<real,6,defaultNonInert> > > >
				 ::iterator it = coords.begin(); it!=coords.end(); ++it)
				//Пройти по всем моментам времени
				for (map<real,pair<kinematic<real,6,defaultNonInert>,
					 kinematic<real,6,defaultNonInert> > >
					 ::iterator it2 = it->second.begin(); it2!=it->second.end();
					 ++it2)
				{

					//Если нужно выполнить преобразование координат,
					//выполнить его до записи в таблицу
					kinematic < real, 6, defaultNonInert > inscoords;
					if (defaultTRS == rframeid)
						inscoords = it2->second.first;
					else
						inscoords = trans->translateITRF(it2->second.first,
								rframeid, defaultTRS, it2->first);

					//Записать в таблицу
					for (unsigned int i=0; i<6; i++)
						if (framedef)
							rframes->insertRow(Tuple()<<rframeid<<it->first
											   <<(int)i,
											   Tuple()<<inscoords[i]
											   <<it2->first
											   <<it2->second.second[i]
											   );
						else if (i<3)
							mpositions->insertRow(Tuple()<<it->first
											  <<(int)i<<it2->first,
											  Tuple()<<inscoords[i]);
				}
		}
	}

public:
	SINEXReader (DBTableCollection & base, ifstream & str,
				 const string&rframe = string(),
				 bool framedef = false)
	{
		rstream = &str;
		Base = &base;
		linenumber = -1;
		linenumber = -1;
		supportedVersions.insert("2.01");
		supportedVersions.insert("2.02");
		supportedVersions.insert("2.10");
		sets = (Settings*)(base.getTable("settings"));
		frames = (Frames*)(Base->getTable("coordinate_frames"));
		filetitle = "%=SNX";
		fileending = "%ENDSNX";
		this->framedef = framedef;
		if (rframe == "")
			rframename = sets->getSettings(SINEX_TRS).toString();
		else
			rframename = rframe;
		rframeid = frames->getCoordinateFrameID(rframename);
		if(rframeid==0xffffffff)
		{
			if(framedef)
			{
				if (framedef)
				frames->insertRow(Tuple()<<Frames::FT_ITRS<<rframename);
				rframeid = frames->getCoordinateFrameID(rframename);
			}
			else
				throw StrException("SINEXReader::SINEXReader",
						"Указанная система координат не найдена.");
		}

	}

	virtual void processCurrentTitle()
	{

		if (title == "SITE/ID")
		{
			if (sets->getSettings(SINEX_ReadSiteID).toString()=="Yes")
				readSiteID();
			else
				skipBlock();
			return;
		}

		// Смещение опорной точки антенны относительно
		if (title == "SITE/ECCENTRICITY")
		{
			if (sets->getSettings(SINEX_readSiteEccentricity).toString()==
					"Yes")
				readSiteEccentricity();
			else
				skipBlock();
			return;
		}

		if (title == "SOLUTION/ESTIMATE")
		{
			readSolutionEstimate();
			return;
		}

		skipBlock();

	}

	void read()
	{
		string line;

		//Первая строка должна содержать заголовок SINEX-файла
		getline(*rstream, line);
		linenumber++;

		if (line.substr(0,5)!=filetitle)
			throw WrongSINEXFormatException(0, "В начале SINEX-файла должно быть "
											+filetitle);

		//Версия SINEX-файла
		string version = trim(line.substr(6,4));
		if (supportedVersions.find(version) == supportedVersions.end())
			throw WrongSINEXFormatException(0, "Версия не поддерживается.");

		//Другие поля первой строки будут пропущены

		//Чтение записей файла
		while (true)
		{
			//Выход, когда данные закончатся
			if (rstream->eof())
				break;

			//Считать строку
			getline(*rstream, line);
			linenumber++;

			//Если строка пустая или комментарий, то перейти к следующей строке
			if (trim(line)=="")
				continue;
			if (line[0]=='*')
				continue;
			//Конец SINEX-файла
			if (trim(line)==fileending)
				break;

			//Новый блок начинается с символа '+'
			if (line[0]!='+')
				throw WrongSINEXFormatException(linenumber,
					"Ожидалось начало нового блока, символ '+' в начале строки.");

			title = trim(line.substr(1));

			processCurrentTitle();

		}
	}

};

//! Класс чтения SINEX-Tropo-файла
class SINEXTropoReader : public SINEXReader
{
protected:
	/**
	 * @brief Список уточняемых параметров. Коды см. @ref ParamTroposphere.
	 * Если таблица не предусматривает хранения параметра данного типа
	 * (например, STDDEV), то в списке пишется -1 на этом месте
	 */
	vector < int > adjparams;

	void readTropoDescription()
	{
		while(true)
		{
			//Выход в конце файла (неожиданный конец)
			if (rstream->eof())
				throw WrongSINEXFormatException(linenumber,
												"Неожиданный конец файла");

			string line;
			getline(*rstream, line);
			linenumber++;

			//Пропустить пустую линию (хотя не должно быть в SINEX-файле)
			if (trim(line)=="")
				continue;
			if (line[0]=='*')
				continue;

			//Конец нужной секции
			if (trim(line)==("-" + title))
				break;

			string descriptiontype = trim(line.substr(1,29));

			//Считывать только список уточняемых параметров
			if ((descriptiontype != "SOLUTION_FIELDS_1")
					&& (descriptiontype != "SOLUTION_FIELDS_2"))
				continue;

			if (descriptiontype == "SOLUTION_FIELDS_1")
			{
				if (adjparams.size() > 0)
					throw WrongSINEXFormatException(linenumber,
						"SOLUTION_FIELDS_2 должен следовать после "
													"SOLUTION_FIELDS_1.");
				vector < string > adjparams_s = split(line.substr(31),' ');
				adjparams.resize(adjparams_s.size());
				transform(adjparams_s.begin(), adjparams_s.end(),
						adjparams.begin(), ParamTroposphere::getParameterType);
				continue;
			}
			if (descriptiontype == "SOLUTION_FIELDS_2")
			{
				if (adjparams.size() != 7)
					throw WrongSINEXFormatException(linenumber,
						"Секция SOLUTION_FIELDS_2 может быть только если в "
						"секции SOLUTION_FIELDS_1 перечислено 7 параметров.");
				vector < string > adjparams_s = split(line.substr(31),' ');
				vector < int > adjparams2 (adjparams_s.size());
				transform(adjparams_s.begin(), adjparams_s.end(),
						adjparams2.begin(), ParamTroposphere::getParameterType);
				adjparams.insert(adjparams.end(), adjparams2.begin(),
								 adjparams2.end());
				continue;

			} //if

		} //while
	} //void read

	void readTropSolution()
	{
		ParamTroposphere * tropo = (ParamTroposphere*)
				(Base->getTable("troposphere"));
		Markers * markers = (Markers*)(Base->getTable("markers"));
		while(true)
		{
			//Выход в конце файла (неожиданный конец)
			if (rstream->eof())
				throw WrongSINEXFormatException(linenumber,
												"Неожиданный конец файла");

			string line;
			getline(*rstream, line);
			linenumber++;

			//Пропустить пустую линию (хотя не должно быть в SINEX-файле)
			if (trim(line)=="")
				continue;
			if (line[0]=='*')
				continue;

			//Конец нужной секции
			if (trim(line)==("-" + title))
				break;

			string markername = trim(line.substr(1,4));

			transform(markername.begin(), markername.end(),
					  markername.begin(), ::toupper);

			DBTable::DBConstIterator it = markers->idx_find("marker_name",
													Tuple()<<markername);

			//Если этого маркера нет в списке, перейти к следующему маркеру
			if (it==markers->const_end())
				continue;

			int marker_id = it.keyColumnValue(0).toInt();

			real epoch = SINEXEpoch(line.substr(6,12));

			//Считать параметры
			istringstream data(line.substr(19));
			for (unsigned int i=0; i<adjparams.size(); i++)
			{
				try
				{
					real paramvalue;
					data>>paramvalue;
					//Все задержки в SINEX-Tropo приводятся в миллиметрах.
					//Необходимо приводить все величины к километрам.
					if (ParamTroposphere::isDelayINKm(adjparams[i]))
						paramvalue*=1e-6;
					if (adjparams[i]!=-1)
						tropo->insertRow(Tuple()<<marker_id<<adjparams[i]
										 <<epoch, Tuple()<<paramvalue);
				}
				catch (exception e)
				{
					throw WrongSINEXFormatException(linenumber,
						"Не удалось извлечь требуемые значения "
						+Variant((int)(adjparams.size())).toString()
						+" параметров из строки: "
						+line.substr(19));
				}
			}
		} //while
	} //void

public:
	SINEXTropoReader(DBTableCollection & base, ifstream & is)
		: SINEXReader(base, is, "")
	{
		filetitle = "%=TRO";
		fileending = "%=ENDTRO";
		supportedVersions.clear();
		supportedVersions.insert("1.00");
	}

	virtual void processCurrentTitle()
	{
		if (title=="TROP/DESCRIPTION")
		{
			readTropoDescription();
			return;
		}
		if (title=="TROP/SOLUTION")
		{
			readTropSolution();
			return;
		}
		SINEXReader::processCurrentTitle();
	}
};

void readSINEX (DBTableCollection *base, ifstream & str, const string &frame,
				bool framedef)
{
	SINEXReader rd(*base, str, frame, framedef);
	rd.read();
}

void readTropoSINEX(DBTableCollection * base, ifstream &str)
{
	SINEXTropoReader tro(*base, str);
	tro.read();
}

#ifdef WithQT
QScriptValue readSNX (QScriptContext*ctx, QScriptEngine * eng)
{
	try
	{
		DBTableCollection * tc = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		if (tc == 0)
			throw StrException("readSINEX","Первый аргумент должен быть "
							   "корректным сеансом обработки.");
		string filename_ = ctx->argument(1).toString().toStdString();
		string framename = "";
		bool framedef = false;
		if (ctx->argumentCount() > 2)
			framename = ctx->argument(2).toString().toStdString();
		if (ctx->argumentCount() > 3)
			framedef = ctx->argument(3).toBool();
		ifstream sinexfile(filename_.c_str());
		if (!sinexfile.is_open())
			throw StrException("readSINEX", "Не удалось открыть SINEX-файл");
		readSINEX(tc, sinexfile, framename, framedef );
		sinexfile.close();
		return QScriptValue();
	}
	catch(StrException  & e)
	{
		returnError(eng, string("Не удалось прочитать SINEX-файл: ")+e.what());
	}
}

QScriptValue readTropoSNX (QScriptContext*ctx, QScriptEngine * eng)
{
	try
	{
		DBTableCollection * tc = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		string filename_ = ctx->argument(1).toString().toStdString();
		ifstream sinexfile(filename_.c_str());
		if (!sinexfile.is_open())
			throw StrException("readTropoSINEX",
							   "Не удалось открыть SINEX-файл");
		readTropoSINEX(tc, sinexfile);
		sinexfile.close();
		return QScriptValue();
	}
	catch(StrException  & e)
	{
		returnError(eng, string("Не удалось прочитать SINEX-файл: ")+e.what());
	}
}

BuiltIn rdsnx("readSINEX", 4, readSNX);
BuiltIn rdtropo("readTropoSNX", 2, readTropoSNX);
#endif

}

/** @file
 *
 * @brief Модуль чтения SINEX-файлов
 */

#include <fstream>

namespace libgnss
{

class DBTableCollection;

class WrongSINEXFormatException : public StrException
{
public:
	WrongSINEXFormatException (int linenumber, const string & what);
};

/**
 * @brief Чтение данных из SINEX-файла
 * @param base Коллекция, в которую будут считаны данные
 * @param str Поток, из которого считывается SINEX-файл
 * @param frame Система координат, в которой записан SINEX-файл
 * @param framedef Признак считывания определения системы координат
 *
 * Чтение данных из SINEX-файла возможно в двух режимах: чтение определения
 * системы координат (система координат задаётся координатами и скоростями
 * базовых БИС и их среднеквадратическими отклонениями), или чтение решения
 * ЭВЗ на короткий промежуток времени. Режим задаётся флагом framedef.
 * Название считываемой системы координат
 *
 * Из SINEX-файла читаются следующие данные:
 * @li SITE/ID - список БИСов, заносится в таблицу Markers.
 * @li SITE/ECCENTRICITY - сдвиг опорной точки антенны относительно маркера,
 * заносится в таблицу MarkersEccentricity.
 * @li SOLUTION/ESTIMATE - значение уточняемых параметров. Считываются только
 * параметры положения БИСов STAX, STAY, STAZ и их скорости VELX, VELY, VELZ.
 * При чтении определения системы координат данные считываются в таблицу
 * @ref ReferenceFrames, при чтении решения - в таблицу @ref MarkerPosition.
 *
 */
void readSINEX ( DBTableCollection * base, ifstream & str,
				 const string & frame=string(),
				 bool framedef=false);

/**
 * @brief Чтение SINEX-Tropo-файла с данными о тропосферной задержке
 * @param base Коллекция таблиц, в которую происходит считывание
 * @param str Поток, из которого считывается SINEX-файл
 *
 * По сравнению с обычным SINEX-файлом, SINEX-Tropo-файл имеет следующие
 * отличия:
 * @li В начале файла стоит не SNX, а TRO
 * @li Добавляются новые таблицы: TROP/DESCRIPTION,TROP/STA_COORDINATES,
 * TROP/SOLUTION.
 * @li Наоборот, нет таблиц, не относящихся напрямую к тропосфере. При этом,
 * данная функция поддерживает чтение только TROP/DESCRIPTION, причем только
 * строки, содержащей список уточняемых параметров, и TROP/SOLUTION, из которого
 * считываются только уточняемые параметры допустимых типов (см. поле Type
 * таблицы @ref ParamTroposphere).

 */
void readTropoSINEX ( DBTableCollection * base, ifstream & str);

}

//! @file

#include <set>
#include <limits>

using namespace std;

#include <DBTable.h>
#include <DBTableCollection.h>
#include <DBVariant.h>
#include <observables.h>
#include <StdTables.h>
#include <CycleSlip.h>
#include <Frames.h>
#include <PhaseCentre.h>
#include <SiteDisplacement.h>

namespace libgnss
{

Settings::Enumerator minarclength("Observables", "Editor", "minArcLength",
								  Variant::TYPE_DOUBLE,
			"Минимальная длина непрерывной последовательности измерений, сек",
								(real)(900));

Settings::Enumerator minobscount("Observables", "Editor", "minObsCount",
								  Variant::TYPE_DOUBLE,
		"Минимальное число моментов измерений на интервале непрерывности фазы",
								4);


Settings::Enumerator usegfdetector("Observables", "Editor", "usegfdetector",
								   CTypeSelect::yesOrNo(),
			"Использовать Geometry-Free-детектор скачков фазы?",
								   "Yes");

Settings::Enumerator usemwdetector("Observables", "Editor", "usemwdetector",
								   CTypeSelect::yesOrNo(),
			"Использовать Melbourne-Wubbena-детектор скачков фазы?",
								   "Yes");

Settings::Enumerator usempdetector("Observables", "Editor", "usempdetector",
								   CTypeSelect::yesOrNo(),
			"Использовать детектор многолучовости для поиска скачков фазы?",
								   "Yes");

AmbigousObservationSource::AmbigousObservationSource(
		const string &markername, const string &antenna1,
		const string &antenna2, const string &receiver1,
		const string &receiver2)
	: StrException("AmbigousObservationSource",
				   "Для маркера '"+markername+"' БИС не определена однозначно. "
				   "В частности, (Приемник1, Антенна1)=(" + receiver1+","
				   +antenna1+"), (Приемник2, Антенна2)=(" + receiver2+","
				   +antenna2+").")
{

}

ObservableTypes::ObservableTypes(DBTableCollection *base)
	: NumeratedTable(Columns()
		<<Column(Variant::TYPE_STRING,"denotement") //0
		<<Column(Variant::TYPE_CHAR,"system_letter") //1
		<<Column(Variant::TYPE_INT,"frequency") //2
		<<Column(Variant::TYPE_INT,"type") //3
		<<Column(Variant::TYPE_CHAR,"attribute") //4
		<<Column(Variant::TYPE_STRING,"description") //5
	)
{
	createIndex("system_denotement", OperatorPushableVector<string>()
				<<"system_letter"<<"denotement");
	createIndex("system_freq_type_attr", OperatorPushableVector<string>()
				<<"system_letter"<<"frequency"<<"type"<<"attribute");
	base->addTable("observable_types", this);
}

int ObservableTypes::getCorrespondentL1L2(int obs_type) const
{
	//Найти данный тип измерения (при отсутствии, метод read сгенерирует
	//нужное исключение)
	Tuple obsdetail = read(Tuple()<<obs_type);
	int anotherfreq = -1;

	//1) Случай GPS
	if (obsdetail[2] == getFrequencyFromAntex("G01"))
		anotherfreq = getFrequencyFromAntex("G02");
	if (obsdetail[2] == getFrequencyFromAntex("G02"))
		anotherfreq = getFrequencyFromAntex("G01");

	//2) Случай GLONASS
	if (obsdetail[2] == getFrequencyFromAntex("R01"))
		anotherfreq = getFrequencyFromAntex("R02");
	if (obsdetail[2] == getFrequencyFromAntex("R02"))
		anotherfreq = getFrequencyFromAntex("R01");

	//3) Случай Compass
	if (obsdetail[2] == getFrequencyFromAntex("C01"))
		anotherfreq = getFrequencyFromAntex("C02");
	if (obsdetail[2] == getFrequencyFromAntex("C02"))
		anotherfreq = getFrequencyFromAntex("C01");

	//3) Случай QZSS
	if (obsdetail[2] == getFrequencyFromAntex("J01"))
		anotherfreq = getFrequencyFromAntex("J02");
	if (obsdetail[2] == getFrequencyFromAntex("J02"))
		anotherfreq = getFrequencyFromAntex("J01");

	if (anotherfreq == -1)
		return -1;

	//Попробовать найти тот же тип измерений на другой частоте
	obsdetail[2] = anotherfreq;
	DBTable::DBConstIterator it = idx_find("system_freq_type_attr",
			Tuple()<<obsdetail[0]<<anotherfreq<<obsdetail[3]<<obsdetail[4]);

	//Если его нет, вернуть -1
	if (it==const_end())
		return -1;

	return it.keyColumnValue(0).toInt();

}

real ObservableTypes::getFrequencyForAntex(int freqn)
{
	if (freqn == getFrequencyFromAntex("G01"))
		return 1.57542e+9;
	if (freqn == getFrequencyFromAntex("G02"))
		return 1.22760e+9;
	if (freqn == getFrequencyFromAntex("G05"))
		return 1.17645e+9;
	if (freqn == getFrequencyFromAntex("E01"))
		return 1.57542e+9;
	if (freqn == getFrequencyFromAntex("E05"))
		return 1.17645e+9;
	if (freqn == getFrequencyFromAntex("E07"))
		return 1.207140e+9;
	if (freqn == getFrequencyFromAntex("E08"))
		return 1.191795e+9;
	if (freqn == getFrequencyFromAntex("E06"))
		return 1.27875e+9;
	if (freqn == getFrequencyFromAntex("S01"))
		return 1.57542e+9;
	if (freqn == getFrequencyFromAntex("S05"))
		return 1.17645e+9;
	if (freqn == getFrequencyFromAntex("R01"))
		return  1.602e+9;
	if (freqn == getFrequencyFromAntex("R02"))
		return 1.246e+9;
}

int ObservableTypes::getObservableTypeID(char navsys, const string &denotement)
const
{
	DBConstIterator it = idx_find("system_denotement",
								  Tuple()<<navsys<<denotement);
	if (it.isEnd())
		return -1;
	return it.keyColumnValue(0).toInt();
}

int ObservableTypes::getObservableTypeID(char navsys, int freq, int type,
										 char attr) const
{
	DBConstIterator it = idx_find("system_freq_type_attr",
								  Tuple()<<navsys<<freq<<type<<attr);
	if (it.isEnd())
		return -1;
	return it.keyColumnValue(0).toInt();
}

real ObservableTypes::getFrequency(int obstype, int letter) const
{
	Tuple obsdetail = read(Tuple()<<obstype);

	//Случай системы GPS
	if (obsdetail[1].toChar() == 'G')
	{
		if (obsdetail[2].toInt() == getFrequencyFromAntex("G01"))
			return 1.57542e+9;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("G02"))
			return 1.22760e+9;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("G05"))
			return 1.17645e+9;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("G12"))
			return 1.57542e+9 + 1.22760e+9;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("G15"))
			return 1.57542e+9 + 1.17645e+9;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("G25"))
			return 1.22760e+9 + 1.17645e+9;
	}

	//Случай системы Galileo
	if (obsdetail[1].toChar() == 'E')
	{
		if (obsdetail[2].toInt() == getFrequencyFromAntex("E01"))
			return 1.57542e+9;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("E05"))
			return 1.17645e+9;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("E07"))
			return 1.207140e+9;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("E08"))
			return 1.191795e+9;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("E06"))
			return 1.27875e+9;
	}

	//Случай сигнала SBAS
	if (obsdetail[1].toChar() == 'S')
	{
		if (obsdetail[2].toInt() == getFrequencyFromAntex("S01"))
			return 1.57542e+9;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("S05"))
			return 1.17645e+9;
	}

	//Случай системы ГЛОНАСС
	if (obsdetail[1].toChar() == 'R')
	{
		if (obsdetail[2].toInt() == getFrequencyFromAntex("R01"))
			return  1.602e+9+letter*5.625e+5;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("R02"))
			return 1.246e+9+letter*4.375e+5;
		if (obsdetail[2].toInt() == getFrequencyFromAntex("R12"))
			return (1.602e+9 + 1.246e+9)+letter*(4.375e+5+5.625e+5);
	}
	return 0;

}

string ObservableTypes::getFrequencyDenotement(int freq_id)
{
	static OperatorPushableVector < string > denotements;
	if (denotements.size() == 0)
		denotements<<"G01"<<"G02"<<"G05"<<"R01"<<"R02"<<"E01"
					 <<"E05"<<"E07"<<"E08"<<"E06"<<"C01"<<"C02"
					   <<"C07"<<"C06"<<"J01"<<"J02"<<"J05"<<"J06"
						 <<"S01"<<"S05"<<"G12"<<"G15"<<"G25"<<"R12"
						   <<"G125";
	return denotements[freq_id];
}

int ObservableTypes::getFrequencyFromAntex(const string& antexfreq)
{
	static map < string, int > antexfreqstr;
	if (antexfreqstr.size() == 0)
	{
		int i = 0;
		antexfreqstr["G01"]=(i++);
		antexfreqstr["G02"]=(i++);
		antexfreqstr["G05"]=(i++);
		antexfreqstr["R01"]=(i++);
		antexfreqstr["R02"]=(i++);
		antexfreqstr["E01"]=(i++);
		antexfreqstr["E05"]=(i++);
		antexfreqstr["E07"]=(i++);
		antexfreqstr["E08"]=(i++);
		antexfreqstr["E06"]=(i++);
		antexfreqstr["C01"]=(i++);
		antexfreqstr["C02"]=(i++);
		antexfreqstr["C07"]=(i++);
		antexfreqstr["C06"]=(i++);
		antexfreqstr["J01"]=(i++);
		antexfreqstr["J02"]=(i++);
		antexfreqstr["J05"]=(i++);
		antexfreqstr["J06"]=(i++);
		antexfreqstr["S01"]=(i++);
		antexfreqstr["S05"]=(i++);
		antexfreqstr["G12"]=(i++);
		antexfreqstr["G15"]=(i++);
		antexfreqstr["G25"]=(i++);
		antexfreqstr["R12"]=(i++);
		antexfreqstr["G125"]=(i++);
	}
	map<string,int>::iterator it = antexfreqstr.find(antexfreq);
	if (it == antexfreqstr.end())
		return -1;
	else
		return it->second;
}

void loadIonosphereFreeObservableCodes(DBTableCollection &tcol)
{
	ObservableTypes * types = (ObservableTypes*)
			(tcol.getTable("observable_types"));

	//GPS - фаза и дальность с исключенной ионосферой по частотам L1 и L2
	types->insertRow(Tuple()<<string("C12")<<'G'<<20<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код GPS с исключенной по частотам 1575.42 и 1227.60 ионосферной задержкой"));
	types->insertRow(Tuple()<<string("P12")<<'G'<<20<<ObservableTypes::MTYPE_C<<'P'<<string("Высокоточный код GPS с исключенной по частотам 1575.42 и 1227.60 ионосферной задержкой"));
	types->insertRow(Tuple()<<string("L12")<<'G'<<20<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GPS с исключенной по частотам 1575.42 и 1227.60 ионосферной задержкой"));

	//GPS - фаза и дальность с исключенной ионосферой по частотам L1 и L5
	types->insertRow(Tuple()<<string("C15")<<'G'<<21<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код GPS с исключенной по частотам 1575.42 и 1176.45 ионосферной задержкой"));
	types->insertRow(Tuple()<<string("P15")<<'G'<<21<<ObservableTypes::MTYPE_C<<'P'<<string("Высокоточный код GPS с исключенной по частотам 1575.42 и 1176.45 ионосферной задержкой"));
	types->insertRow(Tuple()<<string("L15")<<'G'<<21<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GPS с исключенной по частотам 1575.42 и 1176.45 ионосферной задержкой"));

	//GPS - фаза и дальность с исключенной ионосферой по частотам L2 и L5
	types->insertRow(Tuple()<<string("C25")<<'G'<<22<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код GPS с исключенной по частотам 1227.60 и 1176.45 ионосферной задержкой"));
	types->insertRow(Tuple()<<string("P25")<<'G'<<22<<ObservableTypes::MTYPE_C<<'P'<<string("Высокоточный код GPS с исключенной по частотам 1227.60 и 1176.45 ионосферной задержкой"));
	types->insertRow(Tuple()<<string("L25")<<'G'<<22<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GPS с исключенной по частотам 1227.60 и 1176.45 ионосферной задержкой"));

	//GPS - фаза и дальность с исключенной ионосферой по частотам L1, L2, L5
	types->insertRow(Tuple()<<string("C125")<<'G'<<24<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код GPS с исключенной по частотам 1575.42, 1227.60 и 1176.45 ионосферной задержкой"));
	types->insertRow(Tuple()<<string("P125")<<'G'<<24<<ObservableTypes::MTYPE_C<<'P'<<string("Высокоточный код GPS с исключенной по частотам 1575.42, 1227.60 и 1176.45 ионосферной задержкой"));
	types->insertRow(Tuple()<<string("L125")<<'G'<<24<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения GPS с исключенной по частотам 1575.42, 1227.60 и 1176.45 ионосферной задержкой"));

	//ГЛОНАСС - фаза и дальность с исключенной ионосферой по частотам L1 и L2
	types->insertRow(Tuple()<<string("C12")<<'R'<<23<<ObservableTypes::MTYPE_C<<'C'<<string("Стандартный код ГЛОНАСС с исключенной по частотам 1602+k*9/16 и 1246+k*7/16 ионосферной задержкой"));
	types->insertRow(Tuple()<<string("P12")<<'R'<<23<<ObservableTypes::MTYPE_C<<'P'<<string("Высокоточный код ГЛОНАСС с исключенной по частотам 1602+k*9/16 и 1246+k*7/16 ионосферной задержкой"));
	types->insertRow(Tuple()<<string("L12")<<'R'<<23<<ObservableTypes::MTYPE_L<<'C'<<string("Фазовые измерения ГЛОНАСС с исключенной по частотам 1602+k*9/16 и 1246+k*7/16 ионосферной задержкой"));
}

IncostitentGLONASSFreqSlotData::IncostitentGLONASSFreqSlotData(
		int slot, real tai, int l1, int l2)
	: StrException("InconsistentGLONASSFreqSlotData",
		"Противоречивая информация о литере НКА R"+Variant(slot).toString("%2d")
				  +" в момент времени "
				   +UTCDateTime::fromTAIJ2000(tai).getUTCDateTimeString()
				   +". Ранее указана литера "+Variant(l1).toString()
				   +", и на это же время попытка записать литеру "
				   +Variant(l2).toString())
{

}

GLONASSFrequencySlots::GLONASSFrequencySlots (DBTableCollection * base)
: DBTable(
Columns()
<<Column(Variant::TYPE_INT, "slot")
<<Column(Variant::TYPE_DATETIME, "since"),
		  Columns()<<Column(Variant::TYPE_INT, "letter"))
{
	base->addTable("glonass_frequency_slots", this);
}


int GLONASSFrequencySlots::getLetter(int slot, real t, real *t1) const
{
	if (t1 == 0)
		return getLetter(slot, UTCDateTime::fromTAIJ2000(t));
	else
		return getLetter(slot, UTCDateTime::fromTAIJ2000(t), t1);
}

int GLONASSFrequencySlots::getLetter(int slot, UTCDateTime t, real *t1) const
{
	DBTable::DBConstIterator it0 = lower_bound(Tuple()<<slot<<t);
	if (it0 == const_end())
		throw UnknownSlot(slot, t);
	int result = it0[0].toInt();
	if (t1!=0)
	{
		it0.subinc(1,0);
		if (it0.isEnd())
			*t1 = UTCDateTime::now().getTAIJ2000();
		else
			*t1 = it0.keyColumnValue(1).toUTCDateTime().getTAIJ2000();
	}
	return result;
}

void GLONASSFrequencySlots::setLetter(int slot, UTCDateTime t, int freqslot)
{
	DBTable::DBConstIterator it0 = lower_bound(Tuple()<<slot<<t);
	if (it0.isEnd() == false)
	{
		if(it0[0].toInt()==freqslot)
			return;
		if(it0.keyColumnValue(1).toUTCDateTime()==t)
			throw IncostitentGLONASSFreqSlotData(slot,t.getTAIJ2000(),
												 it0[0].toInt(), freqslot);
	}

	//Если выполнение дошло до этого места, необходимо вставить строку в таблицу
	insertRow(Tuple()<<slot<<t, Tuple()<<freqslot);

	//Проверить следующую запись - не совпадает ли она с данной
	it0 = find(Tuple()<<slot<<t);
	it0.subinc(1,0);
	if (it0.isEnd())
		return;
	if (it0[0] == freqslot)
		deleteRows(it0.subkey());
}

Observables::Observables(DBTableCollection *base)
	: DBTable(Columns()
			  <<Column(Variant::TYPE_INT, "source_id")
			  <<Column(Variant::TYPE_DOUBLE, "epoch")
			  <<Column(Variant::TYPE_INT, "sat_history_id")
			  <<Column(Variant::TYPE_INT, "observable_type_id"),
			  Columns()
			<<Column(Variant::TYPE_DOUBLE, "observable_value")
		   <<Column(Variant::TYPE_INT, "flags"))
{
	Base = base;
	base->addTable("observables", this);
}


void Observables::deleteIonosphere(char navsys,
		const OperatorPushableVector < string > & denotements,
		const string & newdenotement)
{
	//Все необходимые таблицы
	SatelliteHistory * history = (SatelliteHistory *)
			(Base->getTable("satellite_history"));
	ObservableTypes * obstypes = (ObservableTypes *)
			(Base->getTable("observable_types"));
	GLONASSFrequencySlots * gslots = (GLONASSFrequencySlots*)
			(Base->getTable("glonass_frequency_slots"));

	vector < pair < int, Tuple > > obst;

	for (int i=0; i<denotements.size(); i++)
	{
		DBTable::DBConstIterator it0 = obstypes->idx_find("system_denotement",
											Tuple()<<navsys<<denotements[i]);
		if (it0==obstypes->const_end())
			throw StrException("Observables::deleteIonosphere",
							   "Неизвестное обозначение измерительных данных: "
							   + denotements[i]);
		obst.push_back(pair < int, Tuple > (it0.keyColumnValue(0).toInt(),
											it0.values()));
		if (i>0)
			if ((obst[i-1].second[3]!=obst[i].second[3])
				//	|| (obst[i-1].second[4]!=obst[i].second[4])
					||(obst[i-1].second[2] == obst[i].second[2]))
				throw StrException("Observables::deleteIonosphere",
								   "Исключение ионосферы возможно только по "
						"измерениям одинаковых типов на разной частоте");
	}

	int newobstype = obstypes->idx_find("system_denotement",Tuple()<<navsys
								<<newdenotement).keyColumnValue(0).toInt();

	//Для каждого БИС: для каждого НКА: накопленное значение флага фазы
	map < int, map < int, int > > flags;

	//Цикл по всем эпохам измерений для каждого БИС и НКА
	DBTable::DBConstIterator it = const_begin();
	while(true)
	{
		if (it == const_end())
			break;

		//Запомнить значения ключей для текущей эпохи и номеров НКА, БИС
		Tuple currentKey = it.subkey();
		//и для следующих значений эпохи, номеров НКА и БИС
		it.inc(2);

		//Найти НКА
		int obs_src_id = currentKey[0].toInt();
		int sat_history_id = currentKey[2].toInt();
		if (flags[obs_src_id].find(sat_history_id) == flags[obs_src_id].end())
			flags[obs_src_id][sat_history_id] = 0;
		DBTable::DBConstIterator satit = history->find(Tuple()<<currentKey[2]);

		//Пропустить неизвестный НКА
		if (satit == history->const_end())
			continue;

		//Пропустить НКА не ГЛОНАСС и не GPS
		if ((satit[0].toChar() != 'G') &&
				(satit[0].toChar() != 'R'))
			continue;

		//Момент измерения
		real curt = currentKey[1].toDouble();

		//Запомнить, по какому ключу искать следующие данные (итератор будет
		//недействителен после добавления/удаления данных)
		Tuple nextkey;
		if (it!=const_end())
			nextkey = it.subkey();

		//Если НКА ГЛОНАСС, определить литеру (частотный слот)
		int letter;
		if (satit[0].toChar() == 'R')
		{
			int slot = satit[2].toInt();
			letter = gslots->getLetter(slot,curt);
		}

		vector < pair < real, pair < real, int > > > freqvalues;

		//Проверить, нельзя ли исключить ионосферу по заданным наборам
		//измерений
		for (int i=0; i<obst.size(); i++)
		{
			real freq = obstypes->getFrequency(obst[i].first,letter);
			currentKey[3] = obst[i].first;
			DBMap::DBConstIterator it = find(currentKey);
			if (it.isEnd())
				continue;
			Tuple valueflag = it.values();
			real value = valueflag[0].toDouble();
			int flag = valueflag[1].toInt();
			flags[obs_src_id][sat_history_id] |= flag;
			freqvalues.push_back(pair<real,pair<real, int > >(freq,
							pair < real, int > (value, flag)));
		}

		//Если для данных БИС, НКА и момента времени полного набора измерений
		//для исключения ионосферы нет, перейти к следующим
		if (freqvalues.size()<obst.size())
			continue;

		//Удалить из таблицы использованные измерительные данные
		for (int i=0; i<obst.size(); i++)
		{
			currentKey[3] = obst[i].first;
			deleteRows(currentKey);
		}

		//Выполнить исключение ионосферы по двум частотам
		if (freqvalues.size() == 2)
		{
			//Создать ионосферно-свободную комбинацию
			real ionfree =
					(pow(freqvalues[0].first,2)*freqvalues[0].second.first
					-pow(freqvalues[1].first,2) * freqvalues[1].second.first)
					/(pow(freqvalues[0].first,2)-pow(freqvalues[1].first,2));

			//Флаги для комбинации
			//flags&255 - флаги эпохи
			// * flags&(255*256)/256 - мощность сигнала
			// * flags&(255*65536)/65536 - LLI

			int newepochflag0 = (freqvalues[0].second.second & 255)
								  | (freqvalues[1].second.second & 255);
			int newsigstrength = min(freqvalues[0].second.second & 255*256,
									  freqvalues[1].second.second & 255*256);
			int newlli = (freqvalues[0].second.second & 255*65536)|
					(freqvalues[1].second.second & 255*65536);
			int newflag = newepochflag0|newsigstrength|newlli
					|flags[obs_src_id][sat_history_id];
			flags[obs_src_id][sat_history_id] = 0;

			//Ключ для записи данных
			currentKey[3] = newobstype;
			insertRow(currentKey, Tuple()<<ionfree<<newflag);
		}

		//Поскольку были проделаны изменения с таблицей, необходимо
		//обновить ставший недействительным итератор
		if (nextkey.size() > 0)
			it = find(nextkey);
		else
			break;
	}
}

//Удалить измерительные данные с момента времени t0 по момент времени t1
//включительно
void Observables::deleteArc(int obs_src_id, int sat_his_id, real t0,
							real t1)
{
	//Если длина интервала меньше ограничения, удалить
	//лишние измерения
	Tuple key0;
	key0<<obs_src_id<<t0<<sat_his_id;
	DBTable::DBConstIterator it2 = find(key0);
	if (it2 == const_end())
		throw KeyNotFoundException(key0);
	while (true)
	{
		//Выбрать ключ для удаления
		Tuple deleteKey;
		real tToDelete = it2.keyColumnValue(1).toDouble();
		if (tToDelete>t1)
			break;
		deleteKey<<obs_src_id<<tToDelete<<sat_his_id;

		//Выбрать следующий ключ для восстановления итератора
		Tuple newkey;
		it2.subinc(1,0);
		if (it2!=const_end())
			newkey = it2.subkey();

		//Удалить измерительные данные
		deleteRows(deleteKey);

		//Восстановить итератор
		if (newkey.size() == 0)
			break; //Нулевой размер нового ключа обозначает конец интервала
		else
			it2 = find(newkey);
	}
}

void Observables::findCycleSlips (string L1_denotement,
						string L2_denotement, string P1_denotement,
						string P2_denotement, char curnavsys)
{
	ObservableTypes * obstypes = (ObservableTypes*)
			(Base->getTable("observable_types"));
	SatelliteHistory * his =
			(SatelliteHistory*)(Base->getTable("satellite_history"));
	Settings * sets = (Settings *)(Base->getTable("settings"));
	bool usemp = sets->getSettings(usempdetector).toString() == "Yes";
	bool usemw = sets->getSettings(usemwdetector).toString() == "Yes";
	bool usegf = sets->getSettings(usegfdetector).toString() == "Yes";
	//Пройти по всем БИС

	map < int, real > previousT;
	for (DBTable::DBConstIterator it0 = const_begin();
		 it0!=const_end();)
	{
		DBTable::DBConstIterator it = it0;
		int obssrcid = it0.keyColumnValue(0).toInt();
		int nextsrcid = 0;  //Следующий идентификатор БИС
		int nextexist = false; //Существует ли следующая БИС
		it0.inc(0);
		if (it0 != const_end())
		{
			nextexist = true;
			nextsrcid = it0.keyColumnValue(0).toInt();
		}
		else
			nextexist = false;

		//Сначала пройти и пометить все разрывы фазы
		//Создать детекторы разрывов
		MelbourneWubbenaDetector mw(Base, L1_denotement, L2_denotement,
									P1_denotement, P2_denotement);
		MultipathDetector mp1(Base,L1_denotement, L2_denotement,
							  P1_denotement, P2_denotement,true);
		MultipathDetector mp2(Base,L1_denotement, L2_denotement,
							  P1_denotement, P2_denotement,false);
		GeometryFreeDetector gf(Base, L1_denotement, L2_denotement);


		bool stage_forward = true;

		while (true)
		{
			real t = it.keyColumnValue(1).toDouble();
			int sat_history_id = it.keyColumnValue(2).toInt();
			char navsys = (*his)[sat_history_id][0].toChar();
			if ((curnavsys!='A') && (navsys!=curnavsys))
				continue;

			bool slip, slip1, slip2, slip3, slip4;

			//Список измерений для данного момента времени для данных БИС и
			//НКА
			map < int, real > observs;
			for (DBTable::DBConstIterator it1 = find(Tuple()<<obssrcid
													 <<t<<sat_history_id);
				 it1!=const_end();
				 it1.subinc(3,2)
				 )
				observs[it1.keyColumnValue(3).toInt()] = it1[0].toDouble();

			slip1=usemw&&mw.detectCycleSlip(navsys,sat_history_id,observs,t);
			slip2=usemp&&mp1.detectCycleSlip(navsys,sat_history_id,observs,t);
			slip3=usemp&&mp2.detectCycleSlip(navsys,sat_history_id,observs,t);
			slip4=usegf&&gf.detectCycleSlip(navsys,sat_history_id,observs,t);
			slip = slip1||slip2||slip3||slip4;


			//Пометить найденный разрыв
			if (slip == true)
			{
				//Итератор, указывающий на измерение, на которое нужно
				//навесить флаг
				DBTable::DBConstIterator itslip;

				if(stage_forward)
					//При движении вперёд помечать разрывом текущее измерение
					itslip = it;
				else
				{
					//При движении назад помечать разрывом последующее по
					//времени (предшествующее по циклу) измерение
					map < int, real > :: iterator pti =
							previousT.find(sat_history_id);
					if (pti != previousT.end())
					{
						real prevt = pti->second;
						itslip = find(Tuple()<<obssrcid<<prevt
									  <<sat_history_id);
					}
					else
						itslip = const_end();
				}

				if (itslip != const_end())
					for (DBTable::DBIterator it1 = itslip; it1!=const_end();
						 it1.subinc(3,2))
					{
						Variant obstype = it1.keyColumnValue(3);
						//Пометить флагом только фазовые измерения
						if (obstypes->read(obstype)[3].toInt()==
								ObservableTypes::MTYPE_L)
						{
							int curflag = it1[1].toInt();
							curflag = curflag|65536;
							it1.updateCell(1, curflag);
						}
					}
			}

			//if (stage_forward == true)
			previousT[sat_history_id] = t;
			//Контроль выполнения цикла:

			//Если выполняется проход вперёд
			if (stage_forward)
			{

				it.subinc(2,0);
				if (it==const_end())
				{
					//Теперь начать проход в обратную сторону

					//Найти последнюю запись для данной БИС
					it = find(obssrcid);
					it.inc(0);
					--it;

					//Продолжить выполнение цикла, в обратную сторону
					stage_forward = false;
					continue;
				}
			}
			//Если выполняется проход в обратную сторону
			else
			{
				it.subdec(2,0);
				if (it.isReverseEnd())
					break;
			}
		} //Цикл по измерительным данным


		//Управление циклом по БИС
		//Требуется восстановление итератора на случай, если данные были удалены
		if (nextexist)
			it0 = find(nextsrcid);
		else
			break;

	} //Цикл по БИС
}

void Observables::deleteSmallArcs(char todelete)
{
	Settings * sets = (Settings *)(Base->getTable("settings"));
	real minarc = sets->getSettings(minarclength).toDouble();
	int mincount = sets->getSettings(minobscount).toDouble();
	ObservableTypes * obstypes = (ObservableTypes*)
			(Base->getTable("observable_types"));

	for (DBMap::DBConstIterator it0 = const_begin(); !(it0.isEnd());)
	{
		int obssrcid = it0.keyColumnValue(0).toInt();
		it0.inc(0);
		int nextsrcid;
		if (!(it0.isEnd()))
			nextsrcid = it0.keyColumnValue(0).toInt();

		DBMap::DBConstIterator it = find(Tuple()<<obssrcid);
		//Условие, которое должно выполняться при выполнении цикла:
		//prev_t0[n] и prev_t1[n] существуют одновременно.
		map < int, real > prev_t0;
		map < int, int > curcount;
		map < int, real > prev_t1;
		while (true)
		{
			if (it == const_end())
			{
				//Проверить длину последней дуги
				for (map<int, real>::iterator it2 = prev_t0.begin();
					 it2!= prev_t0.end(); ++it2)
				{
					int sat_history_id2 = it2->first;
					real t1 = prev_t1[sat_history_id2];
					real t2 = it2->second;
					real arclen = t1-t2;
					if (((arclen<minarc) && (todelete == 'L'))
					||((curcount[sat_history_id2]<mincount)&&(todelete=='C')))
						deleteArc(obssrcid, sat_history_id2,
								  it2->second, t1);
				}
				break;

			}
			real t = it.keyColumnValue(1).toDouble();
			int sat_history_id = it.keyColumnValue(2).toDouble();
			if (prev_t0.find(sat_history_id) == prev_t0.end())
			{
				//Предыдущей дуги пока нет - удалять нечего
				prev_t0[sat_history_id] = t;
				prev_t1[sat_history_id] = t;
				curcount[sat_history_id] = 1;
				it.subinc(2,0);
				continue;
			}
			int curflag = 0;
			for (DBTable::DBConstIterator it1 = it; it1!=const_end();
				 it1.subinc(3,2))
				if (obstypes->read(it1.keyColumnValue(3))[3].toInt()==
						ObservableTypes::MTYPE_L)
					curflag |= it1[1].toInt();

			//Если стоит флаг разрыва, то очередная дуга пройдена
			if ((curflag & 65536) == 0)
			{
				prev_t1[sat_history_id] = t;
				curcount[sat_history_id] ++;
			}
			else
			{
				//Нужно ли удалять пройденную дугу?
				real t1 = prev_t1[sat_history_id];
				real t2 = prev_t0[sat_history_id];
				real al = t1-t2;
				bool tooshort = al < minarc;
				bool toofew = curcount[sat_history_id] < mincount;
				if ((tooshort && (todelete=='L'))
				||(toofew && (todelete=='C'))
				||((toofew||tooshort) && (todelete=='B')))
				{
					//Удаление дуги
					Tuple curtuple = it.subkey();
					real t_from = prev_t0[sat_history_id];
					real t_until = prev_t1[sat_history_id];
					deleteArc(obssrcid, sat_history_id,t_from,t_until);
					it = find(curtuple);
				}
				prev_t0[sat_history_id] = t;
				prev_t1[sat_history_id] = t;
				curcount[sat_history_id] = 1;
			}
			it.subinc(2,0);
		} //Цикл по измерительным данным


		if (it0.isEnd())
			break;
		else
			it0 = find(nextsrcid);
	}
}

#ifdef WithQT
void Observables::deleteSmallArcs(const QString &s)
{
	char first = s.toStdString().at(0);
	deleteSmallArcs(first);
}
#endif

real Observables::getMinTime () const
{
	real result = 1e+100;
	for (DBTable::DBConstIterator it = const_begin();
		 it!=const_end(); it.inc(0))
		if (it.keyColumnValue(1).toDouble() < result)
			result = it.keyColumnValue(1).toDouble();
	return result;
}

real Observables::getMaxTime () const
{
	real result = -1e+100;
	DBTable::DBConstIterator it = const_begin();
	it.inc(0);
	while (true)
	{
		bool exit = (it==const_end());
		--it;
		if (it.keyColumnValue(1).toDouble()>result)
			result = it.keyColumnValue(1).toDouble();
		++it;
		if (exit)
			return result;
		it.inc(0);
	}
	return result;
}

void Observables::resampleDown(real t0, real step)
{
	//Нужно будет запоминать флаги измерений, чтобы перенести их с удаленных
	//на последующие по времени измерения
	//flags[obs_src_id][sat_history_id][obstype] - дизъюнкция всех флагов с
	//предыдущих удалённых измерений
	map < int, map < int , map < int, int > > > flags;

	for (DBTable::DBIterator it = const_begin();
		 it!=const_end();)
	{
		int obs_src_id = it.keyColumnValue(0).toInt();
		int sat_history_id = it.keyColumnValue(2).toInt();
		int obstype = it.keyColumnValue(3).toInt();
		if (flags[obs_src_id][sat_history_id].find(obstype) == flags[obs_src_id]
				[sat_history_id].end())
			flags[obs_src_id][sat_history_id][obstype] = 0;
		int curflag = it[1].toInt();
		flags[obs_src_id][sat_history_id][obstype] |= curflag;
		real t = it.keyColumnValue(1).toDouble();
		real k = (t-t0)/step;

		//Если данные должны остаться
		if (fabs(int(k) - k) < 1e-15 * t)
		{
			//Измерительным данным данным, которые останутся в таблице,
			//присвоить флаг - дизъюнкцию всех флагов предшествующих удаляемых
			//измерений
			it.updateCell(1,flags[obs_src_id][sat_history_id][obstype]);
			//Накопленный флаг стереть, чтобы накапливать с последующих
			//удаляемых данных
			flags[obs_src_id][sat_history_id][obstype] = 0;
			it++;
		}
		//Если данные должны быть удалены
		else
		{
			int co = count();
			Tuple todelete = it.subkey();
			it++;
			Tuple toproceed;
			if (it != const_end())
				toproceed = it.subkey();
			deleteRows(todelete);
			if (co == count())
				co = 0;
			if (toproceed.size() == 0)
				break;
			it = find(toproceed);
		}
	}

}

int Observables::combineSubsequentFlags(int flag1, int flag2)
{
	//Перенести флаг сбоя питания
	int result = flag2;
	if (flag1 & 255 == 1)
		result |= 1;
	//Перенести флаги разрыва
	result |= (flag1&(255*65536));
	return result;
}

#ifdef WithQT
void Observables::deleteIonosphere(const QString & navsys,
								   const QStringList & denotements,
					  const QString & newdenotement)
{
	OperatorPushableVector<string> denotements_;
	for (int i=0; i<denotements.size(); i++)
		denotements_.push_back(denotements[i].toStdString());
	deleteIonosphere(navsys.at(0).toAscii(), denotements_,
					 newdenotement.toStdString());
}

void Observables::findCycleSlips (const QString & navsys,
					const QString & L1_denotement,
					const QString & L2_denotement,
					const QString & P1_denotement,
					const QString & P2_denotement)
{
	findCycleSlips( L1_denotement.toStdString(),
					L2_denotement.toStdString(),
					P1_denotement.toStdString(),
					P2_denotement.toStdString());
}

void Observables::deleteObservablesArc(int obs_src_id,int sat_his_id,double t0,
				double t1)
{
	deleteArc(obs_src_id,sat_his_id,t0,t1);
}

double Observables::getMinimalTime () const
{
	return getMinTime();
}

double Observables::getMaximalTime () const
{
	return getMaxTime();
}

void Observables::resampleDownWithStep(double t0, double step)
{
	resampleDown(t0,step);
}

void Observables::editObservables(const QString &navsys,
								  const QString &L1_denotement,
								  const QString &L2_denotement,
								  const QString &P1_denotement,
								  const QString &P2_denotement)
{
	editObservables(L1_denotement.toStdString(),
					L2_denotement.toStdString(),
					P1_denotement.toStdString(),
					P2_denotement.toStdString());
}
#endif

ObservationSource::ObservationSource(DBTableCollection *base)
	: NumeratedTable (Columns()
							 <<Column(Variant::TYPE_INT, "marker_id")
							<<Column(Variant::TYPE_INT, "receiver_id")
						   <<Column(Variant::TYPE_INT, "antenna_id"))
{
	this->Base = base;
	base->addTable("observation_source",this);
	createIndex("3id",OperatorPushableVector<string>()
				<<"marker_id"<<"receiver_id"<<"antenna_id");
	rec = 0;
	mrk = 0;
	ants = 0;
}

int ObservationSource::addObservationSource(const std::string & marker_name,
		const std::string & receiver_sn,
		const std::string & antenna_sn,
		const std::string & marker_number,
		const std::string & receiver_model,
		const std::string & antenna_model,
		const std::string & marker_desc,
		const std::string & receiver_desc,
		const std::string & antenna_desc,
		int marker_type,
		kinematic<real, 3, defaultNonInert> pos,
		kinematic<real, 3, defaultGeodetic> pos_g,
		const PhaseBiasFreq &phase_shifts,
		real ant_valid_from,
		real ant_valid_until
		)
{
	string nodesc = "Описание отсутствует";
	//1) Указан ли маркер?
	if (marker_name.size()<4)
		throw StrException("ObservationSource::addObservationSource",
						   "Необходимо указать имя маркера, 4 символа");
	Markers * mrk = (Markers*)(Base->getTable("markers"));
	int mrk_id = mrk->getMarkerID(marker_name);
	if (mrk_id == -1)
	{
		//Если маркера нет, добавить его

		//Дополнить недостающую информацию

		string marker_number_ = marker_number;
		if (marker_number_.size() == 0)
			marker_number_ = marker_name;

		string marker_desc_ = marker_desc;
		if (marker_desc_.size() == 0)
			marker_desc_ = nodesc;

		if (marker_type < 0)
			marker_type= Markers::MT_GEODETIC;

		if (isnan(pos.length<0,2>())) //Не указаны декартовы координаты
		{
			if (isnan(pos_g.length<0,2>()))
			{
				//Если вообще не указаны координаты, выбрать нулевые
				pos = kinematic<real,3,defaultNonInert>(0.0l);
				pos_g = kinematic<real,3,defaultGeodetic>(0.0l);
			}
			else
				//Указаны геодезические, но не указаны геоцентрические
				//Вычислить геоцентрические декартовы координаты
				pos = geodeticToGeocentric(pos_g);
		}
		else if (isnan(pos_g.length<0,2>()))
			//Вычислить геодезические координаты
			pos_g = geocentricToGeodetic(pos);

		//Внести маркер в таблицу
		mrk_id = mrk->insertRow(
					Tuple()<<marker_name<<marker_number_
					<<marker_desc_<<marker_type
					<<pos[0]<<pos[1]<<pos[2]<<pos_g[0]<<pos_g[1]<<pos_g[2]);

		//Внести нулевой эксцентриситет
		MarkerEccentricity * ecc = (MarkerEccentricity*)
				(Base->getTable("marker_eccentricity"));
		ecc->insertRow(Tuple()<<mrk_id<<-real(1e50),
					   Tuple()<<0<<real(0)<<real(0)<<real(0)
					   <<real(1e50));
	}

	//2) Указан ли приёмник?
	if (receiver_sn.size() == 0)
		throw StrException("ObservationSource::addObservationSource",
						   "Необходимо указать серийный номер приемника");
	Receivers * rcv = (Receivers*)(Base->getTable("receivers"));
	int rcv_id = rcv->getReceiverID(receiver_sn);
	if (rcv_id == -1)
	{
		//Внести приёмник в таблицу
		string receiver_desc_ = receiver_desc;
		if (receiver_desc_.size() ==0)
			receiver_desc_=nodesc;
		string receiver_model_ = receiver_model;
		if (receiver_model_.size()==0)
			receiver_model_ = receiver_sn;
		rcv_id = rcv->insertRow(Tuple()<<receiver_sn<<receiver_desc_
								<<receiver_model_);
	}

	//3) Указана ли антенна
	if (antenna_sn.size() == 0)
		throw StrException("ObservationSource::addObservationSource",
						   "Необходимо указать серийный номер антенны");

	ReceivingAntennas * ants = (ReceivingAntennas*)
			(Base->getTable("receiving_antennas"));

	//Внести антенну
	int ant_id = ants->getAntennaID(antenna_sn);
	if (ant_id == -1)
	{
		string antenna_model_ = antenna_model;
		if (antenna_model_.size()==0)
			antenna_model_ = antenna_sn;

		string antenna_desc_ = antenna_desc;
		if (antenna_desc_.size()==0)
			antenna_desc_ = nodesc;


		//Найти модель антенны
		AntennaModels * md = (AntennaModels*)
				(Base->getTable("antenna_models"));
		int md_id = md->getModelID(antenna_model_);

		//Вставить антенну пока без идентификатора модели
		ant_id = ants->insertRow(Tuple()<<antenna_sn<<antenna_desc_
								 <<md_id);

		if (md_id == -1)
		{
			//Внести сначала модель антенны
			md_id = md->insertRow(Tuple()<<antenna_model_
								  <<1<<nodesc);
			ants->updateCell(Tuple()<<ant_id, 2, md_id);

			//Внести поправки к фазовым центрам антенн
			PhaseCentreOffsetFrequency * pcofreq = (PhaseCentreOffsetFrequency*)
					(Base->getTable("phase_centre_offset_frequency"));


			int phase_centre_model_id = pcofreq->getMaximalKeyElementValue(
						Tuple(), -1).toInt()+1;

			map<int, kinematic<real,3,otherCoordSys> > phase_shifts_;
			for (map<string, kinematic<real,3,otherCoordSys> >::const_iterator
				 it=phase_shifts.begin();it!=phase_shifts.end();++it)
				phase_shifts_[ObservableTypes::getFrequencyFromAntex(it->first)]
						= it->second;

			//Если сдвиги фазовых центров не указаны, взять все
			//частоты для загруженных типов измерительных данных, и по всем
			//внести нулевые сдвиги
			if (phase_shifts.size()==0)
			{
				ObservableTypes * ot = (ObservableTypes*)
						(Base->getTable("observable_types"));
				std::set<int> otypes;
				for (DBConstIterator it = ot->const_begin();
					!(it.isEnd()); ++it)
					otypes.insert(it[2].toInt());

				for (std::set<int>::iterator it = otypes.begin();
					 it!=otypes.end(); ++it)
					phase_shifts_[*it] = kinematic<real,3,otherCoordSys>();
			}

			//Внести сдвиги фазовых центров
			for (map<int, kinematic<real,3,otherCoordSys> >::iterator
				 it = phase_shifts_.begin(); it!=phase_shifts_.end(); ++it)
			{
				int freq = it->first;
				kinematic<real,3,otherCoordSys> & shift = it->second;
				pcofreq->insertRow(Tuple()<<phase_centre_model_id
								   <<freq,
								   Tuple()
								   <<shift[0]
									<<shift[1]
									<<shift[2]
									<<-1//Сетка не используется
									  );
			}
			ReceivingAntennaPhaseCentreModels * recphc =
					(ReceivingAntennaPhaseCentreModels*)
					(Base->getTable("receiving_antenna_phase_centre_models"));
			if (isnan(ant_valid_from))
				ant_valid_from=-1e+50;
			if (isnan(ant_valid_until))
				ant_valid_until=1e+50;
			recphc->insertRow(Tuple()<<md_id<<ant_id<<ant_valid_from,
							  Tuple()<<phase_centre_model_id
							  <<ant_valid_until);
		}
	}

	int src_id = getSourceID(mrk_id,rcv_id,ant_id);
	if (src_id <0)
		return insertRow(Tuple()<<mrk_id<<rcv_id<<ant_id);
}

int ObservationSource::getSourceID (int marker_id, int antenna_id,
									int receiver_id) const
{
	DBConstIterator it = idx_find("3id",
								  Tuple()<<marker_id<<antenna_id<<receiver_id);
	if (it.isEnd())
		return -1;
	else
		return it.keyColumnValue(0).toInt();
}


void ObservationSource::updateTables()
{
	if ((rec == 0) || (mrk == 0) || (ants == 0))
	{
		rec = (Receivers*)(Base->getTable("receivers"));
		mrk = (Markers*)(Base->getTable("markers"));
		ants = (ReceivingAntennas*)
				(Base->getTable("receiving_antennas"));
	}
}

int ObservationSource::getSourceID(const string &marker_name)
{
	updateTables();
	bool found = false;
	int result;
	for (DBTable::DBConstIterator it = const_begin();
		 it!=const_end(); ++it)
	{
		int curmarker_id = it[0].toInt();
		string markername = mrk->read(curmarker_id)[0].toString();
		if (markername == marker_name)
		{
			if (found == false)
			{
				result = it.keyColumnValue(0).toInt();
				found = true;
			}
			else
			{
				string
				receiver1 = rec->read(read(result)[1].toInt())[0].toString(),
				antenna1 = ants->read(read(result)[2].toInt())[0].toString(),
				receiver2 = rec->read(it[1].toInt())[0].toString(),
				antenna2 = ants->read(it[2].toInt())[0].toString();
				throw AmbigousObservationSource(marker_name,antenna1,antenna2,
												receiver1,receiver2);
			}
		}
	}
	if (found == true)
		return result;
	else
		throw StrException("ObservationSource::getSourceID",
						   "БИС с маркером "+marker_name+" не найдена.");
}

#ifdef WithQT
int GLONASSFrequencySlots::getGLONASSLetter(int slot, double t) const
{
	return getLetter(slot,t);
}
#endif

int ObservablesLoader::addObsType(int obstype)
{
	int newobstypepos = curobstypes.size();
	curobstypes[obstype] = newobstypepos;
	return newobstypepos;
}


ObservablesLoader::ObservablesLoader (DBTableCollection *col, int obs_src_id,
				   char int_criterion, char navsys,
									  string p1denotement,
									string p2denotement
									  , string l1denotement,
									  string l2denotement)
{
	this->navsys = navsys;
	destination = (Observables*)(col->getTable("observables"));
	obstypes = (ObservableTypes*)(col->getTable("observable_types"));
	sathistory = (SatelliteHistory*)(col->getTable("satellite_history"));
	glofreqslots = (GLONASSFrequencySlots*)
			(col->getTable("glonass_frequency_slots"));
	sets = (Settings*)(col->getTable("settings"));
	setNewObsSrcID(obs_src_id);
	intervalcriterion = int_criterion;
	usemp = sets->getSettings(usempdetector).toString() == "Yes";
	usemw = sets->getSettings(usemwdetector).toString() == "Yes";
	usegf = sets->getSettings(usegfdetector).toString() == "Yes";
	minarccount = sets->getSettings(minobscount).toDouble();
	minarclen = sets->getSettings(minarclength).toDouble();
	tcol = col;
	l1d = l1denotement;
	l2d = l2denotement;
	p1d = p1denotement;
	p2d = p2denotement;
	mel = new MelbourneWubbenaDetector(tcol,l1d,l2d,p1d,p2d);
	mp1 = new MultipathDetector(tcol,l1d,l2d,p1d,p2d,true);
	mp2 = new MultipathDetector(tcol,l1d,l2d,p1d,p2d,false);
	gf = new GeometryFreeDetector(tcol,l1d,l2d);
}

ObservablesLoader::~ObservablesLoader()
{
	delete mel;
	delete mp1;
	delete mp2;
	delete gf;
}

void ObservablesLoader::backwardDetector(int sat_history_id)
{
	//Чтобы не сбрасывать исходный детектор, создадим временные детекторы
	MelbourneWubbenaDetector mwtmp (tcol,l1d,l2d,p1d,p2d);
	MultipathDetector mp1tmp(tcol,l1d,l2d,p1d,p2d,true);
	MultipathDetector mp2tmp(tcol,l1d,l2d,p1d,p2d,false);
	GeometryFreeDetector gftmp(tcol,l1d,l2d);
	vector<pair<real,vector<pair<real, int> > > >*curv=&(arcs[sat_history_id]);
	int l = curv->size();
	for (int i = l - 1; i >= 0; i--)
	{
		real tb = curv->at(i).first;
		map < int, real > curobs;
		for (map<int,int>::iterator it = curobstypes.begin();
			 it!=curobstypes.end(); ++it)
		{
			int idx = it->second;
			if (idx >= curv->at(i).second.size())
				continue;
			real obsvalue = curv->at(i).second[idx].first;
			if (!isnan(obsvalue))
				curobs[it->first] = obsvalue;
		}
		bool s1=usemw&&mwtmp.detectCycleSlip(navsys,sat_history_id,curobs,tb);
		bool s2=usemp&&mp1tmp.detectCycleSlip(navsys,sat_history_id,curobs,tb);
		bool s3=usemp&&mp2tmp.detectCycleSlip(navsys,sat_history_id,curobs,tb);
		bool s4=usegf&&gftmp.detectCycleSlip(navsys,sat_history_id,curobs,tb);
		bool slip = s1 || s2 || s3 || s4;
		//В случае разрыва установить бит 0 флага LLI для всех фазовых измерений
		if ((slip == true) && (i < l - 1))
			for (map<int,int>::iterator it = curobstypes.begin();
				 it!=curobstypes.end(); ++it)
			{
				int idx = it->second;
				if (obsdetails[idx][3].toInt()==ObservableTypes::MTYPE_L)
					curv->at(i+1).second[idx].second |= 65536;
			}
	}
}

vector < bool > ObservablesLoader::resampleDown(int sat_history_id)
{
	vector<pair<real,vector<pair<real, int> > > >*curv=&(arcs[sat_history_id]);
	int l = curv->size();
	vector < int > savedflags (curobstypes.size(), 0);
	vector < bool > cut1 (l, true);
	for (int i = 0; i< l; i++)
	{
		real tb = curv->at(i).first;
		for (map<int,int>::iterator it = curobstypes.begin();
			 it!=curobstypes.end(); ++it)
		{
			int ot = it->first;
			int idx = it->second;
			if (idx >= curv->at(i).second.size())
				continue;
			int flagvalue = curv->at(i).second[idx].second;
			bool cut = cutObservables(sat_history_id, tb, ot);
			//Накопить флаг с текущего измерения
			savedflags[idx] = Observables::combineSubsequentFlags(
						savedflags[idx],flagvalue);
			//Перенести на текущее измерение запомненные предыдущие флаги
			if (cut==false)
			{
				curv->at(i).second[idx].second = savedflags[idx];
				//Если данное измерение не вырезается, забыть сохранённый флаг
				savedflags[idx] = 0;
			}
			cut1[i] = cut1[i] && cut;
		}
	}
	return cut1;
}

int ObservablesLoader::nextInterval(int sat_history_id, int &i, int &count,
									real &length, vector<bool> &cut)
{
	count = 0;
	real arcbegin = arcs[sat_history_id][i].first;
	real arcend = arcbegin;
	int result = -1;
	int l = arcs[sat_history_id].size();
	while(cut[i]==true)
	{
		i++;
		if (i>=l)
			return -1;
	}
	result = i;
//	i++;
	for (; i<l; i++)
	{
		//Пропускать вырезанные эпохи
		if (cut[i]==true)
			continue;

		//Если дошли до начала следующего интервала (LLI!=0), выйти
		int lli = 0;
		for (map<int,int>::iterator it = curobstypes.begin();
			 it!=curobstypes.end(); ++it)
		{
			int idx = it->second;
			if (obsdetails[idx][3].toInt()==ObservableTypes::MTYPE_L)
				lli |= (arcs[sat_history_id][i].second[idx].second & 65536);
		}
		if ((lli!=0) && (count> 0))
			break;
		count++;

		arcend = arcs[sat_history_id][i].first;
	}
	length = arcend-arcbegin;
	return result;
}

void ObservablesLoader::addObservable(int sat_history_id, int t_idx,
									  int obstype, real value, int flag)
{
	//Добавить тип измерительных данных, если ещё не добавлен
	int obstypepos;
	map<int,int>::iterator it = curobstypes.find(obstype);
	if (curobstypes.find(obstype) == curobstypes.end())
		obstypepos = addObsType(obstype);
	else
		obstypepos = it->second;

	//Добавить измерение
	int s = arcs[sat_history_id][t_idx].second.size();
	if (s<=obstypepos)
	arcs[sat_history_id][t_idx].second.resize(obstypepos+1);
	arcs[sat_history_id][t_idx].second[obstypepos].first = value;
	arcs[sat_history_id][t_idx].second[obstypepos].second = flag;
}


void ObservablesLoader::loadObservablesArc(int sat_history_id, int begin,
										   int end, const vector<bool> &cut)
{
	end = min((unsigned int)end,(unsigned int)(arcs[sat_history_id].size()));
	for (int i = begin; i<end; i++)
	{
		if (cut[i])
			continue;
		real t = arcs[sat_history_id][i].first;
		for (map<int,int>::iterator it = curobstypes.begin();
			 it!=curobstypes.end(); ++it)
		{
			int idx = it->second;
			int ot = it->first;
			real val = arcs[sat_history_id][i].second[idx].first;
			if (isnan(val)) //Измерение не считано
				continue;
			int flag = arcs[sat_history_id][i].second[idx].second;
			loadObservable(sat_history_id,ot,t,val,flag);
		}
	}
}

void ObservablesLoader::preprocessArc(int sat_history_id)
{
	//Выполнить обратный ход детектора разрывов
	backwardDetector(sat_history_id);
	//Выполнить прореживание
	vector < bool > cut1=resampleDown(sat_history_id);
	//Пройти по всем интервалам непрерывности
	int i=0;
	int l = arcs[sat_history_id].size();
	//Цикл по интервалам непрерывности фазы
	while (i<l)
	{
		int tcount;
		real arclen;
		int i1 = nextInterval(sat_history_id,i,tcount,arclen, cut1);
		if (i1==-1)
			break;
		//Проверить, удовлетворяет ли интервал условиям
		bool tooshort = (arclen < minarclen);
		bool toofew = (tcount < minarccount);
		bool tocut= ((tooshort&&(intervalcriterion == 'L'))
			||(toofew&&(intervalcriterion == 'C'))
			||((toofew||tooshort)&&(intervalcriterion == 'B')));
		if (tocut)
			continue;
		//Загрузить интервал
		loadObservablesArc(sat_history_id,i1,i,cut1);
	}
}

void ObservablesLoader::loadObservables (int sat_history_id, real t,
							  const map < int , real > & data,
								const map<int, int> &flags)
{
	//Проверить наличие разрыва
	bool slip;
	bool slip1 = usemw && mel->detectCycleSlip(navsys,sat_history_id,data,t);
	bool slip2 = usemp && mp1->detectCycleSlip(navsys,sat_history_id,data,t);
	bool slip3 = usemp && mp2->detectCycleSlip(navsys,sat_history_id,data,t);
	bool slip4 = usegf && gf->detectCycleSlip(navsys,sat_history_id,data,t);
	slip = slip1 || slip2 || slip3 || slip4;
	//Если детектор обнаружил разрыв (причем ранее измерения уже были)
	int as = arcs[sat_history_id].size();
	if ((slip == true) && (as <= 2) && (as > 0))
	{
		arcs.erase(sat_history_id);
		return;
	}
	if ((slip == true) && (arcs[sat_history_id].size()> 2))
	{
		preprocessArc(sat_history_id);
		arcs.erase(sat_history_id);
	}

	//Если нет разрыва, просто запомнить измерительные данные
	//Сначала проверить наличие всех типов измерительных данных
	for (map<int,real>::const_iterator it = data.begin();
		 it!=data.end(); ++it)
	{
		map<int,int>::iterator it2 = curobstypes.find(it->first);
		if (it2 == curobstypes.end())
		{
			addObsType(it->first);
			obsdetails.push_back(obstypes->read(it->first));
		}
	}
	//Измерительные данные, которых нет, равны nan
	pair<real,vector<pair<real,int> > > newelem (
				t,vector<pair<real,int> >(curobstypes.size(),
					pair<real,int> (numeric_limits<real>::quiet_NaN(),0)));
//	arcs[sat_history_id].push_back(pair<real,vector<pair<real,int> > >
	//Теперь внести измерительные данные и флаги во временный массив
	for (map<int,real>::const_iterator it = data.begin();
		 it!=data.end(); ++it)
	{
		int idx = curobstypes[it->first];
		int cnt = arcs[sat_history_id].size();
		newelem.second[idx].first = it->second;
		newelem.second[idx].second = flags.at(it->first);
		//Первое измерение пометить как начало интервала непрерывности
		if (cnt == 0)
			newelem.second[idx].second |= 65536;
	}
	arcs[sat_history_id].push_back(newelem);

	return;
}

bool ObservablesLoader::cutObservables (int sat_history_id, real t,
							 int obstype)
{
	//С базовом классе все измерения оставлять
	return false;
}

void ObservablesLoader::loadObservable (int sat_history_id, int obstype, real t,
							 real obs, int flag)
{
	destination->insertRow(Tuple()<<obssrcid<<t<<sat_history_id<<obstype,
						   Tuple()<<obs<<flag);
}

void ObservablesLoader::finish()
{
	for (map < int, vector < pair < real, vector < pair<real,int> > > > >
		 ::iterator it = arcs.begin(); it!=arcs.end(); ++it)
		preprocessArc(it->first);
	arcs.clear();
}

void ObservablesLoader::setNewObsSrcID(int new_obs_src_id)
{
	finish();
	obssrcid = new_obs_src_id;
}

NoPreprocessingObservablesLoader::NoPreprocessingObservablesLoader
	(DBTableCollection *tcol, int obs_src_id)
	: ObservablesLoader(tcol,obs_src_id,'C','G',"C1","C2","L1","L2")
	/** @todo При создании NoPreprocessingObservablesLoader может быть ошибка,
	 * если потребуется сразу найти идентификаторы типов измерений
	 */
{
	this->tcol = tcol;
	this->obssrcid = obs_src_id;
	destination = (Observables*)(tcol->getTable("observables"));
}

void NoPreprocessingObservablesLoader::loadObservables(
		int sat_history_id, real t, const map<int, real> &data,
		const map<int, int> &flags)
{
	for (map<int,real>::const_iterator it = data.begin(); it!=data.end(); ++it)
	{
		int obstype = it->first;
		int flag = flags.at(obstype);
		real obsvalue = it->second;
		loadObservable(sat_history_id,obstype,t,obsvalue,flag);
	}
}

}

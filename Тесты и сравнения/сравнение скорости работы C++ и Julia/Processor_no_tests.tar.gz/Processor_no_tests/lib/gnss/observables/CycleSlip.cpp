#include <limits>

#include <CycleSlip.h>
#include <observables.h>
#include <StdTables.h>
#include <Consts.h>
#include <fit.hpp>
#include <basis.h>
#include <Interpolate.hpp>

namespace libgnss
{


Settings::Enumerator gfnumofpoints("Observables","Editor","GFNumOfPoints",
								   Variant::TYPE_INT,
				"Число узлов аппроксимации в фильтре выбросов \"L1-L2\"",
								   2);

Settings::Enumerator gforder("Observables", "Editor", "GFOrder",
									Variant::TYPE_INT,
			"Степень аппроксимирующего полинома в фильтре выбросов \"L1-L2\"",
									1);

Settings::Enumerator gftheshold ("Observables", "Editor",
								 "GFThreshold", Variant::TYPE_DOUBLE,
				"Максимальный допустимый скачек в Geometry-Free-комбинации",
								 (real)(3e-5l));

Settings::Enumerator mwthreshold ("Observables", "Editor",
								  "WBThreshold", Variant::TYPE_DOUBLE,
								  "Коэффициент, определяющий порог определения "
								  "срыва фазы методом Melbourne-Wubbena",
								  (real)(4));

Settings::Enumerator mpthreshold ("Observables", "Editor",
								  "MPThreshold", Variant::TYPE_DOUBLE,
								  "Коэффициент, определяющий порог определения "
								  "срыва фазы методом Multipath-комбинаций",
								  (real)(4));

Settings::Enumerator minterval ("Observables", "Editor",
								 "Interval", Variant::TYPE_DOUBLE,
								 "Длина интервала времени между измерениями, "
								 "означающая срыв фазы, сек.", (real)(60));


CycleSlipDetector::CycleSlipDetector(DBTableCollection * base,
												   string l1, string l2,
												   string p1, string p2)
{
	settings = (Settings * )(base->getTable("settings"));
	gfs = (GLONASSFrequencySlots *)
			(base->getTable("glonass_frequency_slots"));
	history = (SatelliteHistory*)(base->getTable("satellite_history"));
	obstypes = (ObservableTypes *)(base->getTable("observable_types"));
	threshold = settings->getSettings(mwthreshold).toDouble();
	maxinterval = settings->getSettings(minterval).toDouble();
	l1denotement = l1;
	l2denotement = l2;
	p1denotement = p1;
	p2denotement = p2;
}

void CycleSlipDetector::initialize(int sat_history_id,
										  real t, real Bmw, real sigma)
{
	//Запомнить данную дугу
	map < int, ARC_DATA > :: iterator it = cur_arc.find(sat_history_id);
	if (it!=cur_arc.end())
		prev_arc[sat_history_id] = it->second;

	//Начать новую дугу
	ARC_DATA prevepoch;
	prevepoch.t = t;
	prevepoch.t0 = t;
	prevepoch.avg = Bmw;
	prevepoch.rms = sigma;
	prevepoch.k = 1;
	cur_arc[sat_history_id] = prevepoch;
}

bool CycleSlipDetector::detectCycleSlip(char navsys, int sat_history_id,
									const map<int, real> &observables, real t,
										bool knownslip)
{
	if (obsids.find(sat_history_id) == obsids.end())
	{

		obsids[sat_history_id].obsl1 = obstypes->idx_find("system_denotement",
					Tuple()<<navsys<<l1denotement).keyColumnValue(0).toInt();
		obsids[sat_history_id].obsl2 = obstypes->idx_find("system_denotement",
					Tuple()<<navsys<<l2denotement).keyColumnValue(0).toInt();
		obsids[sat_history_id].obsp1 = obstypes->idx_find("system_denotement",
					Tuple()<<navsys<<p1denotement).keyColumnValue(0).toInt();
		obsids[sat_history_id].obsp2 = obstypes->idx_find("system_denotement",
					Tuple()<<navsys<<p2denotement).keyColumnValue(0).toInt();
	}
	ObsIDs ids = obsids[sat_history_id];
	int obsl1 = ids.obsl1, obsl2 = ids.obsl2,
			obsp1 = ids.obsp1, obsp2 = ids.obsp2;
	real l1, l2, p1, p2;
	try
	{
		l1 = observables.at(obsl1);
		l2 = observables.at(obsl2);
		p1 = observables.at(obsp1);
		p2 = observables.at(obsp2);
	}
	catch (...)
	{
		//Если нет необходимых измерительных данных, пропустить эпоху
		return false;
	}

	real f1, f2;
	bool haveinfo = true;
	map<int,pair<real, pair<real,real> > >::iterator f_it =
			frequences.find(sat_history_id);
	if (f_it == frequences.end())
		haveinfo = false;
	else if (f_it->second.first <= t)
		haveinfo = false;
	if (haveinfo == true)
	{
		f1 = f_it->second.second.first;
		f2 = f_it->second.second.second;
	}
	else
	{
		if (navsys == 'R')
		{
			//Частота зависит от литеры
			int slot = history->read(sat_history_id).at(2).toInt();
			real chgt;
			int letter = gfs->getLetter(slot, t, &chgt);
			f1 = obstypes->getFrequency(obsl1, letter);
			f2 = obstypes->getFrequency(obsl2, letter);
			frequences[sat_history_id]=pair<real, pair<real,real> >(
						chgt, pair<real,real>(f1,f2));
		}
		else
		{
			//Частота не зависит от литеры и не меняется
			f1 = obstypes->getFrequency(obsl1, 0);
			f2 = obstypes->getFrequency(obsl2, 0);
			real chgt = numeric_limits<real>::infinity();
			frequences[sat_history_id]=pair<real, pair<real,real> >(
						chgt, pair<real,real>(f1,f2));
		}
	}

	real lambdawl = fabs(lightSpeed/(f1-f2));
	real detect_value = combination(f1,f2,l1,l2,p1,p2);

	//Если уже известно, что здесь стоит разрыв фазы, необходимо заново
	//инициализировать детектор в любом случае
	if (knownslip)
	{
		initialize(sat_history_id, t, detect_value, lambdawl);
		return true;
	}

	//Если этот НКА ещё не встречался, запомнить его и вернуть разрыв фазы
	map < int, ARC_DATA> :: iterator it = cur_arc.find(sat_history_id);
	if (it == cur_arc.end())
	{
		initialize(sat_history_id, t, detect_value, lambdawl);
		return true;
	}

	//Проверить разрыв с последним измерением
	if (fabs(t-it->second.t) > maxinterval)
	{
		initialize(sat_history_id, t, detect_value, lambdawl);
		return true;
	}

	real avg = it->second.avg;
	real rms = it->second.rms;

	//Проверить разрыв с помощью среднего значения
	if (fabs(avg - detect_value) > threshold * rms)
	{
		initialize(sat_history_id, t, detect_value, lambdawl);
		return true;
	}

	//Вычислить новое состояние по рекуррентной формуле
	int k = (++(it->second.k));
	it->second.t = t;
	it->second.avg=((k-1)*avg+detect_value)/k;
	it->second.rms=sqrt(((k-1)*pow(rms,2)+pow(detect_value-avg,2))/k);

	//Разрыва фазы пока нет
	return false;
}

//! Количество точек в последней обработанной дуге для данного НКА
real CycleSlipDetector::previousArcAvg(int sat_history_id) const
{
	map < int, CycleSlipDetector::ARC_DATA > :: const_iterator it =
			prev_arc.find(sat_history_id);
	if(it==prev_arc.end())
		return 0;
	else
		return it->second.k;
}

int CycleSlipDetector::previousArcCount(int sat_history_id) const
{
	map < int, CycleSlipDetector::ARC_DATA > :: const_iterator it =
			prev_arc.find(sat_history_id);
	if(it==prev_arc.end())
		return 0;
	else
		return it->second.avg;
}

pair < real, real > CycleSlipDetector::previousArcInterval
(int sat_history_id) const
{
	pair < real, real > result (0,0);
	map < int, CycleSlipDetector::ARC_DATA > :: const_iterator it =
			prev_arc.find(sat_history_id);
	if(it!=prev_arc.end())
	{
		result.first = it->second.t0;
		result.second = it->second.t;
	}
	return result;
}

MelbourneWubbenaDetector::MelbourneWubbenaDetector(DBTableCollection * base,
						string l1, string l2, string p1, string p2)
	: CycleSlipDetector(base, l1, l2, p1, p2)
{

}

real MelbourneWubbenaDetector::combination(real f1, real f2,
							real l1, real l2, real p1, real p2)
{
	real phasewl = (f1 * l1 - f2 * l2) / (f1 - f2);
	real rangenl = (f1 * p1 + f2 * p2) / (f1 + f2);
	return phasewl - rangenl;
}

MultipathDetector::MultipathDetector(DBTableCollection *base,
						string l1, string l2, string p1, string p2, bool L1)
	: CycleSlipDetector(base, l1,l2,p1,p2)
{
	MP_L1 = L1;
	threshold = settings->getSettings(mpthreshold).toDouble();
}

real MultipathDetector::combination(real f1, real f2, real l1,
									   real l2, real p1, real p2)
{
	if (MP_L1)
		return p1 - l1 - 2 * (f2*f2/(f1*f1-f2*f2)) * (l1-l2);
	else
		return p2 - l2 - 2 * (f1*f1/(f1*f1-f2*f2)) * (l1-l2);
}

GeometryFreeDetector::GeometryFreeDetector(DBTableCollection *base, string l1,
										   string l2)
{
	Settings * sets = (Settings*)(base->getTable("settings"));
	gfthres = sets->getSettings(gftheshold).toDouble();
	maxinterval = sets->getSettings( minterval ).toDouble();
	obstypes = (ObservableTypes *)(base->getTable("observable_types"));
	nverts = sets->getSettings(gfnumofpoints).toInt();
	order = sets->getSettings(gforder).toInt();
	basis = powerBasis(order+1);
	l1denotement = l1;
	l2denotement = l2;
}


bool GeometryFreeDetector::detectCycleSlip(char navsys, int sat_history_id,
										   const map<int, real> &observables,
										   real t)
{
	if (obsids.find(sat_history_id) == obsids.end())
	{

		obsids[sat_history_id].obsl1 = obstypes->idx_find("system_denotement",
					Tuple()<<navsys<<l1denotement).keyColumnValue(0).toInt();
		obsids[sat_history_id].obsl2 = obstypes->idx_find("system_denotement",
					Tuple()<<navsys<<l2denotement).keyColumnValue(0).toInt();
	}
	ObsIDs ids = obsids[sat_history_id];
	int obsl1 = ids.obsl1, obsl2 = ids.obsl2;
	int N = previousData[sat_history_id].first.size();
	bool result = false;

	//Получить измерительные данные
	real l1, l2, val;
	try
	{
		l1 = observables.at(obsl1);
		l2 = observables.at(obsl2);
		val = l1-l2;
	}
	catch (exception e)
	{
		if (N == 0)
			return true;
		real previousT = previousData[sat_history_id].first[N-1];
		if (fabs(t-previousT) > maxinterval)
			return true;
		return false;
	}


	//Если уже можно построить полиномиальную аппроксимацию,
	//то выполнить проверку.
	if (N > 0)
	{
		real previousT = previousData[sat_history_id].first[N-1];
		if (fabs(t-previousT) > maxinterval)
			result = true;

		real curvalue;
		if (N == order + 1)
			curvalue = interpolateLagrange(previousData[sat_history_id].first,
										   previousData[sat_history_id].second,
										   t);
		else
		{
			Fit<PowerOfX,real> window(previousData[sat_history_id].first,
					previousData[sat_history_id].second,(N>order)?basis:
					powerBasis(N));
			curvalue = window(t);
		}
		if (fabs(curvalue - val) > gfthres)
			result = true;
	}

	if (N == 0)
		result = true;

	//Сдвинуть или увеличить окно
	if (N < nverts)
	{
		previousData[sat_history_id].first.push_back(t);
		previousData[sat_history_id].second.push_back(val);
	}
	else
	{
		for(unsigned int i=1; i<N; ++i)
		{
			previousData[sat_history_id].first[i-1] =
					previousData[sat_history_id].first[i];
			previousData[sat_history_id].second[i-1] =
					previousData[sat_history_id].second[i];
		}
		previousData[sat_history_id].first[N-1] = t;
		previousData[sat_history_id].second[N-1] = val;
	}

	return result;

}

}

#ifndef CYCLESLIP_H_
#define CYCLESLIP_H_

/** @file CycleSlip.h
 *
 * @brief Модуль нахождения срывов фазы
 *
 * Данный модуль реализует алгоритм нахождения срывов фазы с помощью нескольких
 * типов линейных комбинаций двухчастотных фазовых и кодовых измерений,
 * например, L1, L2, P1, P2.
 *
 * Пусть \f$l1_{m,n}(t)\f$, \f$l2_{m,n}(t)\f$ - фазовые, а \f$p1_{m,n}(t)\f$,
 * \f$p2_{m,n}(t)\f$ - кодовые измерения на двух частотах \f$f_1\f$, \f$f_2\f$
 * между \f$n\f$-м НКА и \f$m\f$-й БИС. И фазовыые и кодовые измерения считаем
 * выраженными в километрах.
 *
 * Используемые линейные комбинации задаются равенствами:
 *
 * \f[MW_{m,n}(t)=\frac{f_1l1_{m,n}(t)-f_2l2_{m,n}(t)}{f_1-f_2}-
	 \frac{f_1p1_{m,n}(t)+f_2p2_{m,n}(t)}{f_1+f_2},\f]
 *
 * \f[MP1_{m,n}(t)=p1_{m,n}(t)-l1_{m,n}(t)-\frac{2f_2^2}{f_1^2-f_2^2}
	\cdot (l1_{m,n}(t)-l2_{m,n}(t)), \f]
 *
 * \f[MP2_{m,n}(t)=p2_{m,n}(t)-l2_{m,n}(t)-\frac{2f_1^2}{f_1^2-f_2^2}
	\cdot (l1_{m,n}(t)-l2_{m,n}(t)). \f]
 *
 * Алгоритм нахождения разрывов взят из
 *
 * G. Blewitt, AN AUTOMATIC EDITING ALGORITHM FOR GPS DATA // GEOPHYSICAL
 * RESEARCH LETTERS, VOL. 17, NO. 3, PAGES 199-202, MARCH 1990.
 *
 * Для каждой линейной комбинации \f$C_{m,n}(t)\f$ из приведённых выше
 * для последовательных моментов времени \f$t_i,\ i=0,\ldots \f$ рассчитывается
 * последовательность:
 *
 * \f[\langle C^0_{m,n} \rangle = C_{m,n}(t_0), \quad \langle C^i_{m,n}\rangle =
  \langle C^{i-1}_{m,n}\rangle+(C_{m,n}(t_i)-\langle C^{i-1}_{m,n}\rangle)/i,\f]
 *
 * \f[(\sigma^i_{m,n})^2 = (\sigma^{i-1}_{m,n})^2+
 \left((C_{m,n}(t_i)-\langle C^{i-1}_{m,n}\rangle)^2 -
 (\sigma^{i-1}_{m,n})^2\right)\f]
 *
 * Разрыв фазы устанавливается при условии:
 *
 * \f[(C_{m,n}(t_{i+1})-\langle C^{i}_{m,n}\rangle)>\tau\cdot\sigma^{i}_{m,n}.\f]
 */

#include <map>
#include <DBTableCollection.h>
#include <StdTables.h>
#include <observables.h>
#include <basis.h>

namespace libgnss
{

/**
 * @brief Детектор разрывов в измерительных данных по двум частотам
 *
 * @ingroup obsdata
 *
 * Общий алгоритм поиска разрывов можно описать следующим образом:
 * @li На вход подаются измерения фазы и кода на двух частотах
 * @li Вычисляется линейная комбинация \f$l(t_i)\f$, в которой должно быть
 * исключено геометрическое расстояние, уход часов, тропосфера, и т.д., т.е.
 * линейная комбинация, которая на интервалах непрерывности фазы должна
 * оставаться константой, с точностью до шума.
 * @li В ходе работы аппроксимируется среднее значение и СКО значения линейной
 * комбинации на текущем интервале непрерывности фазы.
 * @li Если разность значения линейной комбинации на текущем и на предыдущем
 * шаге выходит далеко за пределы СКО: \f$|l(t_{i+1})-l(t_i)|>n\sigma\f$
 * (величина \f$n\f$ определяется
 * настройками), счетается найденным разрыв фазы. Также разрыв отмечается при
 * большом шаге по времени между последовательными измерениями (шаг определяется
 * настройками).
 */
class CycleSlipDetector
{
protected:

	//! Состояние детектора для одного НКА
	struct ARC_DATA
	{
		//! Число непрерывных измерений
		int k;

		//! Первый момент времени
		real t0;

		//! Последний обработанный момент времени
		real t;

		//! Среднее значение
		real avg;

		//! Средне-квадратическое отклонение
		real rms;
	};

	//! Обозначения используемых измерительных данных
	string l1denotement, l2denotement, p1denotement, p2denotement;

	struct ObsIDs
	{
		int obsl1, obsl2, obsp1, obsp2;
	};

	//! Для каждого НКА - идентификаторы типов измерительных данных
	map < int, ObsIDs > obsids;

	//! Параметр \f$n\f$ в неравенстве \f$|l(t_{i+1})-l(t_i)| > n\cdot \sigma\f$
	real threshold;

	//! Максимальный шаг между последовательными неразрывными измерениями
	real maxinterval;

	GLONASSFrequencySlots * gfs;
	SatelliteHistory * history;
	Settings * settings;
	ObservableTypes * obstypes;

	//! Для каждого номера НКА - данные о текущей обрабатываемой дуге
	map < int, ARC_DATA > cur_arc;

	//! Для каждого номера НКА - данные о предыдущей уже обработанной дуге
	map < int, ARC_DATA > prev_arc;

	//! Инициализировать начало нового интервала непрерывности
	void initialize(int sat_history_id, real t, real Bmw, real sigma);

	//! Для каждого НКА - пара (следующий момент изменения литеры, частоты)
	map<int,pair<real, pair<real,real> > > frequences;
public:

	/** Конструктор детектора разрывов.
	 *
	 * В качестве аргументов принимает указатель на коллекцию таблиц и
	 * обозначения измерений, соответствующие колонке denotement в таблице
	 * observable_types.
	 */
	CycleSlipDetector(DBTableCollection * base, string l1,
							 string l2, string p1, string p2);

	/**
	 * @brief Проверить, не произошел ли срыв фазы
	 * @param sat_history_id Идентификатор НКА
	 * @param observables Набор измерительных данных
	 * @param t Момент времени в шкале приёмника
	 * @param knownslip Флаг наличия уже известного разрыва фазы
	 * @return true, если замечен разрыв фазы; false, если не замечен
	 */
	virtual bool detectCycleSlip (char navsys, int sat_history_id,
					const map < int, real > & observables, real t,
								  bool knownslip=false);

	/**
	 * @brief Вычисление линейной комбинации
	 * @param f1 Первая частота
	 * @param f2 Вторая частота
	 * @param l1 Фаза на первой частоте, км.
	 * @param l2 Фаза на второй частоте, км
	 * @param p1 Псевдодальность на первой частоте, км
	 * @param p2 Псевдодальность на второй частоте, км
	 * @return Значение линейной комбинации
	 */
	virtual real combination (real f1, real f2, real l1,
								 real l2, real p1, real p2) = 0;

	//! Количество точек в последней обработанной дуге для данного НКА
	int previousArcCount(int sat_history_id) const;

	//! Среднее значение комбинации Мельбурна-Вуббена на последней дуге
	real previousArcAvg(int sat_history_id) const;

	//! Интервал времени последней обработанной дуги
	pair < real, real > previousArcInterval (int sat_history_id)
	const;
};

/**
 * @brief Детектор разрывов Мельбурна-Вуббены
 *
 * @ingroup obsdata
 *
 * Ссылка:
 *
 * G. Blewitt. An automatic editing Algorithms for GPS data // Geophysical
 * Research Letters. 1990. Vol. 17. No 3. pp. 199-202.
 *
 * Линейная комбинация вычисляется по формуле: \f$l=wl-nl,\f$
 * где \f$wl\f$ - широкополостная (widelane) линейная комбинация фазы,
 * \f$nl\f$- узкополостная (narrowlane) линейная комбинация псевдодальноти,
 * выражаемые формулами:
 * \f[wl=\frac{f_1 l_1 - f_2 l_2}{f_1-f_2},\qquad
	 nl=\frac{f_1 p_1 + f_2 p_2}{f_1+f_2}
\f]
 * \f[\f]
 */
class MelbourneWubbenaDetector : public CycleSlipDetector
{
public:
	MelbourneWubbenaDetector(DBTableCollection * base, string l1,
							 string l2, string p1, string p2);

	virtual real combination (real f1, real f2, real l1,
								 real l2, real p1, real p2);

};

/**
 * @brief Детектор разрывов на основе многолучевой линейной комбинации
 *
 * @ingroup obsdata
 *
 * Ссылка:
 *
 * L.H. Estey, C.M. Meertens.  TEQC: The Multi-Purpose Toolkit for GPS/GLONASS
 * Data // GPS Sol. 1999. Vol. 3 P. 42–49.
 *
 * Линейные комбинации вычисляются по формулам
 *
 * \f[mp1 = p_1-l_1 - \frac{2 f_2^2 (l_1-l_2)}{f_1^2-f_2^2},\f]
 *
 * \f[mp2 = p_2-l_2 - \frac{2 f_1^2 (l_1-l_2)}{f_1^2-f_2^2}.\f]
 *
 */
class MultipathDetector : public CycleSlipDetector
{
private:
	bool MP_L1;
public:
	MultipathDetector(DBTableCollection * base, string l1,
					  string l2, string p1, string p2, bool L1);

	virtual real combination (real f1, real f2, real l1,
								 real l2, real p1, real p2);
};

/**
 * @brief Детектор разрывов на основе комбинации с исключенной геометрией
 *
 * @ingroup obsdata
 *
 * Линейная комбинация - разность фазы на двух частотах, должна представлять
 * собой достаточно гладкую функцию, поскольку равна линейной по частоте части
 * ионосферной задержки сигнала.
 *
 * Выбросы в этой разности находятся путем аппроксимации предыдущих значений,
 * экстраполяции значения в следующий момент времени и его сравнения с реально
 * полученным значением.
 */
class GeometryFreeDetector
{
private:
	ObservableTypes * obstypes;
	map < int, pair < vector < real >, vector < real > > > previousData;
	real gfthres;
	int order;
	int nverts;
	vector < PowerOfX > basis;
	real maxinterval;
	struct ObsIDs
	{
		int obsl1, obsl2, obsp1, obsp2;
	};
	map < int, ObsIDs > obsids;
	string l1denotement, l2denotement;
public:
	GeometryFreeDetector(DBTableCollection * base,  string l1,
						 string l2);

	virtual bool detectCycleSlip(char navsys,int sat_history_id,
							const map < int, real > & observables, real t);
};

}

#endif

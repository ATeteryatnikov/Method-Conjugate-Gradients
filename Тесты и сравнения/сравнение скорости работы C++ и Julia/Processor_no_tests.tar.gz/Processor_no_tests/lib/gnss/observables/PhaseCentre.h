#ifndef PHASECENTRE_H_
#define PHASECENTRE_H_

#include <StdTables.h>
#include <DBTable.h>
#include <DBTableCollection.h>

//! @file

/**
 * @defgroup phasecentre Модуль вычисления положения фазового центра БИС и НКА
 *
 * @ingroup phasecentre
 *
 * Предполагается, что измеренная псевдодальность между БИС и НКА определяются
 * по следующему принципу.
 *
 * Даны положение центра масс НКА и опорная точка антенны (Antenna Reference
 * Point = ARP). В системе координат, связанной с НКА (X направлена к центру
 * Земли, ось Z перпендикулярна плоскости СОЗ, ось Y такая, что XYZ - правая
 * тройка, причём ось Z смотрит в полупространство, в котором не содержится
 * центр Солнца), дан вектор от центра масс до среднего (по углу возвышения и
 * азимуту) положения фазового центра. Аналогично, в системе координат,
 * связанной с БИС (оси на Север, на Восток и вверх), задан вектор от ARP до
 * среднего (по углу возвышения и азимуту) положения фазового центра (Average
 * Phase Centre = APC).
 *
 * Пусть Геом. дальность - это расстояние между средними положениями фазовых
 * центров БИС и КА. Дополнительно задаётся поправка к положению фазового
 * центра БИС и КА, зависящего от угла места, азимута и частоты. Всё вместе
 * даёт формулу:
 *
 * Псевдодальность = Геом. дальность + ПоправкаБИС + ПоправкаКА + Др. поправки,
 *
 * Поправка БИС и поправка КА задаются как функции от угла места и угла
 * возвышения, а также от частоты, в виде таблицы с постоянным шагом по обоим
 * аргументам.
 * 
 * Для хранения данных о поправке фазового центра вводится понятие модели
 * поправок к фазовому центру. Эта модель может относиться как к одному НКА/БИС,
 * так и к нескольким (как правило, к единственному КА, или ко всем БИС с данной
 * моделью антенны).
 * 
 * 
 * Для вычисления поправок используется следующий алгоритм.
 * 
 * Требуется: 
 * @li observation_source_id (соответствует autoinc в @ref ObservationSource)
 * @li satellite_history_id (соответствует autoinc в @ref SatelliteHistory)
 * @li t - момент времени, секунды TAI от J2000
 * 
 * Алгоритм:
 * @li С помощью @ref SVPhaseCentreModels::getPhaseCentreModelID() найти
 * идентификатор модели поправок к фазовому центру для НКА
 * @li С помощью @ref ReceivingAntennaPhaseCentreModels::getPhaseCentreModelID()
 * найти идентификатор модели поправок к фазовому центру для БИС
 * @li По таблице @ref PhaseCentreOffsetFrequency найти вектор от опорной точки
 * антенны (Antenna Reference Point) до среднего положения фазового центра
 * (Average Phase Centre) антенн БИС и КА. Эти поправки необходимо будет
 * прибавлять к положению БИС/КА для при вычислении псевдодальности
 * @li По таблице @ref PhaseCentreOffsetFrequency найти идентификаторы заданной
 * на сети функции вариации поправки к фазовому центру (grid_id)
 * @li С помощью @ref PhaseCentreVariationGrid::getVariation() найти
 * вариации для БИС и для КА, которые нужно будет прибавить к псевдодальности.
 *
 */

namespace libgnss
{


/** @brief Передающие антенны НКА
 *
 * @ingroup phasecentre
 * 
 * Ключ
 * @li char nav_sys (буква навигационной системы, G=GPS, R=ГЛОНАСС, ...)
 * @li int satellite_id (Номер НКУ/SVN, соответствует satellite_id в 
 * 			@ref SatelliteHistory).
 * 
 * Значение
 * @li int antenna_model_id Идентификатор модели антенны
 */
class SVAntennas : public DBTable
{
private:
	DBTableCollection * Base;
public:
	SVAntennas(DBTableCollection * base);
};

/** @brief Отсутствие информации об антенне на данный момент времени
 *
 * @ingroup except
 * 
 * Если для данного БИС/НКА отсутствует информация о смещении фазового центра
 * антенны, действительная на данный момент времени, будет сгенерировано данное
 * исключение.
 */
class NoValidAntennaRecord : public StrException
{
public:
	
	/** @param model_id Идентификатор модели антенны
	 * @param devicename Имя устройства (НКА/БИС)
	 * @param t Момент времени, секунды TAI (J2000).
	 */
    NoValidAntennaRecord(int model_id, string devicename, real t);
};

class PhaseCentreOffsetFrequency;
class PhaseCentreVariationGrid;

/** @brief Соответствие идентификаторов устройств и модели фазового центра
 *
 * @ingroup phasecentre
 * 
 * Ключ:
 * @li int model_id Модель антенны (соответствует autoinc в @ref AntennaModels)
 * @li int device_id Идентификатор устройства (соответствует autoinc в
 *     @ref SatelliteHistory для НКА и autoinc в @ref ReceivingAntennas для БИС)
 * @li double valid_from Момент времени, с которого действительна информация
 * 
 * Значения:
 * @li int phase_centre_model_id (соответствует phase_centre_model_id в
 *  таблице  @ref PhaseCentreOffsetFrequency)
 * @li double valid_until До какого момента действительна найденная информация
 *
 * Моменты времени valid_from и valid_until - в секундах шкалы TAI от J2000.
 * 
 */
class PhaseCentreModels : public DBTable
{
private:
	PhaseCentreOffsetFrequency * pcof;
	PhaseCentreVariationGrid * pcvar;
protected:
	DBTableCollection * Base;
	virtual int getModelID ( int device_id ) const = 0;
	virtual string getDeviceName ( int device_id ) const = 0;
public:
    PhaseCentreModels( DBTableCollection* base, string tblname );
	
	/** @brief Возвращает идентификатор модели поправки к фазовому центру
	 * 
	 * @param device_id Идентификатор устройства
	 * @param t Момент времени, секунды TAI от J2000
	 * 
	 * device_id - либо autoinc в @ref SatelliteHistory для НКА, либо autoinc в
	 * @ref ReceivingAntennas для БИС
	 * 
	 * Алгоритм:
	 * @li По идентификатору устройства найти model_id - идентификатор модели
	 * антенны.
	 * @li Найти элементы таблицы по идентификатору модели и проверить, есть ли
	 * поля со значением не равным -1.
	 * @li Если -1 - это единственное значение device_id для этой модели
	 * антенн, тогда найти подходящий промежуток времени, в который попадает
	 * момент времени t. Для этого сначала находится строка таблицы по нижней
	 * границе @ref DBTable::lower_bound(), а затем проверяется, что промежуток
	 * не истек, и возвращается индекс модели поправки.
	 * @li Если -1 - не единственное значение, то ищется строка таблицы по
	 * данным device_id и valid_from с помощью @ref DBTable::lower_bound(),
	 * а затем проверяется, что промежуток времени не закончился, и возвращается
	 * идентификатор модели поправки.
	 * 
	 * В случае, если не удаётся найти идентификатор модели антенны, то 
	 * сгенерированное при этом исключение @ref KeyNotFoundException не будет
	 * обработано, и будет возвращено.
	 * 
	 * В случае, если для данных model_id, device_id и момента времени не
	 * будет найдена подходящая запись в данной таблице, то будет возвращено
	 * исключение @ref NoValidAntennaRecord.
	 */
	int getPhaseCentreModelID ( real t, int device_id ) const;
};

class PhaseCentreOffsetFrequency;
class PhaseCentreVariationGrid;

/** @brief Соответствие номеров КА моделей поправки к фазовому центру
 *
 * @ingroup phasecentre
 */
class SVPhaseCentreModels : public PhaseCentreModels
{
private:
	SatelliteHistory * history;
	SVAntennas * svants;
	PhaseCentreOffsetFrequency * pcofreq;
	PhaseCentreVariationGrid * pcvg;
protected:
	virtual int getModelID ( int device_id ) const;
	virtual string getDeviceName ( int device_id) const;
public:
    SVPhaseCentreModels(DBTableCollection * base);
};

/** @brief Соответствие модели приёмной антенны и поправок к фазовому центру
 *
 * @ingroup phasecentre
 */
class ReceivingAntennaPhaseCentreModels : public PhaseCentreModels
{
private:
	ReceivingAntennas * rants;
protected:
	virtual int getModelID ( int device_id  )const;
	virtual string getDeviceName ( int device_id  )const;
public:
	ReceivingAntennaPhaseCentreModels(DBTableCollection * base);
};

/**
 * @brief Данные о сдвиге фазового центра антенны для одной частоты
 *
 * @ingroup phasecentre
 *
 * Название таблицы: phase_centre_offset_frequency
 * 
 * Ключ:
 *
 * @li int phase_centre_model_id - номер модели фазового центра
 * @li int frequency - номер частоты (см. частоты в @ref ObservableTypes)
 *
 * Значения:
 * @li double dnorth, double deast, double dheight - сдвиг APC относительно ARP,
 *  км.
 * @li int grid_id - идентификатор сетки из таблицы @PhaseCentreVariationGrid
 *
 * grid_id = -1 соответствует отсутствию сетки - поправка будет нулевой.
 *
 */
class PhaseCentreOffsetFrequency : public DBTable
{
public:
	PhaseCentreOffsetFrequency(DBTableCollection * base);
};

/**
 * @brief Сетки поправок к расстоянию до фазового центра антенны
 *
 * @ingroup phasecentre
 *
 * Ключ:
 * @li int grid_id - идентификатор сетки
 * @li double azimuth - значения по азимуту, от 0 до 2Pi, радианы
 * @li double zenith - значения зенитного угла, радианы
 *
 * Значение:
 * @li double offset - поправка в км.
 *
 * Отрицательное значение азимута означает, что сетка не зависит от азимута.
 * Поправка прибавляется к псевдодальности:
 * 
 * Измеренная псевдодальность = "Псевдодальность" между средними положениями
 * фазовых центров + offset
 *
 * grid_id = -1 соответствует отсутствию сетки - поправка будет нулевой.
 *
 */
class PhaseCentreVariationGrid : public DBTable
{
public:
	PhaseCentreVariationGrid ( DBTableCollection * base );

	
	/**
	 * @brief Вычислить зависящую от направления поправку на фазовый центр
	 *
	 * @param grid_id Идентификатор сетки
	 * @param azimuth Угол азимута, рад.
	 * @param zenith Зенитный угол, рад.
	 * @return Поправка к псевдодальности
	 * 
	 * Вычисляет поправку к псевдодальности из-за вариаций положения фазового
	 * центра, в зависимости от направления, заданного зенитным углом и углом
	 * азимута.
	 * 
	 * Используется линейная интерполяция, когда поправка не зависит от азимута,
	 * и билинейная, когда зависит.
	 **/
	real getVariation(int grid_id, real azimuth, real zenith);
};

/**
 * @brief Пересчитывает поправки фазового центра для двухчастотных измерений
 * @param base Коллекция таблиц
 *
 * Для всех антенн, для которых есть для двух частот поправки среднего фазового
 * центра и поправки к псевдодальности за счет вариации фазового центра,
 * вычисляет эти же поправки для комбинации измерений с исключенной по двум
 * частотам ионосферой.
 *
 * Поправка среднего положения фазового центра \f$\Delta APC_{LC}\f$ для
 * ионосферно-свободной комбинации дальностей на частотах \f$f_1\f$ и \f$f_2\f$
 * вычисляется по формуле:
 * \f[ \Delta APC_{LC}=\frac{f_1^2 \Delta APC_{L1}-
   f_2^2 \Delta APC_{L2}}{f_1^2-f_2^2}.\f]
 *
 * По аналогичной формуле расчитывается поправка к псевдодальности.
 *
 * Работает только для GPS G01, G02, G05 и для ГЛОНАСС R01, R02.
 *
 */
void ionFreePhaseCentre(DBTableCollection * base);

}

#endif

#include <set>

using namespace std;

#include <PhaseCentre.h>
#include <StdTables.h>
#include <observables.h>
#include <BuiltIn.h>

//! @file

namespace libgnss
{

SVAntennas::SVAntennas(DBTableCollection* base)
	: DBTable(Columns()<<Column(Variant::TYPE_CHAR, "nav_sys")
	<<Column(Variant::TYPE_INT, "satellite_id"),
			  Columns()<<Column(Variant::TYPE_INT, "antenna_model_id"))
{
	Base = base;
	base->addTable("sv_antennas",this);
}

NoValidAntennaRecord::NoValidAntennaRecord(int model_id, string devicename,
	real t): StrException("NoValidAntennaRecord",
								"Нет действительной информации о смещении "
		"фазового центра антенны id="
		+Variant(model_id).toString()+
		" для устройства "
		+devicename+" в момент времени "
		+ UTCDateTime::fromTAIJ2000(t).getUTCDateTimeString()
	)
{

}

PhaseCentreModels::PhaseCentreModels(DBTableCollection* base, string tblname)
: DBTable(Columns()
	<<Column(Variant::TYPE_INT, "model_id")
	<<Column(Variant::TYPE_INT, "device_id")
	<<Column(Variant::TYPE_DOUBLE, "valid_from"),
		  Columns()
		  <<Column(Variant::TYPE_INT, "phase_centre_model_id")
		  <<Column(Variant::TYPE_DOUBLE, "valid_until"))
{
	Base = base;
	base->addTable(tblname, this);
	pcof = 0;
	pcvar = 0;
}

int PhaseCentreModels::getPhaseCentreModelID(real t, int device_id) const
{
	// По идентификатору устройства найти идентификатор модели антенны.
	int model_id = getModelID(device_id);
	
	//Сразу попробовать найти элемент с помощью lower_bound
	DBTable::DBConstIterator it0 = lower_bound(Tuple()<<model_id<<device_id<<t);
	
	//Если элемент нашелся, значит разные устройства данной модели имеют разные
	//поправки к фазовому центру. Проверить, что промежуток времени 
	//действительный (то есть t <= valid_until) и вернуть идентификатор.
	if (it0!=const_end())
	{
		if (it0[1].toDouble() >= t)
			return it0[0].toInt();
	}
	else
	{
			//Если элемент не нашелся, то попробовать поискать device_id = -1
		DBTable::DBConstIterator it1 = lower_bound(Tuple()<<model_id<<-1<<t);
	
		//Если элемент нашелся, это означает, что все антенны данной модели
		//имеют одинаковые поправки к фазовому центру. Проверить, что 
		//t<=valid_until и вернуть найденный идентификатор
		if (it1!=const_end())
			if (it1[1].toDouble() >= t)
				return it1[0].toInt();

	}
	
	//Если ни один из вариантов не подошел, вернуть ошибку: для данного
	//устройства нет информации о фазовом центре антенны.
	throw NoValidAntennaRecord(model_id, getDeviceName(device_id),t);
	
}

SVPhaseCentreModels::SVPhaseCentreModels (DBTableCollection * base)
	: PhaseCentreModels(base,"sv_phase_centre_models")
{
	history=(SatelliteHistory *)(base->getTable("satellite_history"));
	svants=(SVAntennas*)(base->getTable("sv_antennas"));
}

string SVPhaseCentreModels::getDeviceName(int device_id) const
{
	DBTable::DBConstIterator It = history->find(Tuple()<<device_id);
	return "НКА "+It[0].toString()+It[1].toString();
}

int SVPhaseCentreModels::getModelID(int device_id) const
{
	DBTable::DBConstIterator It0 = history->find(Tuple()<<device_id);
	DBTable::DBConstIterator It1 = svants->find(Tuple()<<It0[0].toChar()
												<<It0[1].toInt());
	return It1[0].toInt();
}

ReceivingAntennaPhaseCentreModels::ReceivingAntennaPhaseCentreModels
(DBTableCollection * base) : PhaseCentreModels (base, 
				"receiving_antenna_phase_centre_models")
{
	rants=(ReceivingAntennas*)(base->getTable("receiving_antennas"));
}

string ReceivingAntennaPhaseCentreModels::getDeviceName(int device_id) const
{
	return "Антенна на БИС " 
			+ (*rants)[Tuple()<<device_id][0].toString();
}

int ReceivingAntennaPhaseCentreModels::getModelID(int device_id) const
{
	return (*rants)[Tuple()<<device_id][2].toInt();
}

PhaseCentreVariationGrid::PhaseCentreVariationGrid(DBTableCollection *base)
	: DBTable (Columns()
					  <<Column(Variant::TYPE_INT, "grid_id")
					 <<Column(Variant::TYPE_DOUBLE, "azimuth")
					<<Column(Variant::TYPE_DOUBLE, "zenith"),
					  Columns()<<Column(Variant::TYPE_DOUBLE, "offset"))
{
	base->addTable("phase_centre_variation_grid", this);
}

PhaseCentreOffsetFrequency::PhaseCentreOffsetFrequency(DBTableCollection *base)
	: DBTable (Columns()
			   <<Column(Variant::TYPE_INT, "phase_centre_model_id")
			  <<Column(Variant::TYPE_INT, "frequency"),
			   Columns()
			   <<Column(Variant::TYPE_DOUBLE, "dnorth")
			  <<Column(Variant::TYPE_DOUBLE, "deast")
			 <<Column(Variant::TYPE_DOUBLE, "dheight")
			<<Column(Variant::TYPE_INT, "grid_id"))
{
	base->addTable("phase_centre_offset_frequency", this);
}

real PhaseCentreVariationGrid::getVariation(int grid_id, real azimuth,
											   real zenith)
{
	if (grid_id == -1)
		return 0.0l;

	//Найти ближайшее снизу значение азимута
	DBTable::DBConstIterator it = lower_bound(Tuple()<<grid_id<<azimuth);
	real az1 = it.keyColumnValue(1).toDouble();

	//Найти при ближайшем меньшем значении азимута найти ближайшее меньшее
	//значение зенита
	DBTable::DBConstIterator it1 = lower_bound(Tuple()<<grid_id<<az1<<zenith);
	
	//Если оно равно -1, то поправка не зависит от азимута
	if ((az1 < 0)||(az1 == azimuth))
	{
		//Найти ближайшее снизу значение зенитного угол
		real zen1 = it1.keyColumnValue(2).toDouble();
		real var1 = it1[0].toDouble();
		if (zen1 == zenith)
			return var1;
		
		//++it1;
		it1.subinc(2,1);
		if (it1==const_end())
			return var1;
		real zen2 = it1.keyColumnValue(2).toDouble();
		real var2 = it1[0].toDouble();
		
		//Линейная интерполяция по зениту
		return ((zenith - zen1) * var2 + (zen2 - zenith) * var1) / (zen2-zen1);
	}
	
	real var1; //Левое по азимуту интерполированное по зениту значение
	real var2; //Правое по азимуту интерполированное по зениту значение
	
	//Значение [az1; zen1]
	real zen1 = it1.keyColumnValue(2).toDouble();
	real var11 = it1[0].toDouble();
	if (zen1==zenith)
		var1 = var11;
	else
	{
	
		//Значение [az1; zen2]
		DBTable::DBConstIterator it2 = it1;
		it2.subinc(2,1);
		if (it2==const_end())
			var1 = var11;
		else
		{
			real zen2 = it2.keyColumnValue(2).toDouble();
			real var12 = it2[0].toDouble();

			//Линейная интерполяция по зениту
			var1 = ((zenith-zen1)*var12+(zen2-zenith)*var11)/(zen2-zen1);
		}

	}
	
	it1.subinc(1,0);
	if (it1==const_end())
		return var1;
	real az2 = it1.keyColumnValue(1).toDouble();
	DBTable::DBConstIterator it2 = lower_bound(Tuple()<<grid_id<<az2<<zenith);
	
	//Значение [az2; zen1]
	zen1 = it2.keyColumnValue(2).toDouble();
	real var21 = it2[0].toDouble();
	
	//Значение [az2; zen2]
	it2.subinc(2,1);
	if (it2==const_end())
		var2 = var21;
	else
	{
		real zen2 = it2.keyColumnValue(2).toDouble();
		real var22 = it2[0].toDouble();
		
		//Линейная интерполяция по зениту
		var2 = ((zenith-zen1)*var22+(zen2-zenith)*var21)/(zen2-zen1);
	}
		
	//Теперь интерполяция по азимуту
	return ((azimuth - az1) * var2 + (az2 - azimuth) * var1) / (az2-az1);
}

/**
 * @brief Пересчитать поправки ФЦ для заданной антенны и заданных частот
 * @param pcof Таблица сдвигов в зависимости от частоты
 * @param pcgrid Таблица поправок в зависимости от направления
 * @param phase_centre_model_id Идентификатор данных для модели ФЦ
 * @param navsys Буква навигационной системы
 * @param freqn1 Имеющаяся частота 1
 * @param freqn2 Имеющаяся частота 2
 * @param freqn3 Номер "фиктивной частоты"
 */
void ionFreePhaseCentreSub(PhaseCentreOffsetFrequency * pcof,
						   PhaseCentreVariationGrid * pcgrid,
						   int phase_centre_model_id,
						   char navsys, int freqn1, int freqn2, int freqn3)
{
	//Найти частоты и коэффициенты комбинации
	real freq1 = ObservableTypes::getFrequencyForAntex(freqn1);
	real freq2 = ObservableTypes::getFrequencyForAntex(freqn2);
	real alpha1 = freq1*freq1/(freq1*freq1 - freq2*freq2);
	real alpha2 = freq2*freq2/(freq1*freq1 - freq2*freq2);

	//Извлечь данные для двух частот
	Tuple delta1 = pcof->read(Tuple()<<phase_centre_model_id<<freqn1);
	Tuple delta2 = pcof->read(Tuple()<<phase_centre_model_id<<freqn2);
	Tuple delta3 = delta1;

	//Вычислить новый сдвиг среднего фазового центра
	delta3[0] = alpha1*delta1[0].toDouble() - alpha2*delta2[0].toDouble();
	delta3[1] = alpha1*delta1[1].toDouble() - alpha2*delta2[1].toDouble();
	delta3[2] = alpha1*delta1[2].toDouble() - alpha2*delta2[2].toDouble();

	//Либо записать grid_id = -1, если сетки поправок нет
	if ((delta1[3].toInt() == -1) || (delta2[3].toInt() == -1))
		delta3[3] = -1;
	//Либо создать новую сетку поправок
	else
	{
		//Найти свободный номер нового grid_id
		DBTable::DBConstIterator it1 = pcgrid->const_end();
		--it1;
		delta3[3] = it1.keyColumnValue(0).toInt() + 1;

		//Пройти по сетке для первой частоты
		for (DBTable::DBConstIterator it2 = pcgrid->find(delta1[3]);
			 it2!=pcgrid->const_end(); it2.subinc(2,0))
		{
			//Найти азимут, зенит и поправку на первой частоте
			real azimuth = it2.keyColumnValue(1).toDouble();
			real zenith = it2.keyColumnValue(2).toDouble();
			real offset1 = it2[0].toDouble();

			//Найти соответствующую поправку на второй частоте
			real offset2 = pcgrid->getVariation(delta2[3].toInt(),
					azimuth,zenith);

			//Найти ионосферно-свободную комбинацию
			real offset3 = alpha1*offset1 - alpha2*offset2;

			try
			{
				//Записать поправку
				pcgrid->insertRow(Tuple()<<delta3[3]<<azimuth<<zenith,
													Tuple()<<offset3);
			}
			catch (const DuplicateKeyException & e)
			{

			}
		}
	}

	try
	{
		//Записать сдвиг фазового центра для ионосферно-свободной комбинации
		pcof->insertRow(Tuple()<<phase_centre_model_id<<freqn3,
						delta3);
	}
	catch (const DuplicateKeyException & e)
	{

	}
}

void ionFreePhaseCentre(DBTableCollection * base)
{
	PhaseCentreOffsetFrequency * pcof = (PhaseCentreOffsetFrequency*)
			(base->getTable("phase_centre_offset_frequency"));
	PhaseCentreVariationGrid * pcgrid = (PhaseCentreVariationGrid*)
			(base->getTable("phase_centre_variation_grid"));

	//Пройти по всем моделям антенн
	for (DBTable::DBConstIterator it = pcof->const_begin();
		 it!=pcof->const_end(); it.inc(0))
	{
		int phase_centre_model_id = it.keyColumnValue(0).toInt();

		//Пройти по всем возможным частотам и проверить все возможные
		//комбинации исключения ионосферы
		for (DBTable::DBConstIterator it1 = it; it1!=pcof->const_end();
			 it1.subinc(1,0))
		{
			int freqn = it1.keyColumnValue(1).toInt();
			//Для каждой частоты проверять наличие меньших номеров частот
			//для исключения ионосферы
			if (freqn == ObservableTypes::getFrequencyFromAntex("G02"))
			{
				//Проверить G12
				DBTable::DBConstIterator it2 = pcof->find(
							Tuple()<<phase_centre_model_id
							<<ObservableTypes::getFrequencyFromAntex("G01"));
				if (it2 != pcof->const_end())
					ionFreePhaseCentreSub(pcof,pcgrid,phase_centre_model_id,
									'G',freqn,it2.keyColumnValue(1).toInt(),
								ObservableTypes::getFrequencyFromAntex("G12"));
			}
			if (freqn == ObservableTypes::getFrequencyFromAntex("G05"))
			{
				//Проверить G15
				DBTable::DBConstIterator it2 = pcof->find(
							Tuple()<<phase_centre_model_id
							<<ObservableTypes::getFrequencyFromAntex("G01"));
				if (it2 != pcof->const_end())
					ionFreePhaseCentreSub(pcof,pcgrid,phase_centre_model_id,
									'G',freqn,it2.keyColumnValue(1).toInt(),
								ObservableTypes::getFrequencyFromAntex("G15"));

				//Проверить G25
				it2 = pcof->find(
							Tuple()<<phase_centre_model_id
							<<ObservableTypes::getFrequencyFromAntex("G02"));
				if (it2 != pcof->const_end())
					ionFreePhaseCentreSub(pcof,pcgrid,phase_centre_model_id,
									'G',freqn,it2.keyColumnValue(1).toInt(),
								ObservableTypes::getFrequencyFromAntex("G25"));
			}
			if (freqn == ObservableTypes::getFrequencyFromAntex("R02"))
			{
				//Проверить G12
				DBTable::DBConstIterator it2 = pcof->find(
							Tuple()<<phase_centre_model_id
							<<ObservableTypes::getFrequencyFromAntex("R01"));
				if (it2 != pcof->const_end())
					ionFreePhaseCentreSub(pcof,pcgrid,phase_centre_model_id,
									'R',freqn,it2.keyColumnValue(1).toInt(),
								ObservableTypes::getFrequencyFromAntex("R12"));
			}

			//Если были добавлены новые данные, итераторы перестали быть
			//действительными.
			it = pcof->find(phase_centre_model_id);
			it1 = pcof->find(Tuple()<<phase_centre_model_id<<freqn);
		}
	}

}

#ifdef WithQT
QScriptValue genIonFreePhaseCentre(QScriptContext * ctx,
								   QScriptEngine * eng)
{
	try
	{
		DBTableCollection * tc = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		ionFreePhaseCentre(tc);
		return QScriptValue();
	}
	catch(StrException & e)
	{
		returnError(eng, string("Не удалось сгенерировать поправки смещения "
								"фазового центра антенн: ")+e.what());
	}
}

BuiltIn genionfree("generateIonFreePhaseCentres", 1, genIonFreePhaseCentre);
#endif
}

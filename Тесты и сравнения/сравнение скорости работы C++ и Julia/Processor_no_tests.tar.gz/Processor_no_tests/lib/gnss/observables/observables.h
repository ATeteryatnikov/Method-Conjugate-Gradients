#ifndef OBSERVABLES_H_
#define OBSERVABLES_H_

//! @file

#include <string>
#include <map>
#include <gnssconfig.h>
#ifdef WithQT
#include <QString>
#include <QStringList>
#endif

#include <StdTables.h>
#include <DBTable.h>
#include <Frames.h>

namespace libgnss
{

/**
 * @brief Ошибка: не удалось определить параметры маркера
 *
 * БИС складывается из маркера, приёмника и антенны. В файлах данных, как
 * правило, измерительные данные и другая информация относится к маркеру.
 * Данное исключение возникает, когда по имени маркера невозможно однозначно
 * определить, к какой антенне и с каким приёмником он был установлен.
 *
 * @ingroup except
 */
class AmbigousObservationSource : public StrException
{
public:
	AmbigousObservationSource (const string & markername,
		const string & antenna1, const string & antenna2,
		const string & receiver1, const string & receiver2);
};

/**
 * @brief Список БИС
 *
 * @ingroup obsdata
 *
 * БИСом будем называть совокупность работающих вместе приёмника и антенны,
 * установленных на некотором маркере. Таким образом, БИС задаётся тройкой
 * Маркер, Приёмник, Антенна.
 *
 * Ключ - автоматически инкременируемое поле int autoinc
 *
 * Значения:
 * @li int marker_id - идентификатор маркера (autoinc в Markers)
 * @li int receiver_id - идентификатор приёмника (autoinc в Receivers)
 * @li int antenna_id - идентификатор антенны (autoinc в ReceivingAntennas)
 *
 * Для обратного поиска введён дополнительный индекс "3id" с полями
 * "marker_id", "receiver_id", "antenna_id".
 *
 * Название таблицы: observation_source
 */
class ObservationSource : public NumeratedTable
{
private:
	DBTableCollection * Base;
	Receivers * rec;
	Markers * mrk;
	ReceivingAntennas * ants;

	void updateTables();
public:

	ObservationSource (DBTableCollection * base);

	typedef std::map<std::string,kinematic<real,3,otherCoordSys> >PhaseBiasFreq;

	/**
	 * @brief Возвращает идентификатор на новый источник измерительных данных
	 *
	 * Для добавления источника измерительных данных можно указать только часть
	 * информации, но её должно быть достаточно, чтобы идентифицировать маркер,
	 * приёмник и антенну. При необходимости, маркер, приёмник и антенна могут
	 * быть добавлены в соответствующие таблицы, а затем использованы их
	 * идентификаторы.
	 *
	 * Чтобы не указывать строковый аргумент, нужно оставить его пустым.
	 * Чтобы не указывать координаты, нужно каждой координате присвоить nan.
	 * Чтобы не указывать целое значение, нужно указать вместо него -1.
	 *
	 * @param marker_name Имя маркера (обязательно)
	 * @param marker_number Номер маркера
	 * @param marker_desc Описание маркера
	 * @param marker_type Тип маркера (см. таблицу Markers)
	 * @param pos Положение маркера в декартовой системе координат
	 * @param pos_g Геодезические координаты маркера
	 * @param receiver_sn Серийный номер приёмника (обязательно)
	 * @param receiver_desc Описание приёмника
	 * @param receiver_model Модель приёмника
	 * @param antenna_sn Серийный номер антенны (обязательно)
	 * @param antenna_model Модель антенны
	 * @param desc Описание антенны
	 * @param phase_shifts Для каждой частоты - смещение системы координат
	 * @return Идентификатор существующего, или вновь созданного БИС.
	 *
	 * Если маркер не найден, он будет добавлен. При этом, если не указан номер
	 * маркера, он будет совпадать с именем маркера; описание будет заполнено
	 * строкой "Описание отсутствует"; если не указаны геодезические, но
	 * указаны декартовы координаты, геодезические будут вычислены, и наоборот.
	 * Если никакие координаты не указаны, будут указаны нулевые координаты.
	 *
	 * Если приёмник не найден, он будет добавлен. Если отсутствует модель, она
	 * будет совпадать с именем приёмника; описание: "Описание отсутствует".
	 *
	 * Если антенна отсутствует, она будет добавлена. Если не указана модель,
	 * она будет совпадать с серийным номером; описание, если его нет, станет
	 * "Описание отсутствует". Также будет добавлено описание фазового центра
	 * антенны в таблицу PhaseCentreOffsetFrequency. Сдвиги фазового центра
	 * указываются в местной системе координат с координатами: смещение на
	 * север, смещение на восток, смещение по высоте (всё в км).
	 *
	 * MarkerEccentricity не будет заполнено, поскольку оно не зависит от
	 * частот, и можно считать, что ARP совпадает с положением маркера.
	 */
	int addObservationSource(
			const std::string & marker_name,
			const std::string & receiver_sn,
			const std::string & antenna_sn,
			const std::string & marker_number="",
			const std::string & receiver_model="",
			const std::string & antenna_model="",
			const std::string & marker_desc="",
			const std::string & receiver_desc="",
			const std::string & antenna_desc="",
			int marker_type=-1,
			PosNonInert pos = PosNonInert(numeric_limits<real>::quiet_NaN()),
			PosGeodetic pos_g = PosGeodetic (numeric_limits<real>::quiet_NaN()),
			const PhaseBiasFreq & phase_shifts = PhaseBiasFreq(),
			real ant_valid_from = numeric_limits<real>::quiet_NaN(),
			real ant_valid_until = numeric_limits<real>::quiet_NaN());

	/**
	 * @brief Получить идентификатор БИС
	 * @param marker_id Идентификатор маркера
	 * @param antenna_id Идентификатор антенны
	 * @param receiver_id Идентификатор приёмника
	 * @return Идентификатор БИС, или -1, если БИС не найден
	 */
	int getSourceID (int marker_id, int antenna_id, int receiver_id) const;

	/**
	 * @brief Получить идентификатор источника измерительных данных
	 * @param marker_name Имя маркера
	 * @param antenna_sn Серийный номер антенны
	 * @param receiver_sn Серийный номер приёмника
	 * @return Идентификатор источника с данными маркером, антенной и приёмником
	 */
	int getSourceID(const string & marker_name, const string & antenna_sn,
					const string & receiver_sn) const;

	/**
	 * @brief Возвращает идентификатор источника измерительных данных
	 * @param marker_name Имя маркера
	 *
	 * Если маркер с данным именем используется только в одной БИС (в том числе,
	 * на БИС не менялись приёмник и антенна - в последнем случае БИСу
	 * присваивается новый идентификатор), то данный метод возвращает
	 * идентификатор БИС.
	 *
	 * Если идентификаторы БИС с данным маркером менялись (например, менялись
	 * часы, приёмник, антенна), то будет сгенерировано исключение.
	 *
	 * @return  Идентификатор источника с данным маркером
	 */
	int getSourceID(const string & marker_name);
};

/** @brief Справочник типов измерительных данных
 *
 * @ingroup obsdata
 * 
 * Справочник служит для сопоставления измерительных данных с их обозначениями.
 * 
 * Ключ:
 * @li int autoinc - автоматически инкременируемый идентификатор типов, ключ
 *
 * Данные:
 * @li string denotement - обозначение в файлах
 * @li char system_letter - буква, обозначающая навигационную систему
 * @li int frequency - номер частоты
 * @li int type - тип измерений
 * @li char attribute - дополнительный аттрибут измерений
 * @li string description - текстовое описание измерений
 * 
 * Заметим, что типы измерений, обозначаемые L1 в RINEX, для GPS и ГЛОНАСС
 * должны соответствовать разным строкам в таблице.
 * 
 * Для нахождения идентификатора типа по букве навигационной системы и 
 * RINEX-обозначению измерения используется индекс "system_denotement" с 
 * полями
 * @li system_letter
 * @li denotement
 *
 * Также введён индекс 	"system_freq_type_attr" по полям
 * @li system_letter
 * @li frequency
 * @li type
 * @li attribute
 *
 * Типы измерений:
 * @li MTYPE_C - Кодовая псевдодальность, км
 * @li MTYPE_L - Фаза, км
 * @li MTYPE_D - Допплеровский сдвиг, км/с.
 * @li MTYPE_S - Мощность сигнала, Дб
 * @li MTYPE_I - Ионосферная поправка к фазе
 * @li MTYPE_X - Число каналов приёмника
 * 
 * Частоты:
 * @li 0-'G01' - L1 GPS
 * @li 1-'G02' - L2 GPS
 * @li 2-'G05' - L5 GPS
 * @li 3-'R01' - L1 ГЛОНАСС
 * @li 4-'R02' - L2 ГЛОНАСС
 * @li 5-'E01' - E1 Galileo         
 * @li 6-'E05' - E5a Galileo         
 * @li 7-'E07' - E5b Galileo        
 * @li 8-'E08' - E5 (E5a+E5b) Galileo
 * @li 9-'E06' - E6 Galileo         
 * @li 10-'C01' - E1 Compass         
 * @li 11-'C02' - E2 Compass         
 * @li 12-'C07' - E5b Compass
 * @li 13-'C06' - E6 Compass
 * @li 14-'J01' - L1 QZSS
 * @li 15-'J02' - L2 QZSS
 * @li 16-'J05' - L5 QZSS
 * @li 17-'J06' - LEX QZSS
 * @li 18-'S01' - L1 SBAS
 * @li 19-'S05' - L5 SBAS
 * @li 20 'G12' - L1-L2 GPS (исключение ионосферы по частотам L1 и L2)
 * @li 21 'G15' - L1-L5 GPS (исключение ионосферы по частотам L1 и L5)
 * @li 22 'G25' - L2-L5 GPS (исключение ионосферы по частотам L2 и L5)
 * @li 23 'R12' - L1-L2 ГЛОНАСС (исключение ионосферы по частотам L1 и L2)
 * @li 24 'G125' - L1-L2-L5 GPS (исключения ионосферы по частотам L1, L2, L5)
 * 
 * Атрибуты измерений:
 * 
 * @li P - измерения высокой точности (санкционированного доступа)
 * @li С - измерения обычной точности (открытого доступа)
 * @li Y - зашифрованный код
 * @li M - автономный код высокой точности (не требует приёма С-кода)
 * @li N - сигнал без дальномерного кода
 * @li Каналы: A, B, C, I, Q, S, L
 * @li X - каналы A+B (GALILEO), I+Q(GPS, GALILEO), M+L(GPS)
 * @li W - каналы A+B+C
 */
class ObservableTypes : public NumeratedTable
{

public:
	enum SignalType
	{
		
		//! Тип измерений: кодовая дальность
		MTYPE_C = 1,
		 
		//! Тип измерений: Доплер
		MTYPE_D = 2,
		
		//! Тип измерений: фаза
		MTYPE_L = 3,
		
		//! Тип измерений: мощность сигнала
		MTYPE_S = 4,
		
		//! Тип измерений: ионосферная задержка
		MTYPE_I = 5,
		
		//! Тип измерений: число каналов
		MTYPE_X = 6
	};
	
	ObservableTypes(DBTableCollection * base);

	/**
	 * @brief Возвращает строковое обозначение частоты по его идентификатору
	 * @param freq_id Идентификатор частоты
	 * @return Строковое обозначение заданной частоты
	 */
	static string getFrequencyDenotement(int freq_id);
	
	/**
	 * @brief Возвращает номер частоты по его ANTEX-обозначению
	 * @param antexfreq ANTEX-обозначение частоты
	 * @return Номер частоты, используемый в таблице типов измерений
	 *
	 * Если обозначение antexfreq неизвестно, будет возвращена -1.
	 */
	static int getFrequencyFromAntex(const string & antexfreq);

	/**
	 * @brief Вернуть соответствующее измерение на другой частоте L1/L2
	 * @param obs_type Тип измерения на частоте L1 или L2
	 * @return Тот же тип измерения, что и obs_type, только на другой частоте
	 *
	 * Под типом измерений понимается значение ключевого поля - идентификатора
	 * данного измерения в таблице.
	 *
	 * Если измерение переданного типа ведётся на частоте L1, то будет
	 * возвращено соответствующее ему измерение (тот же тип @ref SignalType,
	 * с тем же аттрибутом) на частоте L2, и наоборот.
	 *
	 * Используется для используется при исключении ионосферной задержки и
	 * других похожих процедурах.
	 *
	 * Если тип измерений obs_type не найден в таблице типов измерений, будет
	 * сгенерировано исключение @ref KeyNotFoundException. Если тип измерений
	 * obs_type найден, но соответствующего ему типа на другой частоте нет,
	 * будет возвращено значение -1.
	 */
	int getCorrespondentL1L2 (int obs_type) const;

	/**
	 * @brief Возвращает частоту данного НКА в данный момент времени
	 * @param obstype Тип измерительных данных
	 * @param letter Частотный слот (для ГЛОНАСС)
	 * @return Частота, Гц.
	 *
	 * Если данный тип измерений относится к системе ГЛОНАСС на частотах L1 или
	 * L2, то номер частотного слота используются для нахождения частоты;
	 * все остальные системы и система ГЛОНАСС на новых частотах используют
	 * кодовое разделение сигнала, и номер слота не используется.
	 *
	 * Если измерение данного типа не присутствует в таблице,
	 * то будет сгенерировано исключение @ref KeyNotFoundException.
	 *
	 * Для неподдерживаемых типов измерений будет возвращено значение 0.
	 */
	real getFrequency(int obstype, int letter) const;

	static real getFrequencyForAntex (int freqn);

	/**
	 * @brief Возвращает идентификатор типа измерительных данных
	 * @param navsys Навигационная система
	 * @param denotement Обозначение
	 * @return Идентификатор, или -1, если тип измерительных данных не найден
	 */
	int getObservableTypeID(char navsys, const string & denotement) const;

	/**
	 * @brief Найти идентификатор типа измерительных данных
	 * @param navsys Буква навигационной системы
	 * @param freq Идентификатор частоты
	 * @param type Тип (псевдодальность, фаза, ...)
	 * @param attr Аттрибут
	 * @return Идентификатор, или -1, если тип неизвестен
	 */
	int getObservableTypeID(char navsys, int freq, int type, char attr) const;

};

/**
 * @brief Класс для хранения и редактирования измерительных данных
 *
 * @ingroup obsdata
 * 
 * Ключ:
 * @li int source_id - идентификатор БИС (@ref ObservationSource)
 * @li double epoch - эпоха (секунды шкалы БИС от J2000).
 * @li int sat_history_id - идентификатор источника сигнала
 * @li int observable_type_id - тип измерительных данных
 *
 * Метка времени \f$t_{R}\f$ в шкале БИС определяется относительно метки
 * \f$t\f$ в "идеальной" шкале TAI (внутренней шкале) равенством:
 * \f$t_{R} = t + \Delta t_{R}\f$, где \f$\Delta t_{R}\f$ - уход часов БИС
 * (см. таблицу @ref TimeShift).
 *
 * Идентификатор приёмника сигнала соответствует полю autoinc таблицы
 * @ref ObservationSource. Идентификатор источника сигнала соответствует
 * полю autoinc таблицы @ref SatelliteHistory.
 * 
 * Данные:
 * @li double Значение измерения
 * @li int Флаги
 * 
 * Флаг имеет следующий смысл:
 * flags&255 - флаги эпохи
 * flags&(255*256)/256 - мощность сигнала
 * flags&(255*65536)/65536 - LLI
 **/
class Observables : public DBTable
{
	Q_OBJECT
private:
	DBTableCollection * Base;

public:

	/** @brief Метод сливает два набора флагов измерительных данных
	  *
	  * Используется при удалении измерительных данных. В метод передаются флаги
	  * удаляемых данных и флаги последующих данных, которые пока не удаляются.
	  * Результатом должен стать флаг, корректно отражающий события между
	  * предыдущим и последующим измерениями после удаления.
	  *
	  * @param flag1 Флаги удаляемых данных
	  * @param flag2 Флаги последующих данных
	  * @return Флаг, который нужно присвоить последующим данным
	  *
	  * Из флага эпохи переноса требует только сбой питания между эпохами; флаги
	  * LLI накапливаются с помощью OR; мощность сигнала не переносится.
	  */
	static int combineSubsequentFlags (int flag1, int flag2);

	Observables (DBTableCollection * base);

	/**
	 * @brief Исключить ионосферную задержку по частотам L1 и L2
	 *
	 * @param newfreq Обозначение "псевдо-"частоты с исключенной задержкой
	 *
	 * Номер newfreq можно получить методом
	 * @ref ObservableTypes::getFrequencyFromAntex(), передав ему одну из строк
	 * G12, G15, G25, R12. При других значениях номера newfewq изменения не
	 * будут внесены и исключение не будет сгенерировано.
	 *
	 * Функция пробегает все эпохи, НКА и БИС, для которых есть измерения
	 * на заданных частотах, и из них генерирует измерения с исключенной
	 * ионосферной задержкой; при этом использованные измерения удаляются.
	 * Измерительные данные, которые не удалось использовать, остаются на месте.
	 * Для исключения ионосферы по двум измерениям они должны быть одинакового
	 * типа (Фаза/Псевдодальность) и одинаковой точности (Высокой/Низкой), если
	 * она различается для этих измерений. Таким образом, например, по P1 и C2
	 * ионосферная задержка не исключается.
	 */
	void deleteIonosphere (char navsys,
						   const OperatorPushableVector<string> &denotements,
						   const string &newdenotement);

	/**
	 * @brief Поиск разрывов в измерительных измерительных данных
	 *
	 * Разрывов фазы находятся путём вычисления рекуррентных последователностей
	 * (@ref CycleSlip.h) в прямом и обратном направлении по времени и проверки
	 * условия разрыва фазы на каждом шаге.
	 *
	 * Это позволяет определять отсекать "плохие" измерения в начале и конце
	 * интервала видимости, т.е. при малых углах над горизонтом (например, при
	 * многолучовости).
	 *
	 * Большинство выбросов фиксируются как двойной разрыв фазы (разрыв
	 * фиксируется в момент выброса и в следующий момент времени), а затем
	 * удаляются как слишком короткие последователности непрерывных измерений.
	 * Аналогично, удаляются последовательности измерений на концах интервала
	 * видимости, "испорченные" многолучовостю.
	 *
	 * Для определения срывов используется несколько техник
	 * (@ref MelbourneWubbenaDetector, @ref MultipathDetector).
	 *
	 * Во всех техниках используются измерения кода и фазы на двух частотах.
	 * В качестве кодовых измерений считается допустимым использовать
	 * комбинации C1, P2, так как P1 доступно не для всех БИС.
	 *
	 * @param navsys Навигационная система (G=GPS, R=ГЛОНАСС, E=Galileo, A=Все)
	 * @param L1_denotement RINEX-обозначение фазы на первой частоте
	 * @param L2_denotement RINEX-обозначение фазы на второй частоте
	 * @param P1_denotement RINEX-обозначение кода на первой частоте
	 * @param P2_denotement RINEX-обозначение кода на второй частоте
	 */
	void findCycleSlips (
						string L1_denotement,
						string L2_denotement,
						string P1_denotement,
						string P2_denotement,
						char curnavsys='A');

	/**
	 * @brief Предобработка измерительных данных
	 * @param navsys Навигационная система (G=GPS, R=ГЛОНАСС, E=Galileo)
	 * @param L1_denotement RINEX-обозначение фазы на первой частоте
	 * @param L2_denotement RINEX-обозначение фазы на второй частоте
	 * @param P1_denotement RINEX-обозначение кода на первой частоте
	 * @param P2_denotement RINEX-обозначение кода на второй частоте
	 * @param todelete Метод выбора интервалов непрерывности для удаления
	 *
	 * Выполняется сначала поиск разрывов (@ref findCycleSlips() ),
	 * а затем удаление коротких дуг. Если todelete='L', то удаляются слишком
	 * короткие дуги (@ref deleteShortArcs() ), если todelete='C', то удаляются
	 * дуги с малым числом измерений (@ref deleteSmallArcs() ).
	 */
	inline void editObservables(string L1_denotement,
								string L2_denotement,
								string P1_denotement,
								string P2_denotement,
								char todelete='L')
	{
		findCycleSlips(L1_denotement, L2_denotement,
					   P1_denotement, P2_denotement);
		deleteSmallArcs(todelete);
	}

	/**
	 * @brief Удалить заданные измерительные данные
	 * @param obs_src_id Номер БИС (@ref ObservationSource)
	 * @param sat_his_id Номер НКА (@ref SatelliteHistory)
	 * @param t0 Начальный момент времени (включается в интервал)
	 * @param t1 Конечный момент времени (включается в интервал)
	 */
	void deleteArc (int obs_src_id, int sat_his_id, real t0,
					real t1);

	//! Возвращает минимальный момент времени среди всех измерительных данных
	real getMinTime () const;

	//! Возвращает максимальный момент времени среди всех измерительных данных
	real getMaxTime () const;

	/**
	 * @brief Прореживание измерительных данных
	 * @param t0 Базовый "целый" момент времени
	 * @param step Шаг прореживания
	 *
	 * Из всех измерений будут оставлены только те, чей момент времени
	 * равен t0 + k * step для некоторого целого k.
	 */
	void resampleDown (real t0, real step);

	/**
	 * @brief Удаление отрезков непрерывности фазы с небольшим числом измерений
	 *
	 * @param whattodelete Способ выбора дуг для удаления
	 *
	 * Если todelete='L', удаляются слишком короткие дуги. Длина дуги задаётся
	 * настройкой Observables->Editor->minArcLength. Если todelete='C', то
	 * удаляются дуги с небольшим числом измерений. Минимальное число моментов
	 * измерения задаётся найтройкой Observables->Editor->minObsCount.
	 *
	 * Если флаги разрывов фазы не были выставлены в RINEX-файле, перед
	 * запуском данного метода необходимо найти разрывы фазы, используя
	 * метод @ref findCycleSlips().
	 */
	void deleteSmallArcs(char todelete);

#ifdef WithQT
public slots:
	void deleteIonosphere(const QString & navsys,const QStringList& denotements,
						  const QString & newdenotement);
	void findCycleSlips (const QString & navsys, const QString & L1_denotement,
						const QString & L2_denotement,
						const QString & P1_denotement,
						const QString & P2_denotement);
	void editObservables (const QString & navsys, const QString & L1_denotement,
						const QString & L2_denotement,
						const QString & P1_denotement,
						const QString & P2_denotement);

	void deleteSmallArcs(const QString& s);

	void deleteObservablesArc (int obs_src_id, int sat_his_id, double t0,
					double t1);
	double getMinimalTime () const;
	double getMaximalTime () const;
	void resampleDownWithStep(double t0, double step);
#endif
};

/**
 * @brief Загружает в коллекцию таблиц идентификаторы измерений с
 * исключенной ионосферой
 *
 * @ingroup obsdata
 *
 * @param tcol Целевая коллекция таблиц
 */
void loadIonosphereFreeObservableCodes(DBTableCollection & tcol);

/**
 * @brief Ошибка: литера НКА не определена на данный момент времени
 *
 * Исключение возникает при попытке определить литеру НКА в момент времени, в
 * который, согласно таблице, литера не была присвоена.
 *
 * @ingroup except
 */
class UnknownSlot : public StrException
{
public:
    UnknownSlot(int slot, UTCDateTime t)
	: StrException("UnknownSlot",
				   "На момент времени "+t.getUTCDateTimeString()+" неизвестна "
		"литера НКА R"+Variant(slot).toString())
	{
	}
};

/**
 * @brief Исключение возникает при попытке внесения неверного частотного слота
 *
 * Исключение обозначает, что в таблице GLONASSFrequencySlots на заданный момент
 * времени записан частотный слот l1, в то время как в оперативной информации
 * записан слот l2.
 */
class IncostitentGLONASSFreqSlotData : public StrException
{
public:
	IncostitentGLONASSFreqSlotData(int slot, real tai, int l1, int l2);
};

/** @brief Справочная таблица присвоения литер спутникам ГЛОНАСС
 *
 * @ingroup obsdata
 * @ingroup stdtbl
 *
 * Ключ:
 * @li int slot - Номер слота
 * @li datetime since - С какого момента НКА занимает орбитальный слот
 *
 * Значение:
 * @li int letter - Номер литеры
 */
class GLONASSFrequencySlots : public DBTable
{
	Q_OBJECT
public:
	GLONASSFrequencySlots (DBTableCollection * base);

	/**
	 * @brief Возвращает литеру НКА ГЛОНАСС на заданный момент времени
	 * @param slot Слот НКА ГЛОНАСС
	 * @param t Момент времени
	 * @param[out] t1 Возвращает момент времени, до которого литера не изменится
	 * @return Литера НКА на заданный момент времени
	 *
	 * Если в таблице есть информация о смене литеры позднее, в t1 будет
	 * записано время смены литеры; если смены литеры не будет, то в t1 будет
	 * записано текущее время.
	 */
	int getLetter (int slot, real t, real * t1 = 0) const;

	/**
	 * @brief Возвращает литеру НКА ГЛОНАСС на заданный момент времени
	 * @param slot Слот НКА ГЛОНАСС
	 * @param t Момент времени
	 * @param[out] t1 Возвращает момент времени, до которого литера не изменится
	 * @return Литера НКА на заданный момент времени
	 *
	 * Если в таблице есть информация о смене литеры позднее, в t1 будет
	 * записано время смены литеры; если смены литеры не будет, то в t1 будет
	 * записано текущее время.
	 */
	int getLetter (int slot, UTCDateTime t, real * t1 = 0) const;

	/**
	 * @brief Записать информацию о частотном слоте НКА
	 * @param slot Орбитальный слот НКА
	 * @param t Метка времени
	 * @param freqslot Частотный слот
	 *
	 * Если, согласно текущей информации, в данный момент времени НКА уже
	 * использует данный частотный слот, данные в таблицу не заносятся.
	 */
	void setLetter (int slot, UTCDateTime t, int freqslot);

#ifdef WithQT
public slots:
	int getGLONASSLetter (int slot, double t) const;
#endif
};

class MelbourneWubbenaDetector;
class MultipathDetector;
class GeometryFreeDetector;

/** @brief Класс для загрузки измерительных данных
 *
 * @ingroup obsdata
  *
  * Объект данного класса используется для загрузки измерительных данных от
  * единственного БИС.
  *
  * При чтении файла измерительных данных метод @ref loadObservables() должен
  * быть вызван для каждого момента времени для каждого НКА.
  *
  * При вызове loadObservables() происходит накопление передаваемых измерений
  * в отдельных буферах для каждого НКА. При этом сразу выполняется проход
  * детектором разрывов. Как только детектор находить разрыв, накопление для
  * данного НКА заканчивается и начинается обратных проход детектором по
  * интервалу непрерывности фазы, в результате чего интервал может быть ещё
  * разбит на более короткие интервалы.
  *
  * После нахождения разрывов выполняется прореживание измерений. Для каждого
  * измерения вызывается метод @ref cutObservables(), и, если он возвращает
  * истину, измерение вырезается.
  *
  * После этого выполняется удаление маленьких интервалов непрерывности фазы.
  * Оставшиеся интервалы копируются в таблицу измерительных данных с помощью
  * вызова метода @ref loadObservable().
  *
  * При поиске разрывов используются те типы измерений, которые указаны при
  * создании объекта.
  */
class ObservablesLoader
{
protected:
	ObservableTypes * obstypes;
	char navsys;
	DBTableCollection * tcol;
	int obssrcid;
	inline ObservablesLoader() {}
	Observables * destination;
private:
	/** @brief Временный буфер для хранения непредобработанных измерений
	 *
	 * Имеет формат:
	 * (НомерНКА)-> Вектор пар (момент времени, вектор пар (Измерение, флаг))
	 *
	 * Запись в буфер происходит при передаче новых данных в метод
	 * @ref loadObservables(). Чтение данных требуется при предобработке.
	 * Для этого следует использовать методы @ref getNumEpochs(),
	 * @ref getEpoch(), @ref getObsTypeIndex(), @ref getObservables().
	 */
	map < int, vector < pair < real, vector < pair<real,int> > > > > arcs;

	//! Для каждого типа измерений - его индекс в векторе измерений в arcs
	map < int, int > curobstypes;
	vector < Tuple > obsdetails;
	SatelliteHistory * sathistory;
	GLONASSFrequencySlots * glofreqslots;
	Settings * sets;
	char intervalcriterion;
	bool usemp, usemw, usegf;
	MelbourneWubbenaDetector * mel;
	MultipathDetector * mp1;
	MultipathDetector * mp2;
	GeometryFreeDetector * gf;
	string l1d, l2d, p1d, p2d;
	int minarccount;
	real minarclen;

protected:

	/**
	 * @brief Добавить тип измерительных данных к списку известных
	 * @param obstype Новый тип измерительных данных
	 */
	virtual int addObsType(int obstype);

	/** @brief Метод выполняет обратных ход детектора разрывов фазы
	  *
	  * @param sat_history_id Идентификатор НКА
	  *
	  * Найденные разрывы устанавливаются во флагах измерений. Метод проходит
	  * вектор arcs[sat_history_id] в обратном порядке. Если при переходе
	  * с позиции i на позицию i-1 обнаруживается разрыв, то устанавливается
	  * разрыв во флагах i-й позиции. Разрыв устанавливается как 0-й бит LLI
	  * во всех фазовых измерениях эпохи.
	  */
	virtual void backwardDetector(int sat_history_id);

	/** @brief Метод выполняет прореживание измерительных данных
	  *
	  * @param sat_history_id Идентификатор НКА
	  * @return Вектор, указывающий какие данные нужно вырезать
	  *
	  * Метод читает структуру arcs[sat_history_id] и для каждого элемента
	  * измерительных данных вызывает виртуальный метод @ref cutObservables(),
	  * который указывает, какие измерительные данные нужно вырезать при
	  * прореживании.
	  *
	  * Результатом является вектор логических значений. Если result[i] = true,
	  * то все измерения на i-й момент времени необходимо вырезать.
	  *
	  * Если на вырезанный момент времени приходятся флаги, они корректно
	  * переносятся на последующие моменты времени. Мощность сигнала не
	  * переносится; флаг начала движения антенны и флаги разрыва фазы (LLI)
	  * накапливаются оператором or и присваиваются первому невырезанному
	  * измерению.
	  */
	virtual vector < bool > resampleDown (int sat_history_id);

	/** @brief Перейти к следующему интервалу непрерывности фазы
	  *
	  * @param sat_history_id Идентификатор НКА
	  * @param[out] i Индекс начало интервала (см. ниже)
	  * @param[out] count Число эпох на пройденном интервале
	  * @param[out] length Длина пройденного интервала в секундах
	  * @param cut Признаки удаления эпохи измерительных данных
	  * @return Индекс начала пройденного интервала
	  *
	  * До запуска метода i - индекс текущего интервала непрерывности фазы в
	  * векторе arcs[sat_history_id].
	  *
	  * Метод вычисляет число эпох измерительных данных на нём и его длину,
	  * затем записывает в i индекс начала следующего интервала, возвращая
	  * в качестве результата индекс начала пройденного интервала.
	  *
	  * Если интервал последний, то в результате выполнения метода i будет
	  * указывать за границу массива.
	  *
	  * Если интервал подобрать не удалось, будет возвращено 0.
	  */
	virtual int nextInterval (int sat_history_id, int & i, int & count,
							  real & length, vector < bool > & cut);

	/** @brief Загрузить измерительные данные в данном интервале
	  *
	  * @param sat_history_id Идентификатор НКА
	  * @param begin Индекс начала интервала в векторе arcs[sat_history_id]
	  * @param end Индекс конца интервала в векторе arcs[sat_history_id]
	  *
	  * Копирует измерительные данные (вызывая @ref loadObservable() ),
	  * начиная с эпохи begin и заканчивая end (не включая).
	  */
	virtual void loadObservablesArc (int sat_history_id, int begin, int end,
									const vector < bool > & cut);

	/**
	 * @brief Произвести предобработку накопленных измерений для данного НКА
	 * @param sat_history_id Идентификатор НКА
	 */
	virtual void preprocessArc(int sat_history_id);

public:

	/**
	 * @brief Загрузчик двухчастотных измерительных данных от одного БИС
	 * @param col Коллекция таблиц
	 * @param obs_src_id Идентификатор БИС
	 * @param int_criterion С или L - критерий удаления малых интервалов
	 * @param navsys Навигационная система
	 * @param p1denotement Обозначение для псевдодальности на первой частоте
	 * @param p2denotement Обозначение для псевдодальности на второй частоте
	 * @param l1denotement Обозначение для фазы на первой частоте
	 * @param l2denotement Обозначение для фазы на второй частоте
	 *
	 * Критерий удаления малых интервалов - см.
	 *  @ref Observables::deleteSmallArcs().
	 */
	ObservablesLoader (DBTableCollection * col,
			 int obs_src_id, char int_criterion, char navsys,
					   string p1denotement="P1", string p2denotement="P2",
					   string l1denotement="L1", string l2denotement="L2"
					   );

	~ObservablesLoader();

	/**
	 * @brief Загрузка измерительных данных одного БИС от одного НКА
	 * @param sat_history_id Идентификатор НКА
	 * @param t Момент времени
	 * @param data Отображение: тип данных -> измеренная величина
	 * @param flags Отображение: тип данных -> флаг
	 *
	 * Функция принимает измерительные данные, проверяет, не начался ли новый
	 * интервал непрерывности фазы, и, если начался, то выгружает накопленные
	 * на предыдущий интервал данные (вызывая метод @ref loadObservable()).
	 *
	 * После обработки всех данных, например, RINEX-файла, в буфере объекта
	 * остаётся последний интервал непрерывности фазы, который необходимо также
	 * выгрузить, вызвав метод @ref finish().
	 */
	virtual void loadObservables (int sat_history_id, real t,
								  const map < int , real > & data,
								  const map < int, int> & flags);

	/**
	 * @brief Метод прореживания измерительных данных
	 *
	 * Определяет, подлежат ли удалению измерительные данные от данного НКА на
	 * заданный момент времени.
	 *
	 * В данной реализации метод возвращает false всегда. Чтобы выполнить
	 * прореживание измерительных данных, его необходимо перегрузить.
	 *
	 * @param sat_history_id Идентификатор НКА
	 * @param t Момент времени
	 * @param obstype Тип измерительных данных
	 * @return true, если данные подлежат удалению. Иначе - false.
	 */
	virtual bool cutObservables (int sat_history_id, real t,
								 int obstype);

	/**
	 * @brief Внесение отобранных измерительных данных в хранилище
	 *
	 * Заносит в хранилище отобранные измерительные данные заданного типа на
	 * заданный момент времени от заданного НКА.
	 *
	 * Данный метод в стандартной реализации вызывается только для отобранных
	 * измерений (после удаления выбросов и прореживания).
	 *
	 * @param sat_history_id Идентификатор НКА
	 * @param obstype Тип измерительных данных
	 * @param t Момент времени
	 * @param obs Измеренная величина
	 * @param flag Флаг измерения
	 */
	virtual void loadObservable (int sat_history_id, int obstype, real t,
								 real obs, int flag);

	/**
	 * @brief Очищает буфер накопленных измерительных данных
	 *
	 * Большую часть времени для внесения измерительных данных используется
	 * метод @ref loadObservables(). Однако он выполняет внесение измерительных
	 * данных с предыдущего интервала непрерывности фазы только когда
	 * начинается новый интервал, поэтому после чтения всего массива данных
	 * (например, RINEX-файла) в буфере остаются накопленные измерительные
	 * данные, которые необходимо также обработать и внести в таблицу. Это
	 * действие выполняется данным методом.
	 */
	virtual void finish();

	//! Метод возвращает идентификатор БИС, для которого считываются измерения
	inline int getObsSrcID() const
	{
		return obssrcid;
	}

	/**
	 * @brief Выбрать другую БИС
	 * @param new_obs_src_id Идентифткатор другой БИС
	 *
	 * Производится сброс всех накопленных от предыдущей БИС данных
	 * (@ref finish()), а затем все вновь загружаемые данные будут считаться
	 * поступающими от БИС с новым указанным идентификатором.
	 */
	virtual void setNewObsSrcID (int new_obs_src_id);

	//! @brief Возвращает указатель на коллекцию таблиц
	inline DBTableCollection * getTableCollection()
	{
		return tcol;
	}

	//! @brief Возвращает константный указатель на коллекцию таблиц
	inline const DBTableCollection * getTableCollection () const
	{
		return (const DBTableCollection *)tcol;
	}

	//! @brief Возвращает обозначение фазы на первой частоте
	inline const string & getL1Denotement() const
	{
		return l1d;
	}

	//! @brief Возвращает обозначение фазы на второй частоте
	inline const string & getL2Denotement() const
	{
		return l2d;
	}

	//! @brief Возвращает обозначение псевдодальности на первой частоте
	inline const string & getR1Denotement() const
	{
		return p1d;
	}

	//! @brief Возвращает обозначение псевдодальности на второй частоте
	inline const string & getR2Denotement() const
	{
		return p2d;
	}

	//! @brief Возвращает число эпох для данного НКА в буфере
	inline int getNumEpochs(int sat_history_id) const
	{
		return arcs.at(sat_history_id).size();
	}

	/**
	 * @brief Возвращает момент времени загруженного измерения
	 * @param sat_history_id Идентификатор НКА
	 * @param n Номер момента времени от начала интервала непрерывности
	 * @return Момент времени загруженного измерения от данного НКА
	 *
	 * В буфере хранятся принятые измерения, которые находятся на разных стадиях
	 * обработки (загрузка новых данных, поиск выбросов, прореживание,
	 * копирование в окончательное хранилище). Данный метод позволяет получить
	 * к доступ к моменту времени измерения.
	 *
	 * Чтобы узнать число хранимых в буфере моментов времени для данного НКА,
	 * нужно вызвать метод @ref getNumEpochs().
	 */
	inline real getEpoch(int sat_history_id, int n) const
	{
		int N = arcs.at(sat_history_id).size() - 1;
		if (n<N)
			N = n;
		return arcs.at(sat_history_id)[N].first;
	}

	/**
	 * @brief Получить индекс типов измерительных данных в буфере
	 *
	 * В буфере данные хранятся в виде вектора пар (измерение, флаг).
	 * Каждый элемент вектора соответствует своему типу измерительных данных.
	 * Данная функция возвращает индекс в этом массиве пары (измерения, флага)
	 * в виде отображения тип->его индекс в массиве в буфере.
	 *
	 * @warning По мере загрузки измерительных данных новых типов индекс,
	 * возвращаемый данной функцией, также будет пополняться. Однако индексы
	 * уже типов уже загруженных данных сохраняются.
	 *
	 * @return Индексы различных типов измерительных данных в буфере
	 */
	inline const map<int,int> & getObsTypeIndex()
	{
		return curobstypes;
	}

	/**
	 * @brief Возвращает из буфера измерительные данные для данного НКА
	 * @param sat_history_id Идентификатор НКА
	 * @param n Номер эпохи
	 * @return Вектор пар (измеренная величина, флаг).
	 *
	 * Для выбора нужной эпохи можно использовать методы:
	 * @li @ref getNumEpochs() - для получения числа хранимых эпох
	 * @li @ref getEpoch() - для чтения эпохи измерительных данных
	 * @li @ref getObsTypeIndex() - для получения
	 */
	inline const vector<pair<real,int> > & getObservables(int sat_history_id,
														  int n) const
	{
		int N = arcs.at(sat_history_id).size() - 1;
		if (n<N)
			N = n;
		return arcs.at(sat_history_id)[N].second;
	}

	/**
	 * @brief Добавляет измерительные данные
	 * @param sat_history_id Идентификатор НКА
	 * @param t_idx Индекс момента времени
	 * @param obstype Тип измерительных данных данных
	 * @param value Значение измерительных данных
	 * @param flag Флаг измерительных данных
	 */
	void addObservable(int sat_history_id, int t_idx, int obstype,
					   real value, int flag);

	inline char getNavSystem() const
	{
		return navsys;
	}
};

/**
 * @brief Загрузчик измерительных данных без предобработки
 *
 * @ingroup obsdata
 */
class NoPreprocessingObservablesLoader : public ObservablesLoader
{
public:
	NoPreprocessingObservablesLoader (DBTableCollection * tcol, int obs_src_id);
	void loadObservables(int sat_history_id, real t,
						  const map < int , real > & data,
						  const map < int, int> & flags);
};

}

#endif

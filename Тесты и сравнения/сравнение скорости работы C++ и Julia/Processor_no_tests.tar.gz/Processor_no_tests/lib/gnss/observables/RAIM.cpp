#include <RAIM.h>
#include <UTCDateTime.h>

using namespace std;

namespace libgnss
{

RAIMTooFewSatellites::RAIMTooFewSatellites(const string &marker_name, real t,
										   int req, int have)
	: StrException("RAIMTooFewSatellites",
				   "Невозможно выполнить RAIM для БИС "+marker_name+" в "
					"момент времени "
				   +UTCDateTime::fromTAIJ2000(t).getUTCDateTimeString()
				   +": требуется "+Variant(req).toString()+" НКА, а имеется "
				   +Variant(have).toString())
{

}

void stepRAIM(const DBTableCollection * col, const DBTable::DBConstIterator & i,
			  int n, std::set < int > * toexclude )
{

}

}

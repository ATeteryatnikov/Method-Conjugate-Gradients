#ifndef INTEGRATE_H_
#define INTEGRATE_H_

//! @file

#include <DBTableCollection.h>
#include <Kinematic.h>
#include <Frames.h>
#include <Types.h>
#include <ParamTrajectory.h>

namespace libgnss
{

class GravityPotential;
class ERPStorage;
class ParameterRadiationPressure;

/**
 * @brief Модуль управления интегрированием траектории КА
 *
 * Модуль выступает прослойкой между коллекцией данных DBTableCollection
 * и модулем интегрирования Integrate::integrate().
 *
 * @ingroup integrate
 */
class ForwardIntegrate
{
	friend void forwardIntegrate(DBTableCollection * base, int sat_history_id,
		real t0, real t1, kinematic<real, 6, defaultInert> init,
								 ParamTrajectory * traj);
private:
	map < real, kinematic < real, 6, defaultInert > > result;
	DBTableCollection * base;
	GravityPotential * gp;
	ERPStorage * erp;
	ParameterRadiationPressure * rp;


	real regular_step;
	int maxDiv;
	int sat_history_id;
public:

	inline ERPStorage * getERPStorage() const
	{
		return erp;
	}

	inline const map < real, kinematic < real, 6, defaultInert > > &
	getResult()
	{
		return result;
	}


	/**
	 * @brief Создание класса для интегрирования траектории КА
	 * @param Коллекция таблиц с данными
	 * @param Номер КА
	 */
	ForwardIntegrate(GravityPotential * gp,
					 ERPStorage * erp,
					 ParameterRadiationPressure * rp,
					 int sat_history_id, real regular_step, int maxDiv);

	/**
	 * @brief Метод, вычисляющий ускорение КА
	 * @param t Момент времени, TAI
	 * @param x Положение и скорость КА
	 * @return Ускорение, действующее на КА
	 */
	virtual kinematic < real, 6, defaultInert > operator()
		(real t, const kinematic < real, 6, defaultInert > & x) const;

	/**
	 * @brief Метод, дающий методу integrate доступ для записи результата
	 * @param Момент времени
	 * @return Ссылка на нужную ячейку памяти
	 */
	virtual kinematic < real, 6, defaultInert > & operator() (real t);

	/**
	 * @brief Метом, управляющий шагом интегрирования
	 * @param t Момент времени
	 * @param x Координаты и скорость КА
	 * @return true, если шаг должен быть поделен, иначе - false
	 */
	virtual bool stepDiv
		(real t, const kinematic < real, 6, defaultInert > & x) const;

	virtual void runIntegrate(real t0, real t1,
					  kinematic<real, 6, defaultInert> init);
};

/**
 * @brief Функция интегрирования уравнения движения вперёд
 *
 * @ingroup integrate
 */
void forwardIntegrate(GravityPotential *gp, ERPStorage *erp,
					  ParameterRadiationPressure *rp, Frames *framest,
					  int sat_history_id,
					  real t0, real t1,
					  kinematic<real, 6, defaultInert> init,
					  ParamTrajectory * traj
					  , real regular_step, int step_div);

/**
 * @brief Функция интегрирования уравнения движения вперёд
 *
 * @ingroup integrate
 *
 * @param Коллекция таблиц, из которой брать данные
 * @param Идентификатор НКА
 * @param Начальный момент времени
 * @param Конечный момент времени
 * @param Начальные условия
 * @param Класс траектории для записи результата
 */
void forwardIntegrate(DBTableCollection * base,
					  int sat_history_id,
					  real t0, real t1,
					  kinematic<real, 6, defaultInert> init,
					  ParamTrajectory * traj);

/**
 * @brief Таблица производных по параметрам модели движения
 *
 * @ingroup integrate
 *
 * Единственной целью объявления данного класса является закрепление алгоритма
 * выбора столбцов данной таблицы в зависимости от набора параметров РД.
 *
 * Ключ:
 * @li int coordinate_id Идентификатор координаты
 * @li double Time Момент времени
 *
 * Значения:
 * @li double delta Невязка приближения траектории
 * @li double d/dX(0) Производная по начальному условию X
 * @li duuble d/dY(0) Производная по начальному условию Y
 * @li double d/dZ(0) Производная по начальному условию Z
 * @li double d/dVX(0) Производная по начальной скорости по X
 * @li double d/dVY(0) Производная по начальной скорости по Y
 * @li double d/dVZ(0) Производная по начальной скорости по Z
 * @li double d/dr1 Производная по первому параметру радиационного давления
 * @li double d/dr2 Производная по второму параметру радиационного давления
 * @li ... Производные по остальным параметрам радиационного давления
 */
class IntegrateDerivativesTable : public DBTable
{
private:
	Columns colsList(int coeffscount);
public:
	IntegrateDerivativesTable (int coeffscount );
};

/**
 * @brief Находит производные значения функции по параметрам уравнения движения
 *
 * @ingroup integrate
 *
 * @param base Коллекция таблиц
 * @param sat_history_id Идентификатор НКА
 * @param t0 Начальный момент времени траектории
 * @param t1 Конечный момент времени траектории
 * @param T0 Левая граница интервала обработки
 * @param T1 Правая граница интервала обработки
 * @param init Начальные условия в момент времени t0
 *
 * Параметрами уравнения движения служат начальные положение и скорость, а также
 * параметры модели радиационного давления (РД).
 *
 * Координаты НКА записаны в таблице trajectory (@ref ParamTrajectory) в
 * коллекции таблиц, там же есть таблица с коэффициентами радиационного давления
 * на НКА.
 *
 * Данная функция, вариируя начальные условия и коэффициенты РД, находит
 * производные от каждой координаты НКА в пределах указанного временнОго
 * интервала обработки по начальным условиям и коэффициентам РД.
 *
 * @return Таблица производных и невязок
 *
 * В таблице-результате сохраняются производные координат по параметрам и
 * невязки приближения траектории с текущими значениями параметров.
 *
 * Таблица имеет ключ:
 * @li Индекс координаты
 * @li Момент времени
 *
 * Значения:
 * 0) Невязка
 * 1) Производная коориднаты по X(0)
 * 2) Производная координаты по Y(0)
 * 3) Производная координаты по Z(0)
 * 4) Производная координаты по Vx(0)
 * 5) Производная координаты по Vy(0)
 * 6) Производная координаты по Vz(0)
 * 7) Производная по первому параметру РД
 * ...
 * 7+k) Производная по k-1-му параметру РД
 */
IntegrateDerivativesTable  *integrateDerivatives(DBTableCollection * base,
					int sat_history_id,
					real t0, real t1,
					real T0, real T1,
					kinematic < real, 6, defaultInert> init);

/**
 * @brief Базовый класс, ответственный за предобработку матрицы МНК
 *
 * @ingroup integrate
 *
 * После токо, как расширенная матрица МНК для приближения траектории готова,
 * может потребоваться её доработка (например, домножения строк на веса).
 * Для этого необходимо перегрузить в данном классе метод preprocess и передать
 * функции @ref fitTrajectory объект соответствующего класса.
 */
class PreprocessFitTrajectoryMatrix
{
public:
	virtual void preprocess(IntegrateDerivativesTable * tbl) = 0;
};


/**
 * @brief Подбирает параметры РД и начальные условия для приближения траектории
 *
 * @ingroup integrate
 *
 * @param[in] base Коллекция таблиц
 * @param[in] sat_history_id Идентификатор НКА
 * @param[in] t0 Момент времени, в который нужно вычислить начальные условия
 * @param[in] T0 Левая граница интервала обработки
 * @param[in] T1 Правая граница интервала обработки
 * @param[in,out] init Начальные условия для уравнения движения
 *
 * Если init не задано (isnan(init.length<0,2>()) = true), то оно будет взято
 * из таблицы траектории.
 *
 * Функция вычисляет параметры радиационного давления и начальные условия для
 * уравнения движения так, чтобы полученная при его интегрировании траектория
 * в смысле наименьших квадратов аппроксимировала траекторию НКА, сохраненную
 * в таблице траекторий.
 *
 * Вычисленные начальные условия возвращаются через параметр функции; найденное
 * РД записывается в таблицу РД.
 *
 * Для начала работы необходимо, чтобы в момент времени t0 в таблице траектории
 * были координаты и скорость нужного НКА.
 */
void fitTrajectory(DBTableCollection * base, int sat_history_id,
				   real t0, real T0, real T1,
				   kinematic < real, 6, defaultInert > & init,
				   int maxiter=-1,
				   PreprocessFitTrajectoryMatrix * preprocessmatrix = 0);

}

#endif

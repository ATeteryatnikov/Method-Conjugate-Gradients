#ifndef ACCELERATION_H_
#define ACCELERATION_H_

//! @file

#include <Kinematic.h>
#include <Frames.h>
#include <GravityPotential.h>
#include <ERPStorage.h>
#include <RadPressure.h>
#include <NewtonGravity.h>

namespace libgnss
{


/** @brief Вычисление возмущения ускорения, действующего на КА
 *
 * @ingroup integrate
  *
  * Ускорение, испытываемое КА, состоит из:
  * @li Ускорения от Земли, как от материальной точки
  * @li Поправок к градиенту гравитационного потенциала Земли
  * @li Ускорению от гравитации Луны, Солнца и др. космических тел
  * @li Ускорению от радиационного давления (включает давление переотраженного
  * излучения, тепловое излучение КА, ускорение от излучение передающей
  * антенны КА, и др. компоненты ускорения радиационной природы).
  *
  */
inline kinematic < real, 3, defaultInert > acceleration (
		const GravityPotential * gpe,
		const ERPStorage * erp,
		const ParameterRadiationPressure * rpm,
		int sat_history_id,
		kinematic < real, 6, defaultInert > posvel,
		real TAI
		)
{
	kinematic < real, 3, defaultInert > pos = posvel.subset<0,2>();
	real length = posvel.length<0,2>();
	real scal = -GM_earth/(length*length*length);
	kinematic <real, 3, defaultNonInert> posnoninert=erp->GCRStoITRF(pos, TAI);
	//Заранее вычислить гравитационное ускорение от Земли
	kinematic <real, 3, defaultInert > gnewt = posvel.subset<0,2>()*scal;
	kinematic <real, 3, defaultInert > geopot = erp->ITRFtoGCRS(
					gpe->gradient(posnoninert, TAI),TAI);
	kinematic <real, 3, defaultInert> newt=getNewtonGravity(pos,TAI);
	real shad = shadowFactor(TAI, posvel.subset<0,2>());
	kinematic <real, 3, defaultInert> rp = rpm->calcAcceleration(sat_history_id,
																posvel,TAI,
																shad);
	kinematic <real, 3, defaultInert> result = geopot + rp + newt;

	return result + gnewt;
}

}

#endif

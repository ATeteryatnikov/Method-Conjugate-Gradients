#include <map>
//#include <iostream>

using namespace std;

//! @file

#include <Integrate.h>
#include <ParamTrajectory.h>
#include <Acceleration.h>
#include <StdTables.h>
#include <RadPressure.h>
#include <integrate.hpp>
#include <Frames.h>
#include <BuiltIn.h>
//#include <f2c.h>


namespace libgnss
{

Settings::Enumerator intRegularStep("Integration","Adams",
								"Regular_step",Variant::TYPE_DOUBLE,
								"Регулярный шаг интегрирования методом Адамса",
									Variant(real(10.0)));
Settings::Enumerator intSubdivide("Integration","Adams",
								  "Subdivide",Variant::TYPE_INT,
								  "Коэффициент дробление шага в методе Адамса",
								  Variant(int(10)));

ForwardIntegrate::ForwardIntegrate(GravityPotential *gp, ERPStorage *erp,
								   ParameterRadiationPressure *rp,
								   int sat_history_id,
								   real regular_step,
								   int maxDiv)
{
	this->gp  = gp;
	this->erp = erp;
	this->rp = rp;
	this->sat_history_id = sat_history_id;
	this->regular_step = regular_step;
	this->maxDiv = maxDiv;
}

kinematic < real, 6, defaultInert > ForwardIntegrate::operator()
	(real t, const kinematic < real, 6, defaultInert > & x) const
{
	return x.subset<3,5>().concat(acceleration(gp,erp,rp,sat_history_id,x,t));
}

kinematic <real, 6, defaultInert> & ForwardIntegrate::operator() (real t)
{
	return result[t];
}

bool ForwardIntegrate::stepDiv
	(real t, const kinematic < real, 6, defaultInert > & x) const
{
	//Измельчать шаг при заходе НКА в полутень/тень

	//Найти примерное положение КА через regular_step секунд
	kinematic<real, 3, defaultInert> futureCoords = x.subset<0,2>()+
			regular_step*x.subset<3,5>();

	//Найти коэффициент освещённости НКА через заданное число секунд
	real shadow = shadowFactor(t,futureCoords);

	//! @bug Правильно рассчитать и/или вынести в другое место эту константу
	const real minshadow = 1-1e-7;
	if (shadow>minshadow)
		return false;
	return true;
}

void ForwardIntegrate::runIntegrate(real t0, real t1,
									kinematic<real, 6, defaultInert> init)
{
	integrate(t0,t1,init,*this,regular_step,maxDiv,*this);
}

void forwardIntegrate(GravityPotential * gp, ERPStorage * erp,
					  ParameterRadiationPressure * rp,
					  Frames * framest,
					  int sat_history_id,
					  real t0,
					  real t1,
					  kinematic<real,6,defaultInert> init,
					  ParamTrajectory *traj,
					  real regular_step,
					  int step_div)
{
	//Создать модуль интегрирования
	ForwardIntegrate fi(gp,erp, rp,
						sat_history_id, regular_step, step_div);

	//Выполнить интегрирования
	fi.runIntegrate(t0,t1,init);

	//Получить номера координат defaultInert-системы координат
	vector < int > coordtypes = framest->getFrameCoordinates(
				framest->getCoordinateFrameID("GCRS"));


	//Скопировать данные в траекторию
	for (map<real,kinematic<real,6,defaultInert> > :: const_iterator it0=
		 fi.getResult().begin(); it0!=fi.getResult().end(); ++it0)
		for (unsigned int i=0; i<6; i++)
			traj->insertRow(Tuple()<<sat_history_id<<coordtypes[i]<<it0->first,
							Tuple()<<it0->second[i]);
}

void forwardIntegrate(DBTableCollection * base,
					  int sat_history_id,
					  real t0, real t1,
					  kinematic<real, 6, defaultInert> init,
					  ParamTrajectory * traj)
{
	GravityPotential * gp = (GravityPotential*)
			(base->getTable("gravity_potential"));
	ERPStorage * erp = (ERPStorage*)(base->getTable("ERP"));
	ParameterRadiationPressure * rp =
			(ParameterRadiationPressure*)(base->getTable(
					ParameterRadiationPressure::getRPStorageName(*base)));
	Frames * frm = (Frames*)(base->getTable("coordinate_frames"));
	Settings * sets = (Settings *)(base->getTable("settings"));
	real step = sets->getSettings(intRegularStep).toDouble();
	int stepDiv = sets->getSettings(intSubdivide).toInt();
	forwardIntegrate(gp,erp,rp,frm,sat_history_id,t0,t1,init,traj,
					 step,stepDiv);
}


Columns IntegrateDerivativesTable::colsList(int coeffscount)
{
	Columns valueColumns;
	valueColumns<<Column(Variant::TYPE_DOUBLE, "delta")
				<<Column(Variant::TYPE_DOUBLE, "d/dX(0)")
				<<Column(Variant::TYPE_DOUBLE, "d/dY(0)")
				<<Column(Variant::TYPE_DOUBLE, "d/dZ(0)")
				<<Column(Variant::TYPE_DOUBLE, "d/dVX(0)")
				<<Column(Variant::TYPE_DOUBLE, "d/dVY(0)")
				<<Column(Variant::TYPE_DOUBLE, "d/dVZ(0)")
;
	for (unsigned int i=0; i<coeffscount; i++)
		valueColumns
			<<Column(Variant::TYPE_DOUBLE, "d/dr"+Variant((int)i).toString());
	return valueColumns;
}

IntegrateDerivativesTable::IntegrateDerivativesTable(int coeffscount)
	: DBTable (Columns()<<Column(Variant::TYPE_INT,"coordinate_id")
					   <<Column(Variant::TYPE_DOUBLE,"Time"),
			   colsList(coeffscount))
{

}

IntegrateDerivativesTable  * integrateDerivatives(DBTableCollection * base,
					int sat_history_id,
					real t0, real t1,
					real T0, real T1,
					kinematic < real, 6, defaultInert> init)
{
	//Определить таблицу с коэффициентами РД
	string RPTable = ParameterRadiationPressure::getRPStorageName(*base);
	ParameterRadiationPressure * rpm = (ParameterRadiationPressure *)
			(base->getTable(RPTable));
	CoordinateTypes * ctypes0 = (CoordinateTypes*)
			(base->getTable("coordinate_types"));
	Frames * frames0 = (Frames*)(base->getTable("coordinate_frames"));
	Settings * sets0 = (Settings*)(base->getTable("settings"));
	GravityPotential * gp =
			(GravityPotential*)(base->getTable("gravity_potential"));
	ERPStorage * erp = (ERPStorage*)(base->getTable("ERP"));
	CoordinateTypes * ctypes =
			(CoordinateTypes*)(base->getTable("coordinate_types"));
	real regularStep = sets0->getSettings(intRegularStep).toDouble();
	int stepDiv = sets0->getSettings(intSubdivide).toInt();
	//Перечислить все коэффициенты РД для этого НКА
	int coeffscount = 0;
	for (DBTable::DBConstIterator it = rpm->find(Tuple()<<sat_history_id);
		 it!=rpm->const_end(); it.subinc(1,0))
		coeffscount++;

	ParamTrajectory * traj = (ParamTrajectory*)
			(base->getTable("trajectory"));
	//0-я траектория - априорная, остальные - вариированные
	vector < DBTableCollection * > collections (coeffscount + 7);
	vector < ParamTrajectory * > trajectories (coeffscount + 7);
	for (unsigned int i=0; i<trajectories.size(); i++)
	{
		collections[i] = new DBTableCollection;
		Frames * fr = new Frames (collections[i]);
		fr->copyFrom(frames0->const_begin(), frames0->const_end());
		CoordinateTypes * ct = new CoordinateTypes (collections[i]);
		ct->copyFrom(ctypes0->const_begin(), ctypes0->const_end());
		Settings * st = new Settings(collections[i]);
		st->copyFrom(sets0->const_begin(), sets0->const_end());
		trajectories[i] = new ParamTrajectory(collections[i]);
	}

	//Вычислить траектории
	real deltas [] = {0,
					   1e-3,1e-3,1e-3,1e-6,1e-6,1e-6,
					   1e-11,1e-11,1e-11,1e-11,1e-11,1e-11,
						   1e-11,1e-11,1e-11};
	for (unsigned int i=0; i<coeffscount + 7; i++)
	{
		//Если i>0, вариировать начальные значения и РД
		if ((i >= 1) && (i<7))
			init[i-1] += deltas[i];
		if (i >= 7)
		{
			DBMap::DBIterator it=rpm->find(Tuple()<<sat_history_id<<(int)(i-7));
			real currpc = it[0].toDouble();
			it.updateCell(0,Variant(currpc + deltas[i]));
		}

		//Интегрировать вариированную траекторию
		forwardIntegrate(gp,erp,rpm,frames0, sat_history_id, t0, t1, init,
						 trajectories[i],regularStep,stepDiv);

		//Вернуть начальные значения и РД
		if ((i >= 1) && (i<7))
			init[i-1] -= deltas[i];
		if (i >= 7)
		{
			DBMap::DBIterator it=rpm->find(Tuple()<<sat_history_id<<(int)(i-7));
			real currpc = it[0].toDouble();
			it.updateCell(0,Variant(currpc - deltas[i]));
		}
	}

	//Создать таблицу
	IntegrateDerivativesTable * result =
			new IntegrateDerivativesTable(coeffscount);

	//Вычислить производные и записать результат в таблицу
	for (DBTable::DBConstIterator it = traj->find(Tuple()<<sat_history_id);
		 it!=traj->const_end(); it.subinc(2,0))
	{
		int coordinate_id = it.keyColumnValue(1).toInt();
		if (ctypes->read(coordinate_id)[1].toInt()>=3)
			continue;
		//Проверить, что это компонента координаты, а не скорости или ускорения
		real t = it.keyColumnValue(2).toDouble();
		if ((t<T0) || (t>T1))
				continue;
		Tuple derivs;
		derivs.resize(7+coeffscount);
		Tuple subkey;
		subkey<<sat_history_id<<coordinate_id;
		real sp3val = it[0].toDouble();
		real integrval = trajectories[0]->getParameterValue(subkey,t);
		derivs[0] = Variant(sp3val-integrval);
		for (unsigned int i=1; i<7+coeffscount; i++)
			derivs[i]=Variant((trajectories[i]->getParameterValue(subkey,t)
					- trajectories[0]->getParameterValue(subkey,t))/deltas[i]);
		result->insertRow(Tuple()<<coordinate_id<<t,derivs);
	}

	//Удалить более не нужные траектории
	for (unsigned int i=0; i<coeffscount+7; i++)
	{
		delete (*(collections[i]))["coordinate_frames"];
		delete (*(collections[i]))["coordinate_types"];
		delete (*(collections[i]))["settings"];
		delete (*(collections[i]))["trajectory"];
		delete collections[i];
	}

	return result;
}

extern "C" int dgels_(char *trans, long int *m, long int *n, long int *
	nrhs, double *a, long int *lda, double *b, long int *ldb,
	double *work, long int *lwork, long int *info, long int trans_len);
//extern "C" void dgels_ ( char * trans, int * m, int * n, int * nrhs,
//						 double * a, int * lda, double * b, int * ldb,
//						 double * work, int * lwork, int * info );

void fitTrajectory(DBTableCollection *base, int sat_history_id, real t0,
		real T0, real T1, kinematic<real, 6, defaultInert> &init, int maxiter,
				   PreprocessFitTrajectoryMatrix *preprocessmatrix)
{
	ParamTrajectory * traj = (ParamTrajectory *)
			(base->getTable("trajectory"));
	if (isnan(init.length<0,2>()))
		init = traj->getPositionVelocity(sat_history_id, t0);
	real t1 = T1;
	if (t1<=t0)
		StrException("fitTrajectory","Ошибка приближения траектории: T1 < t0.");
	bool iterate = true;
	string rpname = ParameterRadiationPressure::getRPStorageName(*base);
	ParameterRadiationPressure * rpm =
			(ParameterRadiationPressure*)(base->getTable(rpname));
	int iterationnumber = 0;
	while (iterate)
	{
		iterationnumber++;
		if ((iterationnumber > maxiter) && (maxiter>0))
			break;
//		cout<<"Итерация №"<<(++iterationnumber)<<endl;
		IntegrateDerivativesTable * lsp = integrateDerivatives(base,
											sat_history_id,t0,t1, T0, T1, init);
		if (preprocessmatrix != 0)
			preprocessmatrix->preprocess(lsp);
		//Создать матрицу и правую часть для lapack
		long int nrows = lsp->count();
		long int ncols = lsp->getValueColumnsCount() - 1;
		double*matrix=new double[ncols*nrows];
		double*rhs=new double[nrows];
		int i=0;
		for (DBTable::DBConstIterator it = lsp->const_begin();
			 it!=lsp->const_end(); ++it)
		{
			rhs[i] = (double)(it[0].toDouble());
			for (unsigned int k=0; k<ncols; k++)
				matrix[k*nrows+i] = (double)(it[k+1].toDouble());
			i++;
		}
		//Параметры для lapack-функции dgels
		delete lsp;
		double*work;
		double dwork;
		long int lwork = -1;
		long int nrhs = 1;
		long int info;
		char trans='N';
		//Сколько памяти требуется алгоритму
		dgels_(&trans,&nrows,&ncols,&nrhs,matrix,&nrows,rhs,&nrows,&dwork,
			   &lwork, &info, 0);
//		cout<<nrows<<" "<<ncols<<endl;
		lwork = (int)(dwork);
		work = new double[lwork];
		//Решить задачу МНК
		dgels_(&trans,&nrows,&ncols,&nrhs,matrix,&nrows,rhs,&nrows,work,&lwork,
			   &info, 0);
		//Изменить значения уточняемых параметров
		iterate = false;
		for (unsigned int j=0; j<6; j++)
		{
			if (fabs(rhs[j])>1e-8)
				iterate = true;
			init[j] += rhs[j];
		}
		i = 0;
		for (DBTable::DBIterator it = rpm->find(Tuple()<<sat_history_id);
			 it!=rpm->const_end(); it.subinc(1,0))
		{
			it.updateCell(0,it[0].toDouble() + (real)(rhs[i+6]));
			i++;
		}
		delete[] matrix;
		delete[] rhs;
		delete[] work;
	}
}

#ifdef WithQT
QScriptValue fwdInt(QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		DBTableCollection * base_ = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		int sat_history_id = ctx->argument(1).toInt32();
		real t0 = ctx->argument(2).toNumber();
		real t1 = ctx->argument(3).toNumber();
		kinematic<real, 6, defaultInert> init_;
		QVariantList init = ctx->argument(4).toVariant().toList();
		for (unsigned int i=0; i<6; i++)
			init_[i] = init[i].toDouble();
		ParamTrajectory * traj_ = qobject_cast<ParamTrajectory*>
				(ctx->argument(5).toQObject());
		GravityPotential * gp = (GravityPotential *)
				(base_->getTable("gravity_potential"));
		ERPStorage * erp =(ERPStorage*)(base_->getTable("ERP"));
		ParameterRadiationPressure * rp =
				(ParameterRadiationPressure*)(base_->getTable(
						ParameterRadiationPressure::getRPStorageName(*base_)));
		Frames*frm = (Frames*)(base_->getTable("coordinate_frames"));
		Settings*sets = (Settings*)(base_->getTable("settings"));
		real regularStep = sets->getSettings(intRegularStep).toDouble();
		int stepDiv = sets->getSettings(intSubdivide).toInt();
		forwardIntegrate(gp,erp,rp,frm, sat_history_id, t0, t1, init_, traj_,
						 regularStep, stepDiv);
		return QScriptValue();
	}
	catch (StrException & e)
	{
		returnError(eng, string("Не удалось проинтегрировать траекторию: ")+
					e.what());
	}
}

QScriptValue intDers(QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		DBTableCollection * base_ = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		int sat_history_id = ctx->argument(1).toInt32();
		real t0 = ctx->argument(2).toNumber();
		real t1 = ctx->argument(3).toNumber();
		real T0 = ctx->argument(4).toNumber();
		real T1 = ctx->argument(5).toNumber();
		kinematic<real, 6, defaultInert> init_;
		QVariantList init = ctx->argument(6).toVariant().toList();
		for (unsigned int i=0; i<6; i++)
			init_[i] = init[i].toDouble();
		DBTable * result_ = integrateDerivatives(base_,sat_history_id,
												 t0,t1,T0,T1,init_);
		return eng->newQObject(result_,QScriptEngine::ScriptOwnership);
	}
	catch(StrException & e)
	{
		returnError(eng, string("Не удалось вычислить производные по "
					"начальным условиям и параметрам модели движения: ")
					+e.what());
	}
}

QScriptValue fitTraj (QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		DBTableCollection * base_ = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		int sat_history_id = ctx->argument(1).toInt32();
		real t0 = ctx->argument(2).toNumber();
		real T0 = ctx->argument(3).toNumber();
		real T1 = ctx->argument(4).toNumber();
		kinematic<real, 6, defaultInert> init;
		fitTrajectory(base_,sat_history_id,t0,T0,T1,init);
		QVariantList result;
		result<<(double)(init[0])<<(double)(init[1])
				<<(double)(init[2])<<(double)(init[3])<<(double)(init[4])
				<<(double)(init[5]);
		return eng->toScriptValue<QVariantList>(result);
	}
	catch (StrException & e)
	{
		returnError(eng,string("Не удалось выполнить приближение траектории: ")
					+e.what());
	}
}

BuiltIn fwdintegrate("forwardIntegrate", 6, fwdInt);
BuiltIn intderivs("integrateDerivatives", 7, intDers);
BuiltIn fittraj("fitTrajectory", 5, fitTraj);
#endif

}

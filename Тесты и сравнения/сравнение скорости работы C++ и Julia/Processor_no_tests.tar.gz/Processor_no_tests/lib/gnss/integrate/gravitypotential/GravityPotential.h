#ifndef GRAVITYPOTENTIAL_H_
#define GRAVITYPOTENTIAL_H_

#include <Types.h>
#include <Kinematic.h>
#include <DBTableCollection.h>
#include <DBTable.h>
#include <StdTables.h>
#include <Frames.h>
#include <ERPStorage.h>

/*
 * GravityPotential.h
 *
 *  Created on: 02.07.2010
 *      Author: yuron & neko
 */
//! @file

namespace libgnss
{


//! Гравитационный параметр Земли км^3/c^2 (WGS 84)
const real GM_WGS84 = 398600.4415;

//! Большая полуось км/с (WGS 84)
const real a_WGS84 = 6378.1363;

/** @brief Таблица с коэффициентами долгопериодических твердотельных приливов
 *
 * См. IERS Conventions, tn36, глава 6.
 *
 * Ключи:
 * @li double freq Частота применяемого эффекта, градусы/час
 * @li int nj_l Фундаментальный аргумент теории нутации \f$l\f$
 * @li int nj_lp Фундаментальный аргумент теории нутации \f$l\f$'
 * @li int nj_f Фундаментальный аргумент теории нутации \f$F\f$
 * @li int nj_d Фундаментальный аргумент теории нутации \f$D\f$
 * @li int nj_om Фундаментальный аргумент теории нутации \f$\Omega\f$
 *
 * Значения:
 * @li double ampl_in0 Синфазный коэффициент модели приливов
 * @li double ampl_out0 Не синфазный коэффициент модели приливов
 *
 * @ingroup integrate
 */
class LongperiodSolidTides : public DBTable
{
public:
	LongperiodSolidTides ( DBTableCollection * base );
};

/** @brief Таблица с коэффициентами суточных твердотельных приливов
 *
 * @ingroup integrate
 */
class DiurnalSolidTides : public DBTable
{
public:
	DiurnalSolidTides ( DBTableCollection * base);
};

/** @brief Таблица с коэффициентами полусуточных твердотельных приливов
 *
 * @ingroup integrate
 */
class SemidiurnalSolidTides : public DBTable
{
public:
	SemidiurnalSolidTides ( DBTableCollection * base);
};

/** @brief Таблица с коэффициентами океанических приливов
 *
 * @ingroup integrate
 */
class OceanTides : public DBTable
{
public:
	OceanTides ( DBTableCollection * base);
};

/** @brief Таблица с коэффициентами океанических полюсных приливов
 *
 * @ingroup integrate
 */
class OceanPoleTides : public DBTable
{
public:
	OceanPoleTides ( DBTableCollection * base);
};


/** @class GravityPotential GravityPotential.h GravityPotential.h
 * 
* @brief Класс для вычисления возмущения градиента гравитационного потенциала
* Земли (ГПЗ).
*
* @ingroup integrate
* 
*
* Градиент возмущения вычисляется по формуле:
* \f[
* grad\, V(r,\theta, \lambda)=grad\, \frac{GM}{r} \sum_{n=2}^{N_{max}}
* \left(\frac{a}{r}\right)^n \sum_{m=0}^{n}(\overline{C}_{nm}\cos m\lambda +
* \overline{S}_{nm}\sin m\lambda )\overline{P}_{nm}(\cos \theta),
* \f]
* \f[
* \overline{P}_{nm}(z)=\left( \frac{(n-m)!(2n+1)k}{(n+m)!}\right)^{\frac{1}{2}}
* P_{nm}(z), \;\; k = \left\{
\begin{array}{rl}
1, & \mbox{если } m=0 \\
2, & \mbox{если } m\neq0 \\
\end{array} \right. ,
* \f]
* \f[
* P_{nm}(z)=(1-z^2)^{\frac{m}{2}}\;\frac{d^m}{dz^m}\left(P_n(z)\right),
* \f]
* \f[
P_{n}(z)=\frac{1}{2^n n!}\;\frac{d^n}{dz^n}(z^2-1)^n,
* \f]
* где
*
* \f$r, \theta, \lambda\f$ - сферические координаты,
*
* \f$r\f$ - расстояние до центра масс Земли,
*
* \f$\theta\f$ - дополнение геоцентрической широты,
*
* \f$\lambda\f$ - геоцентрическая долгота,
*
* \f$GM\f$ - гравитационный параметр Земли,
*
* \f$a\f$ - большая полуось эллипсоида WGS84,
*
* \f$\overline{C}_{nm}, \overline{S}_{nm}\f$ - коэффициенты разложения
* гравитационного потенциала,
*
* \f$n\f$, \f$m\f$ - степень и порядок соответственно,
*
* \f$N_{max}\f$ - порядок разложения ГПЗ.
*
*
* Внимание! Данный класс не является параллельным (thread-safe), так как для
* оптимизации применяется заблаговременное выделение необходимой памяти
* внутри полей класса.
*
*
*/
class GravityPotential  : public DBTable
{
Q_OBJECT
private:
	bool dataPrepared;
	bool solidTidesLP;
	bool solidTidesD;
	bool solidTidesSD;
	bool oceanTides;
	bool oceanPoleTides;
	void prepareData();
	DBTableCollection * Base;
	ERPStorage * erps;
	CelestialBodies * bodies;
public:
	GravityPotential(DBTableCollection *base);

private:

	//! @brief Порядок разложения ГПЗ.
	int Nmax;

	//! @brief Коэффициенты при косинусах в разложении ГПЗ.
	double**CoefficientsCnm;

	//! @brief Коэффициенты при синусах в разложении ГПЗ.
	double**CoefficientsSnm;
	
	//! @brief Модифицированные приливами коэффициенты ГПЗ при косинусах.
	double **Cnm;

	//! @brief Модифицированные приливами коэффициенты ГПЗ при синусах.
	double **Snm;
	
	/** @brief Указатель на временные переменные для хранения значений
	  * \f$Pcos_{nm}\equiv P_{nm}(\sin\varphi)\cos m \lambda\f$.
	  */
	double**Pcos;

	/** @brief Указатель на временные переменные для хранения значений
	  * \f$Psin_{nm}\equiv P_{nm}(\sin\varphi)\sin m\lambda\f$.
	  */
	double**Psin;



	/** @brief Метод, вычисляющий возмущение гравитационного потенциала
	* под влиянием приливов.
	*
	* @param t Момент времени.
	* @return Ничего не возвращает, в процессе работы изменяет значения
	* гравитационных коэффициентов.
	*/
	void TideContribution(real t);

	/** @brief Метод, вычисляющий возмущения гравитационного потенциала под
	* влиянием твердотельных приливов.
	*
	* @param t Момент времени.
	* @return Ничего не возвращает, в процессе работы изменяет значения
	* гравитационных коэффициентов.
	*/
	void SolidTideContribution(real t);

	/* Данные для твердотельных приливов */

	/** @name Статические переменные, хранящие константы, для нахождения
		влияния твердотельных приливов. */
	//! @{
	/*Долгопериодические приливы*/
	/** @brief Количество различных частот в разложении приливного
	  * потенциала для долгопериодических приливов.
	  */
	static const int LT=21;
	/** @brief Множители фундаментальных аргументов теории нутации (для
	  * каждой частоты) для долгопериодических приливов.
	  */
	int N_f20[LT][5]; //Множители фундаментальных аргументов теории нутации.
	//! @brief Амплитуды синфазы и несинфазы для долгопериодических приливов
	double inA0[LT];
	//! @brief Амплитуды несинфазы для долгопериодических приливов.
	double outA0[LT];

	/*Суточные приливы*/
	/** @brief Количество различных частот в разложении приливного
	 * потенциала для суточных приливов.
	 */
	static const int DT=48;
	/** @brief Множители фундаментальных аргументов теории нутации (для
	  * каждой частоты) для суточных приливов.
	  */
	int N_f21[DT][5]; // Множители фундаментальных аргументов теории нутации.
	//! @brief Амплитуды синфазы и несинфазы для суточных приливов.
	double inA1[DT];
	//! @brief Амплитуды несинфазы для суточных приливов.
	double outA1[DT];

	/*Полусуточные приливы*/
	//! @brief Количество различных частот в разложении приливного потенциала для полусуточных приливов.
	static const int ST=2;
	//! @brief Множители фундаментальных аргументов теории нутации (для каждой частоты) для полусуточных приливов.
	int N_f22[2][5]; // Множители фундаментальных аргументов теории нутации.
	//! @brief Амплитуды полусуточных приливов.
	double A2[ST];
	//! @}

	/** @name Статические переменные, хранящие константы, для нахождения влияния океанических приливов. */
	//! @{
	/* Данные для океанических приливов */
	//! @brief Вспомогательная структура для хранения констант океанических приливов.
	struct Harmonic_Amplitudes{
		//! @brief Шестимерный вектор фундаментальных аргументов Дудсона.
		int Doodson[6];
		//! @brief Степень и порядок разложения океанического приливного геопотенциала.
		int n,m;
		//! @brief Амплитуды гармоник океанического приливного геопотенциала.
		double DelC_plus, DelS_plus, DelC_minus, DelS_minus;
	};
	//! @brief Указатель на набор констант океанических приливов для различных частот.
	Harmonic_Amplitudes *harmonic_Amplitudes;
	//! @brief Пока порядок разложения геопотенциала океанических приливов.
	int Nmax_ocean;
	//! @brief Количество коэффициентов, считанных из БД (соответствующих разным частотам) для @ref Nmax_ocean порядка разложение геопотенциала океанических приливов.
	int Num;
	//! @}

	/* Данные для океанических полюсных приливов */
	//! @name Указатели на константные коэффициенты, использующиеся при нахождения коэффициентов разложения геопотенциала океанических полюсных приливов.
	//! @{
	double **Anm_R, **Bnm_R, **Anm_I, **Bnm_I;
	//! @}

public:

	void destroyGeopotData();

	/** @brief Метод, вычисляющий возмущение гравитационного потенциала.
	*
	* @param in Точка в системе координат WGS84.
	* @param t Момент времени.
	* @return Возмущение гравитационного потенциала в точке в указанный момент времени.
	*
	* @todo Позаботиться о переводе систем координат ПЗ90\f$\leftrightarrow\f$WGS84.
	*/
	real value(const kinematic<real,3,defaultNonInert>&in, real t);

	/** @brief Метод, вычисляющий возмущение градиента гравитационного потенциала.
	*
	* @param in Координаты точки в системе координат WGS84.
	* @param t Момент времени.
	* @return Возмущение градиента гравитационного потенциала в точке в указанный момент времени, км/c\f${}^2\f$.
	*
	* Внутри функция нарушает атрибут const, изменяя скрытые поля объекта.
	* Однако const необходимо для того, чтобы не дать возможности из
	* использующей процедуры вызывать другие неконстантные методы:
	* insertRow(), updateRow(), и т.д.
	*/
	kinematic<real,3,defaultNonInert> gradient(const kinematic<real,3,defaultNonInert>&in, real t) const;

	//! @brief Деструктор для освобождения памяти из-под коэффициентов.
	~GravityPotential();
	
#ifdef WithQT
public slots:
	double value (const QVariantList & noninertpos, double t);
	
	QVariantList gradient (const QVariantList & noninertpos, double t);
#endif
};

}

#endif /* GRAVITYPOTENTIAL_H_ */

/*
 * GravityPotential.cpp
 *
 *  Created on: 02.07.2010
 *      Author: yuron & neko
 */
//! @file


//#include <mpi.h>

#include <string.h>
#include <fstream>

using namespace std;

#include <Consts.h>
#include <GravityPotential.h>
#include <ephemeris.h>
#include <BuiltIn.h>


namespace libgnss
{

Settings::Enumerator gravOrder("Motion_model", "Gravity_potential", "Order",
			       Variant::TYPE_INT,
			       "Порядок разложения гравитационного потенциала "
			       "Земли", string("20"));

Settings::Enumerator useSolidTidesLP("Motion_model", "Gravity_potential",
					 "useSolTidesLP", CTypeSelect::yesOrNo(),
				 "Учитывать долгопериодические приливные "
					 "воздействия на ГПЗ?",CTypeSelect::yes());

Settings::Enumerator useSolidTidesD("Motion_model", "Gravity_potential",
					 "useSolTidesD", CTypeSelect::yesOrNo(),
				 "Учитывать суточные приливные "
					 "воздействия на ГПЗ?",CTypeSelect::yes());

Settings::Enumerator useSolidTidesSP("Motion_model", "Gravity_potential",
					 "useSolTidesSD", CTypeSelect::yesOrNo(),
				 "Учитывать полусуточные приливные "
					 "воздействия на ГПЗ?",CTypeSelect::yes());

Settings::Enumerator useOceanTides("Motion_model", "Gravity_potential",
					 "useOceanTides", CTypeSelect::yesOrNo(),
				 "Учитывать океанические приливные "
					 "воздействия на ГПЗ?",CTypeSelect::yes());

Settings::Enumerator useOceanPoleTides("Motion_model", "Gravity_potential",
					 "useOceanPoleTides", CTypeSelect::yesOrNo(),
				 "Учитывать полюсные океанические приливные "
					 "воздействия на ГПЗ?",CTypeSelect::yes());


GravityPotential::GravityPotential(DBTableCollection *base)
	: DBTable(Columns()<<Column(Variant::TYPE_INT, "n")
			  <<Column(Variant::TYPE_INT, "m"),
		  Columns()<<Column(Variant::TYPE_DOUBLE, "c")
			  <<Column(Variant::TYPE_DOUBLE, "s"))
{
	base->addTable("gravity_potential",this);
	dataPrepared = false;
	solidTidesLP = false;
	solidTidesD = false;
	solidTidesSD = false;
	oceanTides = false;
	oceanPoleTides = false;
	Base = base;
}

GravityPotential::~GravityPotential()
{
	destroyGeopotData();
}


LongperiodSolidTides::LongperiodSolidTides(DBTableCollection *base)
	: DBTable(Columns()<<Column(Variant::TYPE_DOUBLE, "freq")
			   <<Column(Variant::TYPE_INT, "nj_l")
			   <<Column(Variant::TYPE_INT, "nj_lp")
			   <<Column(Variant::TYPE_INT, "nj_f")
			   <<Column(Variant::TYPE_INT, "nj_d")
			   <<Column(Variant::TYPE_INT, "nj_om"),
		 Columns()<<Column(Variant::TYPE_DOUBLE, "ampl_in0")
			   <<Column(Variant::TYPE_DOUBLE, "ampl_out0")
			     )
{
	base->addTable("solid_tides_longperiod",this);
}

DiurnalSolidTides::DiurnalSolidTides(DBTableCollection *base)
	: DBTable(Columns()<<Column(Variant::TYPE_DOUBLE, "freq")
			  <<Column(Variant::TYPE_INT, "nj_l")
			  <<Column(Variant::TYPE_INT, "nj_lp")
			  <<Column(Variant::TYPE_INT, "nj_f")
			  <<Column(Variant::TYPE_INT, "nj_d")
			  <<Column(Variant::TYPE_INT, "nj_om"),
		Columns()<<Column(Variant::TYPE_DOUBLE, "ampl_in1")
			   <<Column(Variant::TYPE_DOUBLE, "ampl_out1")
			     )
{
	base->addTable("solid_tides_diurnal",this);
}

SemidiurnalSolidTides::SemidiurnalSolidTides(DBTableCollection *base)
	: DBTable(Columns()<<Column(Variant::TYPE_DOUBLE, "freq")
			  <<Column(Variant::TYPE_INT, "nj_l")
			  <<Column(Variant::TYPE_INT, "nj_lp")
			  <<Column(Variant::TYPE_INT, "nj_f")
			  <<Column(Variant::TYPE_INT, "nj_d")
			  <<Column(Variant::TYPE_INT, "nj_om"),
		Columns()<<Column(Variant::TYPE_DOUBLE, "ampl_2")
			     )
{
	base->addTable("solid_tides_semidiurnal",this);
}

OceanTides::OceanTides(DBTableCollection *base)
	: DBTable(Columns()<<Column(Variant::TYPE_INT, "doodson0")
			   <<Column(Variant::TYPE_INT, "doodson1m5")
			   <<Column(Variant::TYPE_INT, "doodson2m5")
			   <<Column(Variant::TYPE_INT, "doodson3m5")
			   <<Column(Variant::TYPE_INT, "doodson4m5")
			   <<Column(Variant::TYPE_INT, "doodson5m5")
			   <<Column(Variant::TYPE_INT, "m")
			   <<Column(Variant::TYPE_INT, "n"),
		  Columns()<<Column(Variant::TYPE_DOUBLE, "delc_plus")
			   <<Column(Variant::TYPE_DOUBLE, "dels_plus")
			   <<Column(Variant::TYPE_DOUBLE, "delc_minus")
			   <<Column(Variant::TYPE_DOUBLE, "dels_minus"))
{
	base->addTable("ocean_tides",this);
}

OceanPoleTides::OceanPoleTides(DBTableCollection *base)
	: DBTable(Columns()<<Column(Variant::TYPE_INT, "m")
			  <<Column(Variant::TYPE_INT,"n"),
		  Columns()
			  <<Column(Variant::TYPE_DOUBLE, "anm_r")
			  <<Column(Variant::TYPE_DOUBLE, "bnm_r")
			  <<Column(Variant::TYPE_DOUBLE, "anm_i")
			  <<Column(Variant::TYPE_DOUBLE, "bnm_i"))
{
	base->addTable("ocean_pole_tides", this);
}



#include <precmath.h>

/*Пприливы*/
const int GravityPotential::LT, GravityPotential::DT, GravityPotential::ST;


void GravityPotential::prepareData()
{

	if (dataPrepared == true)
		return;


//Находим нужные таблицы.
//1) Таблица настроек
	Settings * sets = (Settings *)(Base->getTable("settings"));

	bodies=(CelestialBodies *)(Base->getTable("celestial_bodies"));

	//Загрузка настроек
	Nmax = sets->getSettings(gravOrder).toInt();
	solidTidesLP = (sets->getSettings(useSolidTidesLP)==CTypeSelect::yes());
	solidTidesD = (sets->getSettings(useSolidTidesD)==CTypeSelect::yes());
	solidTidesSD = (sets->getSettings(useSolidTidesSP)==CTypeSelect::yes());
	oceanTides = (sets->getSettings(useOceanTides)==CTypeSelect::yes());
	oceanPoleTides = (sets->getSettings(useOceanPoleTides)==CTypeSelect::yes());
	erps = (ERPStorage*)(Base->getTable("ERP"));

	//Выделение памяти под коэффициенты
	CoefficientsCnm=new double*[Nmax+2],CoefficientsSnm=new double*[Nmax+2];
	//double temp;
	CoefficientsCnm[0]=new double[1]; CoefficientsCnm[1]=new double[2];
	CoefficientsSnm[0]=new double[1]; CoefficientsSnm[1]=new double[2];
	for(int n=2; n<=Nmax+1; ++n)
	{
		CoefficientsCnm[n]=new double[n+1];
		CoefficientsSnm[n]=new double[n+1];
	}

	//Заполнить коэффициенты из таблицы
	CoefficientsCnm[0][0]=CoefficientsCnm[1][0]=CoefficientsCnm[1][1]=0;
	CoefficientsSnm[0][0]=CoefficientsSnm[1][0]=CoefficientsSnm[1][1]=0;

	for (DBConstIterator it0 = const_begin(); it0!=const_end(); ++it0)
	{
		int N = it0.keyColumnValue(0).toInt();
		int M = it0.keyColumnValue(1).toInt();
		if (N>=Nmax+2)
			continue;
		if (M>=N+1)
			continue;
		CoefficientsCnm[N][M] = it0[0].toDouble();
		CoefficientsSnm[N][M] = it0[1].toDouble();
	}

	//Твердотельные долгопериодические приливы
	if (solidTidesLP)
	{
		LongperiodSolidTides * lstides = (LongperiodSolidTides *)
			(Base->getTable("solid_tides_longperiod"));

		int i=0;
		for (DBConstIterator it0=lstides->const_begin();
		     it0!=lstides->const_end(); it0++)
		{
			for (int j=0; j<5; ++j)
				N_f20[i][j]=it0.keyColumnValue(j+1).toDouble();

			inA0[i] = it0[0].toDouble();
			outA0[i] = it0[1].toDouble();
			i++;
			if (i>LT)
				break;
		}
	}

	//Суточные приливы
	if (solidTidesD)
	{
		DiurnalSolidTides * dtides = (DiurnalSolidTides *)
			(Base->getTable("solid_tides_diurnal"));

		int i=0;
		for (DBConstIterator it0=dtides->const_begin();
		     it0!=dtides->const_end(); it0++)
		{
			for (int j=0; j<5; ++j)
				N_f21[i][j]=it0.keyColumnValue(j+1).toDouble();

			inA1[i] = it0[0].toDouble();
			outA1[i] = it0[1].toDouble();
			i++;
			if (i>DT)
				break;
		}
	}

	//Полусуточные приливы
	if (solidTidesSD)
	{
		SemidiurnalSolidTides * sdtides = (SemidiurnalSolidTides *)
			(Base->getTable("solid_tides_semidiurnal"));
		int i=0;
		for (DBConstIterator it0=sdtides->const_begin();
		     it0!=sdtides->const_end(); it0++)
		{
			for (int j=0; j<5; ++j)
				N_f22[i][j]=it0.keyColumnValue(j+1).toDouble();
			A2[i] = it0[0].toDouble();
			i++;
			if (i>DT)
				break;
		}

	}

	//Океанические приливы
	if (oceanTides)
	{
		Nmax_ocean=Nmax/4;
		OceanTides * otides = (OceanTides *)
				(Base->getTable("ocean_tides"));
		harmonic_Amplitudes = new Harmonic_Amplitudes[otides->count()];
		Num = 0;
		for (DBConstIterator it = otides->const_begin();
						it!=otides->const_end(); ++it)
		{
			int n_ = it.keyColumnValue(6).toInt();
			int m_ = it.keyColumnValue(7).toInt();
			if ((n_>Nmax_ocean) || (m_> Nmax_ocean))
				continue;
			for (unsigned int i=0; i<6; i++)
				harmonic_Amplitudes[Num].Doodson[i] =
						it.keyColumnValue(i).toInt();
			harmonic_Amplitudes[Num].n=it.keyColumnValue(6).toInt();
			harmonic_Amplitudes[Num].m=it.keyColumnValue(7).toInt();
			harmonic_Amplitudes[Num].DelC_plus = it[0].toDouble();
			harmonic_Amplitudes[Num].DelS_plus = it[1].toDouble();
			harmonic_Amplitudes[Num].DelC_minus = it[2].toDouble();
			harmonic_Amplitudes[Num].DelS_minus = it[3].toDouble();
			Num++;
		}
	}

	//Полюсные океанические приливы
	if (oceanPoleTides)
	{
		OceanPoleTides * optides = (OceanPoleTides *)
				(Base->getTable("ocean_pole_tides"));
		Anm_R=new double*[Nmax+1];Anm_I=new double*[Nmax+1];
		Bnm_R=new double*[Nmax+1];Bnm_I=new double*[Nmax+1];
		Anm_R[0]=0; Bnm_R[0]=0;Anm_I[0]=0; Bnm_I[0]=0;
		for(int n=1; n<=Nmax; ++n){
			Anm_R[n]=new double[n+1];
			Anm_I[n]=new double[n+1];
			Bnm_R[n]=new double[n+1];
			Bnm_I[n]=new double[n+1];
		}

		for (DBConstIterator it = optides->const_begin();
					it!=optides->const_end(); ++it)
		{
			int n = it.keyColumnValue(0).toInt();
			int m = it.keyColumnValue(1).toInt();
			if ((n>Nmax)||(m>Nmax))
				continue;
			Anm_R[n][m] = it[0].toDouble();
			Bnm_R[n][m] = it[1].toDouble();
			Anm_I[n][m] = it[2].toDouble();
			Bnm_I[n][m] = it[3].toDouble();
		}

	}

	if(Nmax<=0) return;
	//Выделение памяти под временные коэффициенты (зависят от момента времени)
	Cnm=new double*[Nmax+2], Snm=new double*[Nmax+2];
	Cnm[0]=new double[1]; Cnm[1]=new double[2];
	Snm[0]=new double[1]; Snm[1]=new double[2];
	for(int n=2; n<=Nmax+1; ++n)
	{
		Cnm[n]=new double[n+1];
		Snm[n]=new double[n+1];
	}

	//double a[] = {10000.0,15000.0,12000.0};
	//kinematic<coord,3,descartesEarth> res = gradient(kinematic<coord,3,descartesEarth>(&(a[0])),0.0);
	//cout.precision(15);
	//cout<<res[0]<<";"<<res[1]<<";"<<res[2]<<endl;
	//loaded = true;
	Pcos=new double*[Nmax+2], Psin=new double*[Nmax+2];
	for(int n=0; n<=Nmax+1; ++n)
	{
		Pcos[n]=new double[n+1];
		Psin[n]=new double[n+1];
	}

	dataPrepared=true;
}

void GravityPotential::destroyGeopotData()
{
	if (dataPrepared == false)
		return;
	if(Nmax<=0) return;

	/* Удаление памяти, ранее выделенной под массив коэффициентов модели EGM2008	*/
	for(int n=0; n<=Nmax+1; ++n){
		delete[] CoefficientsCnm[n];
		delete[] CoefficientsSnm[n];
	}
	delete[] CoefficientsCnm;
	delete[] CoefficientsSnm;

	delete[] harmonic_Amplitudes;
	
	/* Удаление памяти, ранее выделенной для данных по полюсным океаническим приливам	*/
	for(int n=1; n<=Nmax; ++n){
		delete[] Anm_R[n];
		delete[] Anm_I[n];
		delete[] Bnm_R[n];
		delete[] Bnm_I[n];
	}
	delete[] Anm_R;
	delete[] Anm_I;
	delete[] Bnm_R;
	delete[] Bnm_I;

	if(Nmax<=0) return;

	int n;
	/* Удаление массивов Pcos[n][m] и Psin[n][m] 	*/
	for(n=0; n<=Nmax+1; ++n){
		delete[] Pcos[n];
		delete[] Psin[n];
	}
	delete[] Pcos;
	delete[] Psin;

	/* Удаление памяти, ранее выделенной под массив временных коэффициентов модели EGM2008	*/
	for(n=0; n<=Nmax+1; ++n){
		delete[] Cnm[n];
		delete[] Snm[n];
	}
	delete[] Cnm;
	delete[] Snm;

	
	dataPrepared=false;
}

/* Функция вычисляет поправки к градиенту потенциала Земли в виде суммы сферических функций, км/с^2.
*  Происходит вычисление нормированной присоединённой функции Лежандра, умноженной на cos и sin
*  по рекуррентным формулам Cunningham-ма, развернутыми в цикл.
*  Значения заносятся в массивы Pcos[n][m] и Psin[n][m]. Далее рассчитываются поправки к градиенту потенциала
 * (все формулы см. в файле Equation.pdf, указанные номера формул соответствуют номерам формул Каннингема)
*/
kinematic<real,3,defaultNonInert> GravityPotential::gradient(const kinematic<real,3,defaultNonInert>&in, real t) const
{	
	((GravityPotential*)(this))->prepareData();
	if(Nmax<=0)
	{
		kinematic<real,3,defaultNonInert> result;
		result[0] = 0.0;
		result[1] = 0.0;
		result[2] = 0.0;
		return result;
	}

	//! Копирование значений коэффициентов разложения гравитационного потенциала, для дальнейшей модификации поправками, зависящими от текущего момента времени t.
	//Копируем значения коэффициентов разложения гравитационного потенциала, для дальнейшей модификации воздействиями от приливов
	//Cnm[0][0]=CoefficientsCnm[0][0]; Cnm[1][0]=CoefficientsCnm[1][0]=new double[2];
	//Snm[0][0]=CoefficientsSnm[0][0]; SnmCoefficientsSnm[1]=new double[2];
	for(int i=0; i<=Nmax+1;++i){
		memcpy(Cnm[i],CoefficientsCnm[i], sizeof(double)*(i+1));
		memcpy(Snm[i],CoefficientsSnm[i], sizeof(double)*(i+1));
	}	

	//! В коэффициенты разложения гравитационного потенциала (модель EGM2008) вносятся поправки, зависящие от текущего момента времени t.
	// Внесение поправки в коэффициенты разложение гравитационного потенциала от приливов
	if (solidTidesLP||solidTidesD||solidTidesSD||oceanTides||oceanPoleTides)
		((GravityPotential*)(this))->TideContribution(t);
	
	/** Находится градиент возмущения гравитационного потенциала Земли, представленный в виде суммы сферических функций:
	* <UL>
	*	 <LI> По рекуррентным формулам Каннингема, развернутыми в цикл вычисляются нормированные присоединённые функции Лежандра, умноженные на cos и sin.
	*	<LI> Вычисляется возмущение градиента потенциала в точке, метод возвращает полученное значение.
	* </UL>
	*/
	real x = in[0];
	real y = in[1];
	real z = in[2];

	//cout<<"Coords:"<<x<<" "<<y<<" "<<z<<endl;

	/* Данные для системы координат WSG 84 */
	const real gravityConstant =GM_WGS84; //398600.4415; //! Гравитационный параметр Земли км^3/c^2
	const real earthSemiaxis = a_WGS84;//6378.1363; //! большая полуось км/с
	real r = sqrt(x*x+y*y+z*z); // расстояние до центра масс Земли
	int n, m; // степень и  порядок


	/* Непосредственные вычисления Pcos[n][m] и Psin[n][m]*/
	/* исходные значения Pcos и Psin по формуле (15) для n=m=0 	*/
	Pcos[0][0]=1.;
	Psin[0][0]=0.;

	/*можно рассчитать заранее*/
	real coef, coef2; // Коэффициент, используемый при нормировке

	/* Вычисление значение Pcos и Psin по формуле (14) для n=m */
	for(n=1; n<=Nmax+1; ++n){
		if(n==1) coef = sqrt(3.)/r;
		else coef = sqrt(1. + 0.5/n)/r;

		Pcos[n][n]=coef*(x*Pcos[n-1][n-1] - y*Psin[n-1][n-1]);
		Psin[n][n]=coef*(y*Pcos[n-1][n-1] + x*Psin[n-1][n-1]);
		//cout<<n<<"\t Pcos[n][n]="<<Pcos[n][n]<<"\t Psin[n][n]="<<Psin[n][n]<<endl;
	}

	/* можно вставить предыдущий цикл*/
	/* Вычисление значение Pcos и Psin по формуле (17) для n=m+1*/
	for(n=1; n<=Nmax+1; ++n){
		coef2=sqrt(2.*n+1)*z/r;
		Pcos[n][n-1]=coef2*Pcos[n-1][n-1];
		Psin[n][n-1]=coef2*Psin[n-1][n-1];
		//cout<<n<<"\t Pcos[n][n-1]="<<Pcos[n][n-1]<<"\t Psin[n][n-1]="<<Psin[n][n-1]<<endl;
	}

	/* Вычисление значение Pcos и Psin по формуле (16) для n>=m+2*/
	//	m=1;
	for(m=0;m<Nmax;++m){
		for(int i=m+2;i<=Nmax+1; ++i){
			coef=sqrt((4.*i*i-1)/(i*i-m*m))*z/r;
			coef2=sqrt((i-m-1.)*(i+m-1)*(2.*i+1)/(i*i-m*m)/(2*i-3));

			Pcos[i][m]=coef*Pcos[i-1][m]-coef2*Pcos[i-2][m];
			Psin[i][m]=coef*Psin[i-1][m]-coef2*Psin[i-2][m];
			//cout<<i<<"\t Pcos[i][m]="<<Pcos[i][m]<<"\t Psin[i][m]="<<Psin[i][m]<<endl;
		}
	}

	//cout<<"Psins and Pcos's prepared"<<endl;

	/* Вычисление градиента потенциала */
	kinematic<real,3,defaultNonInert> gradV;
	gradV[0]=0; gradV[1]=0; gradV[2]=0;
	real gradVx, gradVy, gradVz;
	real DxPcos,DxPsin,DyPcos,DyPsin,DzPcos,DzPsin;

	int k1;
	for(n=Nmax; n>=2; --n){ //можно начинать суммирование с n=2, т.к. до этого все коэффициенты равны нулю
		gradVx=0; gradVy=0; gradVz=0;
		for(m=n; m>=0; --m){
			//cout<<"(n,m)=("<<n<<","<<m<<")"<<endl;
			if(m==1) k1=2;
			else k1=1;

			if(m==0){
				coef=-1.*sqrt(0.5*(2.*n+1)*(n+1)*(n+2)/(2.*n+3));
				DxPcos=coef*Pcos[n+1][1];
				DxPsin=0;
				DyPcos=coef*Psin[n+1][1];
				DyPsin=0;
				//cout<<"Done for m==0"<<endl;
			}
			else{
				coef=0.5*sqrt((n+m+1.)*(n+m+2.)*(2.*n+1)/(2.*n+3));
				coef2=0.5*sqrt((n-m+1.)*(n-m+2.)*(2.*n+1)*k1/(2.*n+3));
				DxPcos=(-1.*coef*Pcos[n+1][m+1]+coef2*Pcos[n+1][m-1]);
				DxPsin=(-1.*coef*Psin[n+1][m+1]+coef2*Psin[n+1][m-1]);
				DyPcos=(-1.*coef*Psin[n+1][m+1]-coef2*Psin[n+1][m-1]);
				DyPsin=(coef*Pcos[n+1][m+1]+coef2*Pcos[n+1][m-1]);
			}

			coef=-1.*sqrt((n-m+1.)*(n+m+1.)*(2.*n+1)/(2*n+3));
			DzPcos=coef*Pcos[n+1][m];
			DzPsin=coef*Psin[n+1][m];

			//cout<<"Done DzPcos, DzPsin"<<endl;

			/* Прибавление очередного слагаемого к сумме от m=0 до n*/
			gradVx+=Cnm[n][m]*DxPcos+Snm[n][m]*DxPsin;
			gradVy+=Cnm[n][m]*DyPcos+Snm[n][m]*DyPsin;
			gradVz+=Cnm[n][m]*DzPcos+Snm[n][m]*DzPsin;

		}
		//cout<<"Done for all m"<<endl;
		/* Умножение суммы от m=0 до n на (a/r)^n и прибавление этого слагаемого к сумме от n=0 до Nmax*/
		//! @todo При замене типа maxprec убедиться, что эти функции для него реализованы
		double esa = earthSemiaxis;
		//cout<<"Earth semiaxis = "<<esa<<"  r="<<r<<"  n="<<n<<endl;
		coef=exp(log(esa/r)*n);
		//cout<<"Done const!"<<endl;
		gradV[0]+=coef*gradVx;
		gradV[1]+=coef*gradVy;
		gradV[2]+=coef*gradVz;
	}
	/* Умножение общей двойной суммы (от n=0 до Nmax, m=0 до n) на GM/r^2*/
	coef=gravityConstant/(x*x+y*y+z*z);
	gradV[0]*=coef;
	gradV[1]*=coef;
	gradV[2]*=coef;


	/* Возвращение результатов расчётов */
	return gradV;

}

/* Функция вычисляет поправки к потенциалу Земли в виде суммы сферических функций.*/
real GravityPotential::value(const kinematic<real,3,defaultNonInert> & in, real t)
{
	prepareData();
	if(Nmax<=1) return 0;

	for(int i=0; i<=Nmax+1;++i){
		memcpy(Cnm[i],CoefficientsCnm[i], sizeof(double)*(i+1));
		memcpy(Snm[i],CoefficientsSnm[i], sizeof(double)*(i+1));
	}	

	//! В коэффициенты разложения гравитационного потенциала (модель EGM2008) вносятся поправки, зависящие от текущего момента времени t.
	// Внесение поправки в коэффициенты разложение гравитационного потенциала от приливов
	TideContribution(t);

	/** Находится возмущение гравитационного потенциала Земли, представленное в виде суммы сферических функций:
	* <UL>
	*	 <LI> По рекуррентным формулам Каннингема, развернутыми в цикл вычисляются нормированные присоединённые функции Лежандра, умноженные на cos и sin.
	*	<LI> Вычисляется возмущение потенциала в точке, метод возвращает полученное значение.
	* </UL>
	*/
	real x = in[0];
	real y = in[1];
	real z = in[2];

	/* Данные для системы координат WSG 84 */
	/* Данные для системы координат WSG 84 */
	const real gravityConstant =GM_WGS84; //398600.4415; //! Гравитационный параметр Земли км^3/c^2
	const real earthSemiaxis = a_WGS84;//6378.1363; //! большая полуось км/с
	real r = sqrt(x*x+y*y+z*z); // расстояние до центра масс Земли
	int n, m; // степень и  порядок


	/* Непосредственные вычисления Pcos[n][m] и Psin[n][m]*/
	/* исходные значения Pcos и Psin по формуле (15) для n=m=0 */
	Pcos[0][0]=1.;
	Psin[0][0]=0.;

	/*можно рассчитать заранее*/
	real coef, coef2; // Коэффициент, используемый при нормировке

	/* Вычисление значение Pcos и Psin по формуле (14) для n=m */
	for(n=1; n<=Nmax; ++n){
		if(n==1) coef = sqrt(3.)/r;
		else coef = sqrt(1. + 0.5/n)/r;

		Pcos[n][n]=coef*(x*Pcos[n-1][n-1] - y*Psin[n-1][n-1]);
		Psin[n][n]=coef*(y*Pcos[n-1][n-1] + x*Psin[n-1][n-1]);
		//cout<<n<<"\t Pcos[n][n]="<<Pcos[n][n]<<"\t Psin[n][n]="<<Psin[n][n]<<endl;
	}

	/* можно вставить предыдущий цикл*/
	/* Вычисление значение Pcos и Psin по формуле (17) для n=m+1*/
	for(n=1; n<=Nmax; ++n){
		coef2=sqrt(2.*n+1)*z/r;
		Pcos[n][n-1]=coef2*Pcos[n-1][n-1];
		Psin[n][n-1]=coef2*Psin[n-1][n-1];
		//cout<<n<<"\t Pcos[n][n-1]="<<Pcos[n][n-1]<<"\t Psin[n][n-1]="<<Psin[n][n-1]<<endl;
	}

	/* Вычисление значение Pcos и Psin по формуле (16) для n>=m+2*/
	//	m=1;
	for(m=0;m<Nmax;++m){
		for(int i=m+2;i<=Nmax; ++i){
			coef=sqrt((4.*i*i-1)/(i*i-m*m))*z/r;
			coef2=sqrt((i-m-1.)*(i+m-1)*(2.*i+1)/(i*i-m*m)/(2*i-3));

			Pcos[i][m]=coef*Pcos[i-1][m]-coef2*Pcos[i-2][m];
			Psin[i][m]=coef*Psin[i-1][m]-coef2*Psin[i-2][m];
			//cout<<i<<"\t Pcos[i][m]="<<Pcos[i][m]<<"\t Psin[i][m]="<<Psin[i][m]<<endl;
		}
	}

	//cout<<"Psins and Pcos's prepared"<<endl;

	/* Вычисление потенциала */
	real V=0, Vt;

	//int k1;
	for(n=Nmax; n>=2; --n){
		Vt=0;
		for(m=n; m>=0; --m){
			Vt+=Cnm[n][m]*Pcos[n][m]+Snm[n][m]*Psin[n][m];
		}

		//cout<<"Done for all m"<<m<<endl;
		/* Умножение суммы от m=0 до n на (a/r)^n и прибавление этого слагаемого к сумме от n=0 до Nmax*/
		//! @todo При замене типа maxprec убедиться, что эти функции для него реализованы
		V+=Vt*exp(log(earthSemiaxis/r)*n);
	}
	/* Умножение общей двойной суммы (от n=0 до Nmax, m=0 до n) на GM/r^2*/
	V*=gravityConstant/r;

	/* Возвращение результатов расчётов */
	return V;
}

/* Функция вычисление возмущения гравитационного потенциала под влиянием твердотельных приливов. */
void GravityPotential::SolidTideContribution(real t){

	//! @todo Заменить все double на maxprec, где это целесообразно

	/*Данные таблицы 1 (файл SolidTideContribution.pdf). Номинальные значения чисел Лява
	*  для потенциала, обусловленного приливами в твёрдом теле Земли (используется модель эластичной Земли).
	*/
	//! @todo Возможно, эти значения можно занести в БД
	const double
		LoveNumbers_n2[3]={0.29525,  0.29470, 0.29801},
		LoveNumbers_n3[4]={0.093, 0.093, 0.093, 0.094},
		LoveNumbersP_n2[3]={-0.00087,-0.00079,-0.00057};

	//! @todo убедиться, что всё в одной системе координат, вращающейся с Землёй (WGS84 или др.)
	//Получить координаты планеты  в данный момент времени в инерциальной системе координат



	//ChCoordSys * erps = new ChCoordSys(&(base->getParameterState()));
		
	//Координаты Луны в инерциальной системе
	kinematic<real,3,defaultInert> moonPosInert = getCelestialBodyEphemerides(10, t);
	kinematic<real, 3, defaultNonInert> coord_Moon=erps->GCRStoITRF(moonPosInert, t);
	//Координаты Солнца в инерциальной системе
	kinematic<real,3,defaultInert> sunPosInert = getCelestialBodyEphemerides(11, t);
	kinematic<real, 3, defaultNonInert> coord_Sun=erps->GCRStoITRF(sunPosInert, t);

	real x_Moon=coord_Moon[0],y_Moon=coord_Moon[1],z_Moon=coord_Moon[2];
	real x_Sun=coord_Sun[0], y_Sun=coord_Sun[1], z_Sun=coord_Sun[2];

	real r_Moon=coord_Moon.length<0,2>(); // Расстояние от центра Земли до Луны
	real r_Sun=coord_Sun.length<0,2>(); // Расстояние от центра Земли до Солнца

	//Экваториальный радиус Земли, км. (6378.1363)
	const real Re=bodies->getBodyRadius(3);

	//Гравитационный параметр Земли, км^3/c^2. (3.986004418e5)
	const real GM_Earth = bodies->getBodyGravParameter(3);

	//Гравитационный параметр Луны и Солнца, км^3/c^2. (4902.799186)
	const real GM_Moon=bodies->getBodyGravParameter(10);

	//Гравитационный параметр Солнца, км^3/c^2. (132712400000.)
	const real GM_Sun=bodies->getBodyGravParameter(11);

	int n,m; // Степень и порядок

	//! @todo Вынести выделение памяти в конструктор, а здесь вставить зануление
/* Вычисление нормированной присоединённой функции Лежандра, умноженной на cos и sin */
	int Nmax=3; // Необходимая степень полинома Лежандра
	real **Pcos_Moon=new real*[Nmax+1], **Psin_Moon=new real*[Nmax+1];
	real **Pcos_Sun=new real*[Nmax+1], **Psin_Sun=new real*[Nmax+1];
	for(n=0; n<=Nmax; ++n){
		Pcos_Moon[n]=new real[n+1]; Psin_Moon[n]=new real[n+1];
		Pcos_Sun[n]=new real[n+1]; Psin_Sun[n]=new real[n+1];
	}

	real x_Moon_r=x_Moon/r_Moon, y_Moon_r=y_Moon/r_Moon, z_Moon_r=z_Moon/r_Moon;
	real x_Sun_r=x_Sun/r_Sun, y_Sun_r=y_Sun/r_Sun, z_Sun_r=z_Sun/r_Sun;
	// вспомогательные переменные, для уменьшения кол-ва вычислений
	real coef, coef2;

	double dC2[3], dS2[3]={0}; //C20, C21, C22, S20, S21, S22
	double dC3[4], dS3[4]={0}; //C30, C31, C32,C33, S30, S31, S32, S33
	double dC4[3], dS4[3]; //C40, C41, C42, S40, S41, S42


	//Первый шаг расчётов
	/* Исходные значения Pcos и Psin по формуле (15) для n=m=0 */
	Pcos_Moon[0][0]=1.; Psin_Moon[0][0]=0.;
	Pcos_Sun[0][0]=1.; Psin_Sun[0][0]=0.;

	/* Вычисление значение Pcos и Psin по формуле (14) для n=m */
	for(n=1; n<=Nmax; ++n){
		if(n==1) coef = sqrt(3.);
		else coef = sqrt(1. + 0.5/n);

		Pcos_Moon[n][n]=coef*(x_Moon_r*Pcos_Moon[n-1][n-1] - y_Moon_r*Psin_Moon[n-1][n-1]);
		Psin_Moon[n][n]=coef*(y_Moon_r*Pcos_Moon[n-1][n-1] + x_Moon_r*Psin_Moon[n-1][n-1]);

		Pcos_Sun[n][n]=coef*(x_Sun_r*Pcos_Sun[n-1][n-1] - y_Sun_r*Psin_Sun[n-1][n-1]);
		Psin_Sun[n][n]=coef*(y_Sun_r*Pcos_Sun[n-1][n-1] + x_Sun_r*Psin_Sun[n-1][n-1]);
	}

	/* Вычисление значение Pcos и Psin по формуле (17) для n=m+1*/
	for(n=1; n<=Nmax; ++n){
		coef2=sqrt(2.*n+1)*z_Moon_r;
		Pcos_Moon[n][n-1]=coef2*Pcos_Moon[n-1][n-1];
		Psin_Moon[n][n-1]=coef2*Psin_Moon[n-1][n-1];

		coef2=sqrt(2.*n+1)*z_Sun_r;
		Pcos_Sun[n][n-1]=coef2*Pcos_Sun[n-1][n-1];
		Psin_Sun[n][n-1]=coef2*Psin_Sun[n-1][n-1];
	}

	/* Вычисление значение Pcos и Psin по формуле (16) для n>=m+2*/
	for(m=0;m<=Nmax-2;++m){
		for(int i=m+2;i<=Nmax; ++i){
			coef=sqrt((4.*i*i-1)/(i*i-m*m))*z_Moon_r;
			coef2=sqrt((i-m-1.)*(i+m-1)*(2.*i+1)/(i*i-m*m)/(2*i-3));

			Pcos_Moon[i][m]=coef*Pcos_Moon[i-1][m]-coef2*Pcos_Moon[i-2][m];
			Psin_Moon[i][m]=coef*Psin_Moon[i-1][m]-coef2*Psin_Moon[i-2][m];

			coef=sqrt((4.*i*i-1)/(i*i-m*m))*z_Sun_r;

			Pcos_Sun[i][m]=coef*Pcos_Sun[i-1][m]-coef2*Pcos_Sun[i-2][m];
			Psin_Sun[i][m]=coef*Psin_Sun[i-1][m]-coef2*Psin_Sun[i-2][m];
		}
	}


	coef=Re/r_Moon; coef=coef*coef*coef;
	coef2=Re/r_Sun; coef2=coef2*coef2*coef2;
	/*Формула (1a) и (1b) из SolidTideContribution.pdf, для n=2, m={0,1,2}*/
	for(m=0;m<=2;++m){
		dC2[m]=LoveNumbers_n2[m]*0.2*(GM_Moon*coef*Pcos_Moon[2][m] + GM_Sun*coef2*Pcos_Sun[2][m] )/GM_Earth;
		//cout<<Re/r_Moon*Re/r_Moon*Re/r_Moon<<" "<<coef<<endl<<endl;
	}
	//dS2[0], dS30[0] - уже равны нулю при инициализации
	for(m=1;m<=2;++m){
		dS2[m]=LoveNumbers_n2[m]*0.2*(GM_Moon*coef*Psin_Moon[2][m] + GM_Sun*coef2*Psin_Sun[2][m] )/GM_Earth;
	}

	/*Формула (2a) и (2b) из SolidTideContribution.pdf, для n=4, m={0,1,2}*/
	for(m=0;m<=2;++m){
		dC4[m]=LoveNumbersP_n2[m]*0.2*(GM_Moon*coef*Pcos_Moon[2][m] + GM_Sun*coef2*Pcos_Sun[2][m] )/GM_Earth;
		dS4[m]=LoveNumbersP_n2[m]*0.2*(GM_Moon*coef*Psin_Moon[2][m] + GM_Sun*coef2*Psin_Sun[2][m] )/GM_Earth;
	}

	/*Формула (1a) и (1b) из SolidTideContribution.pdf, для n=3, m={0,1,2,3}*/
	coef*=Re/r_Moon;
	coef2*=Re/r_Sun;
	for(m=0;m<=3;++m){
		dC3[m]=LoveNumbers_n3[m]*(GM_Moon*coef*Pcos_Moon[3][m] + GM_Sun*coef2*Pcos_Sun[3][m] )/(GM_Earth*7.);
	}
	for(m=1;m<=3;++m){
		dS3[m]=LoveNumbers_n3[m]*(GM_Moon*coef*Psin_Moon[3][m] + GM_Sun*coef2*Psin_Sun[3][m] )/(GM_Earth*7.);
	}


	//Второй шаг расчётов
	//TT - Terestrial Time в юлианских столетиях
	double TT;
	TT=(t+32.184)/(jsecondsPerDay*jdaysPerCentury);
	/* TDB (Barycentric Dynamical Time) - барицентрическое динамическое время
	*  находится по формуле из документа "Шкалы времени.pdf" с ошибкой не больше 10 микросекунд или работы ,
	*  Kaplan G. The IAU resolutions on astronomical reference systems, time scales and Earth rotation models;
	*  это более простой вариант формулы из статьи
	*  Fairhead L., Bretagnon P. An analytical formula for the time transformation TB-TT	*
	*/
	double TDB;
	//TDB в сек.
	TDB = (t+32.184) +0.001656674564*sin( 628.3075943033*TT + 6.240054195)
		+0.000022417471*sin( 575.3384970095*TT + 4.296977442)
		+0.000013839792*sin(1256.6151886066*TT + 6.196904410)
		+0.000004770086*sin(  52.9690965095*TT + 0.444401603)
		+0.000004676740*sin( 606.9776754553*TT + 4.021195093)
		+0.000002256707*sin(  21.3299095438*TT + 5.543113262)
		+0.0000102156724*TT*sin( 628.3075849991*TT + 4.249032005);
	//TDB в юлианских столетиях
	TDB/=(jsecondsPerDay*jdaysPerCentury);

	// Фундаментальные аргументы теории нутации (l, lp, F, D, Omega).
	double F[5];
	F[0]=iauFal03(TDB);
	F[1]=iauFalp03(TDB);
	F[2]=iauFaf03(TDB);
	F[3]=iauFad03(TDB);
	F[4]=iauFaom03(TDB);

/*	F[0]=libsofa::iau_fal03_(&TDB);
	F[1]=libsofa::iau_falp03_(&TDB);
	F[2]=libsofa::iau_faf03_(&TDB);
	F[3]=libsofa::iau_fad03_(&TDB);
	F[4]=libsofa::iau_faom03_(&TDB);*/

	/* Нахождение Гринвичского среднего звёздного времени GMST, в радианах.
	* Используется функция из sofa, для которой разделение UT1 на uta+utb и  TT на tta+ttb
	* осуществляется по методу J2000
	*/
	// Используется функция getERP для нахождения ПВЗ в заданный момент времени
	//! @todo Проверить, что получается правильное значение
	//getERP(double t, double&pm_x, double&pm_y, double&ut1_utc, double&dx, double&dy, const ParameterState & ps);
	double pm_x, pm_y, tai_ut1, dx, dy, d1, d2, d3;
	//const ParameterState *ps=base->getControl()->getParameterState(	base->getThreadParams().integrateJob_id, base->getThreadParams().template_idx);
	erps->getERP(pm_x, pm_y, tai_ut1, dx, dy, d1, d2, d3, t);
	TT=(t+32.184)/jsecondsPerDay; //TT в юлианских сутках
	
	double tt2=TT;

	double utb = (t-tai_ut1)/jsecondsPerDay;
	
	//Значение в радианах
	/** @todo По формуле theta_g должна быть в градусах, проверить это и согласовать все единицы измерения.
	* На данный момент всё в радианах, в этих ед. измерения должен получать аргумент cos и sin из math.h
	*/
	double theta_g = iauGmst06(JD_J2000, utb, JD_J2000, tt2);

	/*Долгопериодические приливы*/
	double theta_f;

	/*Формула (3) из SolidTideContribution.pdf, для n=2, m=0*/
	for(int i=0; i<LT; ++i){
		theta_f=0;
		for(int j=0; j<5;++j)
			theta_f-=F[j]*N_f20[i][j];
		//Если theta_f в градусах - переводим в радианы для cos и sin
		//theta_f*=Pi/180.;

		dC2[0]+=inA0[i]*cos(theta_f)-outA0[i]*sin(theta_f);
	}

	/*Суточные приливы*/
	/*Формула (4a) и (4b) из SolidTideContribution.pdf, для n=2, m=1*/
	for(int i=0; i<DT; ++i){
		theta_f=theta_g+Pi;
		//theta_f=theta_g*180./Pi+180;
		for(int j=0; j<5;++j)
			theta_f-=F[j]*N_f21[i][j];
		//Если theta_f в градусах - переводим в радианы для cos и sin
		//theta_f*=Pi/180.;

		dC2[1]+=outA1[i]*cos(theta_f)+inA1[i]*sin(theta_f);
		dS2[1]+=inA1[i]*cos(theta_f)-outA1[i]*sin(theta_f);
	}

	/*Полусуточные приливы*/
	/*Формула (5a) и (5b) из SolidTideContribution.pdf, для n=2, m=2*/
	for(int i=0; i<ST; ++i){
		theta_f=0;
		for(int j=0; j<5;++j)
			theta_f-=F[j]*N_f22[i][j];
		theta_f+=(theta_g+Pi)*2.;
		//theta_f+=(theta_g*180./Pi+180)*2.;
		//Если theta_f в градусах - переводим в радианы для cos и sin
		//theta_f*=Pi/180.;

		dC2[2]+=A2[i]*cos(theta_f);
		dS2[2]-=A2[i]*sin(theta_f);
	}

	for(m=0; m<=2;++m){
		Cnm[2][m]+=dC2[m];
		Snm[2][m]+=dS2[m];

		Cnm[4][m]+=dC4[m];
		Snm[4][m]+=dS4[m];
	}

	for(m=0; m<=3;++m){
		Cnm[3][m]+=dC3[m];
		Snm[3][m]+=dS3[m];
	}

	for(n=0; n<=Nmax; ++n){
		delete[] Pcos_Moon[n];
		delete[] Pcos_Sun[n];
		delete[] Psin_Moon[n];
		delete[] Psin_Sun[n];
	}
	delete[] Pcos_Moon;
	delete[] Pcos_Sun;
	delete[] Psin_Moon;
	delete[] Psin_Sun;
	
	//delete erps;
	
	return;
}

/* Функция вычисление возмущения гравитационного потенциала под влиянием различных факторов, зависящих от времени. */
void GravityPotential::TideContribution(real t){
	
	//! Модифицируются копии коэффициентов разложения гравитационного потенциала Земли в зависимости от момента времени.

	//! @todo Заменить все double на maxprec, где это целесообразно
	//! @todo Разбить поправки на отдельные функции и сделать возможность их включения и выключения при расчетах

	/*Поправки к модели EGM2008, зависящие от времени.*/

	//!	1. Значения коэффициентов, данные на 2000 год, приводятся в соответствие с текущим моментом времени.
	/*1. Приведение коэффициентов модели гравитационного потенциала EGM2008 (даны на 2000 год) к
	 текущему моменту времени t.
	 Для расчётов используется формула (1) и табл. 1 из файла TideContribution.pdf
	Значения C30(t0) и C40(t0) берутся как стандартные коэффициенты модели EGM, а коэффициент
	C20(t0) приведен в IERS (см. табл.1).
	*/
	real TT; //Время по шкале Terestrial Time в юлианских годах c J2000
	//! @todo вместо того, чтобы писать jdaysPerCentury/100, можно ввести константу jdaysPerYear=365.25
	TT=(t+32.184)/(jsecondsPerDay*jdaysPerCentury)*100.;
	//! @todo необходимо хранить в базе данных "модифицированное" значение C20 и dCn0/dt
	Cnm[2][0]=-0.48416531e-3 + 11.6e-12*TT;
	Cnm[3][0]=Cnm[3][0]      + 4.9e-12*TT;
	Cnm[4][0]=Cnm[4][0]      +4.7e-12*TT;

	//! 2. Преобразуются коэффициенты \f$C_{21}\f$ и \f$S_{21}\f$, которые характеризуют положение оси симметрии Земли. Преобразования связаны с переходом в инерциальную систему координат из вращающейся с Землёй, для этого используются координаты усреднённого полюса.
	/*2. Преобразование коэффициентов C21 и S21, которые характеризуют положение оси симметрии Земли.
	 Для расчётов используется формула (2) из файла TideContribution.pdf.
	Координаты среднего полюса находятся по формуле (3) с использованием таблицы 2.
	*/
	real xp_mean=0, yp_mean=0; //Координаты среднего полюса в мс
	//TT определено выше - время по шкале Terestrial Time в юлианских годах c J2000
	//TT-=10.; //10 - это 2010.0 по шкале Terestrial Time в юлианских годах c J2000
	//! @todo занести значения таблицы 2 в базу данных
	double tab[4][4]={
					{55.974, 346.346, 23.513, 358.891},
					{1.8243, 1.7896, 7.6141, -0.6287},
					{0.18413, -0.10729, 0.0, 0.0},
					{0.007024, -0.000908, 0.0, 0.0}
	};
	if(	TT<10){//10 - это 2010.0 по шкале Terestrial Time в юлианских годах c J2000
		for(int i=0; i<=3;++i){
			xp_mean+=pow(TT,i)*tab[i][0];
			yp_mean+=pow(TT,i)*tab[i][1];
		}
	}
	else{
		for(int i=0; i<=3;++i){
			xp_mean+=pow(TT,i)*tab[i][2];
			yp_mean+=pow(TT,i)*tab[i][3];
		}
	}
	//Переход от мс к радианам.
	//xp_mean*=AS2R;
	//yp_mean*=AS2R;

	Cnm[2][1]=sqrt(3)*xp_mean*CoefficientsCnm[2][0]-xp_mean*CoefficientsCnm[2][2]+yp_mean*CoefficientsSnm[2][2];
	Snm[2][1]=-sqrt(3)*yp_mean*CoefficientsCnm[2][0]-yp_mean*CoefficientsCnm[2][2]-xp_mean*CoefficientsSnm[2][2];

	//Переход от мс к радианам (мс->с->рад).
	Cnm[2][1]*=1.e-3*AS2R;//Pi/6.48e6;
	Snm[2][1]*=1.e-3*AS2R;//Pi/6.48e6;

	//! @todo Возможно, надо вынести определение theta_f и theta_g из твердотельных приливов т.к.оно используется и в океанических

	//! 3. Рассчитываются поправки коэффициентов, связанные с влиянием твердотельных приливов (вызывается функция @ref SolidTideContribution).
	/*3. Влияние твердотельных приливов.*/
	//! @todo Вставить функцию SolidTideContribution; возможно, убрать в ней переменные dCnm, dSnm, и сразу изменять значения Cnm, Snm
	SolidTideContribution(t);

	//! 4. Рассчитываются поправки коэффициентов, связанные с влиянием океанических приливов.
	/*4. Влияние океанических приливов на геопотенциал Земли.
	  Для расчётов используется формула (5a) и (5b) из файла TideContribution.pdf.
	  Амплитуды гармоник потенциала предоставлены IERS (файл fes2004_Cnm-Snm.dat)
	*/

	//! @todo Следующий код дублирует код из SolidTides по нахождению thata_f
	//TT - Terestrial Time в юлианских столетиях
	//double TT;
	TT=(t+32.184)/(jsecondsPerDay*jdaysPerCentury);
	/* TDB (Barycentric Dynamical Time) - барицентрическое динамическое время
	*  находится по формуле из документа "Шкалы времени.pdf" с ошибкой не больше 10 микросекунд или работы ,
	*  Kaplan G. The IAU resolutions on astronomical reference systems, time scales and Earth rotation models;
	*  это более простой вариант формулы из статьи
	*  Fairhead L., Bretagnon P. An analytical formula for the time transformation TB-TT	*
	*/
	double TDB;
	//TDB в сек.
	TDB = t+32.184 +0.001656674564*sin( 628.3075943033*TT + 6.240054195)
		+0.000022417471*sin( 575.3384970095*TT + 4.296977442)
		+0.000013839792*sin(1256.6151886066*TT + 6.196904410)
		+0.000004770086*sin(  52.9690965095*TT + 0.444401603)
		+0.000004676740*sin( 606.9776754553*TT + 4.021195093)
		+0.000002256707*sin(  21.3299095438*TT + 5.543113262)
		+0.0000102156724*TT*sin( 628.3075849991*TT + 4.249032005);
	//TDB в юлианских столетиях
	TDB/=(jsecondsPerDay*jdaysPerCentury);

	// Фундаментальные аргументы теории нутации (l, lp, F, D, Omega), в рад.
	double F[5];

	F[0]=iauFal03(TDB);
	F[1]=iauFalp03(TDB);
	F[2]=iauFaf03(TDB);
	F[3]=iauFad03(TDB);
	F[4]=iauFaom03(TDB);

//	F[0]=libsofa::iau_fal03_(&TDB);
//	F[1]=libsofa::iau_falp03_(&TDB);
//	F[2]=libsofa::iau_faf03_(&TDB);
//	F[3]=libsofa::iau_fad03_(&TDB);
//	F[4]=libsofa::iau_faom03_(&TDB);

	/* Нахождение Гринвичского среднего звёздного времени GMST, в радианах.
	* Используется функция из sofa, для которой разделение UT1 на uta+utb и  TT на tta+ttb
	* осуществляется по методу J2000
	*/
	// Используется функция getERP для нахождения ПВЗ в заданный момент времени
	//! @todo Проверить, что получается правильное значение
	//getERP(double t, double&pm_x, double&pm_y, double&ut1_utc, double&dx, double&dy, const ParameterState & ps);
	double pm_x, pm_y, tai_ut1, dx, dy, d1, d2, d3;
	//const ParameterState *ps=base->getControl()->getParameterState(	base->getThreadParams().integrateJob_id, base->getThreadParams().template_idx);
	erps->getERP(pm_x, pm_y, tai_ut1, dx, dy, d1, d2, d3, t);
	TT=(t+32.184)/jsecondsPerDay; //TT в юлианских сутках
	
	double tt2=TT;

	double utb = (t - tai_ut1)/jsecondsPerDay;
	
	//Значение в радианах
	//! @todo По формуле theta_g должна быть в градусах, проверить это.
	double theta_g = iauGmst06(JD_J2000, utb, JD_J2000, tt2);

	//---------------------------------------
	double beta[6];
	//! @todo Проверить правильность нахождения beta[0]!
	//beta[0]=(theta_g*180./Pi+180)-(F[2]+F[4]);
	beta[0]=(theta_g+Pi)-(F[2]+F[4]);
	beta[1]=F[2]+F[4];
	beta[2]=beta[1]-F[3];
	beta[3]=beta[1]-F[0];	
	beta[4]=-1.*F[4];
	beta[5]=beta[1]-F[3]-F[1];

	double theta_f;
	for(int i=0; i<Num; ++i){

		theta_f=0;
		for(int j=0; j<6;++j)
			theta_f+=beta[j]*harmonic_Amplitudes[i].Doodson[j];
		//Если theta_f в градусах - переводим в радианы для cos и sin
		//theta_f*=Pi/180.;

		double cos_theta_f=cos(theta_f), sin_theta_f=sin(theta_f);

		Cnm[ harmonic_Amplitudes[i].n ][ harmonic_Amplitudes[i].m ]+=
		((harmonic_Amplitudes[i].DelC_plus+harmonic_Amplitudes[i].DelC_minus)*cos_theta_f+
		 (harmonic_Amplitudes[i].DelS_plus+harmonic_Amplitudes[i].DelS_minus)*sin_theta_f
		)*1e-12;
		Snm[ harmonic_Amplitudes[i].n ][ harmonic_Amplitudes[i].m ]+=
		((harmonic_Amplitudes[i].DelS_plus-harmonic_Amplitudes[i].DelS_minus)*cos_theta_f-
		 (harmonic_Amplitudes[i].DelC_plus-harmonic_Amplitudes[i].DelC_minus)*sin_theta_f
		)*1e-12;
	}

	//! 5. Рассчитываются поправки коэффициентов, связанные с влиянием твердотельного полюсного прилива.
	/*5. Влияние твердотельного полюсного прилива.
	  Для расчётов используется формула (6) из файла TideContribution.pdf.
	  m1, m2 находятся по формуле (7).
	*/
	//xp, yp - мгновенные координаты полюса, в (угловых) секундах уже получены при вызове getERP
	double xp=pm_x, yp=pm_y; //мгновенные координаты полюса, в (угловых) секундах

	double m1, m2; //параметры смещения, в угловых секундах
	m1=xp-xp_mean*1e-3;// 1e-3 - переход от мс к секундам
	m2=-(yp-yp_mean*1e-3);
	Cnm[2][1]-=1.333e-9*(m1+0.0115*m2);
	Snm[2][1]-=1.333e-9*(m2-0.0115*m1);

	//! 6. Рассчитываются поправки коэффициентов, связанные с влиянием океанического полюсного прилива.
	/*6. Влияние океанического полюсного прилива.
	  Для расчётов используется формула (8a) и (8b) из файла TideContribution.pdf.
	  Коэффициенты Anm и Bnm предоставляются IERS (файл desaiscopolecoef.txt)
	*/

	const double Omega=earthAngularVelocity; //7.292115e-5 средняя угловая скорость вращения Земли (nominal mean Earth's angular velocity), (рад/с)
	const double ae=bodies->getBodyRadius(3)*1.e3 ;//6378136.6 экваториальный радиус Земли (м)
	const double GM=bodies->getBodyGravParameter(3)*1.e9; //3.986004418e14 гравитационный параметр Земли (geocentric gravitational constant), (м^3/с^2)
	const double ge=earthEquatorialGravity; // 9.7803278 среднее экваториальное значение ускорения свободного падения (mean equatorial gravity), (м/c^2)
	double G=earthConstantOfGravitation; //6.67428e-11 гравитационная постоянная (сonstant of gravitation), (м^3/(кг c^2))
	const double rho_w=1025.; // плотность морской воды,(кг/м^3)
	const double kn_prime[7]={0.,0.,-0.3075, -0.195, -0.132, -0.1032, -0.0892};//коэффициенты деформации под действием нагрузки (load deformation coefficients)
	const double gamma2_R=0.6870, gamma2_I = 0.0036;

	// ранее рассчитаны m1 и m2 в угловых секундах, необходимо преобразовать к радианам, домножением на Pi/6.48e5
	m1*=AS2R;
	m2*=AS2R;

	//! @todo на данный момент можно рассчитать поправки только для n=2-6, т.к. нет других значений kn_prime
	double Rn, Rn_t=Omega*Omega/GM*ae*ae*ae*ae*4.*Pi*G*rho_w/ge;
	double m1g2R_plus_m2g2I=m1*gamma2_R+m2*gamma2_I,
		  m2g2R_minus_m1g2I=m2*gamma2_R-m1*gamma2_I;

	for(int n=2; n<=min(Nmax,6);++n){
		Rn=Rn_t*(1.+kn_prime[n])/(2.*n+1.);
		for(int m=0; m<=n;++m){
			Cnm[n][m]+=Rn*(Anm_R[n][m]*m1g2R_plus_m2g2I+Anm_I[n][m]*m2g2R_minus_m1g2I);
			Snm[n][m]+=Rn*(Bnm_R[n][m]*m1g2R_plus_m2g2I+Bnm_I[n][m]*m2g2R_minus_m1g2I);
		}
	}

//	cout<<"Коэффициенты: "<<endl;
//	cout.precision(16);
//	for (unsigned int i=0; i<=Nmax; i++)
//		for (unsigned int j=0; j<=i; j++)
//			cout<<i<<" "<<j<<" "<<Cnm[i][j]<<" "<<Snm[i][j]<<endl;

	//delete erps;
	/*for(int n=1; n<=Nmax;++n)
		for(int m=0; m<=n;++m)
			if(Cnm[n][m]>1e-5 || Snm[n][m]>1e-5) cout<<"n="<<n<<" m="<<m<<" "<<Cnm[n][m]<<" "<<Snm[n][m]<<endl;
	cout<<endl;*/
	//! @todo При необходимость вставить расчёт поправок для других факторов, указанных в TideContribution.pdf
}

#ifdef WithQT
double GravityPotential::value (const QVariantList & noninertpos, double t)
{
	kinematic < real, 3, defaultNonInert > pos;
	pos[0] = noninertpos[0].toDouble();
	pos[1] = noninertpos[1].toDouble();
	pos[2] = noninertpos[2].toDouble();
	return value(pos, t);
}

QVariantList GravityPotential::gradient (const QVariantList & noninertpos, 
																double t)
{
	kinematic < real, 3, defaultNonInert > pos;
	pos[0] = noninertpos[0].toDouble();
	pos[1] = noninertpos[1].toDouble();
	pos[2] = noninertpos[2].toDouble();
	kinematic < real, 3, defaultNonInert > grad = gradient(pos,t);
	QVariantList result;
	result<<QVariant((double)grad[0])<<QVariant((double)grad[1])
											<<QVariant((double)grad[2]);
	return result;
}

QScriptValue addGeopot(QScriptContext * ctx, QScriptEngine * eng)
{
	DBTableCollection * c = (DBTableCollection *)(ctx->argument(0).toQObject());
	GravityPotential * gp = new GravityPotential(c);
	LongperiodSolidTides * lst = new LongperiodSolidTides(c);
	DiurnalSolidTides * dst = new DiurnalSolidTides(c);
	SemidiurnalSolidTides * sst = new SemidiurnalSolidTides (c);
	OceanTides * ot = new OceanTides (c);
	OceanPoleTides * opt = new OceanPoleTides (c);
	return QScriptValue();
}

BuiltIn addgeopot_ ("addGeopotTables", 1, addGeopot);
#endif

}

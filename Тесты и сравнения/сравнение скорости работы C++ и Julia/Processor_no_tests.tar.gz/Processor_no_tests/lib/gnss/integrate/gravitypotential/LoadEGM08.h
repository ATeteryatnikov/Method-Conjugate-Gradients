#ifndef LOADEGM08_H_
#define LOADEGM08_H_

//! @file

#include <DBTableCollection.h>

namespace libgnss
{

/**
 * @brief Загрузить модель EGM08 в таблицы гравитационного потенциала Земли
 *
 * @ingroup integrate
 *
 * @param tables Целевая коллекция таблиц
 * @param nmax Порядок разложения ГПЗ
 */
void LoadEGM08 ( DBTableCollection & tables, int nmax );

}

#endif

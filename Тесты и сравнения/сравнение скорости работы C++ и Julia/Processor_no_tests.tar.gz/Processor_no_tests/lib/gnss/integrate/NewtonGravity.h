#ifndef NEWTON_GRAVITY_H_
#define NEWTON_GRAVITY_H_

//! @file

#include <StdTables.h>
#include <Kinematic.h>
#include <ephemeris.h>

namespace libgnss
{

/**
 * @brief Вычислить ускорениеот притяжения пробного тела к некоторому телу
 *
 * @ingroup integrate
 *
 * @param bodypos Положение тела, вектор
 * @param pos Положение пробного тела, вектор
 * @param gm Гравтационный параметр тела
 * @return Ускорение
 *
 * Единицы измерения должны быть согласованы.
 *
 * Положение указывается в системе координат с центром в центре Земли, поэтому
 * результат корректируется на ускорение Земли при притяжении к данному телу.
 */
inline kinematic<real,3,defaultInert> getNewtonGravity(
			const kinematic<real, 3, defaultInert> & bodypos,
			const kinematic<real, 3, defaultInert> & pos,
			real gm
		)
{
	kinematic<real,3,defaultInert> dist1 = bodypos-pos;
	real distlen1 = dist1.length<0,2>();
	real distlen2 = bodypos.length<0,2>();
	kinematic<real,3,defaultInert> deltap=
			gm*dist1*((real)1/(distlen1*distlen1*distlen1));
	kinematic<real,3,defaultInert> deltan=
			gm*bodypos*((real)1/(distlen2*distlen2*distlen2));
	return deltap-deltan;
}

/** @brief Вычислить ускорение от гравитационных полей космических тел
 *
 * @ingroup integrate
  *
  * @param position Положение пробной точки в системе координат GCRS
  * @param TAI Число секунд TAI в шкале J2000.
  */
inline kinematic<real, 3, defaultInert> getNewtonGravity(
		const kinematic<real, 3, defaultInert> & position,
		real TAI)
{
	kinematic < real, 3, defaultInert> result;
	result += getNewtonGravity(
				getCelestialBodyEphemerides(Idx_venus,TAI),
				position,GM_venus);
	result += getNewtonGravity(
				getCelestialBodyEphemerides(Idx_mars,TAI),
				position,GM_mars);
	result += getNewtonGravity(
				getCelestialBodyEphemerides(Idx_jupiter,TAI),
				position,GM_jupiter);
	result += getNewtonGravity(
				getCelestialBodyEphemerides(Idx_saturn,TAI),
				position,GM_saturn);
	result += getNewtonGravity(
				getCelestialBodyEphemerides(Idx_sun,TAI),
				position,GM_sun);
	result += getNewtonGravity(
				getCelestialBodyEphemerides(Idx_moon,TAI),
				position,GM_moon);
	return result;
}

}

#endif

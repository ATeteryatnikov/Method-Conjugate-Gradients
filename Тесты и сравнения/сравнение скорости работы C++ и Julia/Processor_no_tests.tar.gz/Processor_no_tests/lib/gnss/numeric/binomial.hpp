#ifndef BINOMIAL_HPP_
#define BINOMIAL_HPP_

#include <vector>

namespace libgnss
{

/**
 * @brief Расчет коэффициентов бинома (a+b)^{n-1}
 * @param n Число требуемых биномиальных коэффициентов (степень + 1)
 * @return Коэффициенты бинома (a+b)^{n-1}
 */
inline vector < int > binomialCoefficients(int n)
{
	vector < int > result[2];
	result[0].resize(n);
	result[1].resize(n);
	for (unsigned int i=0; i<n; i++)
		result[0][i] = result[1][i] = 0;
	result[0][0] = 1;
	for (unsigned int i=1; i<n; i++)
		for (unsigned int j=0; j<=i; j++)
			result[i%2][j] = ((j!=0)?(result[(i+1)%2][j-1]):0)
									+((j!=i)?(result[(i+1)%2][j]):0);
	return result[(n+1)%2];
}

/**
 * @brief Расчет коэффициентов бинома (a-b)^{n-1}
 * @param n Число требуемых биномиальных коэффициентов (степень + 1)
 * @return Коэффициенты бинома (a-b)^{n-1}
 */
inline vector < int > binomialCoefficientsAlt(int n)
{
	vector < int > result = binomialCoefficients(n);
	for (unsigned int i=0; i<result.size(); i++)
		result[i]*=(((i+1)%2)*2-1);
	return result;
}

}

#endif

#ifndef SPARSEMATRIX_HPP_
#define SPARSEMATRIX_HPP_

//! @file

#include <vector>
#include <map>

namespace libgnss
{


/** @brief Класс разреженной матрицы, записанной по строкам.
 *
 * @ingroup numeric
 *
 * Представляет собой массив строк, каждая строка хранится в виде массивов
 * ненулевых элементов и их индексов в строке.
 */
template < typename ElementType > class RowWiseSparseMatrix
		: public std::vector<std::vector<std::pair<int,ElementType> > >
{
private:
	int width;
public:
	//! Вернуть ширину матрицы
	int getWidth() const
	{
		return width;
	}

	//! Вернуть высоту матрицы
	int getHeight() const
	{
		return this->size();
	}

	//! Инициализировать матрицу заданных размеров
	RowWiseSparseMatrix (int Width)
	{
		width = Width;
	}

	const std::vector < std::pair<int, ElementType > > & getRow(unsigned int i)
	const
	{
		return this->at(i);
	}

	std::vector < std::pair<int, ElementType > > & getRow(unsigned int i)
	{
		return (*this)[i];
	}

	void adjustWidth()
	{
		width = 0;
		for (unsigned int i = 0; i<this->size(); i++)
			for (unsigned int k =0; k<(*this)[i].size(); k++)
				if ((*this)[i][k].first > width)
					width = (*this)[i][k].first;
		width++;
	}
};

/** @brief Функция вывода матрицы в выходной поток
 *
 * @ingroup numeric
 *
 */
template < typename outputstr, typename ElementType> outputstr & toStream
(outputstr & str, const RowWiseSparseMatrix < ElementType > & Matrix)
{
	for (unsigned int i=0; i<Matrix.getHeight(); i++)
	{
		std::vector < ElementType > row (Matrix.getWidth(), 0.0l);
		for (unsigned int j=0; j<Matrix[i].size(); j++)
			row[Matrix[i][j].first] = Matrix[i][j].second;

		for (unsigned int i=0; i<row.size(); i++)
		{
			if (i>0)
				str<<'\t';
			str<<row[i];
		}
		str<<'\n';
	}
}

}

#endif

#ifndef DERIVATE_HPP
#define DERIVATE_HPP

//! @file

#include <fit.hpp>
#include <basis.h>

namespace libgnss
{

/** @brief Приближение функции по базису для её дифференцирования
 *
 * @ingroup numeric
 *
 * @tparam BasisFunc Тип функций, составляющих базис
 * @tparam fitprecision Тип данных с плавающей точкой
 *
 * Помимо вычисления значения аргумента, класс BasisFunc должен реализовывать
 * метод derivative(int n, fitprecision arg), вычисляющий производную n-го
 * порядка в точке arg от базисной функции.
 *
 */
template < typename BasisFunc, typename fitprecision=double >
class DifferentiableFit : public Fit < BasisFunc, fitprecision >
{
public:


	/**
	 * @brief Аппроксимация функции по заданному числу точек из списка данных
	 *
	 * Принимает те же аргументы, что и соответствующий конструктор класса Fit.
	 */
    DifferentiableFit (const vector < fitprecision > & argument_vals, const vector < fitprecision > & function_vals, const vector < BasisFunc > & basis, int N, int NumPoints, bool shift = true)
	:Fit <BasisFunc, fitprecision > (argument_vals, function_vals, basis, N, NumPoints,shift)
    {

    }


	/**
	 * @brief Аппроксимация функции по заданному набору точек
	 *
	 * Принимает те же аргументы, что и соответствующий конструктор класса Fit.
	 */
    DifferentiableFit (const vector < fitprecision > & argument_vals, const vector < fitprecision > & function_vals, const vector < BasisFunc > & basis,  bool shift = true)
	: Fit < BasisFunc, fitprecision > (argument_vals, function_vals, basis, shift)
    {

    }

	/**
	 * @brief Вычисляет n-ю производную аппроксимированной функции
	 * @param n Порядок производной (при n=0 вычисляется значение функции)
	 * @param arg Значение аргумента функции
	 */
    fitprecision derivative ( int n, double arg )
    {
        fitprecision result = 0;
        for (unsigned int i=0; i<this->functions.size(); i++)
            result += this->functions[i].derivative(n, (arg-this->argShift)/this->argScale) * this->coefficients[i];
        return result/(pow(this->argScale,n));
    }
};

/** @brief Аппроксимация таблично заданной функции и вычисление её производных
 *
 * @ingroup numeric
 *
 * Функция вычисляет аппроксимацию таблично заданной функции и вычисляет
 * значение функции и её производных при заданном значении аргумента.
 *
 * @tparam DblType Тип данных с плавающей точкой
 * @param args Массив значений аргумента
 * @param values Массив значений функции при соответствующих значения аргумента
 * @param t Значение аргумента, при котором требуется аппроксимация
 * @param approximateOrder Степень аппроксимирующего полинома
 * @param derivs Число производных (начиная с 0-й - самой функции).
 */
template <typename DblType> inline vector<DblType> approximate
	( const vector < DblType > & args,
	  const vector < DblType > & values,
	  DblType t, int approximateOrder ,
	  int derivs)
{
	//Выбрать правильно порядок аппроксимации
	int appord = approximateOrder;  //Степень полинома должна быть меньше
									//числа узлов
	if (appord>=args.size())
		appord = args.size() - 1;

	//Создать многочлен, аппроксимирующий значения
	DifferentiableFit<PowerOfX,DblType> df(args, values,
										   powerBasis(appord+1));

	vector< DblType > result;
	result.push_back(df.operator()(t));
	for (unsigned int i=0; i<derivs; i++)
		result.push_back(df.derivative(i+1,t));

	return result;
}


}


#endif

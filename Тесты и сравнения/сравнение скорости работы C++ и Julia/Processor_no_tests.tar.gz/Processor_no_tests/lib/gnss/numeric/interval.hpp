#ifndef INTERVAL_HPP_
#define INTERVAL_HPP_

/**
 * @file interval.hpp
 *
 * Реализация операций с интервалами.
 *
 * Используется для оценок точности.
 *
 * Интервал \f$[a,b]\f$ задаётся началом и концом. Операции сложения и
 * умножения на константу определяются тривиально.
 */

#include <algorithm>

namespace libgnss
{


template < typename numeric_type > struct Interval 
{
	numeric_type begin;
	numeric_type end;
	Interval()
	{
		begin = 0;
		end = 0;
	}

	Interval(numeric_type a)
	{
		begin = a;
		end = a;
	}
};

//-----УНАРНЫЕ ОПЕРАЦИИ----------------------------

template < typename numeric_type > Interval < numeric_type > & operator+=
	(Interval < numeric_type > & a, const Interval < numeric_type > & b)
{
	a.begin+=b.begin;
	a.end+=b.end;
	return a;
}

template < typename numeric_type > Interval < numeric_type > & operator-=
	(Interval < numeric_type > & a, const Interval < numeric_type > & b)
{
	a.begin-=b.begin;
	a.end-=b.end;
	return a;
}


template < typename numeric_type1, typename numeric_type2 >
	Interval < numeric_type1 > & operator*=
		(Interval < numeric_type1 > & a, const numeric_type2 & b)
{
	a.begin*=(numeric_type1)b;
	a.end*=(numeric_type1)b;
	if (b<0)
	{
		numeric_type1 sw = a.begin;
		a.begin = a.end;
		a.end = sw;
	}
	return a;
}

template < typename numeric_type1, typename numeric_type2 >
	Interval < numeric_type1 > & operator*=
		(Interval < numeric_type1 > & a, const Interval < numeric_type2 > & b)
{
	numeric_type1 n1 = a.begin * b.begin;
	numeric_type1 n2 = a.begin * b.end;
	numeric_type1 n3 = a.end * b.begin;
	numeric_type1 n4 = a.end * b.end;
	a.begin = std::min(n1, std::min(n2, std::min(n3,n4)));
	a.end = std::max(n1, std::max(n2, std::max(n3,n4)));
	return a;
}

//-----БИНАРНЫЕ ОПЕРАЦИИ-----------------------------------



template < typename numeric_type > Interval < numeric_type > operator+
	(Interval < numeric_type > & a, const Interval < numeric_type > & b)
{
	Interval < numeric_type > result = a;
	result += b;
	return result;
}

template < typename numeric_type > Interval < numeric_type > operator-
	(Interval < numeric_type > & a, const Interval < numeric_type > & b)
{
	Interval < numeric_type > result = a;
	result -= b;
	return result;
}

template < typename numeric_type1, typename numeric_type2 >
	Interval < numeric_type1 > operator*
		(Interval < numeric_type1 > & a, const numeric_type2 & b)
{
	Interval < numeric_type1 > result = a;
	result *= b;
	return result;
}

template < typename numeric_type1, typename numeric_type2 >
	Interval < numeric_type1 > operator*
		(Interval < numeric_type1 > & a, const Interval < numeric_type2 > & b)
{
	Interval < numeric_type1 > result = a;
	result *= b;
	return result;
}


template < typename numeric_type1, typename numeric_type2 >
	Interval < numeric_type1 > operator*
		(const numeric_type2 & b, Interval < numeric_type1 > & a)
{
	Interval < numeric_type1 > result = a;
	result *= b;
	return result;
}

}

#endif

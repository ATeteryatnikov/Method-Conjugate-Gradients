#include <string>

using namespace std;

#include <gnssconfig.h>
#ifdef WithQT
#ifdef UseMPI
#define CGM_MPI_
#endif
#include <cg.hpp>
#include <QScriptValue>
#include <QVariantList>
#include <QScriptContext>
#include <QScriptEngine>
#include <ScriptShell.h>
#include <DBError.h>
#include <realsparsematrix.h>
#include <BuiltIn.h>

namespace libgnss
{


RealLinearisation::RealLinearisation (int width, QScriptEngine * eng)
	: lhs(width)
{
	engine = eng;
}

int RealLinearisation::getWidth() const
{
	return lhs.getWidth();
}

int RealLinearisation::getHeight() const
{
	return lhs.getHeight();
}

void RealLinearisation::adjustWidth()
{
	lhs.adjustWidth();
}

QVariantList RealLinearisation::getRow(unsigned int line) const
{
	QVariantList result;
	vector < pair < int, real > > row_ = lhs.at(line);
	for (unsigned int i=0; i<row_.size(); i++)
	{
		QVariantList element;
		element.push_back(QVariant::fromValue<int>(row_[i].first));
		element.push_back(QVariant::fromValue<double>(row_[i].second));
		result.push_back(element);
	}
	return result;
}

double RealLinearisation::getRHS (unsigned int line) const
{
	return rhs[line];
}

void RealLinearisation::addRow (const QVariantList & row, double rhsvalue)
{
	try
	{
		vector < pair <int, real> > newline;
		for (unsigned int i=0; i<row.size(); i++)
		{
			QVariantList pair1 = row[i].toList();
			newline.push_back(pair<int,real>(pair1[0].toInt(),
							  pair1[1].toDouble()));
		}
		lhs.push_back(newline);
		rhs.push_back(rhsvalue);
	}
	catch (StrException & e)
	{
		returnError(engine, string("Не удалось добавить строку матрицы: ")+
					e.what());
	}
}

QScriptValue newlin (QScriptContext * ctx, QScriptEngine *eng)
{
	int w = ctx->argument(0).toInt32();
	RealLinearisation * newlinearization = new RealLinearisation(w,eng);
	return eng->newQObject(newlinearization,QScriptEngine::ScriptOwnership);
}

BuiltIn newlinearisation ("newRealLinearisation", 1, newlin);

QScriptValue normcols (QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		RealLinearisation * rlnz = qobject_cast<RealLinearisation*>
				(ctx->argument(0).toQObject());
		if (rlnz == 0)
			throw StrException("normaliseColumns","Первый аргумент должен быть "
							   "объектом линеаризации задачи МНК");
		vector<real> result;
#ifdef UseMPI
		if (ctx->argumentCount() > 1)
		{
			QMPICommunicator * comm = qobject_cast<QMPICommunicator*>
					(ctx->argument(1).toQObject());
			if (comm==0)
				throw StrException("normaliseColumns",
								   "Второй аргумент должен быть "
								   "объектом MPI-коммуникатора.");
			normalizeColumns_MPI(rlnz->lhs, result, comm->getCommSize(),
							 comm->currentCommunicator());
		}
		else
		{
			int commsize;
			MPI_Comm_size(MPI_COMM_WORLD, &commsize);
			normalizeColumns_MPI(rlnz->lhs, result, commsize, MPI_COMM_WORLD);
		}
#else
		normalizeColumns(rlnz->lhs, result);
#endif
		QVariantList result_;
		result_.reserve(result.size());
		for (unsigned int i=0; i<result.size(); i++)
			result_.push_back((double)(result[i]));
		return eng->toScriptValue<QVariantList>(result_);
	}
	catch (StrException & e)
	{
		returnError(eng, string("Нормализация столбцов матрицы не удалась: ")
					+e.what());
	}

}

#ifdef UseMPI
BuiltIn normalcols("normaliseColumns", 2, normcols);
#else
BuiltIn normalcols("normaliseColumns", 2, normcols);
#endif

QScriptValue cgm (QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		RealLinearisation * rlnz = qobject_cast<RealLinearisation*>
				(ctx->argument(0).toQObject());
		if (rlnz == 0)
			throw StrException("cgMethod", "Первый аргумент должен быть "
							   "объектом линеаризации задачи МНК");
		double desiredprecision = ctx->argument(1).toNumber();
		int itlimit = 20000;
		if (ctx->argumentCount() > 2)
			itlimit = ctx->argument(2).toInt32();
		vector<real> precision (rlnz->getWidth(), desiredprecision);
		vector<real> solution (rlnz->getWidth(), 0.0l);
#ifdef UseMPI
		//Если аргументов несколько, значит считать ещё параметры MPI
		if (ctx->argumentCount() > 3)
		{
			QMPICommunicator * comm = qobject_cast<QMPICommunicator*>
					(ctx->argument(3).toQObject());
			if (comm==0)
				throw StrException("cgMethod", "Четвертый аргумент должен быть "
								   "объектом MPI-коммуникатора.");
			cgMethod_MPI<real,leastsquaresprec>(rlnz->lhs, rlnz->rhs,
							precision, solution, itlimit, comm->getCommSize(),
												comm->currentCommunicator());
		}
		else
		{
			int commsize;
			MPI_Comm_size(MPI_COMM_WORLD, &commsize);
			cgMethod_MPI<real,leastsquaresprec>(rlnz->lhs, rlnz->rhs,
						precision, solution, itlimit, commsize, MPI_COMM_WORLD);
		}
#else
		cgMethod<real, leastsquaresprec> (rlnz->lhs, rlnz->rhs,
										  precision, solution, itlimit);
#endif
		QVariantList solution_;
		solution_.reserve(rlnz->getWidth());
		for (unsigned int i =0; i<rlnz->getWidth(); i++)
			solution_.push_back((double)(solution[i]));
		return eng->toScriptValue<QVariantList>(solution_);
	}
	catch (StrException & e)
	{
		returnError(eng, string("Метод сопряженных градиентов: ")+e.what());
	}
}

#ifdef UseMPI
BuiltIn cgmethod("linearConjugateGradient", 4, cgm);
#else
BuiltIn cgmethod("linearConjugateGradient", 3, cgm);
#endif

}

#endif


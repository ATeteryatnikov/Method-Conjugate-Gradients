#ifndef BASIS_H_
#define BASIS_H_

//! @file

#include <cmath>
#include <vector>
#include <Types.h>

namespace libgnss
{

/**
 * @brief Унарная функция - элемент базиса для МНК
 *
 * @ingroup numeric
 */
class UnaryFunction
{
protected:
	int n;
public:
	virtual real operator() (real arg) const;
	virtual real derivative ( int order, double argument ) const;
};

/**
 * @brief Степенная функция для базиса
 *
 * @ingroup numeric
 */
class PowerOfX : public UnaryFunction
{

public:
	PowerOfX (unsigned int degree);

	virtual real operator() (real arg) const;

	virtual real derivative ( int order, double argument ) const;
};

/**
 * @brief Функция Синус для базиса
 *
 * @ingroup numeric
 */
class SinX : public UnaryFunction
{

public:
	inline SinX (unsigned int degree)
	{
		n = degree;
	}

	virtual real operator() (real arg) const;

	virtual real derivative ( int order, double argument ) const;

};

/**
 * @brief Функция Косинус для базиса
 *
 * @ingroup numeric
 */
class CosX : public UnaryFunction
{

public:
	inline CosX (unsigned int degree)
	{
		n = degree;
	}

	virtual real operator() (real arg) const;

	virtual real derivative ( int order, double argument ) const;

};

/**
 * @brief Полиномиальный базис
 *
 * @ingroup numeric
 *
 * @param Count Число полиномов в базисе
 * @return Вектор полиномов x^i для i = 0, 1, ..., Count-1
 */
inline std::vector < PowerOfX > powerBasis ( int Count )
{
	static std::vector < PowerOfX > basis;
	if (basis.size()!=Count)
	{
		basis.clear();
		for (unsigned int i=0; i<Count; i++)
			 basis.push_back(PowerOfX(i));
	}
	return basis;
}

}

#endif

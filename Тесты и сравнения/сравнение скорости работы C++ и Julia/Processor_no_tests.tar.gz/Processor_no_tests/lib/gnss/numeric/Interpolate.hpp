/*
 * Interpolate.hpp
 *
 *  Created on: 07.10.2010
 *      Author: yuron
 */

#ifndef INTERPOLATE_HPP_
#define INTERPOLATE_HPP_

/** @file
 *
 * @brief Различные функции для интерполяции
 *
 */

#include <vector>

namespace libgnss
{

/** @brief Функция, вычисляющая интерполяционный многочлен Лагранжа
 *
 * @ingroup numeric
 *
 * @tparam Domain Тип аргументов функции
 * @tparam Range Тип значений функции
 * @tparam DomainSequentialIterator Итератор по контейнеру аргументов
 * @tparam RangeSequentialIterator Итератор по контейнеру значений функции
 * @param arg0 Итератор начала списка аргументов функции
 * @param argN Итератор, указывающий за конец списка аргументов функции
 * @param vals0 Итератор начала списка значений функции
 * @param valsN Итератор, указывающий за конец списка значений функции
 * @param t Интересующий момент времени
 *
 * Предполагается, что за конечное число итераций инкримента от arg0 можно
 * дойти до argN, и за такое же число инкрементоов - от vals0 до valsN.
 *
 */
template <typename Domain, typename Range, typename DomainSequentialIterator,
          typename RangeSequentialIterator> inline Range interpolateLagrange
	( const DomainSequentialIterator & arg0, const DomainSequentialIterator & argN,
	  const RangeSequentialIterator & vals0, const RangeSequentialIterator & valsN,
	  Domain t )
{
	Range result = 0.0;
	RangeSequentialIterator it1_r = vals0;
	for (DomainSequentialIterator it1_d = arg0;
		 (it1_d!=argN) && (it1_r!=valsN);
		 it1_d++, it1_r++)
	{
		Range prod = *it1_r;
		RangeSequentialIterator it2_r = vals0;
		for (DomainSequentialIterator it2_d = arg0;
			(it2_d!=argN) && (it2_r!=valsN);
			it2_d++, it2_r++)
			if (it2_d!=it1_d)
			{
				prod *= (t - *it2_d)/(*it1_d - *it2_d);
			}
		result+=prod;
	}
	return result;
}

/**
 * @brief Функция, вычисляющая интерполяционный многочлен Лагранжа
 *
 * @ingroup numeric
 *
 * Функция принимает таблично заданную функцию и возвращает её значение
 * в выбранной точке.
 *
 * @param argumentValues Набор значений аргумента функции
 * @param functionValues Набор значений интерполируемой функции
 *
 * @return Приближенное значение функции в момент времени.
 */
template <typename Domain, typename Range> inline Range interpolateLagrange
	( const vector < Domain > & argumentValues,
	  const vector < Range > & functionValues,
	  Domain t )
{
	return interpolateLagrange<Domain, Range>(argumentValues.begin(), argumentValues.end(),
											  functionValues.begin(), functionValues.end(),
											  t);
}


}

#endif /* INTERPOLATE_HPP_ */

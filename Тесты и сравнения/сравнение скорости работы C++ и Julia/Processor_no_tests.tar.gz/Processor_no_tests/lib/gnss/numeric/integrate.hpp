#ifndef INTEGRATE_HPP_
#define INTEGRATE_HPP_

//! @file

#include <math.h>
#include <stdio.h>
#include <Types.h>
#include <limits>
#include <DBError.h>
//#include <float128out.h>
//#include <gmpxx.h>

/** @file
 *
 *
 *  @brief Модуль решения задачи Коши для ОДУ
 * 
 *  @ingroup integrate
 * 
 *  Функции данного пространства имён предназначены для решения задачи Коши
 *  \f[
 *  	x'(t) = f(t,x),\qquad  x(t_0)=x_0.
 *  \f]
 *
 *	Все функции реализованы в виде шаблонов, аргументы которых задают
 *	типы данных, кодирующих время (time_mes), тип пространственных переменных
 *	(spacial).
 *	
 *	Кроме того, большинство функций требуют задания правой части системы.
 *	Объект, вычисляющий правую часть, передаётся в такие функции как один
 *	из параметров. Этим объектом может быть как функция, так и (предпочтительно)
 *	объект класса с перегруженным оператором ():
 * \code
	spacial operator() (time_mes t, spacial x)
   \endcode
 *
 *
 */

namespace libgnss
{
	/** @brief Функция, выполняющая один шаг интегрирования методом Рунге-Кутты
	 *
	 * @ingroup numeric
	 *
	 * Функция делает один шаг интегрирования для решения задачи Коши  
	 *  \f[
	 *  	x'(t) = f(t,x),\qquad  x(t_0)=x_0.
	 *  \f]
	 * 
	 * Считается, что в момент времени \f$ t_0 \f$ известно значение искомой
	 * функции \f$ x_0=x(t_0) \f$ и правой части системы \f$ f(t_0, x(t_0)) \f$.
	 * В результате работы функции значение искомой функции \f$ x(t) \f$ и
	 * правой части \f$ f(t,x(t)) \f$ системы будет вычислено в момент времени
	 * \f$ t_0+h \f$.
	 * 
	 * Параметры шаблона spacial, rhs задают типы данных, соответствующих
	 * пространственным переменным и объектам, вычисляющим правую часть системы.
	 * Такой объект типа rhs должен иметь перегруженный оператор ()
	* \code
		spacial operator() (timeMoment t, spacial x)
	\endcode
	 *
	 *	@param t0 Момент времени \f$ t_0 \f$.
	 *	@param x0 Значение искомой функции в момент времени \f$ t_0 \f$.
	 *	@param f0 Значение правой части в точке \f$ (t_0;x_0) \f$.
	 *	@param f Объект, вычисляющий правую часть системы.
	 *	@param h Величина требуемого шага \f$ h \f$ по времени.
	 *	@param x1 Возвращаемое значение искомой функции в момент \f$ t_0+h \f$.
	 *	@param f1 Возвращаемое значение правой части в вычисленной точке.
	 *
	 * Константы:
	 * 
	 *	nu      - константа, незначительно влияющая на работу метода. См.
	 *	          H.A. Luther, An Explicit Sixth-Order Runge-Kutta Formula.
	 *	          Mathematics of Computation, Vol. 22, No. 102 (Apr., 1968),
	 *		  pp. 434-436.
	 */
	template < typename spacial, typename rhs>
	void stepRungeKutta6
	/*Ввод*/  (real t0, spacial&x0, const spacial&f0, rhs&f, real h,
	               /*Вывод*/	  spacial&x1, spacial&f1 )
	{

		static const real nu = sqrt ( 21.0 ),
		rk3k1 = 0.375,
		rk3k2 = 0.125,
		rk4k1 = 0.2962962962962962962962962962962962962962962962962962962967,
		rk4k2 = 0.0740740740740740740740740740740740740740740740740740740742,
		rk4k3 = 0.2962962962962962962962962962962962962962962962962962962967,
		rk5k1 = -0.053571428571428571428571428571428571428571428571428571428571+
			 0.0229591836734693877551020408163265306122448979591836734693878*nu,
		rk5k2 = -0.142857142857142857142857142857142857142857142857142857142857+
			 0.0204081632653061224489795918367346938775510204081632653061224*nu,
		rk5k3 =  0.85714285714285714285714285714285714285714285714285714285714 -
			 0.122448979591836734693877551020408163265306122448979591836735*nu,
		rk5k4 = -0.160714285714285714285714285714285714285714285714285714285714+
			 0.0076530612244897959183673469387755102040816326530612244897959*nu,
		rk6k1 = -0.58928571428571428571428571428571428571428571428571428571429 -
			 0.130102040816326530612244897959183673469387755102040816326531*nu,
		rk6k2 = -0.142857142857142857142857142857142857142857142857142857142857-
			 0.0204081632653061224489795918367346938775510204081632653061224*nu,
		rk6k3=-0.16326530612244897959183673469387755102040816326530612244898*nu,
		rk6k4 = 0.0321428571428571428571428571428571428571428571428571428571429+
			  0.185204081632653061224489795918367346938775510204081632653061*nu,
		rk6k5 = 1.2+0.2*nu,
		rk7k1 = 1.83333333333333333333333333333333333333333333333333333333333 +
			   0.58333333333333333333333333333333333333333333333333333333333*nu,
		rk7k2 = 0.66666666666666666666666666666666666666666666666666666666667,
		rk7k3 = -1.11111111111111111111111111111111111111111111111111111111111 +
			   1.55555555555555555555555555555555555555555555555555555555556*nu,
		rk7k4 = 0.7 - 1.05* nu,
		rk7k5 = -3.8111111111111111111111111111111111111111111111111111111111 -
																	0.7*nu,
		rk7k6 = 2.72222222222222222222222222222222222222222222222222222222222 -
			   0.38888888888888888888888888888888888888888888888888888888889*nu;

		spacial k1 = h*f0;
		spacial k2 = h*f ( t0+h, x0+k1 );
		spacial k3 = h*f ( t0+h*0.5,x0+ rk3k1*k1 + rk3k2*k2 );
		spacial k4 = h*f ( t0+h* ( 2.0/3.0 ),x0+rk4k1*k1+rk4k2*k2+rk4k3*k3 );
		spacial k5 = h*f ( t0+h* ( ( 7.0-nu ) /14.0 ),
									x0+rk5k1*k1+rk5k2*k2+rk5k3*k3+rk5k4*k4 );
		spacial k6 = h*f ( t0+h* ( ( 7.0+nu ) /14.0 ),
						   x0+rk6k1*k1+rk6k2*k2+rk6k3*k3+rk6k4*k4+rk6k5*k5 );
		spacial k7 = h*f ( t0+h,
					x0+rk7k1*k1+rk7k2*k2+rk7k3*k3+rk7k4*k4+rk7k5*k5+rk7k6*k6 );
		x1 = x0+ ( ( real ) (9) *k1+ ( real ) (64) *k3+
				   ( real ) (49) *k5+ ( real ) (49) *k6+
				   (real) (9) *k7 ) * ( (real) (1) / (real) (180) );
		f1 = f ( t0+h,x1 );
	}


	/**
	* @brief Шаг метода Адамса 7-го порядка типа предиктор-корректор
	*
	* @ingroup numeric
	* 
	* Функция выполняет один шаг интегрирования методом Адамса 7-го порядка
	* типа предиктор-корректор для решения задачи Коши
	*  \f[
	*  	x'(t) = f(t,x),\qquad  x(t_0)=x_0.
	*  \f]
	* 
	* 
	* Шаг предиктора основан на выборе квадратурной формулы для интеграла:
	*
	* \f[
	\tilde x(t+h) = x(t)+ \int \limits_{t}^{t+h} f(v,x(v))\, dv \approx x(t) +
		\int\limits_{t}^{t+h} L_{f_{-7},f_{-6},\ldots,f_{0}} (v)\,dv,
	\f]
	*
	* где \f$ f_{-7},f_{-6},\ldots,f_{0}\f$ - значения правой части в точках
	* \f$ (t-7h,x(t-7h)), (t-6h,x(t-6h)),\ldots, (t,x(t))\f$,
	* \f$ L_{f_{-7},f_{-6},\ldots,f_{0}}\f$ - интерполяционный полином Лагранжа,
	* натянутый на известные значения
	* \f$ f_{-7},f_{-6},\ldots,f_{0}\f$.
	*
	* Коэффициенты \f$\alpha_i\f$ такие, что
	*
	* \f[
		\int\limits_{t}^{t+h} L_{f_{-7},f_{-6},\ldots,f_{0}}(v)\,dv =
	\sum\limits_{i=0}^{7} \alpha_i f_{-i},
	\f]
	* вычисляются заранее, используя формулу интерполяционного полинома Лагранжа
	* и стандартные приёмы дифференцирования. Например, для получения последней
	* суммы в явном виде можно воспользоваться следующими двумя командами
	* системы компьютерной алгебры Mathematica:
	*
	* \code
		LagrangePolynom[n_,h_,x_]:=
		Expand[
			Sum[
				Subscript[f,i+1]*Product[If[i==j,1,(x-h*j)/(h(i-j))],
				{j,0,n}],{i,0,n}
			   ]
			  ];
		Expand[1`100*Integrate[LagrangePolynom[7,1,x],{x,7,8}]]
	\endcode
	*
	* Значения \f$ f_{-7}, f_{-6},\ldots, f_{0}\f$ необходимо иметь для
	* выполнения шага, как и в любом многошаговом методе интегрирования.
	*
	* Для шага корректора используется аналогичный подход к получению
	* коэффициентов \f$ \beta_i \f$ в равенстве:
	* \f[
	   \int\limits_{t}^{t+h} L_{f_{-6},f_{-5},\ldots,f_{0},f_1}(v)\,dv =
		\sum\limits_{i=-1}^{6} \beta_i f_{-i}.
	  \f]
	* Тогда шаг корректора выполняется по формуле:
	* \f[
	\tilde x(t+h) = x(t)+\int\limits_{t}^{t+h} f(v,x(v))\, dv =
		x(t)+\sum\limits_{i=-1}^{6} \beta_i f_{-i}.
	\f]
	*
	* @param t Начальный момент времени.
	* @param x Значение искомой функции в начальный момент времени.
	* @param f Объект, вычисляющий правую часть системы.
	* @param h Шаг интегрирования.
	* @param f1 Значение правой части  \f$ f(t-7h, x(t-7h)) \f$.
	* @param f2 Значение правой части  \f$ f(t-6h, x(t-6h)) \f$.
	* @param f3 Значение правой части  \f$ f(t-5h, x(t-5h)) \f$.
	* @param f4 Значение правой части  \f$ f(t-4h, x(t-4h)) \f$.
	* @param f5 Значение правой части  \f$ f(t-3h, x(t-3h)) \f$.
	* @param f6 Значение правой части  \f$ f(t-2h, x(t-2h)) \f$.
	* @param f7 Значение правой части  \f$ f(t-1h, x(t-1h)) \f$.
	* @param f8 Значение правой части  \f$ f(t, x(t)) \f$.
	* @param x9 Вычисляемое значение искомой функции \f$x(t+h)\f$
	* @param f9 Вычисляемое значение правой части  \f$ f(t+h, x(t+h))\f$
	*
	*
	 */
	template < typename spacial, typename rhs> void stepAdams7
	/*Ввод*/	( real t, spacial&x, rhs&f, real h,
	               spacial&f1, spacial&f2, spacial&f3, spacial&f4,
	               spacial&f5, spacial&f6, spacial&f7, spacial&f8,
	               /*Вывод*/	  spacial&x9, spacial&f9 )
	{

		static const real e1 = - 0.30422453703703703703703703703703703;
		static const real e2 =   2.44516369047619047619047619047619047;
		static const real e3 = - 8.61212797619047619047619047619047619;
		static const real e4 =  17.37965443121693121693121693121693121;
		static const real e5 = -22.02775297619047619047619047619047619;
		static const real e6 =  18.05453869047619047619047619047619047;
		static const real e7 = - 9.52520667989417989417989417989417989;
		static const real e8 =   3.58995535714285714285714285714285714;

		//i = implicit
		static const real i2 =   0.01136739417989417989417989417989417;
		static const real i3 = - 0.09384093915343915343915343915343915;
		static const real i4 =   0.34308035714285714285714285714285714;
		static const real i5 = - 0.73203538359788359788359788359788359;
		static const real i6 =   1.01796461640211640211640211640211640;
		static const real i7 = - 1.00691964285714285714285714285714285;
		static const real i8 =   1.15615906084656084656084656084656084;
		static const real i9 = + 0.30422453703703703703703703703703703;

		if ( h<0 )
		{
			//Какую ошибку выдавать, если шаг <0?
			return;
		}
		spacial tildex9 = x+h* ( f1 * e1 + f2 * e2 + f3 * e3 + f4 * e4 +
								 f5 * e5 + f6 * e6 + f7 * e7 + f8 * e8 );
		spacial tildef9 = f ( t+h, tildex9 );
		tildex9         = x+h* ( f2 * i2 + f3 * i3 + f4 * i4 + f5 * i5 +
								 f6 * i6 + f7 * i7 + f8 * i8 +tildef9 * i9 );
		tildef9         = f ( t + h, tildex9 );
		x9              = x+h* ( f2 * i2 + f3 * i3 + f4 * i4 + f5 * i5 +
								 f6 * i6 + f7 * i7 + f8 * i8 + tildef9 * i9 );
		f9              = f ( t+h, x9 );

	}


	/** @brief Функция, реализующая интерполяционную формулу Адамса 7-го порядка
	 *
	 * @ingroup numeric
	* 
	* Функция вычисляет разность \f$ x(t_2)-x(t_1) \f$ значений функции
	* \f$ x(t) \f$, заданной условиями
	*  \f[
	*  	x'(t) = f(t,x),\qquad  x(t_0)=x_0,
	*  \f]
	* с помощью интерполяционной формулы Адамса 7-го порядка, основываясь на 8
	* известных значениях \f$ f_0, f_{1}, \ldots, f_{7} \f$
	* в точках \f$ (0,x(0)),\,(1,x(1)),\ldots,(7,x(7))\f$:
	* \f[
		x(t_2)-x(t_1) = \int\limits_{t_1}^{t_2} f(v, x(v))\, dv\,\, \approx \,\,
		\int\limits_{t_1}^{t_2} L_{f_0,\ldots,f_7} (v)\, dv,
	\f]
	*
	* Для получения коэффициентов многочленов \f$ \alpha_i (t_1,t_2) \f$ в
	* линейной комбинации
	* 
	* \f[
		\int\limits_{t_1}^{t_2} L_{f_0,\ldots,f_7} (v)\,
		dv=\sum\limits_{i=0}^{7}\alpha_i(t_1,t_2) f_i
	 \f]
	* используется формула интерполяционного многочлена Лагранжа и стандартные
	* приёмы дифференцирования.
	* 
	* Передача значения правой части \f$ f_i \f$ в узлах другой равномерной
	* сетки достигается линейной заменой моментов времени \f$t_1\f$ и \f$t_2\f$.
	*
	*   @param f0 Значение \f$ f_0 \f$
	*   @param f1 Значение \f$ f_1 \f$
	*   @param f2 Значение \f$ f_2 \f$
	*   @param f3 Значение \f$ f_3 \f$
	*   @param f4 Значение \f$ f_4 \f$
	*   @param f5 Значение \f$ f_5 \f$
	*   @param f6 Значение \f$ f_6 \f$
	*   @param f7 Значение \f$ f_7 \f$
	*   @param t1 Момент времени \f$ t_1 \f$
	*   @param tDt Момент времени \f$ t_2 \f$
	*   @return Интеграл \f$\cdot\int_{t_1}^{t_2}L_{f_0,\ldots,f_7}(v)\,dv\f$
	*/
	template<typename spacial,typename qcoeff> spacial adamsInterpolation
		( spacial&f0, spacial&f1, spacial&f2, spacial&f3, spacial&f4,
	        spacial&f5, spacial&f6, spacial&f7, qcoeff t1, qcoeff tDt )
	{

//		mpf_set_default_prec (128);

		qcoeff t2 = t1*t1;
		qcoeff t3 = t2*t1;
		qcoeff t4 = t2*t2;
		qcoeff t5 = t3*t2;
		qcoeff t6 = t3*t3;
		qcoeff t7 = t4*t3;
		qcoeff t8 = t4*t4;

		qcoeff tDt1 = tDt;
		qcoeff tDt2 = tDt1*tDt1;
		qcoeff tDt3 = tDt2*tDt1;
		qcoeff tDt4 = tDt2*tDt2;
		qcoeff tDt5 = tDt3*tDt2;
		qcoeff tDt6 = tDt3*tDt3;
		qcoeff tDt7 = tDt4*tDt3;
		qcoeff tDt8 = tDt4*tDt4;

		qcoeff c0= (
		               ( qcoeff ) ( -1 ) *t1 +
		               ( qcoeff ) ( 1 ) *tDt1 +
		               ( ( qcoeff ) 363/ ( qcoeff ) 280 ) *t2 -
		               ( ( qcoeff ) 469/ ( qcoeff ) 540 ) *t3 +
		               ( ( qcoeff ) 967/ ( qcoeff ) 2880 ) *t4 -
		               ( ( qcoeff ) 7/ ( qcoeff ) 90 ) *t5 +
		               ( ( qcoeff ) 23/ ( qcoeff ) 2160 ) *t6 -
		               ( ( qcoeff ) 1/ ( qcoeff ) 1260 ) *t7 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 40320 ) *t8 -

		               ( ( qcoeff ) 363/ ( qcoeff ) 280 ) *tDt2 +
		               ( ( qcoeff ) 469/ ( qcoeff ) 540 ) *tDt3 -
		               ( ( qcoeff ) 967/ ( qcoeff ) 2880 ) *tDt4 +
		               ( ( qcoeff ) 7/ ( qcoeff ) 90 ) *tDt5 -
		               ( ( qcoeff ) 23/ ( qcoeff ) 2160 ) *tDt6 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 1260 ) *tDt7 -
		               ( ( qcoeff ) 1/ ( qcoeff ) 40320 ) *tDt8
		           );

		qcoeff c1= (
		               ( ( qcoeff ) ( -7 ) / ( qcoeff ) 2 ) *t2 +
		               ( ( qcoeff ) 223/ ( qcoeff ) 60 ) *t3 -
		               ( ( qcoeff ) 319/ ( qcoeff ) 180 ) *t4 +
		               ( ( qcoeff ) 37/ ( qcoeff ) 80 ) *t5 -
		               ( ( qcoeff ) 59/ ( qcoeff ) 864 ) *t6 +
		               ( ( qcoeff ) 3/ ( qcoeff ) 560 ) *t7 -
		               ( ( qcoeff ) 1/ ( qcoeff ) 5760 ) *t8 +
		               ( ( qcoeff ) 7/ ( qcoeff ) 2 ) *tDt2 -
		               ( ( qcoeff ) 223/ ( qcoeff ) 60 ) *tDt3 +
		               ( ( qcoeff ) 319/ ( qcoeff ) 180 ) *tDt4 -
		               ( ( qcoeff ) 37/ ( qcoeff ) 80 ) *tDt5 +
		               ( ( qcoeff ) 59/ ( qcoeff ) 864 ) *tDt6 -
		               ( ( qcoeff ) 3/ ( qcoeff ) 560 ) *tDt7 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 5760 ) *tDt8
		           );

		qcoeff c2= (
		               ( ( qcoeff ) 21/ ( qcoeff ) 4 ) *t2 -
		               ( ( qcoeff ) 293/ ( qcoeff ) 40 ) *t3 +
		               ( ( qcoeff ) 3929/ ( qcoeff ) 960 ) *t4 -
		               ( ( qcoeff ) 71/ ( qcoeff ) 60 ) *t5 +
		               ( ( qcoeff ) 3/ ( qcoeff ) 16 ) *t6 -
		               ( ( qcoeff ) 13/ ( qcoeff ) 840 ) *t7 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 1920 ) *t8 -
		               ( ( qcoeff ) 21/ ( qcoeff ) 4 ) *tDt2 +
		               ( ( qcoeff ) 293/ ( qcoeff ) 40 ) *tDt3 -
		               ( ( qcoeff ) 3929/ ( qcoeff ) 960 ) *tDt4 +
		               ( ( qcoeff ) 71/ ( qcoeff ) 60 ) *tDt5 -
		               ( ( qcoeff ) 3/ ( qcoeff ) 16 ) *tDt6 +
		               ( ( qcoeff ) 13/ ( qcoeff ) 840 ) *tDt7 -
		               ( ( qcoeff ) 1/ ( qcoeff ) 1920 ) *tDt8
		           );

		qcoeff c3= (
		               ( ( qcoeff ) ( -35 ) / ( qcoeff ) 6 ) *t2 +
		               ( ( qcoeff ) 949 / ( qcoeff ) 108 ) *t3 -
		               ( ( qcoeff ) 389 / ( qcoeff ) 72 ) *t4 +
		               ( ( qcoeff ) 1219/ ( qcoeff ) 720 ) *t5 -
		               ( ( qcoeff ) 247/ ( qcoeff ) 864 ) *t6 +
		               ( ( qcoeff ) 25/ ( qcoeff ) 1008 ) *t7 -
		               ( ( qcoeff ) 1/ ( qcoeff ) 1152 ) *t8 +
		               ( ( qcoeff ) 35/ ( qcoeff ) 6 ) *tDt2 -
		               ( ( qcoeff ) 949/ ( qcoeff ) 108 ) *tDt3 +
		               ( ( qcoeff ) 389/ ( qcoeff ) 72 ) *tDt4 -
		               ( ( qcoeff ) 1219/ ( qcoeff ) 720 ) *tDt5 +
		               ( ( qcoeff ) 247/ ( qcoeff ) 864 ) *tDt6 -
		               ( ( qcoeff ) 25/ ( qcoeff ) 1008 ) *tDt7 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 1152 ) *tDt8
		           );

		qcoeff c4= (
		               ( ( qcoeff ) 35/ ( qcoeff ) 8 ) *t2 -
		               ( ( qcoeff ) 41/ ( qcoeff ) 6 ) *t3 +
		               ( ( qcoeff ) 2545/ ( qcoeff ) 576 ) *t4 -
		               ( ( qcoeff ) 22/ ( qcoeff ) 15 ) *t5 +
		               ( ( qcoeff ) 113/ ( qcoeff ) 432 ) *t6 -
		               ( ( qcoeff ) 1/ ( qcoeff ) 42 ) *t7 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 1152 ) *t8 -
		               ( ( qcoeff ) 35/ ( qcoeff ) 8 ) *tDt2 +
		               ( ( qcoeff ) 41/ ( qcoeff ) 6 ) *tDt3 -
		               ( ( qcoeff ) 2545/ ( qcoeff ) 576 ) *tDt4 +
		               ( ( qcoeff ) 22/ ( qcoeff ) 15 ) *tDt5 -
		               ( ( qcoeff ) 113/ ( qcoeff ) 432 ) *tDt6 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 42 ) *tDt7 -
		               ( ( qcoeff ) 1/ ( qcoeff ) 1152 ) *tDt8
		           );

		qcoeff c5= (
		               ( ( qcoeff ) ( -21 ) / ( qcoeff ) 10 ) *t2 +
		               ( ( qcoeff ) 67/ ( qcoeff ) 20 ) *t3 -
		               ( ( qcoeff ) 67/ ( qcoeff ) 30 ) *t4 +
		               ( ( qcoeff ) 37/ ( qcoeff ) 48 ) *t5 -
		               ( ( qcoeff ) 23/ ( qcoeff ) 160 ) *t6 +
		               ( ( qcoeff ) 23/ ( qcoeff ) 1680 ) *t7 -
		               ( ( qcoeff ) 1/ ( qcoeff ) 1920 ) *t8 +
		               ( ( qcoeff ) 21/ ( qcoeff ) 10 ) *tDt2 -
		               ( ( qcoeff ) 67/ ( qcoeff ) 20 ) *tDt3 +
		               ( ( qcoeff ) 67/ ( qcoeff ) 30 ) *tDt4 -
		               ( ( qcoeff ) 37/ ( qcoeff ) 48 ) *tDt5 +
		               ( ( qcoeff ) 23/ ( qcoeff ) 160 ) *tDt6 -
		               ( ( qcoeff ) 23/ ( qcoeff ) 1680 ) *tDt7 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 1920 ) *tDt8
		           );

		qcoeff c6= (
		               ( ( qcoeff ) 7/ ( qcoeff ) 12 ) *t2 -
		               ( ( qcoeff ) 1019/ ( qcoeff ) 1080 ) *t3 +
		               ( ( qcoeff ) 1849/ ( qcoeff ) 2880 ) *t4 -
		               ( ( qcoeff ) 41/ ( qcoeff ) 180 ) *t5 +
		               ( ( qcoeff ) 19/ ( qcoeff ) 432 ) *t6 -
		               ( ( qcoeff ) 11/ ( qcoeff ) 2520 ) *t7 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 5760 ) *t8 -
		               ( ( qcoeff ) 7/ ( qcoeff ) 12 ) *tDt2 +
		               ( ( qcoeff ) 1019/ ( qcoeff ) 1080 ) *tDt3 -
		               ( ( qcoeff ) 1849/ ( qcoeff ) 2880 ) *tDt4 +
		               ( ( qcoeff ) 41/ ( qcoeff ) 180 ) *tDt5 -
		               ( ( qcoeff ) 19/ ( qcoeff ) 432 ) *tDt6 +
		               ( ( qcoeff ) 11/ ( qcoeff ) 2520 ) *tDt7 -
		               ( ( qcoeff ) 1/ ( qcoeff ) 5760 ) *tDt8
		           );

		qcoeff c7= (
		               ( ( qcoeff ) ( -1 ) / ( qcoeff ) 14 ) *t2 +
		               ( ( qcoeff ) 7/ ( qcoeff ) 60 ) *t3 -
		               ( ( qcoeff ) 29/ ( qcoeff ) 360 ) *t4 +
		               ( ( qcoeff ) 7/ ( qcoeff ) 240 ) *t5 -
		               ( ( qcoeff ) 5/ ( qcoeff ) 864 ) *t6 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 1680 ) *t7 -
		               ( ( qcoeff ) 1/ ( qcoeff ) 40320 ) *t8 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 14 ) *tDt2 -
		               ( ( qcoeff ) 7/ ( qcoeff ) 60 ) *tDt3 +
		               ( ( qcoeff ) 29/ ( qcoeff ) 360 ) *tDt4 -
		               ( ( qcoeff ) 7/ ( qcoeff ) 240 ) *tDt5 +
		               ( ( qcoeff ) 5/ ( qcoeff ) 864 ) *tDt6 -
		               ( ( qcoeff ) 1/ ( qcoeff ) 1680 ) *tDt7 +
		               ( ( qcoeff ) 1/ ( qcoeff ) 40320 ) *tDt8
		           );

		return ( c0*f0+c1*f1+c2*f2+c3*f3+c4*f4+c5*f5+c6*f6+c7*f7 );
	}


	/** @brief Интегратор для решения задачи Коши с системой ОДУ
	 *
	 * @ingroup integrate
	 * @ingroup numeric
	 *
	 * Задача класса - управление интегрированием методом Адамса с
	 * регулируемым шагом задачи Коши \f$ x'(t)=f(t,x(t)),\, x(t_0)=x(0) \f$.
	 * Для работы метода Адамса необходима разгонная сетка. Класс отвечает за
	 * построение и поддержание разгонной сетки.
	 *
	 * Основной метод класса - stepIntegrate(), выполняющий шаг интегрирования.
	 * Используется метод Адамса 7-го порядка типа предиктор-корректор.
	 * Для хранения разгонной сетки используются циклические массивы xtemp,
	 * rhstemp, rhstime. Выполняется соотношение:
	 *
	 * \code
			rhstemp[i] = f ( rhstime[i], xtemp[i] )
	   \endcode
	 * Для изъятия значений из разгонной сетки используются методы getTime(),
	 * getResult(), getRightHandSide().
	 *
	 * Создание разгонной сетки методом Рунге-Кутты 6-го порядка происходит в
	 * конструкторе.
	 *
	 * Создание новой разгонной сетки с измельченным шагом происходит в методе
	 * subdivide(). Используется интерполяционная формула Адамса, работающая по
	 * уже имеющейся сетке значений искомой функции.
	 *
	 * \tparam spacial Тип пространственных переменных
	 * \tparam rhs Тип объекта, вычисляющего правую часть ОДУ
	 *
	 * Правую часть ОДУ вычисляет объект, для которого определён оператор ():
	 * \code
		spacial operator() ( spacial x, timeMoment t )
	   \endcode
	 *
	 * Также должен у него должен быть перегружен метод stepDiv(), управляющий
	 * шагом интегрирования:
	 *
		\code
		bool stepDiv ( spacial x, timeMoment t )
		\endcode
	 *
	 * Возвращаемое значение true означает, что необходимо интегрирование с
	 * измельченным шагом, false - что достаточно интегрирования с регулярным
	 * шагом. Регулярный шаг должен быть кратен измельченному.
	 *
	 * @tparam spacial Тип пространственной переменной x.
	 * @tparam rhs Класс, реализующий правую часть системы уравнений
	 */
	template <typename spacial, typename rhs>
	class Integrator
	{
	private:

		//Аргументы конструктора
		rhs*f;
		real regularStep;
		int stepDiv;
		real t0;
		spacial init;

		//! Массив для временного хранения значения искомой функции
		spacial*xtemp;

		//! Массив хранящий моменты времени, для которых имеется правая часть
		real*rhstime;

		//! Массив для временного хранения значения правой части
		spacial*rhstemp;


		//! Размер массивов для временного хранения величин
		int tempsize;

		//! Минимальный шаг интегрирования
		real minimalStep;

		//! Переменные для хранения позиции на текущем и следующем шаге
		spacial curX, nextX;

		//! Индекс в циклическом массиве последнего вычисленного элемента
		int curIndex;

		//! Шаг в циклическом массиве до следующего вычисляемого элемента
		int curStep;

		//! Число точек, вычисленных подряд с текущим шагом
		int stepsReady;

		//! Формирование разгонной сетки методом Рунге-Кутты
		void boost(real t0)
		{
			//Разгон методом Рунге-Кутты вперёд. При этом если при разгоне
			//возникает потребность измельчить шаг, разгон начинается сначала с
			//мелким шагом.
			bool boost = false;

			bool sd = f->stepDiv(t0, curX);
			curStep = sd?1:stepDiv;

			rhstemp[0] = (*f) ( t0, curX );
			rhstime[0] = t0;

			//! 1) Выполнить разгон вперёд методом Рунге-Кутты 6-го порядка
			while (boost==false)
			{
				boost = true;
				//Вспомнить начальные данные
				curX = init;


				//Начать разгон
				for (int i=1; i<8; i++)
				{
					//! 1.1) Выполнить один шаг методом Рунге-Кутты 6-го порядка
					stepRungeKutta6(
							//Начало интервала интегрирования
							t0+(i-1)*curStep*minimalStep,
							//начальное значение
							curX,
							//Значение правой части в момент начала
							//интегрирования
							rhstemp[(tempsize+(i-1)*curStep)%tempsize],
							//экземпляр класса rhs, вычисляющий правую часть
							(*f),
							//шаг, на который мы сдвигаемся
							curStep*minimalStep,
							//Вычисляемое значение функции
							nextX,
							//Вычисляемое значение правой части
							rhstemp[(tempsize+i*curStep)%tempsize]
						);
					xtemp[(tempsize+i*curStep)%tempsize] = nextX;
					curX = nextX;
					//Проверить шаг
					/** 1.2) Проверить, не требуется ли на временнОм промежутке
					 * в пределах разгонной сетки более мелкий шаг
					 */
					sd = f->stepDiv(t0+i*curStep*minimalStep,curX);

					int newCurStep = (sd)?1:stepDiv;
					/** 1.3) Если в пределах разгонной сетки требуется более
					 * мелкий шаг, забыть все вычисленные точки и начать разгон
					 * заново (пункт 1).
					 */
					if (newCurStep<curStep)
					{
						boost = false;
						curStep = newCurStep;
						break;
					}

					//! 1.4) В противном случае - продолжать разгон
				}
			}
			for (int i=0; i<8; i++)
				rhstime[i*curStep] = t0+minimalStep*i*curStep;
		}

		//! Деление шага
		void subdivide()
		{
			/** 3.5.2) Если шаг требуется уменьшить, то подготовить
			 * разгонную сетку для метода Адамса 7-го порядка с новым шагом.
			 * Поскольку считается, что предыдущие точки вычислены с
			 * допустимым для них шагом, то возможно вычисление разгонной
			 * сетки с помощью интерполяционной формулы Адамса по этим
			 * предыдущим точкам.
			 */
			if (stepsReady<8)
				throw StrException("Integrator::subdivide",
								   "Внутрення ошибка в модуле интегрирования.");

			/** 3.4.2.1) Выбрать значения правых частей, вычисленных в
			 * последних восьми точках
			 */
			spacial&f0=rhstemp[(8*tempsize+curIndex-curStep*7 )%tempsize];
			spacial&f1=rhstemp[(8*tempsize+curIndex-curStep*6 )%tempsize];
			spacial&f2=rhstemp[(8*tempsize+curIndex-curStep*5 )%tempsize];
			spacial&f3=rhstemp[(8*tempsize+curIndex-curStep*4 )%tempsize];
			spacial&f4=rhstemp[(8*tempsize+curIndex-curStep*3 )%tempsize];
			spacial&f5=rhstemp[(8*tempsize+curIndex-curStep*2 )%tempsize];
			spacial&f6=rhstemp[(8*tempsize+curIndex-curStep*1 )%tempsize];
			spacial&f7=rhstemp[(8*tempsize+curIndex)%tempsize];
			real divs = ( real ) 1/ ( real ) curStep;
			//Дробление шага с помощью интерполяционной формулы Адамса
			for ( int i=0; i<7; i++ )
			{
				real chkt = rhstime[
						(8*tempsize+curIndex-(i+1) )%tempsize
										];
				//Если значение правой части в этой точке не было получено
				//ранее, вычислить его
				if (
					(
					 fabs(
						chkt-(t0+(curIndex-(i+1))*minimalStep)
						 ) >minimalStep*0.5
					)
					||
					(isnan(chkt))
				   )
				{
					/** 3.5.2.2) С помощью интерполяционной формулы Адамса
					 * вычислить новую разгонную сетку
					 */
					int nId=(8*tempsize+curIndex-(i+1))%tempsize;
					//Записать временную отметку
					rhstime[nId]=t0+(curIndex-(i+1))*minimalStep;

					//Вычислить значение искомой функции
					xtemp[nId]=
						xtemp[(8*tempsize+curIndex-i)%tempsize]+
						adamsInterpolation(f0,f1,f2,f3,f4,f5,f6,f7,7-i*divs,
										7-(i+1)*divs)*curStep*minimalStep;

					//Вычислить значение правой части
					rhstemp[nId]=(*f)(rhstime[nId],xtemp[nId]);
				}
			}
			//Отметить, что сетка из, по крайней мере, 8 узлов есть
			stepsReady = 8;
			curStep = 1;
		}

	public:

		//! Один шаг интегрирования методом Адамса с регулируемым шагом
		void stepIntegrate()
		{
			//В данный момент curIndex указывает на позицию последнего
			//записанного в массив result значения, curStep означает шаг,
			//который будет сделан до следующей записи в массив result.

			// При правильной работе должно быть накоплено не меньше 8 узлов
			if ( stepsReady<8 )
				throw StrException("Integrator::stepIntegrate",
								   "Внутренняя ошибка в модуле интегрирования");

			//Если есть 8 накопленных узлов, делать шаг методом Адамса

			//! 3.1) Сделать один шаг методом Адамса
			stepAdams7 (
						//Текущий момент времени
						t0+curIndex*minimalStep,
						//Текущее положение
						curX,
						//Объект, вычисляющий правую часть
						(*f),
						//Размер совершаемого шага
						curStep*minimalStep,
						//Положение в 8 имеющихся точках
						rhstemp[ ( 8*tempsize+curIndex-curStep*7 ) %tempsize],
						rhstemp[ ( 8*tempsize+curIndex-curStep*6 ) %tempsize],
						rhstemp[ ( 8*tempsize+curIndex-curStep*5 ) %tempsize],
						rhstemp[ ( 8*tempsize+curIndex-curStep*4 ) %tempsize],
						rhstemp[ ( 8*tempsize+curIndex-curStep*3 ) %tempsize],
						rhstemp[ ( 8*tempsize+curIndex-curStep*2 ) %tempsize],
						rhstemp[ ( 8*tempsize+curIndex-curStep*1 ) %tempsize],
						rhstemp[ ( 8*tempsize+curIndex ) %tempsize],
						//Переменная для записи нового положения
						nextX,
						//Переменная для записи новой правой части
						rhstemp[ ( curStep+curIndex ) %tempsize]
					   );

			//! 3.2) Запомнить, что время было вычислено с нужным шагом
			rhstime[ ( curIndex+curStep ) %tempsize] = t0+ ( curIndex+curStep )*
																minimalStep;


			//Временно запомнить значение вычисляемой функции
			xtemp[ ( curIndex+curStep ) %tempsize ] = nextX;

//			//! 3.3) Сохранить вычисленные значения в выходные объект result
			//Записать значение вычисляемой функции в массив результата
			//result[curIndex+curStep] = nextX;

			//Продвинулись на curStep
			curIndex+=curStep;
			curX = nextX;

			//Копим узлы, в которых вычислены значения правой части
			stepsReady++;

			//! 3.5) Проверить, нужно ли менять шаг
			//Запросить требуемый шаг интегрирования
			bool divid = f->stepDiv ( t0+curIndex*minimalStep, curX );

			//Вычислить новый шаг
			int newCurStep = (divid)?1:stepDiv;

			//Если нужно увеличить шаг
			if ( newCurStep > curStep )
			{
				/** 3.5.1) Если разрешается использовать более крупный шаг
				 * \f$ h \f$, то проверить, имеются ли значения правой части в
				 * моменты времени \f$ t,\, t-h\,\ldots, t-7h \f$.
				 */
				//Увеличиваем его за счет расчета с меньшим шагом достаточно
				//большого числа вершин. Если накоплено достаточно вершин для
				//увеличения шага - увеличить его.
				if ( ( stepsReady*curStep ) >= ( 8*newCurStep ) )
					//! 3.5.1.1) Продолжить интегрирование с новым шагом \f$h\f$
				{
					//Сколько-то накопленных узлов у нас еще осталось - не будем
					//разбирать все случаи,
					//8 их точно осталось.
					stepsReady = 8;

					//Указать с каким шагом идти дальше
					curStep = newCurStep;
				}
				/** 3.5.1.2) Если не имеются, продолжить интегрирование со
				 * старым шагом до накопления требуемого набора значений правой
				 * части.
				 */
			}

			//Если нужно уменьшить шаг
			else if ( newCurStep < curStep )
				subdivide();

		}


		/** Создание интегратора и инициализация разгонной сетки
		 * @param t0 Начальный момент времени
		 * @param init Начальное условие для задачи Коши
		 * @param f Объект, вычисляющий правую часть системы
		 * @param regularStep Шаг интегрирования на регулярных промежутках
		 * @param stepDiv Делитель шага
		 */
		Integrator (real t0, const spacial & init,
					rhs&f, real regularStep, int stepDiv)
		{
			//Сохранить параметры
			this->t0 = t0;
			this->init = init;
			this->f = &f;
			this->regularStep = regularStep;
			this->stepDiv = stepDiv;


			//Подготовить временные переменные
			minimalStep = regularStep/(real)(stepDiv);
			tempsize = stepDiv*9;
			rhstemp = new spacial[tempsize];
			xtemp = new spacial[tempsize];
			rhstime = new real[tempsize];

			//Пока заполнить NAN'ами, чтобы показать, что массивы rhstemp и
			//xtemp хранят бесполезные значения
			for ( int i=0; i<tempsize; i++ )
				rhstime[i] = std::numeric_limits<real>::quiet_NaN();
			nextX = init; curX = nextX;
			stepsReady = 0;
			boost(t0);
			xtemp[0] = init;
			curIndex = 7*curStep;
			stepsReady = 8;
		}

		~Integrator()
		{
			delete[] rhstemp;
			delete[] xtemp;
			delete[] rhstime;
		}


		inline real currentTime()
		{
			return rhstime[curIndex % tempsize];
		}

		inline real getTime(int idx)
		{
			return rhstime[(tempsize+curIndex-idx*curStep)%tempsize];
		}

		inline spacial & getRightHandSide(int idx)
		{
			return rhstemp[(tempsize+curIndex-idx*curStep)%tempsize];
		}

		inline spacial & getResult(int idx)
		{
			return xtemp[(tempsize+curIndex-idx*curStep)%tempsize];
		}

		inline spacial getResult (real t)
		{
			//Масштабируем t в интервал [0;7]
			real tn = (t - getTime(7))*(getTime(0)-getTime(7));

			//Находим ближайшую вершину
			int nearest = floor(tn+0.5);
			if (nearest<0)
				nearest = 0;
			if (nearest>7)
				nearest = 7;

			return getResult(nearest)+
					adamsInterpolation(getRightHandSide(7),
									   getRightHandSide(6),
									   getRightHandSide(5),
									   getRightHandSide(4),
									   getRightHandSide(3),
									   getRightHandSide(2),
									   getRightHandSide(1),
									   getRightHandSide(0),
									   real(nearest),
									   tn)*curStep*minimalStep;
		}

	};


	/** Функция, решающая задачу Коши \f$x'(t)=f(t,x(t)),\,x(t_0)=x(0)\f$
	 *
	 * @ingroup numeric
	 *
	 * Вывод положений и скоростей осуществляется в специальный объект, для
	 * чего у него должен быть перегружен оператор ():
	 *
	 * spacial & operator () (timeMoment t)
	 *
	 * \tparam spacial Тип пространственных переменных
	 * \tparam rhs Тип объекта, вычисляющего правую часть ОДУ
	 * \tparam acceptor Тип объекта, принимающего результат интегрирования
	 * @param t0 - Начальный момент времени \f$ t_0 \f$
	 * @param t1 - Конец интервала интегрирования \f$ t_1 \f$
	 * @param init Начальное значение \f$ x(t_0) \f$
	 * @param f Объект, вычисляющий правую часть и метод stepDiv
	 * @param regularStep Регулярный шаг интегрирования
	 * @param stepDiv Во сколько раз можно измельчать шаг
	 * @param result Объект, сохраняющий результат
	 *
	 */
	template < typename spacial, typename rhs, typename acceptor >
	void integrate (real t0, real t1, const spacial & init,
					rhs&f, real regularStep, int stepDiv,
					acceptor&result)
	{
		//Создать интегратор
		Integrator<spacial,rhs> integrator(t0,init,f,regularStep,stepDiv);

		/** 2) После удачного завершения разгона сохранить разгонную сетку
		 * в массив результата
		 */
		for (int i=0; i<8; i++)
			result(integrator.getTime(i)) = integrator.getResult(i);
		

		/** 3) Продолжить интегрирование с помощью метода Адамса 7-го порядка
		 * типа предиктор-корректор с переменным шагом
		 */
		while ( integrator.currentTime()<t1 )
		{
			//Сделать шаг
			integrator.stepIntegrate();

			//Записать результат
			result(integrator.currentTime()) = integrator.getResult(0);
		}
	}

};

#endif

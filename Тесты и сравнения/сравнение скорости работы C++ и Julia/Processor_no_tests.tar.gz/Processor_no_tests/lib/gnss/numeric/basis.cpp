//! @file

#include <basis.h>

#include <cmath>

namespace libgnss
{

real UnaryFunction::derivative(int order, double argument) const
{
	return 0;
}

real UnaryFunction::operator ()(real argument) const
{
	return 0;
}

PowerOfX::PowerOfX(unsigned int degree)
{
	n = degree;
}

real PowerOfX::operator ()(real arg) const
{
	return pow(arg, (real)n);
}

real PowerOfX::derivative(int order, double argument) const
{
	if (order == 0)
		return (*this) (argument);
	if (order > n)
		return 0;
	double dernumber = 1;
	for (unsigned int i=0; i<order; i++)
		dernumber*=(n-i);
	return pow(argument, n-order)*dernumber;

}

real CosX::operator () (real arg) const
{
	return cos (arg * n);
}

real CosX::derivative(int order, double argument) const
{
	if (order % 2 == 0)
		return ((order %4 == 0)?1:(-1)) * pow ((real)n,(real)order) * cos(n*argument);
	else
		return ((order %4 == 3)?1:(-1)) * pow ((real)n,(real)order) * sin(n*argument);
}

real SinX::operator () (real arg) const
{
	return sin (arg * n);
}

real SinX::derivative(int order, double argument) const
{
	if (order % 2 == 0)
		return ((order %4 == 0)?1:(-1)) * pow ((real)n,(real)order) * sin(n*argument);
	else
		return ((order %4 == 1)?1:(-1)) * pow ((real)n,(real)order) * cos(n*argument);
}

}

#ifndef CG_HPP_
#define CG_HPP_

#include <DBVariant.h>
#include <DBError.h>
#include <gnssconfig.h>
#include <sparsematrix.hpp>
#include <map>
#include <unistd.h>
#include <cmath>
#include <Distribute.hpp>

#ifdef UseMPI
#include <mpi.h>
#endif


namespace libgnss
{

/**
 * @brief Ошибка: размерности вектора и матрицы не подходят для умножения
 *
 * @ingroup except
 */
class MatrixVectorDimensionError : public StrException
{
public:
	MatrixVectorDimensionError (int M, int V)
		: StrException ("MatrixVectorDimensionError",
						"Ширина "+Variant(M).toString()+" матрицы не совпадает "
						"с высотой "+Variant(V).toString()+" вектора.")
	{

	}
};

/**
 * @brief Ошибка: размерности вектором не совпадают
 *
 * @ingroup except
 */
class VectorDimensionError : public StrException
{
public:
	VectorDimensionError (int M, int N)
		: StrException ("VectorDimensionError",
						"Размерности векторов не совпадают: "
						+Variant(M).toString()+", "+Variant(N).toString())
	{

	}
};

/** @brief Умножение матрицы (число строк больше числа столбцов) на вектор
 *
 * @ingroup numeric
 *
 * @param M Разреженная матрица, записанная по строкам
 * @param V Вектор
 * @param result Вектор результата (точность не повышена)
 *
 */
template < typename MatrixElementType, typename VectorElementType,
			typename ResultElementType> void MxV (
						const RowWiseSparseMatrix < MatrixElementType > & M,
						const std::vector < VectorElementType > & V,
						vector < ResultElementType > & result)
{
	int h = M.getHeight();
	int w = M.getWidth();
	if (w =! V.size())
		throw MatrixVectorDimensionError(w, V.size());
	result.resize(h);
	for (unsigned int i=0; i<h; i++)
	{
		result[i] = 0;
		for (unsigned int j=0; j<M[i].size(); j++)
			result[i]+=((ResultElementType)(M[i][j].second) *
						(ResultElementType)(V[M[i][j].first]));
	}
}

/**
 * @brief Метод распаковывает вектор
 *
 * @ingroup numeric
 *
 * @param v Вектор
 * @param nzcols Список ненулевых столбцов
 * @param srcwidth Ширина исходной матрицы
 *
 * Пусть в некоторой матрице @ref RowWiseSparseMatrix были удалены
 * нулевые столбцы методом @ref RowWiseSparseMatrix::deleteZeroColumns(),
 * при этом был возвращен вектор индексов ненулевых столбцов nzcols.
 * Пусть вектор v предназначен для умножения матрицы после удаления
 * столбцов на него. Данный метод возвращает соответствующий вектор для
 * умножения на него исходной матрицы.
 *
 * @return
 */
template < typename ElementType >
std::vector<ElementType> unpackVector(
		const std::vector<ElementType>&v, const std::vector<int>&nzcols,
										int srcwidth)
{
	std::vector<ElementType> result(srcwidth,(ElementType)0);
	for (unsigned int i = 0; i< nzcols.size(); i++)
		result[nzcols[i]] = v[i];
	return result;
}


#undef CGM_MPI_
#include <cg_.hpp>
#ifdef UseMPI
#define CGM_MPI_
#include <cg_.hpp>
#endif

}

#endif

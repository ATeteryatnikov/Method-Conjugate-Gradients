#ifndef REALSPARSEMATRIX_H_
#define REALSPARSEMATRIX_H_
#include <gnssconfig.h>
#ifdef WithQT
#include <vector>
#include <gnssconfig.h>

#ifdef WithQT
#include <QObject>
#include <QVariantList>
#include <QScriptEngine>
#endif

#include <Types.h>
#include <sparsematrix.hpp>

namespace libgnss
{

class RealLinearisation : public QObject
{
	Q_OBJECT
public:
	RowWiseSparseMatrix<real> lhs;
	std::vector <real > rhs;
	QScriptEngine * engine;
	RealLinearisation (int width, QScriptEngine * eng);

public slots:
	//! Вернуть ширину матрицы
	int getWidth() const;

	//! Вернуть высоту матрицы
	int getHeight() const;

	//! Найти ширину матрицы по индексам ненулевых элементов
	void adjustWidth();

	//! Получить массив пар (индекс, элемент)
	QVariantList getRow(unsigned int line) const;

	//! Получить значение правой части в строке с заданным номером
	double getRHS (unsigned int line) const;

	//! Добавить значение в правую часть
	void addRow (const QVariantList & row, double rhsvalue);
};

}

#endif
#endif

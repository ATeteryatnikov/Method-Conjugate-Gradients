//! @file

#ifdef CGM_MPI_
#undef CGMethod_Name
#undef PlainFinalizeCondition_Name
#define CGMethod_Name CGMethod_MPI
#define PlainFinalizeCondition_Name PlainFinalizeCondition_MPI
#else
#undef CGMethod_Name
#undef PlainFinalizeCondition_Name
#define CGMethod_Name CGMethod
#define PlainFinalizeCondition_Name PlainFinalizeCondition
#endif

/** @brief Умножение транспонированной матрицы на вектор
 *
 * @ingroup numeric
 *
 * @param M Разреженная матрица, записанная по строкам
 * @param V Вектор
 * @param result Вектор результата (точность повышена)
 *
 * При распределённой работе через MPI дополнительно передаются два параметра:
 * comm_size - число MPI-процессов и distribution - размерность подматрицы в
 * каждом процессе.
 */
#ifdef CGM_MPI_
template < typename MatrixElementType, typename VectorElementType,
		   typename ResultElementType> void MTxV_MPI (
						const RowWiseSparseMatrix < MatrixElementType > & M,
						const std::vector < VectorElementType > & V,
						vector < ResultElementType > & result, int comm_size,
						int comm_rank, MPI_Comm comm)
#else
template < typename MatrixElementType, typename VectorElementType,
		   typename ResultElementType> void MTxV (
						const RowWiseSparseMatrix < MatrixElementType > & M,
						const std::vector < VectorElementType > & V,
						vector < ResultElementType > & result)
#endif
{
	int h = M.getHeight();
	int w = M.getWidth();
	if (h!=V.size())
		throw MatrixVectorDimensionError(h, V.size());
	result.resize(w);
	for (unsigned int i=0; i<w; i++)
		result[i] = ResultElementType (0);
	for (unsigned int i=0; i<h; i++)
	{
		for (unsigned int j=0; j<M[i].size(); j++)
		{
			int idx = M[i][j].first;
			if (idx>=w)
				throw StrException("cgMethod->MTxV","Внутренняя ошибка МСГ!");
			ResultElementType val = (ResultElementType)(M[i][j].second);
			result[idx]+=val*(ResultElementType)(V[i]);
		}
	}

#ifdef CGM_MPI_
	//Теперь нужно просуммировать вычисленные в каждом процессе
	//скалярне произведение. Распределить это суммирование между
	//всеми процессами.
	//Какую часть вектора результата будет суммировать данный поток?
	pair<int,int> mytask = distribute(0,w-1,comm_size,comm_rank);
	int mysummsize = mytask.second-mytask.first + 1;
	vector<ResultElementType> allgather(mysummsize*comm_size,
										(ResultElementType)0);
	//Разослать данные по потокам, которые будут их суммировать.
	for (unsigned int i=0; i<comm_size; i++)
	{
		pair<int,int> ithtask = distribute(0,w-1,comm_size,i);
		int ithsummsize = ithtask.second - ithtask.first + 1;
		MPI_Gather(&(result[ithtask.first]), //sendbuf
			ithsummsize*sizeof(ResultElementType),//sendcount
			MPI_BYTE,//sendtype
			allgather.data(), //recvbuf
			ithsummsize*sizeof(ResultElementType),//recvcount
			MPI_BYTE,//recvtype
			i, //root
			MPI_COMM_WORLD //comm
				);
	}

	//Выполнить суммирование
	for (unsigned int i=0; i<mysummsize; i++)
	{
		result[i+mytask.first] = 0.0;
		for (unsigned int j=0; j<comm_size; j++)
			result[i+mytask.first] += allgather[j*mysummsize + i];
	}

	//Теперь раздать всё просуммированное всем потокам
	for (unsigned int i=0; i<comm_size; i++)
	{
		pair<int,int> ithtask = distribute(0,w-1,comm_size,i);
		int ithsummsize = ithtask.second - ithtask.first + 1;
		MPI_Bcast(&(result[ithtask.first]), //buffer
				ithsummsize*sizeof(ResultElementType), //count
				MPI_BYTE, //datatype,
				i, //root
				MPI_COMM_WORLD //comm
				);
	}

	allgather.resize(0);
#endif
}

/** @brief Скалярное произведение двух векторов
 *
 * @ingroup numeric
 *
 * @param V1 Первый вектор
 * @param V2 Второй вектор
 * @param result Результат, точность повышена
 */
#ifdef CGM_MPI_
template < typename Vector1ElementType, typename Vector2ElementType,
					typename ResultType > void dotProd_MPI (
							const std::vector < Vector1ElementType > & V1,
							const std::vector < Vector2ElementType > & V2,
							ResultType & result, int comm_size, MPI_Comm comm)
#else
template < typename Vector1ElementType, typename Vector2ElementType,
					typename ResultType > void dotProd (
							const std::vector < Vector1ElementType > & V1,
							const std::vector < Vector2ElementType > & V2,
							ResultType & result)
#endif
{
	int h1 = V1.size();
	if (h1!=V2.size())
		throw VectorDimensionError(h1, V2.size());
	result = ResultType (0);
	for (unsigned int i=0; i<h1; i++)
		result+=(ResultType(V1[i]) * ResultType(V2[i]));

#ifdef CGM_MPI_
	//Передать вычисленное скалярное произведение в каждый
	std::vector < ResultType > allgather;
	allgather.resize(comm_size);
	MPI_Allgather(&result,sizeof(ResultType),MPI_BYTE,
				  allgather.data(),sizeof(ResultType),MPI_BYTE, comm);

	//Просуммировать
	result = 0;
	for (unsigned int i=0; i<comm_size; i++)
		result+=allgather[i];

#endif
}

/** @brief Процедура нормировки столбцов матрицы
 *
 * @ingroup numeric
 *
 * @param M Разрешенная матрица
 * @param scale Вектор норм исходных столбцов
 *
 */
#ifdef CGM_MPI_
template < typename ElementType > void normalizeColumns_MPI (
							RowWiseSparseMatrix < ElementType > & M,
							std::vector < ElementType > & norms,
							int comm_size, MPI_Comm comm)
#else
template < typename ElementType > void normalizeColumns (
							RowWiseSparseMatrix < ElementType > & M,
							std::vector < ElementType > & norms)
#endif
{
	//Выделить память под нормы подстолбцов, хранимых локально
	int w = M.getWidth();
	int h = M.getHeight();
	norms.resize(w);
	for (unsigned int i=0; i<w; i++)
		norms[i] = (ElementType)(0);

	//Вычислить локальные квадраты норм столбцов
	for (unsigned int i=0; i<h; i++)
		for (unsigned int j=0; j<M[i].size(); j++)
		{
			unsigned int colidx = M[i][j].first;
			ElementType v = M[i][j].second;
			norms[colidx]+=(v*v);
		}

#ifdef CGM_MPI_
	//Если используется MPI, просуммировать по процессам квадраты норм
	std::vector < ElementType > allgather;
	allgather.resize(w*comm_size);
	MPI_Allgather(norms.data(),sizeof(ElementType)*w,MPI_BYTE,
				  allgather.data(),sizeof(ElementType)*w,MPI_BYTE, comm);
	for (unsigned int i=0; i<w; i++)
	{
		norms[i] = 0;
		for (unsigned int j=0; j<comm_size; j++)
			norms[i]+=allgather[i+w*j];
	}
#endif

	for (unsigned int i=0; i<w; i++)
		 norms[i] = sqrt(norms[i]);

	//Теперь поделить столбцы на норму
	for (unsigned int i=0; i<h; i++)
		for (unsigned int j=0; j<M.getRow(i).size(); j++)
		{
			int colidx = M[i][j].first;
			ElementType val = M[i][j].second;
			if (norms[colidx]!=0.0)
				M[i][j].second = val/norms[colidx];
		}
}

/** @brief Класс, реализующий метод сопряженных градиентов (МСГ)
 *
 * @ingroup numeric
 *
 * @tparam ElementType Тип чисел, представляющих элементы матрицы и правой части
 * @tparam InternalPrecision Тип чисел для промежуточных вычислений в методе
 * @tparam FinalCondition Класс, реализующий условие завершения итераций МСГ
 */
template < typename ElementType, typename InternalPrecision,
		   typename FinalCondition>
struct CGMethod_Name
{
#ifdef CGM_MPI_
	int comm_rank;
	int comm_size;
	MPI_Comm comm;
#endif

	int w; //!< Ширина матрицы
	vector < InternalPrecision > c;
	vector < InternalPrecision > Mx0;
	vector < InternalPrecision > di;
	vector < InternalPrecision > ri;
	InternalPrecision alphaiup;
	int iteration;
	vector < InternalPrecision > mdi;
	InternalPrecision alphaidown;
	InternalPrecision alphai;
	vector < InternalPrecision > MTdi;
	InternalPrecision betai;

	/** @brief Умножение транспонированной матрицы на вектор
	 */
	template < typename MatrixElementType, typename VectorElementType,
			   typename ResultElementType>
	void doMTxV(const RowWiseSparseMatrix < MatrixElementType > & M,
				const std::vector < VectorElementType > & V,
				vector < ResultElementType > & result)
	{
#ifdef CGM_MPI_
		MTxV_MPI(M,V,result,comm_size,comm_rank,comm);
#else
		MTxV(M,V,result);
#endif
	}

	/** @brief Скалярное произведение векторов
	 */
	template < typename Vector1ElementType, typename Vector2ElementType,
						typename ResultType >
	void doDotProd (const std::vector < Vector1ElementType > & V1,
					const std::vector < Vector2ElementType > & V2,
					ResultType & result)
	{
#ifdef CGM_MPI_
		dotProd_MPI(V1,V2,result,comm_size,comm);
#else
		dotProd(V1,V2,result);
#endif
	}


	/** @brief Решение задачи методом сопряженных градиентов
	 *
	 * @param M Основная матрица системы
	 * @param B Правая часть
	 * @param xi Начальное приближение решения
	 * @param[out] ret_numiterations Число совершенных итераций
	 */
	ElementType runSolver(
			FinalCondition & cond,
#ifdef CGM_MPI_
			const RowWiseSparseMatrix < ElementType > & M,
			const std::vector < ElementType > &B,
			std::vector < ElementType > &xi,
			int & ret_numiterations,
			MPI_Comm comm
#else
			const RowWiseSparseMatrix < ElementType > & M,
			const std::vector < ElementType > &B,
			std::vector < ElementType > &xi,
			int & ret_numiterations
#endif
			)
	{
#ifdef CGM_MPI_
		this->comm = comm;
		MPI_Comm_rank(comm, &comm_rank);
		MPI_Comm_size(comm, &comm_size);
#endif
		// Начало работы:
		double ratio = 0;
		w = M.getWidth();

		// c=M'*B;
		doMTxV(M,B,c);

		// di=ri=c-M'*M*x0
		MxV(M,xi,Mx0);
		doMTxV(M,Mx0,di);
		for (unsigned int i=0; i<c.size(); i++)
			di[i] = c[i]-di[i];
		ri = di;

#ifdef CGM_DEBUG_
		cout<<"ri: ";
		for (unsigned int i=0; i<w; i++)
			cout<<ri[i]<<" ";
		cout<<endl;
#endif

		iteration = -1;

		// Начало итераций
		while(true)
		{
			iteration++;

			//alphaiup=(ri,ri);
			alphaiup = (InternalPrecision)(0);
			for (unsigned int i=0; i<w; i++)
				alphaiup+=(ri[i])*(ri[i]);

			//	alphaidown = mdi^2=(M*di)^2;
			MxV(M,di,mdi);
			doDotProd(mdi,mdi,alphaidown);

			alphai = alphaiup/alphaidown;

#ifdef CGM_DEBUG_
			cout<<"Alpha: "<<alphai<<" "<<alphaiup<<" "<<alphaidown<<endl;
#endif

			//Проверить условие выхода
			if (cond.isFinish())
				break;

			// xi=xi+alphai*di
			// ri=ri-alphai*(M'*mdi)
			doMTxV (M,mdi,MTdi);
			for (unsigned int i=0; i<w; i++)
			{
				xi[i] = xi[i]+alphai*di[i];
				ri[i] = ri[i]-alphai*MTdi[i];
			}

#ifdef CGM_DEBUG_
			cout<<"x: ";
			for (unsigned int i=0; i<w; i++)
				cout<<xi[i]<<" ";
			cout<<endl;
			sleep (1);
#endif

			// betai=dot(ri,ri)/alphaiup
			betai=(InternalPrecision)(0);
			for (unsigned int i=0; i<w; i++)
				betai+=(ri[i]*ri[i]);
			betai/=alphaiup;

			// di=ri+betai*di
			for (unsigned int i=0; i<w; i++)
				di[i] = ri[i]+betai*di[i];
		}

		ret_numiterations = iteration;
		return sqrt(alphaiup);

	}



};

/**
 * @brief Условие завершения МСГ по равномерной сходимости всех элементов решения
 *
 * @ingroup numeric
 */
template < typename ElementType, typename InternalPrecision>
struct PlainFinalizeCondition_Name
{
	CGMethod_Name <ElementType,InternalPrecision,
			PlainFinalizeCondition_Name	<ElementType, InternalPrecision> > & m;

	vector<ElementType> desiredPrecision;
	int itlim;
	ElementType ratio;

	PlainFinalizeCondition_Name(const vector<ElementType> & desiredPrec,
						   int iteration_limit,
						   CGMethod_Name<ElementType,InternalPrecision,
								PlainFinalizeCondition_Name
										<ElementType, InternalPrecision>
						   > & method)
		: m (method)
	{

		desiredPrecision = desiredPrec;
		ratio = 0;
		itlim = iteration_limit;
	}

	bool isFinish()
	{
		ElementType maxratio = 0;
		for (unsigned int i=0; i<m.w; i++)
		{
			ElementType rtio =
					fabs((double)(m.alphai*m.di[i]))
								/desiredPrecision[i];
			if (maxratio<rtio)
				maxratio = rtio;
		}
		if (maxratio<1)
			return true;

		if (itlim<m.iteration)
			return true;

		if (ratio/maxratio<0.1)
			ratio=maxratio;

		return false;
	}
};

/** @brief Выполнить метод сопряженных градиентов с равномерным условием выхода
 *
 * @ingroup numeric
 *
 * @tparam ElementType
 * @tparam InternalPrecision
 * @param M Основная матрица системы
 * @param B Правая часть системы
 * @param desiredPrecision Для каждого элемента решения: наибольшее допустимое
 * относительное отклонение на следующей итерации от предыдущей
 * @param[in,out] xi Вход: начальное приближение; выход: решение
 * @param[in,out] Принимает максимальное число итераций, возвращает число
 * совершенных итераций.
  */
#ifdef CGM_MPI_
template < typename ElementType, typename InternalPrecision > ElementType
					cgMethod_MPI (
							const RowWiseSparseMatrix < ElementType > & M,
							const std::vector < ElementType > &B,
							const std::vector < ElementType >& desiredPrecision,
							std::vector < ElementType > &xi,
							int  & iteration_limit,int comm_size, MPI_Comm comm)
#else
template < typename ElementType, typename InternalPrecision > ElementType
					cgMethod (
							const RowWiseSparseMatrix < ElementType > & M,
							const std::vector < ElementType > &B,
							const std::vector < ElementType >& desiredPrecision,
							std::vector < ElementType > &xi,
							int  & iteration_limit)
#endif
{
	CGMethod_Name <ElementType,InternalPrecision,
			PlainFinalizeCondition_Name<ElementType,InternalPrecision> > method;
	PlainFinalizeCondition_Name<ElementType,InternalPrecision> fc(
					desiredPrecision, iteration_limit, method);
#ifdef CGM_MPI_
	ElementType res = method.runSolver(fc,M,B,xi,iteration_limit,comm);
#else
	ElementType res = method.runSolver(fc,M,B,xi,iteration_limit);
#endif
	return res;
}

/**
 * @brief Метод удаляет из матрицы нулевые столбцы
 *
 * @ingroup numeric
 *
 * @return Список оставшихся, ненулевых столбцов
 */
#ifdef CGM_MPI_
template < typename ElementType >
std::vector < int > deleteZeroColumns_MPI(
		RowWiseSparseMatrix<ElementType> & matrix, MPI_Comm comm)
#else
template < typename ElementType >
std::vector < int > deleteZeroColumns(
		RowWiseSparseMatrix<ElementType> & matrix)
#endif

{
	//Указать для каждого столбца, нулевой он или нет.
	std::vector < int > used (matrix.getWidth(),-1);
	for (unsigned int i=0; i<matrix.size(); i++)
		for (unsigned int j=0; j<matrix[i].size(); j++)
			used[matrix[i][j].first] = 0;

#ifndef CGM_MPI_
	vector<int> & usedall = used;
#else
	std::vector < int > usedall(matrix.getWidth(),0);
	MPI_Allreduce(used.data(), usedall.data(), matrix.getWidth(),
				  MPI_INT, MPI_MAX, comm);
#endif

	int nzcount = 0;
	for (unsigned int i=0; i<matrix.getWidth(); i++)
		if (used[i]>=0)
			nzcount++;

	//Создать список ненулевых столбцов
	//И сразу запомнить, какой столбец переходит в какой
	std::vector<int> result;
	result.reserve(nzcount);
	for (unsigned int i = 0; i< matrix.getWidth(); i++)
		if (usedall[i]>=0)
		{
			usedall[i] = result.size();
			result.push_back(i);
		}

	//Выполнить сжатие матрицы
	for (unsigned int i=0; i<matrix.size(); i++)
		for (unsigned int j=0; j<matrix[i].size(); j++)
		{
			int idx = matrix[i][j].first;
			matrix[i][j].first = usedall[idx];
		}

	vector < pair<int,ElementType> > fakerow;
	fakerow.push_back(pair<int,ElementType>(result.size()-1,(ElementType)0));
	matrix.push_back(fakerow);
	matrix.adjustWidth();
	matrix.pop_back();
	return result;
}

#ifndef FIT_HPP
#define FIT_HPP

//! @file

#include <cmath>
#include <vector>
#include <cstring>
#include <cstdio>
#include <cassert>

namespace libgnss
{

//Пока используется функция из lapack, точность выше double обеспечить не получится.
//SUBROUTINE DGELS	 ( TRANS	   , M	  , N	  , NRHS	  , A		 , LDA	  , B		 , LDB	  , WORK		 , LWORK	  ,  INFO )
extern "C" void dgels_ ( char * trans, long int * m, long int * n, long int * nrhs, double * a, long int * lda, double * b, long int * ldb, double * work, long int * lwork, long int * info );

extern "C" void dgesvd_( char* jobu, char* jobvt, long int* m, long int* n, double* a,
				long int* lda, double* s, double* u, long int* ldu, double* vt, long int* ldvt,
				double* work, long int* lwork, long int* info );

//SUBROUTINE DGEMM(TRANSA,TRANSB,M,N,K,ALPHA,A,LDA,B,LDB,BETA,C,LDC)
extern "C" void dgemm_(char * transa, char * transb, long int * m, long int * n, long int * k, double * alpha, double * A, long int * lda, double * b, long int *ldb, double * beta, double * c, long int * ldc);

//SUBROUTINE DGEMV(TRANS,M,N,ALPHA,A,LDA,X,INCX,BETA,Y,INCY)
extern "C" void dgemv_(char * transa, long int * m, long int * n, double * alpha, double * a, long int * lda, double * x, long int * incx, double * beta, double * y, long int * incry);


/** @brief Аппроксимация функции для вычисления её промежуточных значений
 *
 * @ingroup numeric
 *
 * Объект класса Fit, получая в качестве параметра конструктора массив значений
 * аргумента функции и массив значений функции, а также базис, аппроксимирует
 * функцию по базису и позволяет находить значение функции в промежуточных
 * точках.
 *
 * Для аппроксимации решается задача наименьших квадратов. Поскольку матрица
 * аппроксимации полная (имеет мало нулей), для решения задачи наименьших
 * квадратов используется QR-разложение (более быстрое, но менее точное, когда
 * задача плохо обусловлена) или SVD-разложение (очень медленное, но возвращает
 * более точный результат).
 *
 * @tparam BasisFunc Тип функций, составляющих базис
 * @tparam fitprecision Тип данных с плавающей точкой
 *
 * Функции, составляющие базис, должны иметь оператор (), принимающий значение
 * аргумента и вычисляющий при нём значение функции.
 */
template < typename BasisFunc, typename fitprecision=double >
class Fit
{
public:
	vector < fitprecision > coefficients;
	
protected:
	vector < BasisFunc > functions;
	fitprecision argShift;
	fitprecision argScale;

	/**
	 * @brief Нахождение коэффициентов аппроксимации
	 * @param argument_vals Массив значений аргумента функции
	 * @param function_vals Массив значений функции
	 * @param basis Базис, по которому будет раскладываться функция
	 * @param shift Разрешить применять сдвиг аргументов
	 * @param method Метод решения задачи наименьших квадратов
	 *
	 * Базис состоит из функций - объектов любого класса, для которых определён
	 * оператор (), принимающий один аргумент типа fitprecision.
	 *
	 * При сдвиге находится среднее значение аргумента и вычитается из всех
	 * значений аргумента; это улучшает обусловленность матрицы. Сдвиг хранится
	 * внутри объекта и корректно учитывается при вычислении значения функции
	 * в точке.
	 *
	 * Метод: Q - QR-разложение, S - SVD-разложение.
	 */
	inline void initFit (const vector < fitprecision > & argument_vals,
						 const vector < fitprecision > & function_vals,
						 const vector < BasisFunc > & basis,
						 bool shift = true,
						 char method='Q')
	{
		if (shift == true)
		{
			argShift = argument_vals[0]+(argument_vals[argument_vals.size()-1]
					-argument_vals[0])*0.5;
			argScale = (fabs(argument_vals[0]-argShift)>
					fabs(argument_vals[argument_vals.size()-1]-argShift))?
				(fabs(argument_vals[0]-argShift)):
				(fabs(argument_vals[argument_vals.size()-1]-argShift));

		}
		else
		{
			argShift = 0;
			argScale = 1;
		}

		char S = 'S';
		char N = 'N';
		char T = 'T';
		functions = basis;

		double * rhs = new double [function_vals.size()];
		double * matrix = new double [function_vals.size()*basis.size()];

		//Перевод из формата fitprecision в формат double
		for (unsigned long int i=0; i<function_vals.size(); i++)
			rhs[i] = function_vals[i];

		//cout.precision(16);
		for (unsigned long int i=0; i<function_vals.size(); i++)
			for (unsigned long int j=0; j<basis.size(); j++)
				matrix[j*function_vals.size() + i] = basis[j]((argument_vals[i]-argShift)/argScale);
		long int nrows = function_vals.size();
		long int ncols = basis.size();


		//Более быстрый, но менее точный QR-метод
		if (method == 'Q')
		{
			long int lwork = -1;
			double dwork;
			long int one = 1;
			long int info = 0;
			dgels_(&N, &nrows, &ncols, &one, matrix, &nrows, rhs, &nrows, &dwork, &lwork, &info );
			assert(info == 0);
			lwork = (long int) (dwork);
			double * work = new double[lwork];
			dgels_(&N, &nrows, &ncols, &one, matrix, &nrows, rhs, &nrows, work, &lwork, &info );
			coefficients.resize(basis.size());
			for (unsigned long int i=0; i<basis.size(); i++)
				coefficients[i] = rhs[i];
			delete [] work;
		}
		//Более точный метод, имеющий черепашью скорость
		else if (method == 'S')
		{
			double * rhs1 = new double [function_vals.size()];
			double * Invmatrix = new double [function_vals.size()*basis.size()];
			double * s = new double [basis.size()];
			double * Umatrix = new double [function_vals.size()*basis.size()];
			double * VTmatrix = new double [basis.size()*basis.size()];
			long int lwork = -1;
			double dwork;
			long int info;
			dgesvd_(&S,&S,&nrows,&ncols,matrix,&nrows,s,Umatrix,&nrows,VTmatrix,&ncols,&dwork,&lwork,&info);
			assert(info == 0);
			lwork=(long int)(dwork);
			double * work=new double[lwork];
			dgesvd_(&S,&S,&nrows,&ncols,matrix,&nrows,s,Umatrix,&nrows,VTmatrix,&ncols,work,&lwork,&info);
			//Вычислить матрицу V^T^T S^{-1}UT
			//1) Поделить матрицу U на S
			for (unsigned long int i=0; i<function_vals.size(); i++)
				for (unsigned long int j=0; j<basis.size(); j++)
					if (s[j] != 0)
						Umatrix[j*function_vals.size()+i]/=s[j];
			double d_one = 1.0;
			double d_zero = 0.0;
			double d_minusone = -1.0;
			//double * ax = new double[function_vals.size()];
			long int i_one = 1;
			memset (Invmatrix, 0, sizeof(double)*ncols*nrows);
			//2) Вычислить V * (S^{-1} U^T)
			dgemm_(&T, &T, &ncols, &nrows, &ncols, &d_one, VTmatrix, &ncols, Umatrix, &nrows, &d_one, Invmatrix, &ncols);
			memset (s, 0, sizeof(double)*basis.size());
			memcpy(rhs1,rhs,sizeof(double)*function_vals.size());
			//Восстанавливаем матрицу A
			for (unsigned long int i=0; i<function_vals.size(); i++)
				for (unsigned long int j=0; j<basis.size(); j++)
					matrix[j*function_vals.size() + i] = basis[j]((argument_vals[i]-argShift)/argScale);
			//Несколько итераций уточнения
			for (unsigned long int i=0; i<10; i++)
			{
				//S = S + A' * rhs1
				dgemv_ (&N,&ncols, &nrows, &d_one, Invmatrix, &ncols, rhs1, &i_one, &d_one, s, &i_one );
				//RHS1 = -A * S
				dgemv_ (&N,&nrows, &ncols, &d_minusone, matrix, &nrows, s, &i_one, &d_zero, rhs1, &i_one);
				//RHS1 = RHS1 + B
				for (unsigned long int j=0; j<function_vals.size(); j++)
					rhs1[j]+=rhs[j];
			}
			coefficients.resize(basis.size());
			for (unsigned long int i=0; i<basis.size(); i++)
				coefficients[i] = s[i];
			delete[] rhs1;
			delete[] work;
			delete[] Invmatrix;
			delete[] Umatrix;
			delete[] VTmatrix;
			delete[] s;
		}
		delete[] matrix;
		delete[] rhs;
	}

public:

	//! Возвращает n-й коэффициент разложения
	inline fitprecision operator[] ( unsigned long int n ) const
	{
		return coefficients [n];
	}

	//Конструктор, который строит приближение не по всем точкам, а только по NumberOfPoints точкам вокруг выбранной точки PointNumber

	/**
	 * @brief Конструктор, строящий приближение по указанному числу точек
	 * @param argument_vals Массив аргументов функции
	 * @param function_vals Массив значений функции
	 * @param basis Базис для разложения функции
	 * @param N Номер точки, в окрестности  которой нужно сделать аппроксимацию
	 * @param NumPoints Число вершин аппроксимации
	 * @param shift Допустимо ли сделать сдвиг значений аргумента
	 * @param method Метод решения задачи МНК
	 */
	inline Fit (const vector < fitprecision > & argument_vals,
				const vector < fitprecision > & function_vals,
				const vector < BasisFunc > & basis,
				long int N, long int NumPoints,  bool shift = true,
				char method='Q')
	{
		long int gt = NumPoints-1;
		if (gt<N + (NumPoints/2))
			gt = N+NumPoints/2;
		if (gt>=argument_vals.size())
			gt = argument_vals.size()-1;

		long int leq = argument_vals.size()-1-NumPoints;
		if (leq> gt-NumPoints+1)
			leq = gt-NumPoints+1;
		if (leq<0)
			leq = 0;
		vector < fitprecision > args;
		args.resize(gt - leq + 1);
		vector < fitprecision > vals;
		vals.resize(gt - leq + 1);
		for (unsigned long int i=leq; i<=gt; i++)
		{
			args[i-leq] = argument_vals[i];
			vals[i-leq] = function_vals[i];
		}
		initFit (args, vals, basis, shift, method);
	}

	/**
	 * @brief Конструктор, аппроксимирующий функцию по данному массиву
	 *
	 * Принимает те же аргументы, что и initFit().
	 */
	Fit (const vector < fitprecision > & argument_vals,
		 const vector < fitprecision > & function_vals,
		 const vector < BasisFunc > & basis,
		 bool shift = true, char method='Q')
	{
		initFit (argument_vals, function_vals, basis, shift, method);
	}

	inline fitprecision operator () ( fitprecision argument )
	{
		fitprecision result = 0;
		for (unsigned long int i=0; i<coefficients.size(); i++)
			result+=coefficients[i]*functions[i]((argument-argShift)/argScale);

		return result;

	}
};


}

#endif

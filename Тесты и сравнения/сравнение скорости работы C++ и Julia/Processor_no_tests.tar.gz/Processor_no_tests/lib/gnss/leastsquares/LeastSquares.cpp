#include <gnssconfig.h>
#include <cg.hpp>
#include <LeastSquares.h>
#include <Types.h>
#include <DBInterpolate.h>
#include <Interpolate.hpp>
#include <cstring>
#include <interval.hpp>

namespace libgnss
{


real NormalEquation::func0()
{
	return f0;
}

NormalEquation::NormalEquation (LeastSquaresProblem *problem,
					const string & name,
					int targetColumnNumber, const Tuple & target_key)
{
	this->problem = problem;
	this->tables = problem->getBase();
	this->targetTable = problem->getBase()->getTable(name);
	this->targetColumnNumber = targetColumnNumber;
	this->target_key = target_key;
	stddt.first = 1.0l;
	stddt.second[1.0l] = 1.0l;
	stddt.second[0.0l] = -1.0l;
}

void NormalEquation::calcDerivatives (const string & param_name,
									  DBTable & result) const
{
	//Попробовать посчитать производную эффективным способом
	Derivate * derivator = problem->getDerivator(param_name);
	if (derivator != 0)
	{
		derivator->calcDerivatives(this, result);
		return;
	}
	DBTable * parameters = getBase()->getTable(param_name);
	for (DBTable::DBIterator it = parameters->const_begin();
		 it!=parameters->const_end(); ++it)
	{
		real der = calcSingleDerivative(param_name, it);
		if (der!=0)
			result.insertRow(it.subkey(), Tuple()<<der);
	}
}

real NormalEquation::calcSingleDerivative(const string & param_name,
								DBTable::DBIterator &val_it) const
{
	const DerivateTemplete * dt =
			& getDerivateTemplete(param_name,val_it.subkey());
	real param_value = val_it[0].toDouble();
	real scale = param_value;
	if (scale == 0)
		scale = dt->first;
	real deriv = 0;
	//Вычислять производную по шаблону
	for (map < real, real > :: const_iterator it0 = dt->second.begin();
		 it0!=dt->second.end(); ++it0)
	{
		//Вариировать значение параметра
		val_it.updateCell(0, param_value + scale * it0->first);
		//Вычислять при вариированном значении параметра значение целевого
		//функционала
		deriv += it0->second * functional();
	}
	//Вернуть исходное значение параметра
	val_it.updateCell(0, param_value);

	//Досчитать производную
	return deriv/scale;
}

const NormalEquation::DerivateTemplete &NormalEquation::getDerivateTemplete(
						const string & param_name,
						const Tuple &param_key) const
{
	return stddt;
}

real NormalEquation::getRMS() const
{
	return 1.0l;
}

LeastSquaresProblem::LeastSquaresProblem (DBTableCollection * collection,
										  const string & target,
										  int targetColumnValue)
{
	constructRowIndex = false;
	base = collection;
	target_table_name = target;
	target_column_number = targetColumnValue;
	target_table = collection->getTable(target);
}

DBTable * LeastSquaresProblem::imitate(bool replace)
{
	l.drop();
	DBTable * imitation = 0;

	if (replace == false)
		imitation = new DBTable(getTargetTable()->getKeyColumns(),
						Columns()<<Column(Variant::TYPE_DOUBLE, "imitation"));

	//Пройти по всей целевой таблице
	for (DBTable::DBIterator it = getTargetTable()->begin();
		 it!=getTargetTable()->end(); ++it)
	{
		Tuple key = it.subkey();

		//Для ключа создать объект уравнения
		NormalEquation * equation = createNormalEquation(key);
		if (equation == 0)
			continue;

		//Взять его правую часть
		//! @todo Вести логи ошибок имитации!
		real value;
		try
		{
			value = equation->func0();
		}
		catch (StrException & e)
		{
			l.logException(e);
			delete equation;
			continue;
		}

		//Больше от объекта уравнения ничего не нужно
		delete equation;

		//Заменить значение в целевой таблице
		if (replace == true)
			it.updateCell(getTargetColumnNumber(), value);
		//Либо записать в отдельную таблицу.
		else
			imitation->insertRow(key, Tuple()<<value);
	}

	if (replace == false)
		return imitation;
	else
		return getTargetTable();
}

void LeastSquaresProblem::dropColumnsList()
{
	if (columns.size() != 0)
	{
		for (map < string, DBTable*>::iterator it = columns.begin();
						it!=columns.end(); ++it)
			delete it->second;
		columns.clear();
	}
}

void LeastSquaresProblem::createColumnsList()
{
	dropColumnsList();
	int paramn = 0;
	for (set<string>::iterator it = parameters.begin();
		 it!=parameters.end(); ++it)
	{
		DBTable * tbl = getBase()->getTable(*it);
		columns[*it] = new DBTable(tbl->getKeyColumns(),
			Columns()<<Column(Variant::TYPE_INT, "col_idx"));
		for (DBTable::DBConstIterator it1 = tbl->const_begin();
			 it1!=tbl->const_end(); ++it1)
			columns[*it]->insertRow(it1.subkey(), Tuple()<<(paramn++));
	}
	columnscount = paramn;
}

void LeastSquaresProblem:: linearize (RowWiseSparseMatrix <real> & lhs,
					vector<real> & rhs, vector<Tuple> *rowidx,
									  const Tuple &from, const Tuple &until)
{

	//0) Определить, какую часть таблицы необходимо пробежать:
	// от итератора it_from до итератора it_until не включая последний.
	int N = getTargetTable()->getKeyColumnsCount();
	int n = N;
	DBTable::DBConstIterator it_from = getTargetTable()->find(from);
	if (it_from.isEnd())
		return;

	DBTable::DBConstIterator it_until;
	if (until.size() == 0)
	{
		it_until = getTargetTable()->const_end();
		n = from.size();
	}
	else
	{
		it_until= getTargetTable()->find(until);
		//Найти общую часть ключей
		for(unsigned int i=0; i<n; i++)
			if (it_from.keyColumnValue(i)!=it_until.keyColumnValue(i))
			{
				n = i;
				break;
			}
	}

	l.drop();
	//Заранее выделить память
	lhs.reserve(getTargetTable()->count());
	rhs.reserve(getTargetTable()->count());

	//1) Сформировать матрицу и правую часть
	// Пройти по обозначенной части таблицы
	for (DBTable::DBConstIterator it = it_from; it != it_until;
		 it.subinc(N-1,n-1))
	{
		Tuple key = it.subkey();

		//Создать обекъект уравнения
		NormalEquation * equation;
		try
		{
			equation = createNormalEquation(key);
		}
		catch (const StrException & e)
		{
			l.logException(e);
			continue;
		}

		if (equation == 0)
			continue;

		//Строка матрицы
		vector<pair<int, real> > mat_row;

		real targetvalue = it[getTargetColumnNumber()].toDouble();
		real imitvalue;

		//Взять правую часть
		try
		{
			imitvalue = equation->func0();
		}
		catch (StrException & e)
		{
			l.logException(e);
			delete equation;
			continue;
		}

		real rms = equation->getRMS();
		if (rms == 0)
			throw StrException("LeastSquaresProblem:: linearize",
							   "У уравнения МНК не может быть нулевого "
							   "среднеквадратического отклонения");
		real onebyrms = 1.0/rms;


		real diffvalue = targetvalue - imitvalue;
		real rhselement = diffvalue * onebyrms;
		rhs.push_back(rhselement);

		//Вычислить производные
		for (map<string,DBTable* >::iterator it2 = columns.begin();
			 it2!=columns.end(); ++it2)
		{
			//Создать таблицу для хранения производных
			DBTable * params = getBase()->getTable(it2->first);
			DBTable derivs (params->getKeyColumns(),
					Columns()<<Column(Variant::TYPE_DOUBLE, "deriv"));

			//Вычислить производные
			equation->calcDerivatives(it2->first, derivs);

			for (DBTable::DBConstIterator it3 = derivs.const_begin();
				 it3!=derivs.const_end(); ++it3)
			{
				int idx = (*(it2->second))[it3.subkey()][0].toInt();
				real thismatelement = onebyrms*it3[0].toDouble();
				if (fixedparams.find(idx) == fixedparams.end())
				//Скопировать производные в новую строку матрицы
					mat_row.push_back(pair<int,real>(idx,
												thismatelement));
			}
		}

		lhs.push_back(mat_row);
		//Если нужно, составлять индекс строк
		if (rowidx!=0)
			rowidx->push_back(it.subkey());
		delete equation;
	}

}

void LeastSquaresProblem::updateParameters(const vector<real>&solution)
{
	for (set < string > :: iterator it = parameters.begin();
		 it!=parameters.end(); ++it)
	{
		DBTable * param_table = getBase()->getTable(*it);
		for (DBTable::DBIterator it2 = param_table->const_begin();
			 it2!=param_table->const_end(); ++it2)
		{
			Tuple key = it2.subkey();
			DBTable::DBConstIterator it3 = columns[*it]->find(key);
			if (it3 != columns[*it]->const_end())
			{
				int idx = it3[0].toInt();
				real value = it2[0].toDouble();
				real dvalue = solution[idx];
				it2.updateCell(0, value + dvalue);
			}
			else
			{
				throw InternalException("В методе "
								"LeastSquaresProblem::updateParameters "
								   "Потеряна связь параметров и решения");
			}
		}
	}
}

#ifdef UseMPI
real LeastSquaresProblem::adjust(int &iterationlimit, int comm_size,
						MPI_Comm comm, const Tuple &from, const Tuple &until)
{
	vector<Tuple> rowidx;
	vector<Tuple>*ridx = (getConstructRowIdx()?&rowidx:0);
	createColumnsList();
	RowWiseSparseMatrix<real> lhs(columnscount);
	vector < real > rhs;

	//1) Линеаризовать задачу наименьших квадратов
	linearize(lhs, rhs, ridx, from, until);
	processReadyMatrix(lhs,rhs,ridx);

	//2) Получить вектор точности
	vector < real > precision(columnscount);
	for (map<string, DBTable* >::iterator it = columns.begin();
		 it!=columns.end(); ++it)
		for (DBTable::DBConstIterator it2 = it->second->const_begin();
			 it2!=it->second->const_end(); ++it2)
			precision[it2[0].toInt()] = getPrecision(it->first, *it2);

	//3) Решить линейную задачу МНК
	vector < real > solution(columnscount, 0.0l);
	vector < real > norms;
	normalizeColumns_MPI(lhs,norms,comm_size,comm);
	real residual = cgMethod_MPI<real, leastsquaresprec>(
				lhs, rhs, precision, solution, iterationlimit,comm_size,comm);
	for (unsigned int i=0; i<norms.size(); i++)
		if (norms[i]!=0)
			solution[i] /= norms[i];

	//4) Внести поправки в параметры
	processSolution(lhs, rhs, solution);
	updateParameters(solution);

	//5) Вернуть невязку
	return residual;
}
#endif

real LeastSquaresProblem::adjust(int &iterationlimit, const Tuple &from,
								 const Tuple &until)
{
	vector<Tuple> rowidx;
	vector<Tuple>*ridx = (getConstructRowIdx()?&rowidx:0);
	createColumnsList();
	RowWiseSparseMatrix<real> lhs(columnscount);
	vector < real > rhs;

	//1) Линеаризовать задачу наименьших квадратов
	linearize(lhs, rhs, ridx, from, until);
	processReadyMatrix(lhs,rhs,ridx);

	//2) Получить вектор точности
	vector < real > precision(columnscount);
	for (map<string, DBTable* >::iterator it = columns.begin();
		 it!=columns.end(); ++it)
		for (DBTable::DBConstIterator it2 = it->second->const_begin();
			 it2!=it->second->const_end(); ++it2)
			precision[it2[0].toInt()] = getPrecision(it->first, *it2);

	//3) Решить линейную задачу МНК
	vector < real > solution(columnscount, 0.0l);
	vector < real > norms;
	normalizeColumns(lhs,norms);
	real residual = cgMethod<real, leastsquaresprec>(
				lhs, rhs, precision, solution, iterationlimit);
	for (unsigned int i=0; i<norms.size(); i++)
		if (norms[i]!=0)
			solution[i] /= norms[i];

	//Вернуть нормированные столбцы матрицы
	for (unsigned int i=0; i<lhs.size(); i++)
		for (unsigned int j=0; j<lhs[i].size(); j++)
		{
			int col = lhs[i][j].first;
			lhs[i][j].second *= norms[col];
		}

	processSolution(lhs, rhs, solution);
	updateParameters(solution);

	//5) Вернуть невязку
	return residual;
}

void LeastSquaresProblem::addAdjustableParameter(const string & paramname)
{
	getBase()->getTable(paramname);
	parameters.insert(paramname);
}

void LeastSquaresProblem::removeAdjustableParameter(const string & paramname)
{
	parameters.erase(paramname);
}

LeastSquaresProblem::~LeastSquaresProblem()
{
	dropColumnsList();
	for (map < string, Derivate * >::iterator it = derivators.begin();
		 it!=derivators.end(); ++it)
		delete it->second;
}

void LeastSquaresProblem::lockParameter(const string &name, const Tuple &key)
{
	DBTable::DBConstIterator it = columns[name]->find(key);
	if (it == columns[name]->const_end())
		return;
	int idx = it[0].toInt();
	fixedparams.insert(idx);
}

void LeastSquaresProblem::releaseParameter(const string &name, const Tuple &key)
{
	DBTable::DBConstIterator it = columns[name]->find(key);
	if (it == columns[name]->const_end())
		return;
	int idx = it[0].toInt();
	fixedparams.erase(idx);
}

#include <f2c.h>

extern "C" int dgetrf_(integer *m, integer *n, doublereal *a, integer *
					   lda, integer *ipiv, integer *info);

extern "C" int dgetri_(integer *n, doublereal *a, integer *lda, integer
	*ipiv, doublereal *work, integer *lwork, integer *info);


std::vector<real> LeastSquaresProblem::getParametersStdDev(
			const RowWiseSparseMatrix<real> & lhs,
			const std::vector<real> & rhs,
			const std::vector<real> & solution, int trust)
{
	if (lhs.getWidth() != solution.size())
		throw MatrixVectorDimensionError(lhs.getWidth(), solution.size());
	if (lhs.size() != rhs.size())
		throw StrException ("MatrixDimensionError", "Размеры матрицы и правой "
													"части СЛАУ не совпадают");
	integer N = solution.size();
	integer M = lhs.size();

	//0) Найти индексы ненулевых столбцов
	vector<bool> nz_flag(N,false);
	for (unsigned int i=0; i<M; i++)
		for (unsigned int j=0; j<lhs[i].size(); j++)
			nz_flag[lhs[i][j].first] = true;

	vector<int> nz_indices(N,-1);
	unsigned int k=0;
	for (unsigned int i=0; i<N; i++)
		if (nz_flag[i]==true)
		{
			nz_indices[i] = k;
			k++;
		}
	//Число ненулевых столбцов
	integer N_nonzero = k;

	//1) Найти квадрат нормы невязки (сумму квадратов её элементов)
	real residualnormsq = (real)(0);
	for (unsigned int i=0; i<rhs.size(); i++)
	{
		real residual = rhs[i];
		for (unsigned int j=0; j<lhs[i].size(); j++)
		{
			int pos = lhs[i][j].first;
			residual -= lhs[i][j].second * solution[pos];
		}
		residualnormsq+=(residual*residual);
	}

	//2) Дисперсия единицы веса
	real D = residualnormsq/(M-N);

	//3) Найти матрицу ковариации
	//3.1) Cформировать матрицу A^T A для lapack'а
	vector<double> A(N_nonzero * N_nonzero,0.0);
	for (unsigned int i=0; i<M; i++)
		for (unsigned int j=0; j<lhs[i].size(); j++)
			for (unsigned int k=0; k<lhs[i].size(); k++)
			{
				int idx1 = nz_indices[lhs[i][j].first];
				int idx2 = nz_indices[lhs[i][k].first];
				double toadd = lhs[i][j].second * lhs[i][k].second;;
				A[idx1*N_nonzero+idx2] += toadd;
			}
	//3.2) Найти обратную матрицу Q
	integer * ipiv = new integer[N_nonzero+1];
	integer lwork = N_nonzero*N_nonzero;
	double * work = new double[lwork];
	integer info;
	dgetrf_(&N_nonzero,&N_nonzero,A.data(),&N_nonzero,ipiv,&info);
	dgetri_(&N_nonzero,A.data(),&N_nonzero,ipiv,work,&lwork,&info);
	delete[] work;
	delete[] ipiv;


	//Умножить C=Q*AT на интервальный вектор возможных границ невязок
	//правой части.
	vector<real> result(N,(real)0);

	for (unsigned int i=0; i<N; i++)
	{
		if (nz_flag[i] == false)
			continue;
		int nzi = nz_indices[i];

		for (unsigned int k = 0; k<M; k++)
		{
			real cik = (real)0;
			for (unsigned int j_=0; j_<lhs[k].size(); j_++)
			{
				int j = lhs[k][j_].first;
				if (nz_flag[j] == true)
				{
					real akj = lhs[k][j_].second;
					int nzj = nz_indices[j];
					real qij = A[nzj*N_nonzero + nzi];
					cik += akj * qij;
				}
			}
			result[i]+=fabs(cik);
		}
		result[i]*=(sqrt(D)*trust);
	}
	return result;
}

void LeastSquaresProblem::deleteOutliers(
		real nsigma, RowWiseSparseMatrix<real> &lhs, vector<real> &rhs,
		const vector<Tuple> & rowidx, const vector<bool> &keyclms)
{
	if (rowidx.size() == 0)
		return;
	if (nsigma<=0)
		throw StrException("LeastSquaresProblem::deleteOutliers",
						   "nsigma<=0");
	Columns keycolumns;
	for (unsigned int i=0; i<keyclms.size(); i++)
		if (keyclms[i])
			keycolumns.push_back(Column(rowidx[0][i].getType(),
										"clm"+Variant(int(i)).toString()));
	DBTable convolution(keycolumns,
						Columns()<<Column(Variant::TYPE_DOUBLE,"RMS")
						<<Column(Variant::TYPE_INT,"Count"));
	real rmssq_common=(real)0;
	int cnt=0;
	for (unsigned int i=0; i<rowidx.size(); i++)
	{
		Tuple subkey;
		subkey.reserve(keycolumns.size());
		for (unsigned int j=0; j<keyclms.size(); j++)
			if (keyclms[j])
				subkey.push_back(rowidx[i][j]);
		DBTable::DBIterator it = convolution.find(subkey);
		real rmssq = rhs[i];
		rmssq*=rmssq;
		if (it.isEnd())
			convolution.insertRow(subkey,Tuple()<<rmssq<<1);
		else
		{
			real prevv = it[0].toDouble();
			int prevcnt = it[1].toDouble();
			it.updateCell(0,prevv+rmssq);
			it.updateCell(1,prevcnt+1);
		}
		rmssq_common+=rmssq;
		cnt++;
	}
	rmssq_common = sqrt(rmssq_common/cnt);

	//Удалить из таблицы строки, подлежащие удалению
	for (DBTable::DBIterator it = convolution.begin(); it.isEnd()==false; )
	{
		real this_rmssq = sqrt(it[0].toDouble()/it[1].toInt());

		if (this_rmssq>=nsigma*rmssq_common)
			it.deleteRow();
		else
			++it;
	}

	//Умножить на ноль строки, подлежащие удалению
	for (unsigned int i=0; i<rowidx.size(); i++)
	{
		Tuple subkey;
		subkey.reserve(keycolumns.size());
		for (unsigned int j=0; j<keyclms.size(); j++)
			if (keyclms[j])
				subkey.push_back(rowidx[i][j]);
		DBTable::DBConstIterator it = convolution.find(subkey);
		if (it.isEnd())
		{
			rhs[i]*=0;
			for (unsigned int j=0; j<lhs[i].size(); j++)
				lhs[i][j].second*=0;
		}
	}

}

#ifdef WithQT
#ifdef UseMPI
double LeastSquaresProblem::iteration (int cgiterationlimit,
									   QMPICommunicator & comm)
{
	return adjust(cgiterationlimit, comm.getCommSize(),
				  comm.currentCommunicator());
}

double LeastSquaresProblem::iteration (int cgiterationlimit)
{
	int commsize;
	MPI_Comm_size(MPI_COMM_WORLD, &commsize);
	return adjust(cgiterationlimit, commsize, MPI_COMM_WORLD);
}

#else

double LeastSquaresProblem::iteration (int cgiterationlimit)
{
	return adjust(cgiterationlimit);
}

#endif

void LeastSquaresProblem::enumerateColumns()
{
	createColumnsList();
}

void LeastSquaresProblem::linearize (QObject * ll)
{
	RealLinearisation * ll_ = qobject_cast<RealLinearisation *> (ll);
	linearize(ll_->lhs, ll_->rhs,0);
}


void LeastSquaresProblem::updateParameters(const QVariantList & solution)
{
	vector < real > solution_;
	solution_.resize(solution.size());
	for (unsigned int i=0; i<solution.size(); i++)
		solution_[i] = solution[i].toDouble();
	updateParameters(solution_);
}

QObject *LeastSquaresProblem::getSession() const
{
	return base;
}

QObject * LeastSquaresProblem::getTarget() const
{
	return getTargetTable();
}

QString LeastSquaresProblem::getNameOfTargetTable() const
{
	return QString::fromStdString(getTargetTableName());
}

int LeastSquaresProblem::getTargetTableColumnNumber() const
{
	return getTargetColumnNumber();
}

void LeastSquaresProblem::setAdjustableParameter(const QString & paramname)
{
	addAdjustableParameter(paramname.toStdString());
}

void LeastSquaresProblem::unsetAdjustableParameter (const QString & paramname)
{
	removeAdjustableParameter(paramname.toStdString());
}

int LeastSquaresProblem::getNumberOfColumns() const
{
	return columnscount;
}

QObject *LeastSquaresProblem::getColumnsTable(const QString & paramname)
{
	return (QObject*)(getColumnsIndex(paramname.toStdString()));
}

int LeastSquaresProblem::getColumnNumber (const QString & paramname,
										  const QVariantList & t)
{
	return getParameterColumnIndex(paramname.toStdString(),
								   variantListToTuple(t));
}

QVariantList LeastSquaresProblem::getAdjustableParametersNames() const
{
	QVariantList result;
	for (set<string>::iterator it = parameters.begin();
		 it!=parameters.end(); ++it)
		result.push_back(QString::fromStdString( *it));
	return result;
}

void LeastSquaresProblem::fixAdjustableParameter(const QString & name,
									  const QVariantList & key)
{
	lockParameter(name.toStdString(), variantListToTuple(key));
}

void LeastSquaresProblem::releaseAdjustableParameter(const QString&name,
										  const QVariantList&key)
{
	releaseParameter(name.toStdString(), variantListToTuple(key));
}

QString LeastSquaresProblem::getLastLog() const
{
	ostringstream log;
	printLastExceptionLog(log);
	return QString::fromStdString(log.str());
}

QScriptValue doimitate(QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		LeastSquaresProblem * lsp = qobject_cast<LeastSquaresProblem*>
				(ctx->argument(0).toQObject());
		bool replace_ = ctx->argument(1).toBool();
		DBTable * result_ = lsp->imitate(replace_);
		return eng->newQObject(result_,QScriptEngine::ScriptOwnership);
	}
	catch (StrException & e)
	{
		returnError(eng, string("Имитация не удалась: ") + e.what());
	}
}

BuiltIn doimit("targetValuesImitation", 2, doimitate);
#endif

void LeastSquaresProblem::processReadyMatrix(RowWiseSparseMatrix<real> &lhs,
											 vector<real> &rhs,
											 const vector<Tuple> *rowidx)
{

}

void LeastSquaresProblem::processSolution(
		const RowWiseSparseMatrix < real > & lhs,
		const vector<real> & rhs,
		vector<real> & solution)
{

}

/*****************************************************************************
 *  Модуль дифференцирования по интерполируемому по времени параметру        *
 *****************************************************************************/



//InterpolatedParameterStorage * paramstorage;
//public:

/**
 * @brief Конструктор
 * @param ls Задача наименьших квадратов
 * @param param_name Имя параметра, по которому требуется дифференцировать
 */
InterpolatedParameterDerivator::InterpolatedParameterDerivator
	(const LeastSquaresProblem * ls, const string & param_name)
{
	paramstorage = (InterpolatedParameterStorage*)
			(ls->getBase()->getTable(param_name));
}

void InterpolatedParameterDerivator::calcSingleSubkeyDerivatives (
		const NormalEquation * neq,
		const Tuple & subkey, real t,
		DBTable & result)
{
	//Вычислить производную по мгновенному значению параметра
	real instantderiv = instantDerivative(neq, subkey);

	Tuple subkey0 = subkey;

	//Если уже она равна нулю, нет смысла считать дальше.
	if (instantderiv == 0)
		return;

	//Теперь найти окрестность данного мгновенного значения параметра
	int interpord = paramstorage->getInterpolateOrder(subkey);
	const DBTable*discontinuities = paramstorage->getDiscontinuitiesTable();
	real maxstep = paramstorage->getMaxVerticesStep(subkey);
	real extr = paramstorage->getExtrapolationLimit(subkey);
	vector < real > args;
	vector < real > values;
	args.reserve((interpord<1)?1:interpord);
	values.reserve((interpord<1)?1:interpord);
	getNeighbourhood<real>(args,values,*paramstorage,discontinuities,subkey0,
						   t,0,interpord,extr,maxstep);
	subkey0.push_back(Variant());
	int N = subkey0.size();

	real instantvalue = interpolateLagrange(args, values, t);

	for (unsigned int i=0; i<args.size(); i++)
	{
		real savevalue = values[i];
		values[i]+=1.0l;
		real lagderiv = interpolateLagrange(args, values, t)
				-instantvalue;
		values[i]=savevalue;
		subkey0[N-1] = args[i];
		if (lagderiv!=0)
			result.insertRow(subkey0,Tuple()<<(lagderiv * instantderiv));
	}
}

void InterpolatedParameterDerivator::calcDerivatives
			(const NormalEquation *neq, DBTable & result)
{
	int N = paramstorage->getKeyColumnsCount();
	real t = getTimeMoment(neq);
	vector <Tuple> subkey = getSubkeys(neq);
	for (int i=0; i<subkey.size(); i++)
		calcSingleSubkeyDerivatives(neq, subkey[i], t, result);
}
}

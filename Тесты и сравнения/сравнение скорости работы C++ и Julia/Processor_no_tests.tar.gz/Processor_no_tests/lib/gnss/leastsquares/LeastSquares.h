#ifndef LEASTSQUARES_H_
#define LEASTSQUARES_H_

//! @file

#include <gnssconfig.h>

#include <string>
#include <set>
#include <vector>
#include <map>
#include <stdexcept>

#ifdef UseMPI
#include <mpi.h>
#endif


#include <gnssconfig.h>

#include <BuiltIn.h>
#include <Types.h>
#include <DBTableCollection.h>
#include <ParameterStorage.h>
#include <cg.hpp>
#include <InterpolatedParameterStorage.h>
#include <ScriptShell.h>
#include <realsparsematrix.h>
#ifdef WithQT
#include <QVariantList>
#endif

namespace libgnss
{

/**
 * @brief Ошибка: функционал неприменим к строке целевой таблицы
 *
 * @ingroup leastsq
 */
class FunctionalNotApplicableException : public StrException
{
public:
	FunctionalNotApplicableException (std::string message)
		: StrException("FunctionalNotApplicableException",message)
	{

	}
};

/**
 * @brief Ошибка: параметр не уточняется в данной задаче МНК
 *
 * @ingroup leastsq
 */
class ParameterNotAdjustableException : public StrException
{
public:
	ParameterNotAdjustableException(const std::string & pname)
		: StrException("ParameterNotAdjustableException",
			  "Ошибка: параметр "+pname+" не уточняется.")
	{

	}
};

class Derivate;
class LeastSquaresProblem;

/** @brief Одно уравнение системы для метода наименьших квадратов
 *
 * @ingroup leastsq
 *
 * Основные функции этого класса - это вычисление правой части и коэффициентов
 * левой части уравнения для метода наименьших квадратов.
 *
 * Нормальное уравнение имеет вид:
 * \f[
	f_0 - f(p_0) = \sum\limits_{p} \frac{\partial f(p_0)}{\partial p},
  \f]
 * где \f$f\f$ - аппроксимирующая функция, \f$f_0\f$ - целевое значение,
 * \f$p\f$ - параметры, от которых зависит аппроксимирующая функция,
 * \f$p_0\f$ - набор априорных значений всех параметров функции \f$f\f$.
 *
 * В данной реализации в качестве целевых значений выступают значения заданной
 * колонки целевой таблицы (номер колонки и имя таблицы передаются конструктору
 * класса). В качестве параметров могут выступать любые таблицы коллекции.
 * Считается, что данные в таблицах в момент вызова конструктора представляют
 * \f$ p_0\f$, и в конструкторе должно быть вычислено значение целевого
 * функционала с априорными значениями параметров. Далее оно должно возвращаться
 * методом func0().
 *
 * Целевой функионал задаётся методом functional(), который должен быть чистой
 * функцией, то есть не иметь побочных эффектов.
 *
 * Производные по параметрам вычисляются методом calcDerivatives(). В
 * стандартной реализации данный метод вычисляет производные численно.
 * Каждая отдельная производная вычисляется методом calcSingleDerivative().
 * Шаблон для дифференцирования возвращается методом getDerivateTemplete().
 * Шаблон дифференцирования состоит из двух частей: набора вершин с
 * коэффициентами и одиночного числа. Когда априорное значение параметра не
 * равно нулю, для дифференцирования используется набор вершин, где
 * приращения параметра умножаются на его значение. Если параметр равен нулю,
 * то вместо него для масштабирования шаблона используется передаваемое
 * число.
 *
 * Если есть смысл вычислять сразу несколько производных по параметру одного
 * типа, то можно перегрузить метод calcDerivatives() можно перегрузить, при
 * этом для других параметров, для которых можно вычислять производные
 * по одной, можно использовать вызов этого метода из базового класса.
 */
class NormalEquation : QObject
{
	Q_OBJECT
public:
	typedef pair < real, map < real, real > > DerivateTemplete;
protected:
	DerivateTemplete stddt;
	real f0;
	LeastSquaresProblem * problem;
private:
	DBTableCollection * tables;
	DBTable * targetTable;
	int targetColumnNumber;
	Tuple target_key;


public:
	//! Возвращает значение функционала на априорных значениях параметров
	virtual real func0();

	//! Вычисляет и возвращает функионал на текущих значениях параметров
	virtual real functional() const = 0;

public:

	/**
	 * @brief Конструктор уравнения для МНК
	 * @param Коллекция таблиц
	 * @param Имя целевой таблицы
	 * @param Номер целевой колонки
	 * @param Ключ к строке целевой таблицы
	 *
	 * Конструктор должен вычислить значение целевого функционала f0 на
	 * априорных значениях параметров.
	 */
	NormalEquation (LeastSquaresProblem * problem, const string & name,
					int targetColumnNumber, const Tuple & target_key);


	/**
	 * @brief Вычисляет производные по параметрам
	 * @param param_name Название параметров (таблицы)
	 * @param result Возвращаемая таблица ненулевых производных
	 *
	 * Параметры - это любые данные, записанные в таблицах коллекции. По любому
	 * из них можно численно или более оптимальным способом вычислить
	 * производную.
	 */
	virtual void calcDerivatives (const string & param_name, DBTable & result)
	const;

	/**
	 * @brief Вычисляет производную по параметру
	 * @param param_name Имя параметра
	 * @param param_it Итератор параметра
	 */
	virtual real calcSingleDerivative (const string & param_name,
									DBMap::DBIterator &val_it) const;

	virtual const DerivateTemplete & getDerivateTemplete(
									 const string & param_name,
									 const Tuple & param_key
									 ) const;

	inline DBTable * getTargetTable() const
	{
		return targetTable;
	}

	inline int getTargetColumnNumber() const
	{
		return targetColumnNumber;
	}

	inline DBTableCollection * getBase() const
	{
		return tables;
	}

	const Tuple & getTargetKey () const
	{
		return target_key;
	}

	virtual real getRMS () const;

};

/**
 * @brief Метод наименьших квадратов
 *
 * @ingroup leastsq
 */
class LeastSquaresProblem : public QObject
{
	Q_OBJECT
private:
	DBTableCollection * base;
	DBTable * target_table;
	string target_table_name;
	int target_column_number;
	set < string > parameters;
	map < string, DBTable * > columns;
	map < string, Derivate * > derivators;
	set < int > fixedparams;
	int columnscount;
	ExceptionsLog l;
	bool constructRowIndex;
protected:

	/**
	 * @brief Метод, конструирующий одно уравнение для МНК
	 * @param target_key Ключ к строке целевой таблице
	 * @return Уравнение для данной строки целевой таблицы
	 *
	 * В случае, если требуется отбросить какие-либо целевые данные, для них
	 * данный метод должен вернуть нулевой указатель.
	 */
	virtual NormalEquation * createNormalEquation(const Tuple & target_key) = 0;

	/**
	 * @brief Возвращает требуемую точность уточнения параметра
	 * @param paramname Имя таблицы с параметрами
	 * @param key Ключ к параметру
	 * @return Точность уточнения данного параметра
	 *
	 * Под точностью уточнения данного параметра понимается максимальное
	 * приращение данного параметра, допустимое на последней итерации
	 * метода сопряженных градиентов при решении линеаризованной задачи
	 * наименьших квадратов.
	 */
	virtual real getPrecision(const string & paramname,
								 const Tuple & key) = 0;

	/**
	 * @brief Метод позволяет модифицировать матрицу до решения МНК
	 *
	 * Метод будет вызван сразу после формирования нормальных уравнений
	 * модели измерительных данных, до нормировки столбцов и решения задачи
	 * МНК.
	 *
	 * Для того, чтобы что-либо успеть сделать с матрицей до нормировки
	 * столбцов, нужно перегрузить данный метод.
	 *
	 * @param lhs Сформированная матрица МНК
	 * @param rhs Сформированный вектор правой части
	 * @param rowidx Индекс строк матрицы
	 *
	 * Индекс строк матрицы представляет собой вектор кортежей ключевых
	 * полей целевой таблицы, использованных в МНК. Если индекс не строился,
	 * будет передан 0.
	 */
	virtual void processReadyMatrix(RowWiseSparseMatrix <real> & lhs,
									vector<real> & rhs,
									const vector<Tuple> * rowidx);

	/**
	 * @brief Метод позволяет модифицировать решение МНК перед применением
	 * @param solution Полученное решение МНК
	 *
	 * Метод вызывается после того, как решение задачи МНК найдено и
	 * отмасштабировано в соответствии с нормами столбцов, но пока оно ещё не
	 * применено для модификации уточняемых параметров.
	 */
	virtual void processSolution(const RowWiseSparseMatrix < real > & lhs,
								 const vector<real> & rhs,
								 vector<real> & solution);

public:

	/**
	 * @brief Вывести в поток журнал ошибок в ходе последней операции
	 * @param str Поток
	 */
	inline void printLastExceptionLog(ostream & str) const
	{
		l.outputLog(str);
	}

public:

	/**
	 * @brief Установка флага построения индекса строк матрицы МнК
	 * @param true для построения индекса, false для отказа
	 *
	 * Для предобработки матрицы (например,перевзвешивания) и других целей
	 * может понадобиться индекс строк матрицы МНК - для каждой строки
	 * можно запомнить ключ строки целевой таблицы, использованной для
	 * построения строки матрицы МНК.
	 *
	 * Такой индекс может использовать много памяти, поэтому строить его имеет
	 * смысл не всегда.
	 *
	 * Флаг используется при вызове метода LeastSquaresProblem::adjust().
	 * Если какие-либо методы, вызванные из уже запущенного метода adjust,
	 * меняют флаг, на работу метода это не влияет.
	 */
	inline void setConstructRowIdx(bool c)
	{
		constructRowIndex = c;
	}

	/**
	 * @brief Включено
	 * @return
	 */
	inline bool getConstructRowIdx() const
	{
		return constructRowIndex;
	}

	/**
	 * @brief Метод, выполняющий одну итерацию приближения целевых данных
	 *
	 * Алгоритм итерации:
	 * @li Для каждой строки целевой таблицы создать уравнение
	 * @li Если уравнение создалось, вычислить правую часть уравнения
	 *     и коэффициенты левой части.
	 * @li Вычислить вектор точности параметров (см. @ref cgMethod() )
	 * @li Решить линейную задачу наименьших квадратов методом сопряженных
	 *     градиентов
	 * @li Выполнить модификацию параметров согласно полученному решению
	 * @li Возвращает норму невязки с целевыми значениями
	 *
	 * @param iterationlimit Максимальное число итераций метода СГ
	 * @param comm_size Размер MPI-коммуникатора
	 * @param comm MPI-коммуникатор
	 * @param subkey Ключ, задающий часть целевой таблицы
	 */
#ifdef UseMPI
	virtual real adjust(int & iterationlimit,int comm_size, MPI_Comm comm,
						const Tuple & from=Tuple(),
						const Tuple & until = Tuple());
#endif

	virtual real adjust(int & iterationlimit, const Tuple & from=Tuple(),
						const Tuple & until = Tuple());

	/**
	 * @brief Удалить созданный список столбцов текущего набора параметров
	 */
	virtual void dropColumnsList();


	/**
	 * @brief Метод, создающий список столбцов для текущего набора параметров
	 */
	virtual void createColumnsList();

	/**
	 * @brief Метод, выполняющий линеаризацию задачи МНК
	 *
	 * @param[out] lhs Основная матрица системы
	 * @param[out] rhs Правая часть
	 * @param[out] rowidx Указатель на конструируемый индекс строк матрицы МНК
	 * @param from Начало части таблицы (пустой ключ обозначает начало таблицы)
	 * @param until Конец части таблицы (пустой обозначает конец части таблицы)
	 *
	 * Метод последовательно просматривает записи всей целевой таблицы, или её
	 * части, заданной подключами from и until. Будет найдена часть таблицы,
	 * задаваемая ключами from и until. Для этого находятся первые n полей, по
	 * которым from и until совпадают, причем по остальным полям должно быть
	 * until > from. Далее перебор записей начинается с from и продолжается до
	 * достижения until. Если until - пустое, то перебираться будет вся
	 * часть таблицы, начинающаяся с from; если until лежит в from, то
	 * перебираться будет часть таблицы, заданная from, до достижения until.
	 *
	 * Если в from и until заданы не все ключевые поля, то незаданные значения
	 * ключевых полей будут выставлены в минимальное значение.
	 *
	 * Для каждой записи создаёт нормальное уравнение, линеаризует его и
	 * добавляет в создаваемую расширенную матрицу системы.
	 *
	 * Если rowidx!=0, то в вектор, на который указывает rowidx, будет
	 * сохранён индекс строк матрицы МНК.
	 */
	virtual void linearize (RowWiseSparseMatrix <real> & lhs,
							vector<real> & rhs,
							vector<Tuple> * rowidx,
							const Tuple & from=Tuple(),
							const Tuple & until = Tuple());

	virtual void updateParameters(const vector < real > & solution);

	/**
	 * @brief Конструктор проблемы наименьших квадратов
	 * @param collection Коллекция таблиц
	 * @param target Имя целевой таблицы в коллекции
	 * @param targetColumnValue Номер столбца
	 */
	LeastSquaresProblem (DBTableCollection * collection, const string & target,
						 int targetColumnValue);

	~LeastSquaresProblem();

	inline DBTableCollection * getBase() const
	{
		return base;
	}

	inline DBTable * getTargetTable() const
	{
		return target_table;
	}

	inline const string & getTargetTableName() const
	{
		return target_table_name;
	}

	inline int getTargetColumnNumber() const
	{
		return target_column_number;
	}

	void addAdjustableParameter(const string & paramname);

	void removeAdjustableParameter(const string & paramname);

	inline void setDerivator (const string & paramname, Derivate * der)
	{
		derivators[paramname] = der;
	}

	inline Derivate * getDerivator ( const string & paramname)
	const
	{
		map < string, Derivate* >::const_iterator it=derivators.find(paramname);
		if (it == derivators.end())
			return 0;
		return it->second;
	}

	inline int getColumnsCount()
	const
	{
		return columnscount;
	}

	inline const DBTable * getColumnsIndex(const string & paramname)
	const
	{
		return columns.at(paramname);
	}

	inline int getParameterColumnIndex(const string&paramname, const Tuple &t)
	{
		try
		{
			return columns.at(paramname)->read(t)[0].toInt();
		}
		catch (out_of_range & e)
		{

		}
	}

	inline const set<string > & getParametersSet () const
	{
		return parameters;
	}

	/**
	 * @brief Зафиксировать текущее значение уточняемого параметра
	 * @param name Имя параметра (имя таблицы)
	 * @param key Ключ параметра
	 *
	 * После вызова данной функции столбец производных по параметру, заданному
	 * именем name и ключом key, будет равен нулю; в результате, параметр не
	 * будет уточняться при итерации. Чтобы разблокировать изменение парметра,
	 * нужно использовать метод @ref releaseParameter() .
	 *
	 * Перед вызовом данной функции необходимо проиндексировать все параметры
	 * (вызвать метод @ref createColumnsList() .
	 */
	void lockParameter (const string & name, const Tuple & key);

	/**
	 * @brief Разблокировать изменение уточняемого параметра при итерации
	 * @param name Имя параметра (имя таблицы)
	 * @param key Ключ параметра
	 *
	 * Если значение уточняемого параметра ранее было зафиксировано вызовом
	 * метода @ref lockParameter() , то вызов данного метода снимает эту
	 * блокировку.
	 *
	 * Перед вызовом данной функции необходимо проиндексировать все параметры
	 * (вызвать метод @ref createColumnsList() .
	 */
	void releaseParameter(const string & name, const Tuple & key);

	/**
	 * @brief Метод, имитирующий целевые данные
	 * @return Таблица имитации
	 *
	 * Структура ключа таблицы имитации совпадает со структурой ключа целевой
	 * таблицы. Таблица имитации имеет одно поле данных для имитируемого
	 * значения.
	 *
	 * Для каждой строки целевой таблицы моделируется значение с помощью
	 * текущих значений параметров из таблиц коллекции. Если установлен
	 * параметр replace = true, то значения заменяются в целевой таблице;
	 * в противном случае, создаётся отдельная таблица.
	 *
	 * @param replace Заменять значения в целевой таблице имитируемыми?
	 *
	 */
	virtual DBTable * imitate(bool replace = false);

	/**
	 * @brief Оценка точности решения МНК
	 * @param lhs Матрица МНК \f$A \f$ с \f$m\f$ строками и \f$n\f$ столбцами
	 * @param rhs Правая часть \f$b\f$
	 * @param solution Найденное решение \f$x\f$
	 * @param trust Размер \f$n\f$ оценки невязки измерительных данных
	 * @return Возвращает ширины интервалов, в которые попало решение
	 *
	 * Статический метод выполняет следующие действия:
	 * @li Вычисляет невязку решения задачи МНК
	 * @li Вычисляет апостериорную оценку дисперсии измерительных данных \f$D\f$
	 * @li Создаёт вектор \f$I_R\f$ интервалов \f$[-nD; nD]\f$
	 * @li Вычисляет вектор интервалов \f$I_X\f$ для параметров по формуле:
	 * \f$I_X = (A^T\cdot A)^{-1} A_T I_R.\f$
	 */
	static std::vector<real> getParametersStdDev(
			const RowWiseSparseMatrix<real> & lhs,
			const std::vector<real> & rhs,
			const std::vector<real> & solution,
			int trust);

	/**
	 * @brief Удаление выбросов после формирования матрицы
	 *
	 * Алгоритм создаёт таблицу, ключевыми полями которой служат выбранные
	 * ключевые поля целевой таблицы (выбор с помощью массива keyclms).
	 * Для каждого значения подключа будет вычислено среднеквадратическое
	 * значение правой части; затем будет вычислено среднеквадратическое
	 * значение sigma невязки для всех стоблцов.
	 *
	 * @warning Типы колонок таблицы определяются по типам первого кортежа
	 * из rowidx. Во всех кортежах элементы, стоящие на месте с одинаковым
	 * номером, должны иметь одинаковые типы. Размер массива keyclms
	 * должен совпадать с числом ключевых колонок целевой таблицы.
	 *
	 * Затем среди всех значений подключа выбираются те, СК значение для которых
	 * выходят за пределы nsigma * sigma. Соответствующие им строки матрицы МНК
	 * умножаются на ноль.
	 *
	 * @param nsigma Множитель в критерии определения выбросов
	 * @param lhs Основная матрица задани МНК
	 * @param rhs Правая часть задачи МНК
	 * @param rowidx Ключи строк матрицы МНК
	 * @param keyclm Выбор ключевых столбцов, используемых для отсева измерений.
	 */
	static void deleteOutliers(real nsigma,RowWiseSparseMatrix <real> & lhs,
							   vector<real> & rhs,
							   const vector<Tuple> & rowidx,
							   const vector<bool> & keyclms);

#ifdef WithQT
public slots:

#ifdef UseMPI
	double iteration (int cgiterationlimit, QMPICommunicator & comm);
#endif
	double iteration (int cgiterationlimit);
	void enumerateColumns();
	void linearize (QObject * ll);
	void updateParameters(const QVariantList & solution);
	QObject * getSession() const;
	QObject * getTarget() const;
	QString getNameOfTargetTable() const;
	int getTargetTableColumnNumber() const;
	void setAdjustableParameter(const QString & paramname);
	void unsetAdjustableParameter (const QString & paramname);
	int getNumberOfColumns() const;
	QObject * getColumnsTable(const QString & paramname);
	int getColumnNumber (const QString & paramname, const QVariantList & t);
	QVariantList getAdjustableParametersNames() const;
	void fixAdjustableParameter(const QString & name, const QVariantList & key);
	void releaseAdjustableParameter(const QString&name, const QVariantList&key);
	QString getLastLog() const;
#endif
};

/**
 * @brief Класс, вычисляющий производную по параметрам одного типа
 *
 * @ingroup leastsq
 */
class Derivate
{
public:
	virtual void calcDerivatives (const NormalEquation*neq, DBTable&result)=0;
};

/**
 * @brief Класс, вычисляющий производную по интерполируемому параметру
 *
 * @ingroup leastsq
 *
 * Пусть целевые данные \f$\rho\f$ зависят от значения некоторого полинома
 * \f$p(t)\f$, зависящего от времени и интерполирующего некоторую функцию
 * \f$f(t)\f$ от времени по её значениям в моменты времени \f$t_1,\ldots,t_n\f$.
 *
 * Данный класс вычисляет производные \f$\partial\rho\/\partial f(t_i)\f$.
 *
 * Пусть момент времени фиксирован (он определён для элемента целевых данных
 * \f$\rho\f$). Тогда полином \f$p(t)\f$ записывается в виде линейной
 * комбинации: \f$p(t) = \alpha_1 f(t_1) + \ldots + \alpha_n f(t_n),\f$
 * а производна находится по приближенной формуле:
 *
 * \f[\frac{\partial\rho}{\partial f(t_i)}\approx
   \alpha_i\frac{\partial\rho}{f(t)}\f].
 *
 * Здесь \f$\partial\rho/\partial f(t)\f$ - производная по мгновенному значению
 * величины \f$ f \f$ в заданный момент времени, которую требуется задать при
 * наследовании данного класса для каждого типа параметра перегрузкой метода
 * @ref instantDerivative().
 *
 * Момент времени, который определяется данным элементом целевых данных,
 * вычисляется методом @ref getTimeMoment, который также необходимо перегрузить.
 */
class InterpolatedParameterDerivator : public Derivate
{
protected:

	/**
	 * @brief Производная целевых данных по мгновенному значению параметра
	 * @param neq Уравнение МНК для данного элемента целевых данных
	 * @param param_subkey Ключ к таблице параметров, кроме момента времени
	 * @return Производная целевых данных по мгновенному значению параметра
	 */
	virtual real instantDerivative (const NormalEquation * neq,
									   const Tuple & param_subkey) = 0;

	/**
	 * @brief Возвращает момент времени, определяемый элементом целевых данных
	 * @param eq Уравнение МНК для данного элемента целевых данных
	 * @return Момент времени, секунды TAI (J2000)
	 */
	virtual real getTimeMoment (const NormalEquation * eq) = 0;

	/**
	 * @brief getSubkey Получить подключ параметра для данного измерения
	 *
	 * Интерполируемый параметр представляет собой набор из нескольких
	 * заданных таблично функций, которые нумеруются с помощью подключа.
	 * Каждая такая функция задаётся своими значениями в нескольких точках,
	 * которые и есть параметры, и порядком аппроксимации.
	 *
	 * Как правило, производные от данного измерения по параметрам данного типа
	 * соответствуют какому-либо определённому значению подключа. Данный
	 * метод возвращает это значение подключа.
	 *
	 * При вычислении производных, метод @ref calcDerivatives() вызывает данный
	 * метод, а затем вызывает метод calcSingleSubkeyDerivatives для вычисления
	 * производных по параметрам, соответствующим данному значению подключа.
	 *
	 * Если требуется определить иную функциональность, когда по одному
	 * измерению возможны ненулевые производные по параметрам с разным значением
	 * подключа, необходимо перегрузить метод @ref calcDerivatives().
	 *
	 * @param neq Уравнение модели измерения
	 * @return Значения подключа
	 */
	virtual vector<Tuple> getSubkeys (const NormalEquation * neq) const = 0;

	InterpolatedParameterStorage * paramstorage;
public:

	/**
	 * @brief Конструктор
	 * @param ls Задача наименьших квадратов
	 * @param param_name Имя параметра, по которому требуется дифференцировать
	 */
	InterpolatedParameterDerivator (const LeastSquaresProblem * ls,
									const string & param_name);
	virtual void calcSingleSubkeyDerivatives (const NormalEquation * neq,
											  const Tuple & subkey,
											  real t,
											  DBTable & result);

	virtual void calcDerivatives (const NormalEquation * neq, DBTable & result);
};

}

#endif

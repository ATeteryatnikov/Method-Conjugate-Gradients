#include <Pseudorange.h>
#include <YawAttitude.h>
#include <DBInterpolate.h>
#include <StdTables.h>
#include <PseudorangeDerivatives.h>
#include <BuiltIn.h>
#include <StdTables.h>
#include <Kinematic.h>
#include <Consts.h>
#include <Frames.h>
#include <ParamTrajectory.h>
#include <SiteDisplacement.h>
#include <PhaseCentre.h>
#include <ERPStorage.h>
#include <TimeShift.h>
#include <Troposphere.h>
#include <dcb.h>
#include <PhaseAmbiguity.h>
#include <observables.h>

namespace libgnss
{

Settings::Enumerator useDCB("Least_Squares", "Pseudorange", "DCB",
							CTypeSelect::yesOrNo(),
							"Учитывать межлитерные задержки в ГЛОНАСС",
							CTypeSelect::yesOrNo()->defaultValue());

Settings::Enumerator maxZenith("Least_Squares", "Pseudorange", "maxZenith",
							   Variant::TYPE_DOUBLE,
							   "Максимальный зенитный угол, градусы",
							   "90");

Settings::Enumerator rms_p("Least_Squares", "Pseudorange", "rms_p",
						   Variant::TYPE_DOUBLE,
						   "Среднеквадратическое отклонение "
						   "кодовой дальности, км.", "0.001");

Settings::Enumerator rms_l("Least_Squares", "Pseudorange", "rms_l",
						   Variant::TYPE_DOUBLE,
						   "Среднеквадратическое отклонение "
						   "фазы, км.", "0.00005");

Settings::Enumerator rms_accountzenith("Least_Squares", "Pseudorange",
									"RMSAccountZenith", CTypeSelect::yesOrNo(),
				"Учитывать ли зенитный угол при оценке СКО строк МНК",
									   "No");

PhaseWindupError::PhaseWindupError(string satname, string staname, real t)
	: StrException ("PhaseWindupError",
		  "Ошибка вычисления поправки докрутки фазы для НКА"
					+satname+" и БИС "+staname+" в момент времени "+
					Variant(t).toString()+". Необходимо обеспечить неубывание "
					"моментов времени")
{

}

/******************************************************************************
 *                             Уравнение для МНК                              *
 ******************************************************************************/

ObservablesNormalEquation::ObservablesNormalEquation(
		ObservablesLeastSquaresProblem *problem, const string &name,
		int targetColumnNumber, const Tuple &target_key)
	: NormalEquation(problem, name, targetColumnNumber,
					 target_key)
{
	//this->problem = problem;
	imitdb = problem->imitdb;

	//! 1) Вычислить всю информацию, которая не зависит от уточняемых параметров

	//! 1.1) Информация об измерительных данных
	int observ_type = target_key[3].toInt();
	Tuple obsdetails = imitdb.obstypes->read(observ_type);
	info1.freqn = obsdetails[2].toInt();
	info1.obsmt = obsdetails[3].toInt();

	//! 1.2) Получить необходимые для работы идентификаторы БИС
	info1.observation_source_id=target_key[0].toInt(); //Идентификатор БИС
	Tuple obsrcdetail = imitdb.obssrc->read(info1.observation_source_id);
	info1.marker_id = obsrcdetail[0].toInt(); //Идентификатор маркера
	info1.reciever_id = obsrcdetail[1].toInt(); //Идентификатор приёмника
	info1.antenna_id = obsrcdetail[2].toInt(); //Идентификатор антенны
	info1.rec_timescale_epoch=target_key[1].toDouble();//Эпоха в шкале приёмника

	//! 1.3) Найти момент измерения в шкале TAI
	//Уход часов БИС, сек.
	real timeShiftStation = imitdb.timeshift->stationTimeShift(
				info1.observation_source_id, info1.rec_timescale_epoch);
	//Момент измерения псевдодальности в шкале TAI (J2000)
	real tai = info1.rec_timescale_epoch - timeShiftStation;

	//! 1.4) Получить все необходимые идентификаторы для НКА
	info1.sat_history_id=target_key[2].toInt(); //Номер в истории НКА
	Tuple satdetail = imitdb.satellites->read(info1.sat_history_id);
	info1.navsys = satdetail[0].toChar();
	info1.satellite_id = satdetail[1].toInt();
	if (info1.navsys == 'R')
	{
		info1.glonass_slot = satdetail[2].toInt();
		info1.glonass_letter = imitdb.gloletters->getLetter(info1.glonass_slot,
															tai);
	}

	//! 1.5) Идентификаторы данных фазового центра НКА и БИС
	info1.rec_phase_centre_model_id = imitdb.recpcm->getPhaseCentreModelID(
				tai,info1.antenna_id);
	info1.sv_phase_centre_model_id = imitdb.svpcm->getPhaseCentreModelID(
				tai,info1.sat_history_id);

	//! Найти длину волны
	real freqhz = imitdb.obstypes->getFrequency(observ_type,
												   info1.glonass_letter);
	info1.wavelength = lightSpeed / freqhz;

	info1.usedcb = problem->useDcb();
	info1.maxzenith=problem->mazZenith();

	//! 2) Пометить f0 к вычислению
	f0 = numeric_limits<real>::quiet_NaN();
}

real ObservablesNormalEquation::func0()
{
	if (isnan(f0))
		f0 = functional(info0);
	return f0;
}

real ObservablesNormalEquation::functional(timeDependentInfo &info) const
{
	//Уход часов БИС, сек.
	info.timeShiftStation = imitdb.timeshift->stationTimeShift(
				info1.observation_source_id, info1.rec_timescale_epoch);
	//Момент измерения псевдодальности в шкале TAI (J2000)
	info.tai = info1.rec_timescale_epoch - info.timeShiftStation;
	//Заготовить (если ещё не заготовлена) матрицу перехода на данную эпоху
	imitdb.erp->calcERPMatrix(info.tai, true);

	//Смещение опорной точки антенны относительно маркера
	info.eccentricity = imitdb.eccentricity->getEccentricity(info1.marker_id,
															 info.tai);
	//Смещение фазового центра НКА
	Tuple satpcoff=imitdb.pcofreq->read(Tuple()<<info1.sv_phase_centre_model_id
										  <<info1.freqn);

	//! Найти среднее положение фазового центра приёмной антенны
	//Положение маркера в заданный момент времени
	info.markerpos = imitdb.markerpos->getMarkerPosition(info1.marker_id,
														 info.tai);
	//Сопровождающая система координат БИС NEU, в которой заданы сдвиги ФЦ
	getNorthEastUp(info.markerpos,info.north,info.east,info.up);
	//Сдвиг фазового центра БИС
	Tuple recpcoff;
	recpcoff = imitdb.pcofreq->read(Tuple()
										<<info1.rec_phase_centre_model_id
										<<info1.freqn);
	kinematic < real, 3, defaultNonInert > phcshift =
		info.north * recpcoff[0].toDouble()+info.east * recpcoff[1].toDouble()
			+info.up * recpcoff[2].toDouble();
	//Порядок Вверх,Север,Восток, а не Север,Восток,Вверх, продиктован
	//расположеием этих данных в SINEX-файле
	if (info.eccentricity.first == 0)
		phcshift += info.eccentricity.second[0] * info.up
				+info.eccentricity.second[1]*info.north
				+info.eccentricity.second[2]*info.east;
	else
		for (unsigned int i=0; i<3; i++)
			phcshift[i] += info.eccentricity.second[i];

	info.recieverphasecentre = info.markerpos + phcshift;
	//Положение фазового центра антенны БИС в инерциальной системе координат
	info.recposinert =
			imitdb.erp->ITRFtoGCRS(info.recieverphasecentre, info.tai);

	//! 6) Вычислить дальность (время/скорость света) итерационно
	//Начальное приближение, км.
	real dist = 20000;
	//Ошибка
	real disterror = 5000;
	info.transmitTime = info.tai - dist/lightSpeed;

	//Поскольку ошибка 1 км. псевдодальности на предыдущей итерации
	//приводит к ошибке 1 см. в положении НКА, резонно не использовать
	//при этих расчетах тропсферную и ионосферную задержку, а использовать
	//только геометричесую дальность
	//Если сейчас найти положение НКА с точностью до метра, на следующей
	//итерации это даст положение НКА с точностью до 0.001 мм.
	int itc = 0;
	while (disterror > 1e-6)
	{
		//Время испускания сигнала
		info.transmitTime = info.tai - dist/lightSpeed;

		//Положение центра масс НКА
		kinematic < real, 3, defaultInert > pos =
			imitdb.traj->getPosition(info1.sat_history_id, info.transmitTime);

		//Геометрическая дальность между фазовыми центрами
		real newdist = (pos - info.recposinert).length<0,2>();
		disterror = fabs(newdist - dist);
		dist = newdist;

		itc++;
		if (itc>10)
			break;
	}

	//Положение и скорость НКА
	info.posvel =imitdb.traj->getPositionVelocity(
				info1.sat_history_id, info.transmitTime);
	//Ориентация НКА
	satelliteOrientation(info1.sat_history_id,info.tai,info.posvel,
						 *(imitdb.traj), &(info.axis[0]),info.yaw);
	//Положение фазового центра НКА
	info.satposinert = info.posvel.subset<0,2>()
			+satpcoff[0].toDouble() * info.axis[0]
			+satpcoff[1].toDouble() * info.axis[1]
			+satpcoff[2].toDouble() * info.axis[2];

	//Окончательная геометрическая дальность между фазовыми центрами
	info.geomdist = (info.satposinert - info.recposinert).length<0,2>();

	//! 7) Вычисляем прочие поправки
	//Тропосферная задержка
	// Вычислить углы
//	info.satposnoninert =
//			imitdb.erp->GCRStoITRF(info.satposinert, info.transmitTime);
//	info.zenith_azimuth = getZenithAzimuth(info.markerpos,
//			info.satposnoninert, info.north, info.east, info.up);
	info.zenith_azimuth = getZenithAzimuth(info.recposinert,
								info.satposinert,
								imitdb.erp->ITRFtoGCRS(info.north, info.tai),
								imitdb.erp->ITRFtoGCRS(info.east, info.tai),
								imitdb.erp->ITRFtoGCRS(info.up, info.tai)
										   );
	info.tropodelay = 0.0l;
	if (!(isnan(info.zenith_azimuth.first)))
	{
		if (info.zenith_azimuth.first > info1.maxzenith)
			throw FunctionalNotApplicableException(
					"Превышен максимальный зенитный угол");
		info.tropodelay = imitdb.tropo->troposphereDelay(
					info1.marker_id,
					geocentricToGeodetic(info.markerpos),
					//imitdb.markers->getMarkerApproxGeodeticPosition(marker_id),
					info.zenith_azimuth.first,info.zenith_azimuth.second,
					info.tai);
	}
	//Уход часов НКА
	//!!!!!!!!!!!!!!!!!УХОД ЧАСОВ В МОМЕНТ ОТПРАВКИ СИГНАЛА!!!!!!!!!!!!!!!!!!!!!
	info.timeShiftSatellite = imitdb.timeshift->satelliteTimeShift(
				info1.sat_history_id, info.transmitTime);
	//Поправка DCB
	info.dcb = 0;
	if ((info1.navsys == 'R') && (info1.usedcb == true))
		info.dcb = imitdb.dcb->getParameterValue(Tuple()
								<<info1.observation_source_id
								<<info1.glonass_letter<<info1.freqn, info.tai);
	//Параметр фазовой неоднозначности
	info.phase_ambiguity = 0;
	//Поправка "докрутки" фазы
	info.phase_windup = 0;
	if (info1.obsmt==ObservableTypes::MTYPE_L)
	{
		if (info.up.length<0,2>() == 0)
			info.phase_windup = 0.0l;
		else
		{
			//Поправка докрутки фазы
			real curwindupangle = curWindupAngle(
						info.axis[0], info.axis[1],
						imitdb.erp->ITRFtoGCRS(info.north, info.tai),
						imitdb.erp->ITRFtoGCRS(info.east, info.tai),
						(info.satposinert - info.recposinert).normalize());
	#define obsprob ((ObservablesLeastSquaresProblem *)(problem))
			//Попытаться найти предыдущую докрутку фазы
			if (obsprob->curwindupcorrection
				[info1.observation_source_id].find(info1.sat_history_id) ==
				obsprob->curwindupcorrection[info1.observation_source_id].end())
				obsprob->curwindupcorrection[info1.observation_source_id]
						[info1.sat_history_id] = curwindupangle;
			real prevwindup = obsprob->curwindupcorrection
					[info1.observation_source_id][info1.sat_history_id];
			//Обеспечить непрерывность поправки докрутки фазы
			real NN = round((prevwindup - curwindupangle)/(2*Pi));
			info.phase_windup = 2*NN*Pi + curwindupangle;
		}
		obsprob->curwindupcorrection[info1.observation_source_id]
				[info1.sat_history_id]=info.phase_windup;

		//Параметр фазовой неоднозначности
		info.phase_ambiguity = imitdb.phase_ambiguity->getParameterValue(
					Tuple()<<info1.observation_source_id<<info1.sat_history_id
					<<info1.freqn, info1.rec_timescale_epoch);
	}
	//Релятивистская поправка
	info.relcorrection = relativisticTimeDelay(info.posvel,
											   info.recposinert);

	return info.geomdist+info.tropodelay+lightSpeed*
		(info.timeShiftStation-info.timeShiftSatellite)
		+info.dcb+info.phase_ambiguity+info.phase_windup*info1.wavelength/(2*Pi)
		+info.relcorrection;

}

real ObservablesNormalEquation::getRMS() const
{
	real zenithrms = 0.0;
	if (info1.obsmt == ObservableTypes::MTYPE_C)
		zenithrms = ((ObservablesLeastSquaresProblem*)(problem))->
				getSettings().rms_p;
	if (info1.obsmt == ObservableTypes::MTYPE_L)
		zenithrms = ((ObservablesLeastSquaresProblem*)(problem))->
				getSettings().rms_l;

	if (zenithrms == 0)
			return 1.0;
	if (((ObservablesLeastSquaresProblem*)(problem))->
			getSettings().rms_zenith == true)
	{
		if (isnan(getTimeDependentInfo().zenith_azimuth.first))
			return zenithrms;
		else
			return zenithrms/cos(getTimeDependentInfo().zenith_azimuth.first);
	}
	else
		return zenithrms;
}

real ObservablesNormalEquation::functional() const
{
	timeDependentInfo tmp;
	return functional(tmp);
}

void ObservablesNormalEquation::calcDerivatives(const string &param_name,
								DBTable &result) const
{
//	if (param_name == "phase_ambiguity")
//	{
//		map < timeMoment, const vector < Variant > * > neighb =
//			getNeighbourhood(*(imitdb.phase_ambiguity), Tuple()
//						 <<observation_source_id<<info1.sat_history_id<<freqn,
//							 info1.rec_timescale_epoch, 0);
//		if (neighb.size() == 0)
//			return;
//		timeMoment rte = neighb.begin()->first;
//		result.insertRow(Tuple()<<observation_source_id<<info1.sat_history_id
//						 <<freqn<<rte, Tuple()<<1.0l);
//		return;
//	}

	NormalEquation::calcDerivatives(param_name, result);
}

/******************************************************************************
 *     Задача приближения измерительных данных БИС                            *
 ******************************************************************************/
NormalEquation * ObservablesLeastSquaresProblem::createNormalEquation(
		const Tuple & key)
{
	checkImitDB();

	//Проверить тип измерения и частоту
	int observ_type = key[3].toInt(); //Тип измерительных данных
	Tuple obsdetails = imitdb.obstypes->read(observ_type);
	int freqn = obsdetails[2].toInt();
	if ((freqn != imitdb.obstypes->getFrequencyFromAntex("G12"))
		&&(freqn != imitdb.obstypes->getFrequencyFromAntex("G15"))
		&&(freqn != imitdb.obstypes->getFrequencyFromAntex("G25"))
		&&(freqn != imitdb.obstypes->getFrequencyFromAntex("G125"))
		&&(freqn != imitdb.obstypes->getFrequencyFromAntex("R12"))
		 )
		return 0;
	int obsmt = obsdetails[3].toInt();
	if ((obsmt!=ObservableTypes::MTYPE_C)
			&&(obsmt!=ObservableTypes::MTYPE_L))
		return 0;

	NormalEquation * result =  new ObservablesNormalEquation(
			this, getTargetTableName(),
			getTargetColumnNumber(),
			key);
	return result;
}

//! @todo Выбрать точность для разных параметров
real ObservablesLeastSquaresProblem::getPrecision(
		const string & paramname, const Tuple & key)
{
	return 1e-10;
}


ObservablesLeastSquaresProblem::ObservablesLeastSquaresProblem (
		DBTableCollection * base)
	: LeastSquaresProblem(base, "observables", 0)
{
	checkImitDB();
	usedcb = (imitdb.settings->getSettings(useDCB).toString() == "Yes");
	maxzenith=imitdb.settings->getSettings(maxZenith).toDouble()*Pi/180.0;
	setDerivator("marker_position", new MarkerPositionDerivative(this));
	setDerivator("phase_ambiguity",new PhaseAmbiguityDerivative(this));
	setDerivator("troposphere", new TroposphereParamDerivative(this));
	setDerivator("time_shift", new TimeShiftDerivative(this));
	setDerivator("trajectory", new TrajectoryDerivative(this));
	obslssettings.loaded = false;
}

void ObservablesLeastSquaresProblem::linearize(RowWiseSparseMatrix <real> & lhs,
											   vector<real> & rhs,
											   vector<Tuple> * rowidx,
											   const Tuple & from,
											   const Tuple & until)
{
	curwindupcorrection.clear();
	LeastSquaresProblem::linearize(lhs,rhs,rowidx,from,until);
}

//maxprec ObservablesLeastSquaresProblem::adjust(int iterationlimit,
//					   int comm_size, MPI_Comm comm)
//{
//	curwindupcorrection.clear();
//	LeastSquaresProblem::adjust(iterationlimit, comm_size, comm);
//}

DBTable * ObservablesLeastSquaresProblem::imitate(bool replace )
{
	curwindupcorrection.clear();
	return LeastSquaresProblem::imitate(replace);
}


void ObservablesLeastSquaresProblem::checkImitDB()
{
	if (imitdb.loaded == true)
		return;

	imitdb.stations = (ObservationSource *)
			(getBase()->getTable("observation_source"));
	imitdb.satellites = (SatelliteHistory *)
			(getBase()->getTable("satellite_history"));
	imitdb.traj = (ParamTrajectory *)
			(getBase()->getTable("trajectory"));
	imitdb.markerpos = (MarkerPosition *)
			(getBase()->getTable("marker_position"));
	imitdb.eccentricity = (MarkerEccentricity *)
			(getBase()->getTable("marker_eccentricity"));
	imitdb.svpcm = (SVPhaseCentreModels *)
			(getBase()->getTable("sv_phase_centre_models"));
	imitdb.recpcm = (ReceivingAntennaPhaseCentreModels *)
		(getBase()->getTable("receiving_antenna_phase_centre_models"));
	imitdb.pcofreq = (PhaseCentreOffsetFrequency *)
			(getBase()->getTable("phase_centre_offset_frequency"));
	imitdb.pcvar = (PhaseCentreVariationGrid *)
			(getBase()->getTable("phase_centre_variation_grid"));
	imitdb.obstypes = (ObservableTypes*)
			(getBase()->getTable("observable_types"));
	imitdb.erp = (ERPStorage*)(getBase()->getTable("ERP"));
	imitdb.timeshift = (ClockBias*)(getBase()->getTable("time_shift"));
	imitdb.obssrc = (ObservationSource*)
			(getBase()->getTable("observation_source"));
	imitdb.gloletters = (GLONASSFrequencySlots *)
			(getBase()->getTable("glonass_frequency_slots"));
	imitdb.tropo = (ParamTroposphere*)
			(getBase()->getTable("troposphere"));
	imitdb.dcb = (ParamDCB*)(getBase()->getTable("dcb"));
	imitdb.markers = (Markers*)(getBase()->getTable("markers"));
	imitdb.phase_ambiguity = (ParamPhaseAmbiguity*)
			(getBase()->getTable("phase_ambiguity"));
	imitdb.settings = (Settings*)(getBase()->getTable("settings"));

	imitdb.loaded = true;
}



real relativisticTimeDelay (
		const kinematic < real, 6, defaultInert > & satposvel,
		const kinematic < real, 3, defaultInert > & stapos
		)
{
	//Коррекция часов НКА
	real result = 2.0l/(lightSpeed) *
			(satposvel.subset<0,2>() * satposvel.subset<3,5>());

	//Расстояние от центра Земли до НКА
	real satrv = satposvel.length<0,2>();

	//Расстояние от центра Земли до приёмника
	real starv = stapos.length<0,2>();

	//Расстояние от приёмника  до НКА
	real dist = (satposvel.subset<0,2>()-stapos).length<0,2>();

	//Поправка Шапира
	if (stapos.length<0,2>() != 0)
		result += 2.0l * 398600.4418l *
			log ((satrv+starv+dist)/(satrv+starv-dist))
			/ (lightSpeed*lightSpeed);

	return result;
}

real curWindupAngle (
		const kinematic < real, 3, defaultInert > & sataxisX,
		const kinematic < real, 3, defaultInert > & sataxisY,
		const kinematic < real, 3, defaultInert > & stanorth,
		const kinematic < real, 3, defaultInert > & staeast,
		const kinematic < real, 3, defaultInert > & direct
		)
{
	//Диполь для БИС
	kinematic < real, 3, defaultInert > D = staeast-(direct*staeast)*direct
			+direct.crossProduct(stanorth);
	//Диполь для НКА
	kinematic < real, 3, defaultInert > Dp = sataxisX-(direct*sataxisX)*direct
			-direct.crossProduct(sataxisY);
	real sigma = direct * (Dp.crossProduct(D));
	//! @bug Такой случай, в принципе, не возможен из-за угла излучения НКА
	if (sigma == 0.0l)
		sigma = 1.0l;
	return (sigma/fabs(sigma)) * acos(Dp.normalize() * D.normalize());
}

#ifdef WithQT
QScriptValue createObsProblem(QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		DBTableCollection * tc = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		ObservablesLeastSquaresProblem * ls =
				new ObservablesLeastSquaresProblem(tc);
		return eng->newQObject(ls, QScriptEngine::ScriptOwnership);
	}
	catch (exception & e)
	{
		returnError(eng, string("Не удалось поставить проблему наименьших "
								"квадратов: ") + e.what());
	}
}

BuiltIn createobsprob("newObservablesFitProblem", 1, createObsProblem);
#endif

}

#include <PseudorangeDerivatives.h>
#include <Pseudorange.h>
#include <StdTables.h>
#include <Kinematic.h>
#include <Consts.h>
#include <Frames.h>
#include <ParamTrajectory.h>
#include <SiteDisplacement.h>
#include <PhaseCentre.h>
#include <ERPStorage.h>
#include <TimeShift.h>
#include <Troposphere.h>
#include <dcb.h>
#include <PhaseAmbiguity.h>
#include <observables.h>

namespace libgnss
{


//-----ПРОИЗВОДНАЯ ПО ПАРАМЕТРУ ФАЗОВОЙ НЕОДНОЗНАЧНОСТИ------------------------

PhaseAmbiguityDerivative::PhaseAmbiguityDerivative(const LeastSquaresProblem*ls)
	: InterpolatedParameterDerivator(ls, "phase_ambiguity")
{

}

real PhaseAmbiguityDerivative::getTimeMoment(const NormalEquation *eq)
{
	return eq->getTargetKey()[1].toDouble();
}

real PhaseAmbiguityDerivative::instantDerivative (const NormalEquation * neq,
											const Tuple & param_subkey)
{
	Tuple target_key = ((ObservablesNormalEquation*)neq)->getTargetKey();

	//Проверить совпадение номеров БИС
	int observ_src_id_target = target_key[0].toInt();
	int observ_src_id_param = param_subkey[0].toInt();
	if (observ_src_id_param!=observ_src_id_target)
		return 0.0l;

	//Номеров НКА
	int sat_history_id_target = target_key[2].toInt();
	int sat_history_id_param = param_subkey[1].toInt();
	if (sat_history_id_param!=sat_history_id_target)
		return 0.0l;

	//И частот
	int freqn_target = ((ObservablesNormalEquation*)neq)->getFrequency();
	int freqn_param = param_subkey[2].toInt();
	if (freqn_param!=freqn_target)
		return 0.0l;

	//И если всё совпадает, то производная равна 1
	return 1.0l;
}

vector<Tuple> PhaseAmbiguityDerivative::getSubkeys(const NormalEquation *neq)
const
{
	vector < Tuple > result;
	Tuple target_key = ((ObservablesNormalEquation*)neq)->getTargetKey();
	if (((ObservablesNormalEquation*)neq)->getTimeIndependentInfo().obsmt !=
			ObservableTypes::MTYPE_L)
		return result;

	int freqn_target = ((ObservablesNormalEquation*)neq)->getFrequency();

	Tuple result0;
	result0.resize(3);
	result0[0] = target_key[0];
	result0[1] = target_key[2];
	result0[2] = freqn_target;
	result.push_back(result0);
	return result;
}

//---------------ПРОИЗВОДНАЯ ПО ПАРАМЕТРУ ТРОПОСФЕРЫ---------------------------

TroposphereParamDerivative::TroposphereParamDerivative(
		const LeastSquaresProblem *ls)
	: InterpolatedParameterDerivator(ls, "troposphere")
{
	lsp = (ObservablesLeastSquaresProblem*)(ls);
	ParamTroposphere * tropo = lsp->getImitDB().tropo;
	tropomodel = tropo->getTropoModel();
	usegradient = tropo->useGradient();
	mappingfunction = tropo->getMappingFunctionType();
}

real TroposphereParamDerivative::getTimeMoment(const NormalEquation *eq)
{
	return eq->getTargetKey()[1].toDouble();
}

real TroposphereParamDerivative::instantDerivative (const NormalEquation*neq,
								   const Tuple & param_subkey)
{
	ObservablesNormalEquation * oneq = (ObservablesNormalEquation*)(neq);
	if (isnan(oneq->getTimeDependentInfo().zenith_azimuth.first))
		return 0.0l;
	int pt = param_subkey[1].toInt();
	if (pt>8)
		return 0;

	//Сначала проверить соответствие параметра типу модели тропосферы
	//В случае несоответствия, производная равна нулю.
	//tropomodel: 0-TotalDry 1-TotalWet 2-Dry&Wet
	//usegradient: 0-no 1-yes
	//mappingfunction: 0-GMF 1-NMF 2-CosZ (!=0 - не реализовано)

	if ((usegradient == 0) || ((tropomodel == 2) ^ (pt%3!=0)))
		if (pt > 2)
			return 0;

	kinematic<real, 3, defaultGeodetic> geodpos =
			geocentricToGeodetic(oneq->getTimeDependentInfo().markerpos);

	//Теперь вычислить отображающую функцию
	double hmf; //Гидростатическая отображающая функция
	double wmf; //Влажная отображающая функция
	double dhmf; //Производная гидростатической функции по зенитному углу
	double dwmf; //Производная влажной отображающей функции по зенитному углу
	double zd = ( double )
			( oneq->getTimeDependentInfo().zenith_azimuth.first );
	double az = ( double )
			( oneq->getTimeDependentInfo().zenith_azimuth.second );
	switch (mappingfunction)
	{
		case 0:
		{
			//Global mapping function
			double lon = (double)(geodpos[0]);
			double lat = (double)(geodpos[1]);
			double hm = (double)(geodpos[2]) * 1000;
			double mjdt = getTimeMoment(neq) / jsecondsPerDay + DJM00;
			gmf_(&mjdt,&lat,&lon,&hm,&zd,&hmf,&wmf,&dhmf,&dwmf);
			break;
		}
		case 1:
			throw NotImplementedException("Niel tropospheric mapping function");
		case 2:
			throw NotImplementedException("CosZ tropospheric mapping function");
	}

	//Вычислить производную в зависимости от модели тропосферы
	if (tropomodel == 2)
	{
		switch (pt)
		{
			case 1: return hmf;
			case 2: return wmf;
			case 4: return dhmf*cos(az);
			case 5: return dwmf*cos(az);
			case 7: return dhmf*sin(az);
			case 8: return dwmf*sin(az);
		}
		return 0;
	}

	if (tropomodel == 0)
	{
		switch (pt)
		{
			case 0: return hmf;
			case 3: return dhmf*cos(az);
			case 6: return dhmf*sin(az);
		}
		return 0;
	}

	if (tropomodel == 1)
	{
		switch (pt)
		{
			case 0: return wmf;
			case 3: return dwmf*cos(az);
			case 6: return dwmf*sin(az);
		}
		return 0;
	}

	return 0;
}

vector<Tuple> TroposphereParamDerivative::getSubkeys(const NormalEquation *neq)
const
{
	int obs_src_id = neq->getTargetKey()[0].toInt();
	int marker_id = lsp->getImitDB().obssrc->read(obs_src_id)[0].toInt();
	set < int > param_types = ParamTroposphere::getParametersSet(tropomodel,
																 usegradient);
	vector<Tuple> result;
	result.reserve(param_types.size());
	for (set<int>::iterator it = param_types.begin(); it!=param_types.end();
		 ++it)
		result.push_back(Tuple()<<marker_id<<(*it));

	return result;
}

//----------------ПРОИЗВОДНЫЕ ПО УХОДУ ЧАСОВ-----------------------------------

CTypeSelect timeShiftToAdjust("TimeShiftToAdjust", Tuple()<<string("Receiver")
							  <<string("Satellite")<<string("Both"),2);

Settings::Enumerator timeshifttoadjust("Least_Squares","Pseudorange",
									   "TSToAdj",
									   &timeShiftToAdjust,
									   "Чей уход часов уточнять?",
									   timeShiftToAdjust.defaultValue());

TimeShiftDerivative::TimeShiftDerivative(const LeastSquaresProblem *ls)
	: InterpolatedParameterDerivator(ls, "time_shift")
{
	Settings*sets=(Settings *)(ls->getBase()->getTable("settings"));
	int tta = timeShiftToAdjust.toInt(
				sets->getSettings(timeshifttoadjust));
	recclk = (tta%2 == 0);
	satclk = (tta > 0);
}

real TimeShiftDerivative:: getTimeMoment ( const NormalEquation *eq)
{
	return eq->getTargetKey()[1].toDouble();
}

real TimeShiftDerivative::instantDerivative(const NormalEquation *neq,
								  const Tuple &param_subkey)
{
	ObservablesNormalEquation* oneq = (ObservablesNormalEquation *)neq;

	int tsdata = param_subkey[2].toInt();
	if (tsdata != 0)
		throw NotImplementedException("Дифференцирование по скорости и "
									  "ускорению ухода часов");

	int tstype = param_subkey[0].toInt();

	//Уход часов НКА
	if (tstype == 1)
	{
		//Сравнить номера НКА
		int sat_history_id_neq = neq->getTargetKey()[2].toInt();
		int sat_history_id_par = param_subkey[1].toInt();
		if (sat_history_id_neq!=sat_history_id_par)
			return 0.0l;

		return -lightSpeed;
	}

	//Уход часов БИС
	if (tstype == 0)
	{
		//Сравнить номера БИС
		int obs_src_id_neq = neq->getTargetKey()[0].toInt();
		int obs_src_id_par = param_subkey[1].toInt();
		if (obs_src_id_neq!=obs_src_id_par)
			return 0.0l;

		//Положение и скорость (нулевая) БИС в неинерциальной СК
		kinematic < real, 6, defaultNonInert > stationposvel =
				oneq->getTimeDependentInfo().recieverphasecentre.concat<3>(
					kinematic < real, 3, defaultNonInert > ());

		//Положение и скорость БИС в инерциальной СК
		kinematic < real, 6, defaultInert > stationposvelinert =
				oneq->getImitationDatabase().erp->ITRFtoGCRS(
					stationposvel, oneq->getTimeDependentInfo().tai);

		//Разность XБИС - XКА
		kinematic < real, 6, defaultInert > diffss = stationposvelinert
				- oneq->getTimeDependentInfo().posvel;

		real addition = (diffss.subset<0,2>()-
							diffss.subset<3,5>()).length<0,2>()
				- diffss.length<0,2>();
				//diffss.subset<0,2>() * diffss.subset<3,5>() /
				//diffss.length<0,2>();

		return lightSpeed + addition;
	}
}

vector<Tuple> TimeShiftDerivative::getSubkeys(const NormalEquation *neq) const
{
	vector < Tuple > result;
	int obs_src_id = neq->getTargetKey()[0].toInt();
	int sat_his_id = neq->getTargetKey()[2].toInt();

	if (recclk)
		//Производная по уходу часов БИС
		result.push_back(Tuple()<<0<<obs_src_id<<0);

	if (satclk)
		//Производаня по уходу часов НКА
		result.push_back(Tuple()<<1<<sat_his_id<<0);

	return result;
}

//--------------ПРОИЗВОДНЫЕ ПО ПОЛОЖЕНИЮ БИС--------------------------------//

real MarkerPositionDerivative::getTimeMoment ( const NormalEquation *eq)
{
	return eq->getTargetKey()[1].toDouble();
}

real MarkerPositionDerivative::instantDerivative(const NormalEquation *neq,
								  const Tuple &param_subkey)
{
//	#define oneq ((ObservablesNormalEquation*)(neq));
	ObservablesNormalEquation * oneq = ((ObservablesNormalEquation*)(neq));
	real tai = oneq->getTimeDependentInfo().tai;
	int coordidx = param_subkey[1].toInt();
	//kinematic создаёт нулевой вектор
	kinematic < real, 3, defaultNonInert > vec;
	vec[coordidx] = 1.0l;
	kinematic < real, 3, defaultInert > vecinert =
			oneq->getImitationDatabase().erp->ITRFtoGCRS(vec,tai);
	kinematic < real, 3, defaultInert > direct =
			(oneq->getTimeDependentInfo().satposinert -
			oneq->getTimeDependentInfo().recposinert).normalize();
	return -(vecinert*direct);
}

MarkerPositionDerivative::MarkerPositionDerivative(const LeastSquaresProblem*ls)
	: InterpolatedParameterDerivator (ls, "marker_position")
{

}

vector<Tuple> MarkerPositionDerivative::getSubkeys(const NormalEquation *neq)
const
{
//	#define oneq ((ObservablesNormalEquation*)(neq));
	ObservablesNormalEquation * oneq = (ObservablesNormalEquation*)neq;
	vector < Tuple > result;
	int obs_src_id = neq->getTargetKey()[0].toInt();
	int marker_id=oneq->getImitationDatabase().obssrc->
			read(obs_src_id)[0].toInt();
	result.push_back(Tuple()<<marker_id<<0);
	result.push_back(Tuple()<<marker_id<<1);
	result.push_back(Tuple()<<marker_id<<2);
	return result;
}

//---ПРОИЗВОДНЫЕ ПО КООРДИНАТАМ НКА--------------------------------------------

real TrajectoryDerivative::getTimeMoment ( const NormalEquation * eq)
{
	return eq->getTargetKey()[1].toDouble();
}

real TrajectoryDerivative::instantDerivative(const NormalEquation *neq,
								  const Tuple &param_subkey)
{
	//Производная по данной координате НКА
	ObservablesNormalEquation * oneq = ((ObservablesNormalEquation*)(neq));
	real tai = oneq->getTimeDependentInfo().tai;
	int sat_history_id = param_subkey[0].toInt();
	int coord_idx = param_subkey[1].toInt();
	pair<int,vector<int> > * cd = &(coords[sat_history_id]);
	//Вектор, вдоль которого будет приращение при вариировании данной
	//координаты
	kinematic < real, 3, defaultInert > vecinert;
	if (cd->first == Frames::FT_ECIF)
	{
		if (coord_idx == cd->second[0])
			vecinert[0] = 1.0l;
		else if (coord_idx == cd->second[1])
			vecinert[1] = 1.0l;
		else if (coord_idx == cd->second[2])
			vecinert[2] = 1.0l;
		else
			throw StrException("TrajectoryDerivative::instantDerivative",
			"Дифференцирование по скоростям и ускорением НКА не производится.");
	}
	else if (cd->first == Frames::FT_ITRS)
	{
		kinematic<real,3,defaultNonInert> basisvec_;
		if (coord_idx == cd->second[0])
			basisvec_[0] = 1.0l;
		else if (coord_idx == cd->second[1])
			basisvec_[1] = 1.0l;
		else if (coord_idx == cd->second[2])
			basisvec_[2] = 1.0l;
		else
			throw StrException("TrajectoryDerivative::instantDerivative",
			"Дифференцирование по скоростям и ускорением НКА не производится.");
		vecinert = oneq->getImitationDatabase().erp->ITRFtoGCRS(basisvec_,tai);
	}
	else
		throw NotImplementedException("Дифференцирование по координатам "
				"возможно только в системах координат типа GCRS и ITRS.");
	//Вектор БИС->НКА
	kinematic < real, 3, defaultInert > direct =
			(oneq->getTimeDependentInfo().satposinert -
			oneq->getTimeDependentInfo().recposinert).normalize();
	return vecinert*direct;
}

TrajectoryDerivative::TrajectoryDerivative(const LeastSquaresProblem * ls)
	: InterpolatedParameterDerivator (ls, "trajectory")
{

}

vector<Tuple> TrajectoryDerivative::getSubkeys(const NormalEquation * neq)
const
{
	ObservablesNormalEquation * oneq = (ObservablesNormalEquation*)neq;
	int sat_history_id = oneq->getTimeIndependentInfo().sat_history_id;
	map < int, pair<int, vector<int> > >::const_iterator it =
			coords.find(sat_history_id);
	if (it == coords.end())
	{
		ParamTrajectory * traj = oneq->getImitationDatabase().traj;
		Frames * fr = (Frames *)
				(oneq->getBase()->getTable("coordinate_frames"));
		int frame_id = traj->getCoordinateFrameID(sat_history_id);
		int frame_type = fr->read(frame_id)[0].toInt();
		((TrajectoryDerivative*)(this))->coords[sat_history_id].first=
				frame_type;
		((TrajectoryDerivative*)(this))->coords[sat_history_id].second =
				fr->getFrameCoordinates(frame_id);
	}
	vector<Tuple> result;
	result.reserve(3);
	result.push_back(Tuple()<<sat_history_id
					 <<coords.at(sat_history_id).second[0]);
	result.push_back(Tuple()<<sat_history_id
					 <<coords.at(sat_history_id).second[1]);
	result.push_back(Tuple()<<sat_history_id
					 <<coords.at(sat_history_id).second[2]);
	return result;
}
}

#ifndef PSEUDORANGE_DERIVATIVE_H_
#define PSEUDORANGE_DERIVATIVE_H_

#include <Pseudorange.h>

namespace libgnss
{

/** @brief Дифференцирование по параметру фазовой неоднозначности
 *
 * @ingroup leastsq
 */
class PhaseAmbiguityDerivative : public InterpolatedParameterDerivator
{
protected:
	virtual real getTimeMoment(const NormalEquation *eq);
	virtual real instantDerivative (const NormalEquation * neq,
									   const Tuple & param_subkey);
public:
	PhaseAmbiguityDerivative(const LeastSquaresProblem * ls);
	virtual vector <Tuple> getSubkeys(const NormalEquation *neq) const;
};

/** @brief Дифференцирование по параметру тропосферной задержки
 *
 * @ingroup leastsq
 */
class TroposphereParamDerivative : public InterpolatedParameterDerivator
{
protected:
	ObservablesLeastSquaresProblem * lsp;
	int tropomodel;
	int usegradient;
	int mappingfunction;
	virtual real getTimeMoment(const NormalEquation *eq);
	virtual real instantDerivative (const NormalEquation * neq,
									   const Tuple & param_subkey);
public:
	TroposphereParamDerivative(const LeastSquaresProblem * ls);
	virtual vector<Tuple> getSubkeys(const NormalEquation *neq) const;
};

/** @brief Дифференцирование по параметру ухода часов БИС и НКА
 *
 * @ingroup leastsq
 */
class TimeShiftDerivative : public InterpolatedParameterDerivator
{
protected:
	virtual real getTimeMoment ( const NormalEquation *eq);
	virtual real instantDerivative(const NormalEquation *neq,
									  const Tuple &param_subkey);
	bool recclk;
	bool satclk;
public:
	TimeShiftDerivative(const LeastSquaresProblem * ls);
	virtual vector<Tuple> getSubkeys(const NormalEquation *neq) const;
};

/** @brief Дифференцирование оп параметру положения маркера
 *
 * @ingroup leastsq
 */
class MarkerPositionDerivative : public InterpolatedParameterDerivator
{
protected:
	virtual real getTimeMoment ( const NormalEquation *eq);
	virtual real instantDerivative(const NormalEquation *neq,
									  const Tuple &param_subkey);
public:
	MarkerPositionDerivative(const LeastSquaresProblem * ls);
	virtual vector<Tuple> getSubkeys(const NormalEquation *neq) const;
};

/** @brief Дифференцирование по координатам НКА
 *
 * @ingroup leastsq
 */
class TrajectoryDerivative : public InterpolatedParameterDerivator
{
private:
	/**
	 * В какой системе координат хранятся координаты НКА.
	 */
	map < int, pair<int, vector<int> > > coords;
protected:
	virtual real getTimeMoment ( const NormalEquation * eq);
	virtual real instantDerivative(const NormalEquation *neq,
									  const Tuple &param_subkey);
public:
	TrajectoryDerivative(const LeastSquaresProblem * ls);
	virtual vector<Tuple> getSubkeys(const NormalEquation * neq) const;
};

}

#endif

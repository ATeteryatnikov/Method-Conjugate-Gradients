#ifndef PSEUDORANGEREGULARISE_H_
#define PSEUDORANGEREGULARISE_H_

#include <string>
#include <Pseudorange.h>

namespace libgnss
{


/**
 * @brief Регуляризация уточнения линейного ухода часов
 *
 * @ingroup leastsq
 *
 * Регуляризация добавляет в матрицу МНК дополнительные строки, выражающие
 * дополнительные условия. Данная функция используется, если известно, что
 * уход некоторых часов должен быть близок к линейному.
 *
 * Информация о линейности ухода часов берётся из таблицы
 * @ref ClockLinearResidue.
 *
 * @param lsp Задача наименьших квадратов
 * @param lsmatrix Основная матрица
 * @param rhs Правая часть
 */
void regulariseLinearResidueClockBias(ObservablesLeastSquaresProblem & lsp,
						 RowWiseSparseMatrix < real > & lsmatrix,
						 std::vector < real > & rhs);

/**
 * @brief Регуляризация задачи восстановления ухода часов
 *
 * @ingroup leastsq
 *
 * Функция добавляет к сформированной матрице и правой части задачи МНК новые
 * строки, которые регуляризуют задачу восстановления ухода часов БИС и НКА.
 *
 * Регуляризация проводится в соответствие с содержимым таблицы clock_variance
 * (@ref ClockVariance).
 *
 * Для каждого размера линейной комбинации для каждого БИС/НКА, уход часов
 * которого есть и в таблице time_shift и в таблице clock_variance, выполняется
 * добавление уравнений, регуляризующих линейные комбинации уходов часов БИС/НКА
 * соответствующего размера.
 *
 * @param lsp Задача наименьших квадратов
 * @param lsmatrix Сформированная матрица задачи МНК
 * @param rhs Сформированная правая часть задачи МНК
 */
void regulariseBinomClockBias(ObservablesLeastSquaresProblem & lsp,
						 RowWiseSparseMatrix < real > & lsmatrix,
						 std::vector < real > & rhs);

/**
 * @brief Регуляризация задачи восстановления координат маркера
 *
 * @ingroup leastsq
 *
 * Регуляризация производится путем добавления уравнений вида
 * "Координаты БИС = Заданные координаты БИС",
 * где Заданные координаты БИС берутся из таблицы @ref ReferenceFrames. Оттуда
 * же берутся весовые коэффициенты этих уравнений.
 *
 * @param lsp Задача наименьших квадратов
 * @param lsmatrix Сформированная матрица задачи МНК
 * @param rhs Сформированная правая часть задачи МНК
 */
void regulariseMarkerPosition(ObservablesLeastSquaresProblem & lsp,
							  RowWiseSparseMatrix < real > & lsmatrix,
							  std::vector < real > & rhs);

/**
 * @brief Регуляризация параметра тропосферы
 * @param lsp Задача наименьших квадратов
 * @param lsmatrix Матрица задачи МНК
 * @param rhs Правая часть задачи МНК
 *
 * @ingroup leastsq
 *
 * Метод добавляет уравнения \f$1/\sigma_p \cdot p = 0\f$ для каждого параметра
 * \f$p\f$ тропосферной задержки.
 *
 * Априорное СКО \f$\sigma_p\f$ параметра выбирается из следующих соображений:
 *
 * @li если p - полная или сухая задержка, то \f$\sigma_p = 0.004 km\f$;
 * @li если p - влажная задержка, то \f$\sigma_p = 0.0004 km\f$;
 * @li если p - параметр градиента \f$\sigma_p = 0.000004 km\f$.
 */
void regulariseTroposphereParameters(ObservablesLeastSquaresProblem & lsp,
		RowWiseSparseMatrix < real > & lsmatrix,
		std::vector < real > & rhs, real weight=0.0001);

}

#endif

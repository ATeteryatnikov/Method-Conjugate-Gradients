#include <vector>

using namespace std;

#include <Pseudospeed.h>
#include <Pseudorange.h>
#include <Kinematic.h>
#include <Frames.h>
#include <ERPStorage.h>
#include <Troposphere.h>
#include <derivate.hpp>

namespace libgnss
{


real calcPseudospeed(const ObservablesNormalEquation * eq)
{
#define info0 eq->getTimeIndependentInfo()
#define info eq->getTimeDependentInfo()
#define imit eq->getImitationDatabase()
	const real tropo_delta_t = 300;
	//Найти скорость НКА и БИС
	kinematic<real,3,defaultInert> satvel = info.posvel.subset<3,5>();
	kinematic<real,6,defaultNonInert> staposvel =
					info.recieverphasecentre.concat<3>(
							kinematic<real,3,defaultNonInert>());
	kinematic<real,6,defaultInert> staposvel_inert=imit.erp->ITRFtoGCRS(
				staposvel,info.tai);
	kinematic<real,3,defaultInert> stavel = staposvel_inert.subset<3,5>();

	//Спроецировать разность скоростей БИС-НКА на вектор БИС-НКА
	kinematic<real,3,defaultInert> dir = (info.posvel.subset<0,2>()
			- staposvel_inert.subset<0,2>()).normalize();
	kinematic<real,3,defaultInert> veldiff = satvel - stavel;
	real geomdistdot = veldiff * dir;


	//Найти тропосферную задержку в нескольких точках.
	//! @todo Написать корректное дифференцирование
	int n_tropo=eq->getImitationDatabase().tropo->getInterpolateOrder(Tuple());
	vector<real> args;
	vector<real> vals;
	for (unsigned int i=-floor(n_tropo*0.5); i<n_tropo+floor(n_tropo*0.5); ++i)
	{
		 real x = info.tai + i * tropo_delta_t;
		 real y = imit.tropo->troposphereDelay(info0.marker_id,
				geocentricToGeodetic(info.markerpos), info.zenith_azimuth.first,
					info.zenith_azimuth.second, x);
		 args.push_back(x);
		 vals.push_back(y);
	}
	vector<real> tropoderivs = approximate(args,vals,info.tai, args.size()-1,2);
	real tropodelaydot = tropoderivs[1];
	real relcorrectiondot;

	return geomdistdot + tropodelaydot + relcorrectiondot;
}
}

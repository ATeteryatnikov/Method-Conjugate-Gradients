#include <exception>
#include <stdexcept>
#include <map>
#include <set>

using namespace std;

#include <gnssconfig.h>
#ifdef WithQT
#include <QScriptEngine>
#include <QScriptContext>
#endif
#include <realsparsematrix.h>
#include <DBVariant.h>
#include <StdTables.h>
#include <PseudorangeRegularise.h>
#include <TimeShift.h>
#include <binomial.hpp>
#include <ClockVariance.h>
#include <SiteDisplacement.h>
#include <Troposphere.h>

namespace libgnss
{

CTypeSelect * clkregmeth_t ()
{
	static CTypeSelect clkregmeth_t_ ("ClkRegMeth", Tuple()
			<<"1)Приравнять к нулю уход часов выбранных БИС"
			<<"2)Приравнять к нулю n-ю производную ухода часов выбранных БИС"
			<<"3)Приравнять к нулю n-ю производную ухода часов выбранных НКА"
			<<"4)Использовать методы 2 и 3 одновременно"
			<<"5)Использовать методы 1 и 2 одновременно"
			<<"6)Использовать методы 1 и 3 одновременно"
			<<"7)Использовать методы 1, 2 и 3 одновременно", 6);
	return & clkregmeth_t_;
}


Settings::Enumerator clkregmeth("Least_Squares", "Pseudorange", "ClkRegMeth",
							clkregmeth_t(),
"Методы регуляризации уточнения ухода часов БИС и НКА",
								clkregmeth_t()->defaultValue());

Settings::Enumerator clkzerorec("Least_Squares", "Pseudorange", "clkzerorec",
		Variant::TYPE_STRING,
	"Перечислить через пробел список БИС (со строчными буквами) для 1-го метода"
	" регуляризации ухода часов", "");

Settings::Enumerator clkderzerorec("Least_Squares", "Pseudorange",
	"clkzeroderrec", Variant::TYPE_STRING,
	"Перечислить через пробел список БИС (со строчными буквами) для 2-го метода"
	" регуляризации ухода часов", "");

Settings::Enumerator clkderzerosat("Least_Squares", "Pseudorange",
	"clkzerodersat", Variant::TYPE_STRING,
	"Перечислить через пробел список НКА ((буква)(PRN|Слот)) для 3-го метода"
	" регуляризации ухода часов", "");

Settings::Enumerator clockReg ("Least_Squares", "Pseudorange", "ClockRegOrder",
							   Variant::TYPE_INT,
"Порядок линейной комбинации, регуляризующей уход часов (для 2: x(k)-x(k-1)",
							   3);

void regulariseLinearResidueClockBias(ObservablesLeastSquaresProblem & lsp,
						 RowWiseSparseMatrix < real > & lsmatrix,
						 vector < real > & rhs)
{
	//Необходимые таблицы
	ClockLinearResidue * clklr = (ClockLinearResidue *)
			(lsp.getBase()->getTable("clock_linear_residue"));
	ClockBias*cb=(ClockBias*)(lsp.getBase()->getTable("time_shift"));

	//Пройти по всем часам
	for (DBTable::DBConstIterator it = cb->const_begin();
		 it!=cb->const_end(); it.inc(1))
	{
		int clktype = it.keyColumnValue(0).toInt();
		int device_id = it.keyColumnValue(1).toInt();
		DBTable::DBConstIterator itbegin = cb->find(Tuple()<<clktype
													<<device_id<<0);
		real T0 = itbegin.keyColumnValue(3).toDouble();
		DBTable::DBConstIterator itend = cb->lower_bound(
					Tuple()<<clktype<<device_id<<0
					<<numeric_limits<real>::infinity());
		real T1 = itend.keyColumnValue(3).toDouble();

		//Найти набор интервалов непрерывной работы часов
		vector < pair < real, real > > intervals;
		intervals.push_back(pair < real, real> (T0, T1));

		//Для каждого интервала - СКО невязки линейной аппроксимации
		vector < real > lrrms;

		try
		{
			while (true)
			{
				for (int i = lrrms.size(); i<intervals.size(); i++)
				{
					real rms;
					try
					{
						rms = clklr->clockVariance(clktype,device_id,
										intervals[i].first,intervals[i].second);
					}
					catch (const NotContinuousClockInterval & clkbreak)
					{
						//Дробление интервала
						//Найти точную точку дробления интервала
						DBTable::DBConstIterator itbreak = cb->upper_bound(
									Tuple()<<clktype<<device_id<<0
									<<clkbreak.getTimeBreak());
						real newt1 = intervals[i].second;
						itbreak--;
						real tbreak=itbreak.keyColumnValue(3).toDouble();
						intervals[i].second = tbreak;

						intervals.push_back(pair<real,real>(
									clkbreak.getTimeBreak(),newt1));
						break;
					}
					//Если дробить данный подинтервал не нужно,
					//запомнить СКО для него
					lrrms.push_back(rms);
				}
				if (lrrms.size() == intervals.size())
					break;
			}
		}
		catch (const KeyNotFoundException & e)
		{
			//Это исключение может возникнуть только если в таблице СКО невязок
			//нет информаци для данных часов БИС/НКА
			continue; //К следующему БИС/НКА
		}

		for (int i = 0; i < intervals.size(); i++)
		{
			real t0 = intervals[i].first;
			real t1 = intervals[i].second;
			real sumsqx = 0;
			real sumx = 0;
			real sumy = 0;
			real sumxy = 0;
			real count = 0;

			for (DBTable::DBConstIterator it1 = cb->find(
					 Tuple()<<clktype<<device_id<<0<<t0);
				 it1!=cb->const_end();
				 it1.subinc(3,2))
			{
				if (it1.keyColumnValue(3).toDouble()>t1)
					break;
				real xi = it1.keyColumnValue(3).toDouble() - t0;
				real dt = it1[0].toDouble();
				sumsqx += (xi * xi);
				sumx += xi;
				sumy += dt;
				sumxy += dt*xi;
				count ++;
			}

			real determinant = count * sumsqx - (sumx*sumx);
			real c00 = count / determinant;
			real c01 = -sumx / determinant;
			real c10 = c01;
			real c11 = sumsqx / determinant;

			//Цикл по всем добавляемым уравнениям (по одному на каждый
			//параметр ухода часов)
			for (DBTable::DBConstIterator it1 = cb->find(
					 Tuple()<<clktype<<device_id<<0<<t0);
				 it1!=cb->const_end();
				 it1.subinc(3,2))
			{
				if (it1.keyColumnValue(3).toDouble()>t1)
					break;
				vector < pair < int, real > > line;
				real rhsvalue = 0.0l;
				real xk = it1.keyColumnValue(3).toDouble() - t0;
				//Цикл по всем ненулевым элементам строки
				for (DBTable::DBConstIterator it2 = cb->find(
						 Tuple()<<clktype<<device_id<<0<<t0);
					 it2!=cb->const_end();
					 it2.subinc(3,2))
				{
					if (it2.keyColumnValue(3).toDouble()>t1)
						break;
					real xi = it2.keyColumnValue(3).toDouble() - t0;
					real yi0 = it2[0].toDouble();
					int idx=lsp.getColumnsIndex("time_shift")->
									read(it2.subkey())[0].toInt();
					real coeff0 = (c00 * xi + c01) * xk + (c10 * xi + c11);
					if (xi == xk)
						coeff0 -= 1.0l;
					coeff0 /= lrrms[i];
					line.push_back(pair<int,real>(idx,coeff0));
					rhsvalue -= coeff0 * yi0;
				}

				lsmatrix.push_back(line);
				rhs.push_back(rhsvalue);
			} // По набору параметров ухода часов для одного НКА/БИС
		} //По интервалам непрерывности работы часов БИС/НКА
	} //По списку НКА/БИС
}


void regulariseBinomClockBias(ObservablesLeastSquaresProblem & lsp,
						 RowWiseSparseMatrix < real > & lsmatrix,
						 vector < real > & rhs)
{
	//Необходимые таблицы
	ClockVarBinomial * clkvar =( ClockVarBinomial* )
			(lsp.getBase()->getTable("clock_variance"));
	ClockBias*ts=(ClockBias*)(lsp.getBase()->getTable("time_shift"));

	//Пройти по всем типам линейных комбинаций
	for (DBTable::DBConstIterator it = clkvar->const_begin();
		 it!=clkvar->const_end(); it.inc(0))
	{
		int npoints = it.keyColumnValue(0).toInt();
		vector < int > binom = binomialCoefficientsAlt(npoints);

		//Пройти по всем БИС/НКА, для которых есть информация о регуляризации
		for (DBTable::DBConstIterator it2 = ts->const_begin();
			 it2!=ts->const_end(); it2.inc(1))
		{
			int devtype = it2.keyColumnValue(0).toInt();
			int dev_id = it2.keyColumnValue(1).toInt();
			if (clkvar->find(Tuple()<<npoints<<devtype<<dev_id<<0)
					== clkvar->const_end())
				continue;

			//Создать двигающееся по времени окно

			//Пройти по всем возможным начальным точкам окна
			for (DBTable::DBConstIterator it3=ts->find(Tuple()<<devtype
					<<dev_id<<0); it2!=ts->const_end(); it2.subinc(3,2))
			{
				//Попробовать сформировать строку матрицы МНК
				real step = 0.0l;
				vector < pair < int, real > > vertices;
				real rhsvalue = 0.0l;
				real tfirst = numeric_limits<real>::quiet_NaN();
				real tcur = numeric_limits<real>::quiet_NaN();
				real tnext = numeric_limits<real>::quiet_NaN();
				for (DBTable::DBConstIterator it4 = it3;
					 it4!=ts->const_end(); it4.subinc(3,2))
				{
					tnext = it4.keyColumnValue(3).toDouble();

					//Если шаг уже был определён, сравнить его
					if (vertices.size()>1)
						//Если шаг другой, то не формировать линейную комбинацию
						if (fabs(fabs(tnext-tcur) - step) > step * 1e-15)
							break;

					//Попробовать определить шаг, если он ещё не определён
					if (vertices.size() == 1)
						step = fabs(tnext-tcur);

					if (vertices.size() == 0)
						tfirst = tnext;

					tcur = tnext;

					//Добавить ненулевой элемент строки матрицы
					int idx=lsp.getColumnsIndex("time_shift")->
										read(it4.subkey())[0].toInt();
					real curcoeff = binom[vertices.size()];
					vertices.push_back(pair<int,real>(idx,curcoeff));
					rhsvalue-=curcoeff * it4[0].toDouble();

					if (vertices.size() >= npoints)
						break;
				}

				if (vertices.size() < npoints)
					continue;

				/* Проверить, что между первой вершиной набора и последней не
				 * произошла смена часов БИС/НКА. См. иллюстрацию.
				 *
				 * clock_variance.since:    cмена часов          смена часов
				 *                               |                    |
				 * Вершины:                |  |  ...  |
				 *                         v1 v2      vn
				 */
				DBTable::DBConstIterator lb = clkvar->lower_bound(
							Tuple()<<npoints<<devtype<<dev_id<<tcur);
				real since = lb.keyColumnValue(3).toDouble();
				if (since > tfirst)
					continue;

				//Учесть СКО
				real onebysigma = 1/sqrt(clkvar->clockVariance(
											npoints,devtype,dev_id,tcur,step));
				for (unsigned int i=0; i<vertices.size(); i++)
					vertices[i].second *= onebysigma;
				rhsvalue *= onebysigma;
				rhs.push_back(rhsvalue);
				lsmatrix.push_back(vertices);
			} //Проход по начальным точкам окна
		} //Проход по всем БИС/НКА с информацией о регуляризации
	} //Проход по всем типам линейных комбинаций
}

void regulariseMarkerPosition(ObservablesLeastSquaresProblem & lsp,
							  RowWiseSparseMatrix < real > & lsmatrix,
							  vector < real > & rhs)
{
	//Получить необходимые таблицы
	MarkerPosition * mpos = (MarkerPosition*)
			(lsp.getBase()->getTable("marker_position"));
	ReferenceFrames * rframes = (ReferenceFrames * )
			(lsp.getBase()->getTable("reference_frames"));
	Frames * frames = (Frames*)
			(lsp.getBase()->getTable("coordinate_frames"));
	int frame_id = frames->defaultNonInertFrame();
	//Пройти по всем БИС, координаты которых уточняются
	for (DBTable::DBConstIterator it = mpos->const_begin();
		 it!=mpos->const_end(); ++it)
	{
		int marker_id = it.keyColumnValue(0).toInt();
		int coord_num = it.keyColumnValue(1).toInt();
		real t = it.keyColumnValue(2).toDouble();
		//Регуляризовать только координаты
		if (coord_num >= 3)
			continue;
		//Найти их в определении системы координат. Если нет, значит не
		//регуляризовать
		DBMap::DBConstIterator itp = rframes->find(Tuple()<<frame_id
										   <<marker_id<<coord_num);
		DBMap::DBConstIterator itv = rframes->find(Tuple()<<frame_id
										   <<marker_id<<coord_num+3);
		if ((itp == rframes->const_end()) || (itv == rframes->const_end()))
			continue;
		real years = (itp[1].toDouble() - t)/(86400*365.25);
		real regcoord = itp[0].toDouble() + itv[0].toDouble() * years;
		real stddev = itp[2].toDouble() + itv[2].toDouble() * years;
		vector<pair<int,real> > line;
		int colidx;
		try
		{
			colidx = lsp.getParameterColumnIndex("marker_position",
													 it.subkey());
		}
		catch (const ParameterNotAdjustableException & e)
		{
			throw StrException("regulariseMarkerPosition",
							   "Невозможно регуляризовать уточнение координат "
							   "БИС: они не включены в список уточняемых "
							   "параметров.");
		}

		line.push_back(pair<int,real>(colidx,1.0l/stddev));
		real rhsvalue = (regcoord - it[0].toDouble()) / stddev;
		lsmatrix.push_back(line);
		rhs.push_back(rhsvalue);
	}
}

void regulariseTroposphereParameters(ObservablesLeastSquaresProblem &lsp,
									 RowWiseSparseMatrix<real> &lsmatrix,
									 vector<real> &rhs,
									 real weight)
{
	static map<int, real> onebystddev;
	if (onebystddev.size()==0)
	{
		onebystddev[0] = 1/0.004;
		onebystddev[1] = 1/0.004;
		onebystddev[2] = 1/0.0004;
		onebystddev[3] = 1/0.000004;
		onebystddev[4] = 1/0.000004;
		onebystddev[5] = 1/0.000004;
		onebystddev[6] = 1/0.000004;
		onebystddev[7] = 1/0.000004;
		onebystddev[8] = 1/0.000004;
	}

	ParamTroposphere * trop = lsp.getImitDB().tropo;
	for (DBTable::DBConstIterator it = trop->begin();
		 it!=trop->end(); ++it)
	{
		int param_id = it.keyColumnValue(1).toInt();
		vector<pair<int,real> > equation;
		int eqidx = lsp.getParameterColumnIndex("troposphere",
												it.subkey());
		real curval = -it[0].toDouble()*onebystddev[param_id]*weight;
		real onebysigma = onebystddev[param_id]*weight;
		equation.push_back(pair<int,real>(eqidx,onebysigma));
		lsmatrix.push_back(equation);
		rhs.push_back(curval);
	}
}

#ifdef WithQT
QScriptValue regularlinresid(QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		ObservablesLeastSquaresProblem * lsp =
				qobject_cast<ObservablesLeastSquaresProblem*>
				(ctx->argument(0).toQObject());
		RealLinearisation * rlnz = qobject_cast<RealLinearisation*>
				(ctx->argument(1).toQObject());
		regulariseLinearResidueClockBias(*lsp,rlnz->lhs, rlnz->rhs);
		return QScriptValue();
	}
	catch(StrException & e)
	{
		returnError(eng,string("Ошибка регуляризации ухода часов: ")+e.what());
	}
}

QScriptValue regularbinomtbias(QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		ObservablesLeastSquaresProblem * lsp = qobject_cast<
				ObservablesLeastSquaresProblem*>(ctx->argument(0).toQObject());
		RealLinearisation * rlnz = qobject_cast<RealLinearisation*>
				(ctx->argument(1).toQObject());
		regulariseBinomClockBias(*lsp,rlnz->lhs, rlnz->rhs);
		return QScriptValue();
	}
	catch(StrException & e)
	{
		returnError(eng,string("Ошибка регуляризации ухода часов: ")+e.what());
	}
}

QScriptValue regularmarkerpos(QScriptContext * ctx, QScriptEngine * eng)
{
	try
	{
		ObservablesLeastSquaresProblem * lsp = qobject_cast<
				ObservablesLeastSquaresProblem*>(ctx->argument(0).toQObject());
		RealLinearisation * rlnz = qobject_cast<RealLinearisation*>
				(ctx->argument(1).toQObject());
		regulariseMarkerPosition(*lsp,rlnz->lhs, rlnz->rhs);
		return QScriptValue();
	}
	catch(StrException & e)
	{
		returnError(eng,string("Ошибка регуляризации координат БИС: ")
					+e.what());
	}
}

BuiltIn reglin ("regulariseLinearClockResidue", 2, regularlinresid);
BuiltIn regbin ("regulariseBinomClockBias", 2, regularbinomtbias);
BuiltIn regmpos ("regulariseMarkerPosition", 2, regularmarkerpos);
#endif

}

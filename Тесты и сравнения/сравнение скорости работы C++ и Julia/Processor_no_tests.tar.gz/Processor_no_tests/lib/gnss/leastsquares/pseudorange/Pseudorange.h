#ifndef PSEUDORANGE_H_
#define PSEUDORANGE_H_

//! \file

#include <Kinematic.h>
#include <Consts.h>
#include <LeastSquares.h>
#include <Settings.h>

namespace libgnss
{

class ParamTrajectory;
class MarkerPosition;
class MarkerEccentricity;
class SVPhaseCentreModels;
class ReceivingAntennaPhaseCentreModels;
class PhaseCentreOffsetFrequency;
class PhaseCentreVariationGrid;
class ERPStorage;
class ClockBias;
class ParamTroposphere;
class ParamDCB;
class ParamPhaseAmbiguity;
class Observables;
class ObservationSource;
class Markers;
class SatelliteHistory;
class GLONASSFrequencySlots;
class Settings;
class ObservableTypes;

/**
 * @brief Ошибка вычисления доворота фазы
 *
 * @ingroup leastsq
 */
class PhaseWindupError : public StrException
{
	PhaseWindupError(string satname, string staname, real t);
};

class ObservablesLeastSquaresProblem;
//class ObservablesLeastSquaresProblem::ImitationDatabase;

/**
 * Набор указателей на таблицы, необходимые для имитации
 */
struct ImitationDatabase
{
	//! Таблица БИСов
	ObservationSource * stations;

	//! Таблица соответствия номеров НКУ и слотов
	SatelliteHistory * satellites;

	//! Маркеры
	Markers * markers;

	//! Траектории НКА
	ParamTrajectory * traj;

	//! Положения БИС
	MarkerPosition * markerpos;

	//! Смещение опорной точки антенны относительно положения БИС
	MarkerEccentricity * eccentricity;

	//! Номера моделей сдвига фазового центра НКА
	SVPhaseCentreModels * svpcm;

	//! Номера моделей сдвига фазового центра БИС
	ReceivingAntennaPhaseCentreModels * recpcm;

	//! Данные для модели сдвига среднего фазового центра БИС и НКА
	PhaseCentreOffsetFrequency * pcofreq;

	//! Зависящие от направления поправки к дальности за счет смещения ФЦ
	PhaseCentreVariationGrid * pcvar;

	//! Типы измерительных данных
	ObservableTypes * obstypes;

	//! Хранилище ПВЗ и матриц перехода
	ERPStorage * erp;

	//! Уходы часов БИС и КА
	ClockBias * timeshift;

	//! Номера маркера, приёмника и антенны для БИС
	ObservationSource * obssrc;

	//! Номера литер ГЛОНАСС
	GLONASSFrequencySlots * gloletters;

	//! Тропосферная задержка
	ParamTroposphere * tropo;

	//! Межлитерная задержка
	ParamDCB * dcb;

	//! Параметр фазовой неоднозначности
	ParamPhaseAmbiguity * phase_ambiguity;

	//! Настройки моделей
	Settings * settings;

	bool loaded;

	inline ImitationDatabase()
	{
		loaded = false;
	}
};

/**
 * @brief Уравнение для приближения измерительных данных
 *
 * @ingroup leastsq
 * @ingroup obsmodel
 *
 * Фазовая дальность (фаза, переведённая в км.) \f$\l0_{m,n}(t_r)\f$ с
 * исключенной по двум частотам ионосферной задержкой сигнала между \f$m\f$-й
 * БИС и \f$n\f$-м НКА в момент времени \f$t_r\f$ (в шкале БИС) вычисляется по
 * формуле:
 *
   \f[l0_{m,n}(t_r) = \rho_{m,n}(t, t_t)+T_{m,n}(t)+c\cdot (\Delta t^R_m(t_r) -
   \Delta t^S_n(t_t)) + D_{m,q}(t) + \lambda 0\cdot(A_{m,n}(t) + W_{m,n}(t)) +
   R_{m,n}(t),\f]
 *
 * где \f$ \Delta t^R_m(t_r) \f$ - уход часов \f$m\f$-й БИС в момент времени
 * \f$ t_r\f$ в шкале БИС, \f$t = t_r-\Delta t^R(t_r)\f$ - момент приёма сигнала
 * во внутренней шкале, \f$ t_t \f$ - момент времени передачи сигнала во
 * внутренней шкале, \f$ \Delta t^S_n(t_t)\f$ - уход часов \f$n\f$-го НКА в
 * момент времени \f$ t_t\f$, \f$T_{m,n}(t)\f$ - величина задержки сигнала
 * в тропосфере, в км, \f$ D_{m,q}(t)\f$ - величина межлитерной задержки сигнала
 * в трактах, в км, \f$ \lambda 0 = \lambda_1-\lambda_2 \f$, где \f$\lambda_1\f$
 * и \f$\lambda_2\f$ - длины волн на частотах L1 и L2, \f$A_{m,n}(t)\f$ -
 * параметр фазовой неоднозначности, \f$2\pi\cdot W_{m,n}(t)\f$ - угол доворота
 * фазы, \f$\rho_{m,n}(t, t_t)\f$ - геометрическая дальность между ФЦ НКА в
 * момент \f$t_t\f$ отправки сигнала и ФЦ БИС в момент \f$ t \f$ приёма сигнала.
 * Величины \f$\rho_{m,n}(t,t_t)\f$ и \f$t_t\f$ вычисляются рекуррентно по
 * формулам:
 *
   \f[t_t^{(0)} = t;\qquad t_t^{(k+1)} = \rho^{(k)}_{m,n}(t)/c\f]
   \f[\rho^{(k)}_{m,n}(t) = \|X_m(t)-Y_n(t-t_t^{(k)})\|, \f]
 *
 * где \f$X_m(t)\f$ и \f$Y_n(t-t_n^{(k)})\f$--- координаты БИС и НКА в
 * декартовой системе координат в моменты времени \f$t\f$ и \f$t-t_t^{(k)}\f$
 * во внутренней шкале времени.
 *
 * Хотя нужно вычислять координаты НКА в момент отправки сигнала (а для его
 * вычисления нужно сразу учитывать все задержки сигнала), мы вместо момента
 * отправки сигнала используем момент времени \f$t-\rho^{(k)}_{m,n}(t)/c\f$.
 * Оценим ошибку, возникшую в результате такого огрубления. Пусть, не учитывая
 * атмосферной задержки, на \f$N\f$-й итерации мы нашли время передачи сигнала
 * с точностью до \f$0.1km / 299792.458 km/sec \approx 3.3356 × 10-7 sec\f$.
 * Скорость НКА GPS и ГЛОНАСС примерна равна \f$4 km/sec\f$; проекция этой
 * скорости на прямую, соединяющую БИС и НКА, не превышает \f$0.9 km/sec\f$ при
 * условии видимости НКА. В свою очередь, скорость БИС вследствие вращения Земли
 * не превышает \f$0.5 km/sec\f$. Таким образом, скорость изменения
 * псевдодальности не может быть больше \f$1.5 km/sec\f$. При ошибке вычисления
 * момента передачи сигнала в \f$3.3356 \times 10^{-7} sec\f$ мы получаем,
 * следовательно, ошибку вычисления расстояния не более
 * \f$ 1.5 km/sec \cdot 3.3356 \times 10^{-7} sec \leq 0.5 mm\f$.
 */
class ObservablesNormalEquation : public NormalEquation
{
public:
	struct timeIndependentInfo
	{
		//Информация о типе измерительных данных
		int freqn;
		int obsmt;

		//Информауия о приёмнике
		int observation_source_id;
		int marker_id;
		int reciever_id;
		int antenna_id;


		//Информация об НКА
		int sat_history_id;
		int satellite_id;
		int glonass_slot;
		int glonass_letter;
		char navsys;

		int rec_phase_centre_model_id;
		int sv_phase_centre_model_id;
		real rec_timescale_epoch;

		//Длина волны
		real wavelength;

		bool usedcb;

		//Максимальный зенитный угол
		real maxzenith;
	};

private:

//	//Необходимые для псевдодальностей таблицы
	ImitationDatabase imitdb;

	timeIndependentInfo info1;

public:
	//Информация, необходимая для вычисления псевдодальностей, зависящая от
	//уточняемых параметров
	struct timeDependentInfo
	{
		//! Уход часов БИС, сек.
		real timeShiftStation;

		//! Момент времени измерения в шкале TAI
		real tai;

		/** Смещение опорной точки антенны относительно маркера (см.
		   @ref MarkerEccentricity
		   */
		pair < int, kinematic < real, 3, otherCoordSys> > eccentricity;

		//! Смешение фазового центра НКА в бортовой системе координат
		kinematic < real, 3, otherCoordSys > satPhaseCentreOffset;

		//! Смещение фазового центра БИС в локальной системе координат
		kinematic < real, 3, otherCoordSys > stationPhaseCentreOffset;

		//! Момент излучения сигнала с НКА
		real transmitTime;

		//! Положение маркера
		kinematic < real, 3, defaultNonInert > markerpos;

		//! Положение ФЦ БИС в неинерциальной системе координат
		kinematic < real, 3, defaultNonInert > recieverphasecentre;

		//! Положение ФЦ БИС в инерциальной системе координат
		kinematic < real, 3, defaultInert > recposinert;

		//! Оси бортовой системе координат НКА
		kinematic < real, 3, defaultInert > axis[3];

		//! Угол рыскания НКА, радианы
		real yaw;

		//! Положение и скорость центра масс НКА
		kinematic < real, 6, defaultInert > posvel;

		//! Положение ФЦ НКА в инерциальной системе координат
		kinematic < real, 3, defaultInert > satposinert;

//		//! Положение ФЦ НКА в неинерциальной системе координат
//		kinematic < real, 3, defaultNonInert > satposnoninert;

		//! Уход часов НКА, сек.
		real timeShiftSatellite;

		//! Значение межлитерной задержки для ГЛОНАСС, км.
		real dcb;

		//! Оси системы координат БИС в неинерциальной системе координат
		kinematic < real, 3, defaultNonInert > north, east, up;

		//! Зенит и азимут НКА относительно БИС, радианы
		pair < real, real > zenith_azimuth;

		//! Поправка тропосферы, км.
		real tropodelay;

		//! Значение параметра фазовой неоднозначности, км.
		real phase_ambiguity;

		//! Значение поправки докрутки фазы, радианы
		real phase_windup;

		//! Значение релятивистской поправки часов НКА, км.
		real relcorrection;

		//! Геометрическая дальность, км.
		real geomdist;
	};

private:

	timeDependentInfo info0;

protected:

	/**
	 * @brief Вычтсляет псевдодальность, а заодно и всю промежуточную информацию
	 * @param info Информация, зависящая от уточняемых параметров
	 * @return
	 */
	virtual real functional(
				timeDependentInfo & info
			) const;

public:
	ObservablesNormalEquation(ObservablesLeastSquaresProblem * problem,
								  const string & name,
								  int targetColumnNumber,
								  const Tuple & target_key);
	virtual real functional() const;
	virtual void calcDerivatives(const string &param_name,
									DBTable &result) const;
	virtual real func0();
	inline int getFrequency()
	{
		return info1.freqn;
	}

	inline const timeDependentInfo & getTimeDependentInfo() const
	{
		return info0;
	}

	inline const timeIndependentInfo & getTimeIndependentInfo() const
	{
		return info1;
	}

	virtual real getRMS() const;

	inline const ImitationDatabase & getImitationDatabase() const
	{
		return imitdb;
	}
};

/**
 * @brief Задача приближения измерительных данных
 *
 * @ingroup leastsq
 */
class ObservablesLeastSquaresProblem : public LeastSquaresProblem
{
	Q_OBJECT
	friend class ObservablesNormalEquation;
public:
	struct ObsLeastSquaresProblemSettings
	{
		bool loaded;
		real rms_p;
		real rms_l;
		bool rms_zenith;
	};

private:
	ObsLeastSquaresProblemSettings obslssettings;
	bool usedcb;

	//! Максимально допустимый зенитный угол, радианы
	real maxzenith;

public:
	inline const ObsLeastSquaresProblemSettings & getSettings()
	{
		if (obslssettings.loaded == false)
		{
			checkImitDB();
			obslssettings.rms_p = imitdb.settings->getSettings(
						"Least_Squares", "Pseudorange", "rms_p").toDouble();
			obslssettings.rms_l = imitdb.settings->getSettings(
						"Least_Squares", "Pseudorange", "rms_l").toDouble();
			obslssettings.rms_zenith = (imitdb.settings->getSettings(
				"Least_Squares","Pseudorange","RMSAccountZenith").toString()
										== "Yes");
		}
		return obslssettings;
	}

	inline bool useDcb() const
	{
		return usedcb;
	}

	//! Максимально допустимый зенитный угол, радианы
	inline real mazZenith() const
	{
		return maxzenith;
	}

	/**
	 * @brief Установить максимально допустимый зенитный угол
	 * @param z Зенитный угол, радианы
	 */
	inline void setMaxZenith(real z)
	{
		if (z<Pi/20)
			maxzenith = Pi/2;
		else if (z>Pi)
			maxzenith = Pi;
		else
			maxzenith = z;

	}

protected:
	virtual NormalEquation * createNormalEquation(const Tuple & target_key);
	virtual real getPrecision(const string & paramname, const Tuple & key);
	void checkImitDB();

private:

	/**
	 * Отображение номера БИС, номера НКА в поправку за счет докрутки фазы,
	 * выраженную в радианах.
	 */
	map < int, map < int, real > > curwindupcorrection;

	ImitationDatabase imitdb;

public:
	ObservablesLeastSquaresProblem ( DBTableCollection * base);

	virtual void linearize (RowWiseSparseMatrix <real> & lhs,
							vector<real> & rhs, vector<Tuple> *rowidx,
							const Tuple &from = Tuple(),
							const Tuple &until=Tuple());

	inline const ImitationDatabase & getImitDB() const
	{
		return imitdb;
	}

	virtual DBTable * imitate(bool replace = false);
};

/**
 * @brief Релятивистская поправка к уходу часов НКА
 *
 * @ingroup leastsq
 * @ingroup observables
 *
 * @param satposvel Координаты и скорость НКА
 * @param stapos Координаты БИС в инерциальной системе координат
 * @return Поправка к уходу часов от релятивистских эффектов
 */
real relativisticTimeDelay (
		const kinematic < real, 6, defaultInert > & satposvel,
		const kinematic < real, 3, defaultInert > & stapos
		);

/**
 * @brief Вычисляет текущий угол доворота фазы без учета необходимой склейки
 *
 * @ingroup leastsq
 *
 * @param sataxisX Ось X НКА
 * @param sataxisY Ось Y НКА
 * @param stanorth Направление от БИС на север
 * @param staeast Направление от БИС на восток
 * @param direct Направление БИС-НКА
 * @return Угол доворота фазы
 *
 * Эффект доворота фазы заключается в набегании дополнительных циклов фазовых
 * измерений при осевом вращении одной антенны относительно другой за счет
 * поляризации навигационного сигнала.
 *
 * Для вычисления изменения размера этого эффекта на последовательные по времени
 * фазовые измерения необходимо вычислить изменение угла между дипольными
 * моментами антенн БИС и НКА. Поскольку речь идёт об изменении угла, то в
 * неважно, чему он равен в момент захвата сигнала от НКА. Кроме того,
 * необходимо обеспечить непрерывность этого угла.
 *
 * Формулы для вычисления угла доворота фазы выведены в работе
 * Wu, S., Hajj, G., Bertiguer, W. and Lichten, S., 1993. Effects of Antenna
 * Orientation on GPS Carrier Phase Measurements. Manuscripta Geodaetica. 18,
 * pp. 91-98.
 *
 * Пусть \f$ \vec{i} \f$, \f$ \vec{j} \f$, \f$ \vec{k} \f$ - единичные вектора
 * системы координат, связанной с НКА, \f$ \vec{n} \f$, \f$ \vec{e} \f$ -
 * направления на север и восток от БИС, \f$ \vec{r} \f$ --- вектор БИС-НКА.
 * Тогда угол доворота фазы вычисляется по формуле:
 *
 * \f[ \delta \phi=sign(\zeta)\cdot \arccos \left( \frac{\vec{D}^{\prime}\cdot
   \vec{D}}{\|\vec{D}^{\prime}\|\cdot\|\vec{D}\|}\right), \f]
 * где
 * \f[ \zeta=\vec{r}\cdot \left(\vec{D}^{\prime}\times\vec{D}\right), \f]
 * \f[
	 \vec{D}\,=\vec{e}-\vec{r}(\vec{r}\cdot\vec{e})+\vec{r}\times\vec{n},\qquad
	 \vec{D}^\prime=\vec{i}+\vec{r}(\vec{r}\cdot\vec{i})-\vec{r}\times\vec{j}.
 * \f]
 */
real curWindupAngle (
		const kinematic < real, 3, defaultInert > & sataxisX,
		const kinematic < real, 3, defaultInert > & sataxisY,
		const kinematic < real, 3, defaultInert > & stanorth,
		const kinematic < real, 3, defaultInert > & staeast,
		const kinematic < real, 3, defaultInert > & direct
		);

}

#endif

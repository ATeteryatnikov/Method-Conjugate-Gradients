#include <vector>
#include <algorithm>

using namespace std;

//! @file

#include <RadPressure.h>
#include <RadPressureBerne.h>
#include <NumericAcceleration.h>
#include <ParamTrajectory.h>
#include <DBInterpolate.h>
#include <StdTables.h>
#include <derivate.hpp>
#include <basis.h>
#include <Acceleration.h>
#include <BuiltIn.h>
#include <GravityPotential.h>

namespace libgnss
{

Settings::Enumerator dtsize ("Least_Squares", "Numeric_Acceleration", "dtsize",
	Variant::TYPE_INT,"Число точек, по которым дифференцируется траектория",
				 16);

Settings::Enumerator dorder ("Least_Squares", "Numeric_Acceleration", "dorder",
	Variant::TYPE_INT,"Порядок аппроксимирующего траекторию многочлена",
				 15);


ConvolutionAcceleration::ConvolutionAcceleration(DBTableCollection * base,
const OperatorPushableVector < real > & coefficients, int targetelem)
: DBTable (
((ParamTrajectory*)(base->getTable("trajectory")))->getKeyColumns(),
	Columns()<<Column(Variant::TYPE_DOUBLE, "accel"))
{
	Frames*framest = (Frames*)(base->getTable("coordinate_frames"));
	vector < int > coords = framest->getFrameCoordinates(
								framest->getCoordinateFrameID("GCRS"));

	base->addTable("convolution_acceleration", this);
	ParamTrajectory * traj = (ParamTrajectory *)
			(base->getTable("trajectory"));

	Tuple key0;
	key0.resize(2);
	//Пройти по всем КА и по всем типам координат
	for (DBTable::DBConstIterator it0 = traj->const_begin();
		 it0!=traj->const_end(); it0.inc(1))
	{
		key0[0] = it0.keyColumnValue(0);
		key0[1] = it0.keyColumnValue(1);
		Tuple key1 = key0;
		key1<<(real)0.0;
		int coordid = key0[1].toInt();

		//Если тип координаты - не координата положения, то пропустить её.
		if ((coords[0]!=coordid)&&(coords[1]!=coordid)&&(coords[2]!=coordid))
			continue;

		//Итераторы, которые будут ползти по траектории
		vector <DBTable::DBConstIterator*> iterators;
		iterators.resize(coefficients.size());

		//COefficients COunt
		int coco =coefficients.size();

		iterators[0] = new DBTable::DBConstIterator(it0);

		//Инициализировать итераторы
		for (unsigned int i=1; i<coco; i++)
		{
			iterators[i] = new DBTable::DBConstIterator(*(iterators[i-1]));
			iterators[i]->subinc(2,1);
		}

		while (true)
		{
			//Момент времени, на который рассчитывается ускорение
			real targetTime =
						iterators[targetelem]->keyColumnValue(2).toDouble();

			//Найти шаг шаблона
			real delta = iterators[1]->keyColumnValue(2).toDouble()-
					iterators[0]->keyColumnValue(2).toDouble();

			//Проверить, что коэффициенты отстоят друг от друга на равный
			//промежуток времени
			bool correctTempl = true;
			for (unsigned int i=1; i<coco; i++)
			{
				real delta1 = iterators[i]->keyColumnValue(2).toDouble()-
						iterators[i-1]->keyColumnValue(2).toDouble();
				if (fabs(delta-delta1)>targetTime*1.e-15)
					correctTempl = false;
			}
			if (correctTempl == false)
				continue;

			//Вычислить ускорение с помощью свёртки
			real accel = 0.0;
			for (unsigned int i=0; i<coco; i++)
			{
				real coordval = iterators[i]->operator[](0.0).toDouble();
				accel+=coefficients[i]*coordval;
			}
			accel/=(delta*delta);
			key1[2] = Variant(targetTime);

			//Записать вычисленное ускорение
			insertRow(key1,Tuple()<<accel);

			//Перейти к следующему шаблону
			for (unsigned int i=0; i<coco; i++)
				iterators[i]->subinc(2,1);

			//Если упёрлись в конец последовательности данных, перейти к
			//следующим КА/координате.
			if (*(iterators[coco-1])==traj->const_end())
				break;

		}

		//Удалить итераторы
		for (unsigned int i = 0; i<coefficients.size(); i++)
			delete iterators[i];
	}
}

NumericAcceleration::NumericAcceleration(DBTableCollection *base,
										 int coord_frame_id,
										 real templateCentering)
	: DBTable (((ParamTrajectory*)(base->getTable("trajectory")))
	->getKeyColumns(), Columns()<<Column(Variant::TYPE_DOUBLE, "accel"))
{
	if (templateCentering > 0.5)
		templateCentering = 0.4;
	Frames*framest = (Frames*)(base->getTable("coordinate_frames"));
	if (coord_frame_id==-1)
		coord_frame_id = framest->getCoordinateFrameID("GCRS");
	vector < int > coords = framest->getFrameCoordinates(coord_frame_id);

	base->addTable("numeric_acceleration", this);
	ParamTrajectory * traj = (ParamTrajectory *)
			(base->getTable("trajectory"));
	Settings * sets = (Settings *)(base->getTable("settings"));

	int dtemplsize = sets->getSettings(dtsize).toInt();
	int dpolorder = sets->getSettings(dorder).toInt();

	Tuple key0;
	key0.resize(2);
	//Пройти по всем КА и по всем типам координат
	for (DBTable::DBConstIterator it0 = traj->const_begin();
	     it0!=traj->const_end(); it0.inc(1))
	{
		key0[0] = it0.keyColumnValue(0);
		key0[1] = it0.keyColumnValue(1);
		Tuple key1 = key0;
		key1<<(real)0.0;
		int coordid = key0[1].toInt();

		//Если тип координаты - не координата положения, то пропустить её.
		if ((coords[0]!=coordid)&&(coords[1]!=coordid)&&(coords[2]!=coordid))
			continue;

		//Пройти по всем моментам времени для данного КА и для данной
		//координаты
		for (DBTable::DBConstIterator it1 = it0; it1!=traj->const_end();
		     it1.subinc(2,1))
		{
			//Эпоха, для которой вычисляется производная
			real epoch = it1.keyColumnValue(2).toDouble();
			vector < double > epochs;
			epochs.reserve(dtemplsize);
			vector < double > values;
			values.reserve(dtemplsize);

			getNeighbourhood<double>(epochs,values,*traj,
									 traj->getDiscontinuitiesTable(),
									 key0,epoch,0,dtemplsize,
									 traj->getExtrapolationLimit(key0),
									 traj->getMaxVerticesStep(key0)
									 );

			//Проверить, что текущая точка находится на краю шаблона
			real minpnt = *(min_element(epochs.begin(), epochs.end()));
			real maxpnt = *(max_element(epochs.begin(), epochs.end()));
			real minacc = (1.0l-templateCentering) * minpnt
					+ templateCentering * maxpnt;
			real maxacc = templateCentering * minpnt
					+ (1.0l-templateCentering) * maxpnt;
			if ((epoch<minacc)||(epoch>maxacc))
				continue;

			//Вычислить производную
			DifferentiableFit < PowerOfX >
				fit (epochs,values,powerBasis(dpolorder));
			real accel = fit.derivative(2,epoch);

			//Записать производную в данную таблицу
			key1[2] = epoch;
			insertRow(key1,Tuple()<<accel);
		}
	}
}

NoCoordinateException::NoCoordinateException(int coord_id)
: FunctionalNotApplicableException("Номер "+Variant(coord_id).toString()+
	       " не является номером "
	       "декартовой координаты КА, и по этой координате не может быть "
	       "вычислено ускорение.")
{

}

NumericalAccelerationEquation::NumericalAccelerationEquation(
	LeastSquaresProblem * problem, const string & name, int targetColumnNumber,
								  const Tuple & target_key)
	: NormalEquation(problem, name, targetColumnNumber, target_key)
{
	//1) Определить шаблон дифференцирования
	stddt.second.clear();
	stddt.first = 1e-10l;
	stddt.second[1e-3] = 1e+3;
	stddt.second[0] = -1e+3;

	//2) Найти текущую модель радиационного давления
	this->curRPModel = ParameterRadiationPressure::getRPStorageName(*getBase());
	//Вдруг таблица РД не понадобится?
	rptable = 0;

	//3) Текущая компонента ускорения
	accel_component = -1;
	int coord_id = target_key[1].toInt();
	Frames*frm=(Frames*)(getBase()->getTable("coordinate_frames"));
	vector < int > fullcoordset = frm->getFullCoordinateSet(coord_id);
	for (unsigned int i=0; i<3; i++)
		if (fullcoordset[i] == coord_id)
			accel_component = i;

	//4) Текущее положение НКА
	sat_history_id = target_key[0].toInt();
	curtai = target_key[2].toDouble();
	traj = (ParamTrajectory*)(getBase()->getTable("trajectory"));
	this->satpos0 = traj->getPositionVelocity(sat_history_id, curtai);
	penumbra = shadowFactor(curtai,satpos0.subset<0,2>());

	//5) Ускорение НКА
	tbl = getBase();
	gp = (GravityPotential*)(tbl->getTable("gravity_potential"));
	erp = (ERPStorage *)(tbl->getTable("ERP"));
	rp = (ParameterRadiationPressure*)
		(tbl->getTable(ParameterRadiationPressure::getRPStorageName(*tbl)));
	kinematic < real, 3, defaultInert > accel = acceleration(
				gp,erp,rp,sat_history_id,satpos0, curtai);
	this->f0 = (accel_component!=-1)?(accel[accel_component]):0.0l;
}


real NumericalAccelerationEquation::functional() const
{
	return acceleration(gp,erp,rp,sat_history_id, traj->getPositionVelocity(
							sat_history_id,curtai), curtai)[accel_component];
}

real NumericalAccelerationEquation::calcSingleDerivative (
		const string & param_name, DBMap::DBIterator &it0) const
{
	//Производная по параметру модели РД
	if (param_name == curRPModel)
	{
		//Проверить соответствие номеров НКА
		int rp_sat_history_id = it0.keyColumnValue(0).toInt();
		if (rp_sat_history_id!=sat_history_id)
			return 0;

		if (rptable == 0)
			((NumericalAccelerationEquation*)(this))->rptable =
				getBase()->getTable(curRPModel);

		Variant v0 = (*it0)[0];
		it0.updateCell(0, v0.toDouble() + 1e-13);
		//(*it0)[0] = Variant(v0.toDouble() + 1e-13);
		kinematic < real, 3, defaultInert > acc =
				((ParameterRadiationPressure*) rptable)->calcAcceleration(
					sat_history_id,satpos0,curtai,penumbra);
		it0.updateCell(0,v0);
		real newval = acc[accel_component];
		acc = ((ParameterRadiationPressure*) rptable)->calcAcceleration(
					sat_history_id,satpos0,curtai,penumbra);
		real oldval = acc[accel_component];
		return (newval-oldval)*1e+13;
	}

	//В противном случае, вычислять производную как придётся.
	return NormalEquation::calcSingleDerivative(param_name, it0);
}

NormalEquation * NumericAccelerationFit::createNormalEquation(
		const Tuple & target_key)
{
	int coord_id = target_key[1].toInt();
	if ((coord_id!=gcrscoords[0])
		&&(coord_id!=gcrscoords[1])
		&&(coord_id!=gcrscoords[2]))
		return 0;
	return new NumericalAccelerationEquation(this, getTargetTableName(),
											 getTargetColumnNumber(),
											 target_key);
}


real NumericAccelerationFit::getPrecision(
		const string & paramname, const Tuple & key)
{
	if (paramname==ParameterRadiationPressure::getRPStorageName(*getBase()))
		return 1e-18;

}


NumericAccelerationFit::NumericAccelerationFit (
		DBTableCollection * base, const string & table, int valueColumnIndex )
	: LeastSquaresProblem(base, table, valueColumnIndex)
{
	Frames*frames=(Frames*)(getBase()->getTable("coordinate_frames"));
	int frame_id = frames->getCoordinateFrameID("GCRS");
	vector < int > framecrd = frames->getFrameCoordinates(frame_id);
	this->gcrscoords.push_back(framecrd[0]);
	this->gcrscoords.push_back(framecrd[1]);
	this->gcrscoords.push_back(framecrd[2]);
}

#ifdef WithQT
QScriptValue createNumAccel(QScriptContext * ctx, QScriptEngine * eng)
{
	DBTableCollection*col=(DBTableCollection*)(ctx->argument(0).toQObject());
	NumericAcceleration * accel = new NumericAcceleration (col);
	return eng->newQObject(accel,QScriptEngine::ScriptOwnership);
}

QScriptValue createConvAccel(QScriptContext * ctx, QScriptEngine * eng)
{
	DBTableCollection*col=(DBTableCollection*)(ctx->argument(0).toQObject());
	QVariantList vl = ctx->argument(1).toVariant().toList();
	OperatorPushableVector<real> mp;
	for (int i=0; i<vl.count(); i++)
		mp.push_back(real(vl.at(i).toDouble()));
	int tagelem = ctx->argument(2).toInt32();
	ConvolutionAcceleration*accel=new ConvolutionAcceleration(col,mp,tagelem);
	return eng->newQObject(accel,QScriptEngine::ScriptOwnership);
}

QScriptValue createAccelFit (QScriptContext * ctx, QScriptEngine * eng)
{
	DBTableCollection*col=(DBTableCollection*)(ctx->argument(0).toQObject());
	std::string tablename = ctx->argument(1).toString().toStdString();
	int colIdx = ctx->argument(2).toInt32();
	NumericAccelerationFit*fit=new NumericAccelerationFit(col,tablename,colIdx);
	return eng->newQObject(fit,QScriptEngine::ScriptOwnership);
}

BuiltIn cnacc ("createNumericalAcceleration",1,createNumAccel);
BuiltIn ccacc ("createConvolutionAcceleration",3,createConvAccel);
BuiltIn caccf ("createAccelerationFit",3,createAccelFit);
#endif
}

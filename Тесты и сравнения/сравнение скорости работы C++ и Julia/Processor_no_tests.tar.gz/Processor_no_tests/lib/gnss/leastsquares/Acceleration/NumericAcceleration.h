#ifndef NUMERICACCELERATION_H_
#define NUMERICACCELERATION_H_

//! @file

#include <gnssconfig.h>

#ifdef WithQT
#include <QObject>
#endif

#include <Frames.h>
#include <DBTable.h>
#include <LeastSquares.h>
#include <ParamTrajectory.h>


namespace libgnss
{

/** @brief Исключение при запросе несуществующей координаты ускорения
 *
 * @ingroup except
  *
  * Ускорение состоит из трех компонент - вторые производные по X, Y, Z.
  * Если метод NumericAccelerationFit::functional() вызван для несуществующего
  * типа координат, возникает исключение.
  */
class NoCoordinateException : public FunctionalNotApplicableException
{
public:
	NoCoordinateException (int coord_id);
};

/** @brief Класс численно вычисленного ускорения КА
  *
  * @ingroup except
  *
  * Данный класс создаётся на основе таблицы траекторий КА и вычисляет
  * с помощью двойного дифференцирования ускорения КА в каждый момент времени.
  */
class NumericAcceleration : public DBTable
{
public:
	NumericAcceleration(DBTableCollection * base, int coord_frame_id=-1,
						real templateCentering=0.4l);
};

/** @brief Класс численного вычисления ускорения КА с помощью заданной свёртки
 *
 * @ingroup leastsq
 *
 * Данный класс создаётся на основе таблицы траекторий КА и вычисляет с помощью
 * свёртки с заданными коэффициентами ускорение КА в каждый момент времени.
 *
 * Свёртка задаётся набором коэффициентов \f$\alpha_{-n},\ldots,\alpha_{m}\f$,
 * с помощью которых ускорение вычисляется по набору вершин, отстоящих друг от
 * друга на равный интервал \f$\Delta t\f$ по формуле:
 *\f[ a_i = \frac{1}{\Delta t^2} \sum_{j=-n}^{m} \alpha_j x_j.\f]
 */
class ConvolutionAcceleration : public DBTable
{
public:

	/**
	 * @brief Конструктор, вычисляющий ускорения с помощью свёртки
	 *
	 * В параметрах передаётся указатель на коллекцию таблиц и параметры
	 * свёртки.
	 *
	 * Свёртка передаётся в конструктор в виде вектора коэффициентов и числа
	 * \f$n\f$.
	 *
	 * @param base Коллекция таблиц
	 * @param coefficients Коэффициенты свёртки
	 * @param targetelem
	 */
	ConvolutionAcceleration(DBTableCollection * base,
	const OperatorPushableVector < real > & coefficients, int targetelem);
};

class ParameterRadiationPressure;
class GravityPotential;

/**
 * @brief Уравнение для ускорения НКА, вычисленного численно
 *
 * @ingroup leastsq
 */
class NumericalAccelerationEquation : public NormalEquation
{

private:
	//Модель РД
	string curRPModel;
	//Коордиаты и скорость НКА
	kinematic < real, 6, defaultInert > satpos0;
	//Идентификатор НКА
	int sat_history_id;
	//Текущий момент времени, TAI
	real curtai;
	//Номер компоненты в ускорении
	int accel_component;
	//Таблица траекторий
	ParamTrajectory * traj;
	//Коэффициент освещения (0 = полная тень, 1 = полное освещение)
	real penumbra;
	//Таблица коэффициентов РД
	DBTable * rptable;
	DBTableCollection * tbl;
	GravityPotential * gp;
	ERPStorage * erp;
	ParameterRadiationPressure * rp;

public:
	NumericalAccelerationEquation(LeastSquaresProblem *problem,
								  const string & name,
								  int targetColumnNumber,
								  const Tuple & target_key);
	virtual real functional() const;
	virtual real calcSingleDerivative (const string & param_name,
							DBMap::DBIterator &param_it) const;
};


/** @brief Класс задачи подгонки ускорения КА
 *
 * @ingroup leastsq
  *
  * Обозначим через \f$\vec{x}_m\f$, \f$\vec{v}_m\f$, \f$\vec{a}_m\f$
  * координаты, скорость и ускорение НКА в фиксированный момент времени
  * \f$ t_m\f$. Обозначим через \f$\vec{g}(\vec{x}_m, t_m)\f$ гравитационное
  * ускорение НКА в момент времени времени \f$t_m\f$, через
  * \f$\vec{r}(\vec{x}_m, \vec{v}_m, t_m, p_{0..k})\f$ - ускорение НКА от
  * радиационного давление, зависящие от координат, скорости, момента времени
  * и от набора прочих параметров \f$p_0\ldots p_k\f$.
  *
  * Через \f$\beta_i\f$ и \f$\gamma_i\f$ обозначим наборы коэффициентов свёрток:
  * \f[
	\vec{v}_m \approx \sum\limits_{i=-l}^l \beta_l x_{m+l},\qquad
	\vec{a}_m \approx \sum\limits_{i=-n}^n \gamma_n x_{m+n}.
	\f]
  *
  * В данной задаче МНК минимизируется невязка в системе уравнений:
  *\f[
  \sum\limits_{i=-n}^n \gamma_i \vec{x}_{i+m} = \vec{g}(\vec{x}_m, t_m)+
  \vec{r}(\vec{x}_m, \sum\limits_{i=-l}^l \beta\vec{x}_{i+m}, p_{0..k}).
  \f]
  *
  *Данный класс реализует задачу подгонки параметров модели движения КА
  * для соответствия моделируемых ускорений и ускорений, вычисленных каким-либо
  * другим путём (прежде всего, численно, с помощью класса
  * @ref NumericAcceleration .
  */
class NumericAccelerationFit : public LeastSquaresProblem
{
private:
	vector < int > gcrscoords;
protected:
	virtual NormalEquation * createNormalEquation(const Tuple & target_key);
	virtual real getPrecision(const string & paramname, const Tuple & key);
public:
	NumericAccelerationFit ( DBTableCollection * base, const string & table,
			    int valueColumnIndex );

};

}

#endif

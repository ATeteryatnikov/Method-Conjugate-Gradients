#ifndef SQLLOADER_H_
#define SQLLOADER_H_

#include <vector>
#include <string>

using namespace std;

class DBTableCollection;

/** @brief Класс для обмена данными между коллекцией таблиц и базой данных SQL
  *
  * Основными функциями данного класса являются загрузка данных с помощью
  * SQL-запросов (метод loadFromSQL() ) и выполнение произвольных запросов
  * с использованием данных (метод executeSQL() ).
  */
class SQLDatabase
{
public:
	/** @brief Загрузка данных в коллекцию с помощью SQL-запросов
	  *
	  * @param s Набор SQL-запросов
	  * @param е Коллекция, в которую будут скопированы данные
	  *
	  * Набор SQL-запросов представляет собой массив пар (имя таблицы,
	  * sql-код запроса). Результат каждого запроса будет сохранён в
	  * таблицу из коллекции с соответствующим именем. Для сопоставления
	  * колонок таблицы и результата запроса будут использованы имена
	  * колонок.
	  */
	virtual void loadFromSQL ( const vector < pair < string, string > > & s,
			   DBTableCollection & t ) = 0;

	/** @brief Выполнение произвольных запросов с данными из коллекции
	  *
	  * @param s Набор SQL-запросов
	  * @param t Коллекция, из которой будут взяты данные
	  *
	  */
	virtual void executeSQL ( const vector < pair < string, string > > & s,
			  DBTableCollection & t ) = 0;
};

#endif

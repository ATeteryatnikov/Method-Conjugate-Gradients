#ifndef PARAMTRAJECTORY_H
#define PARAMTRAJECTORY_H

//! @file

#include <map>
#include <set>
#include <InterpolatedParameterStorage.h>
#include <Kinematic.h>
#include <Frames.h>

namespace libgnss
{

class FrameHasNoVelocity : public StrException
{
public:
	FrameHasNoVelocity(const string & frame);
};

class FrameHasNoAcceleration : public StrException
{
public:
	FrameHasNoAcceleration(const string& frame);
};

/** @brief Класс, хранящий траекторию НКА
 *  
 * @bug Сделать первое поле sat_history_id !!!!
 *
 * Ключ:
 * @li int sat_history_id (соответствует ключу в @ref SatelliteHistory )
 * @li int coordinate_type_id (соответствует ключу в @ref CoordinateTypes)
 * @li double Time - эпоха, секунды TAI в J2000
 * 
 * Единственное поле значений - значение координаты, тип и единица измерения
 * которых определяется полностью системой координат через coordinate_type_id.
 */
class ParamTrajectory : public InterpolatedParameterStorage
{
	friend void satelliteOrientation (int sat_history_id, real tai,
								kinematic<real, 6, defaultInert> posvel,
								const ParamTrajectory & traj,
								kinematic < real, 3, defaultInert > * axis,
								real & yaw);
	friend void calcOrientation (DBTableCollection &tables, bool except);

	Q_OBJECT
private:

	real ecldist;
	real regulardensity;
	real singulardensity;
	map<int, map<real, real> > eclipsing;
	void mkeclipsinginfo(int sat_history_id);
	Frames * framest;
	CoordinateTypes * coordtypes;
	/** @brief Наборы данных для каждого КА
	  *
	  * Помимо координат и скорости, для КА можно задавать и другие
	  * наборы данных, например, уход часов, сужение различных векторных
	  * полей на траекторию, и т.д.
	  *
	  * Например, для того, чтобы добавить к траектории цвет в каждой
	  * точке необходимо:
	  *
	  * @li Добавить фиктивную систему координат "Цвет" в таблицу
	  * coordinate_frame
	  * @li Добавить координаты R, G, B в таблицу coordinate_types со
	  * ссылкой на фиктивную систему координат.
	  *
	  * Добавлять к таблице траектории строки, в которых номера координат
	  * будут совпадать с номерами координат R, G, B. В значениях этих
	  * координат указать соответствующие компоненты цвета.
	  *
	  * Данное поле при инициализации траектории для каждого КА запоминает
	  * координаты в каких системах координат для него даны. При этом,
	  * допускается только одна настоящая система координат, все остальные
	  * системы координат должны иметь тип Frames::FT_Fake.
	  *
	  * Отображение имеет следующую семантику:
	  *
	  * <Идентификатор КА> -> Пара (<Настоящая система координат>,
	  * <Множество (<Фиктивные системы координат>)>).
	  *
	  */
	map < unsigned int, pair< unsigned int, set < unsigned int > > > frames;

	/** @brief Флаг наличия скорости для КА
	  *
	  * Отображение: <Идентификатор КА> -> <флаг наличия скорости>
	  */
	map < unsigned int, bool > hasVelocity;
	
	/** @brief Флаг наличия ускорения для КА
	 * 
	 * Отображение <Идентификатор КА> -> <флаг наличия ускорения>
	 */
	map < unsigned int, bool > hasAcceleration;

	//! Метод, который создаёт список наборов данных для каждого КА
	void collectFrames();
protected:
	virtual int getVStepDiv(const Tuple & subkey);
public:
	/**
	  * В дополнение к функции вставки строки в таблицу, данный перегруженный
	  * метод контролирует, чтобы для каждого НКА использовалась только одна
	  * система координат.
	 */
	virtual void insertRow(const Tuple &keyValue, const Tuple &values);

	ParamTrajectory ( DBTableCollection * base );

	/**
	 * @brief Возвращает положение НКА в заданный момент времени
	 * @param sat_history_id Идентификатор НКА (ключ в @ref SatelliteHistory)
	 * @param t Момент вреемни, число секунд TAI от J2000
	 * @return Положение НКА в инерциальной системе координат
	 */
	virtual kinematic < real, 3, defaultInert > getPosition
						(unsigned short int sat_history_id,
						 real t) const;

	/**
	 * @brief Возвращает положение и скорость НКА в заданный момент времени
	 * @param sat_history_id Идентификатор НКА (ключ в @ref SatelliteHistory)
	 * @param t Момент вреемни, число секунд TAI от J2000
	 * @return Положение и скорость НКА в инерциальной системе координат
	 */
	virtual kinematic < real, 6, defaultInert > getPositionVelocity
						(unsigned short int sat_history_id,
						 real t) const;

	/**
	 * @brief Возвращает положение, скорость и ускорение НКА
	 * @param sat_history_id Идентификатор НКА (ключ в @ref SatelliteHistory)
	 * @param t Момент вреемни, число секунд TAI от J2000
	 * @return Положение, скорость и ускорение НКА
	 */
	virtual kinematic < real, 9, defaultInert > getPositionVelocityAcceleration
						(int sat_history_id,
						 real t) const;
	
						 
	//! Начальный момент времени
	virtual real getBeginTime(unsigned short int sat_history_id) const;

	//! Конечный момент времени
	virtual real getEndTime(unsigned short int sat_history_id) const;

	/**
	  * В отличие от базовой реализации, повышение плотности узлов интерполяции
	  * траектории необходимо, когда НКА входит в тень, либо происходят любые
	  * другие особенности.
	  *
	  *
	  *
	 */
	virtual double getDensity ( const Tuple & k, real t );

	//! Минимальный момент времени для всех НКА
	virtual real getBeginTime() const;

	//! Максимальный момент времени для всех НКА
	virtual real getEndTime() const;

	//! При изменении положения НКА необходимо пересчитать информацию о тенях
	virtual void updateCell(const Tuple &keyValue, int colnumber,
							const Variant &value);


#ifdef WithQT
public slots:
	
	double getSatBeginTime ( int sat_history_id ) const;
	
	double getSatEndTime (int sat_history_id ) const;
	
	//! Вычислить координаты КА
	QVariantList getSatellitePosition ( int sat_history_id, double t );
	
	//! Вычислить координаты и скорость КА
	QVariantList getSatellitePositionVelocity ( int sat_history_id,
												double t );
#endif

	//! @brief Перевести все траектории в инерциальную систему
	void toInertial();

	//! @brief Вычислить скорости, если их нет
	void calcVelocity();

	//! @brief Удаление всех скоростей
	void dropVelocities();

	/**
	 * @brief Возвращает идентификатор системы координат траектории НКА
	 * @param sat_history_id Идентификатор НКА (ключ в @ref SatelliteHistory)
	 * @return Идентификатор системы координат (ключ в @ref Frames)
	 */
	inline unsigned int getCoordinateFrameID(int sat_history_id)
	{
		return frames[sat_history_id].first;
	}
};

}

#endif

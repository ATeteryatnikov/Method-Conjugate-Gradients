#include <algorithm>
#include <ParamTrajectory.h>
#include <DBInterpolate.h>
#include <limits>
#include <StdTables.h>
#include <basis.h>
#include <RadPressure.h>
//#include <iostream>
//! @file

#include <derivate.hpp>
#include <StdTables.h>
#include <BuiltIn.h>
#include <ERPStorage.h>

using namespace std;

namespace libgnss
{


Settings::Enumerator shadowcheck("Parameters_settings", "trajectory",
								 "SingNeighb", Variant::TYPE_DOUBLE,
	"На каком расстоянии до особенной точки траектории измельчать шаг (сек)",
								 (real)30);

Settings::Enumerator regdens("Parameters_settings", "trajectory",
							 "RegularDens", Variant::TYPE_DOUBLE,
				"Шаг узлов интерполяции траектории на регулярных участках",
							 (real)(300));

Settings::Enumerator sindens("Parameters_settings", "trajectory",
							 "SingularDens", Variant::TYPE_DOUBLE,
				"Шаг узлов интерполяции траектории на участках с особенностями",
							 (real)(5));

Settings::Enumerator trajintord("Parameters_settings", "trajectory",
							"InterpOrd", Variant::TYPE_INT,
						"Число узлов интерполяции траектории",10);

Settings::Enumerator trajextrlim("Parameters_settings", "trajectory",
						"extrlim",Variant::TYPE_DOUBLE,
					"Максимально допустимый выход целевой точки за пределы "
					"множества узлов интерполяции, сек.",(real)(60l));

Settings::Enumerator trajmaxstep("Parameters_settings", "trajectory",
				"maxstep",Variant::TYPE_DOUBLE,
				"Максимально допустимый шаг между узлами интерполяции, сек.",
				(real)3600l);

ParamTrajectory::ParamTrajectory(DBTableCollection *base)
	: InterpolatedParameterStorage (base, "trajectory",
				Columns()
				<<Column(Variant::TYPE_INT, "sat_history_id")
				<<Column(Variant::TYPE_INT, "coordinate_type")
				<<Column(Variant::TYPE_DOUBLE, "Time")
				)
{
	Settings * sets = (Settings *)(base->getTable("settings"));
	setInterpolateOrder(Tuple(),sets->getSettings(trajintord).toInt());
	setExtrapolationLimit(Tuple(),sets->getSettings(trajextrlim).toInt());
	setMaxVerticesStep(Tuple(), sets->getSettings(trajmaxstep).toInt());
	framest = 0;
	ecldist = numeric_limits<real>::quiet_NaN();
	regulardensity = numeric_limits<real>::quiet_NaN();
	singulardensity = numeric_limits<real>::quiet_NaN();
}

void ParamTrajectory::collectFrames()
{
	if (!frames.empty())
		return;

	frames.clear();
	hasVelocity.clear();
	hasAcceleration.clear();

	if (framest == 0)
	{
		framest=(Frames*)(base->getTable("coordinate_frames"));
		coordtypes = (CoordinateTypes *)
			(base->getTable("coordinate_types"));
	}


	for (DBConstIterator it = const_begin(); it!=const_end(); it.inc(0))
	{
		frames[it.keyColumnValue(0).toInt()].first = 0xffffffff;
		hasVelocity[it.keyColumnValue(0).toInt()] = false;
		hasAcceleration[it.keyColumnValue(0).toInt()] = false;
	}

	//Пройти по всем КА и по всем типам координат
	for (DBConstIterator it = const_begin(); it!=const_end(); it.inc(1))
	{
		unsigned short int sat_history_id = it.keyColumnValue(0).toInt();
		unsigned int coord_id = it.keyColumnValue(1).toInt();
		unsigned int frame_id=coordtypes->getCoordinateFrame(coord_id);
		vector < int > all_coords = framest->
				getFrameCoordinates(frame_id);
		if (std::find <vector < int > :: const_iterator, int>
				( all_coords.begin(),all_coords.end(),coord_id)-
				all_coords.begin() >= 3)
			hasVelocity[sat_history_id] = true;
		if (std::find <vector < int > :: const_iterator, int>
				( all_coords.begin(),all_coords.end(),coord_id)-
				all_coords.begin() >= 6)
			hasAcceleration[sat_history_id] = true;
		Frames::FrameType ft = framest->getFrameType(frame_id);
		if (ft == Frames::FT_Fake)
			frames[sat_history_id].second.insert(frame_id);
		else
		{
			if ((frames[sat_history_id].first != 0xffffffff) &&
				(frames[sat_history_id].first!=frame_id))
				throw StrException("ParamTrajectory::collectFrames",
								   "Допускается указывать "
					"координаты КА только в одной системе "
						"координат.");
			frames[sat_history_id].first = frame_id;
		}
	}
}

real ParamTrajectory::getBeginTime(unsigned short int sat_history_id)
const
{
	DBConstIterator c = find(Tuple()<<(int)sat_history_id);
	return c.keyColumnValue(2).toDouble();
}

real ParamTrajectory::getEndTime(unsigned short int sat_history_id) const
{
	DBConstIterator c = const_begin();
	int coord_type = c.keyColumnValue(1).toInt();
	DBConstIterator c1 = lower_bound(Tuple()<<sat_history_id<<coord_type
					 <<numeric_limits<real>::infinity());
	return c1.keyColumnValue(2).toDouble();
}

real ParamTrajectory::getBeginTime() const
{
	real result = 1e+50;
	for (DBTable::DBConstIterator it = const_begin();
		 it!=const_end(); it.inc(0))
	{
		real tm = getBeginTime(it.keyColumnValue(0).toInt());
		if (tm<result)
			result = tm;
	}
	return result;
}

real ParamTrajectory::getEndTime() const
{
	real result = -1e+50;
	for (DBTable::DBConstIterator it = const_begin();
		 it!=const_end(); it.inc(0))
	{
		real tm = getEndTime(it.keyColumnValue(0).toInt());
		if (tm>result)
			result = tm;
	}
	return result;
}

int ParamTrajectory::getVStepDiv(const Tuple &subkey)
{
	if (isnan(ecldist) || isnan(regulardensity) || isnan(singulardensity))
	{
		Settings*sets = (Settings*)(base->getTable("settings"));
		ecldist = sets->getSettings(shadowcheck).toDouble();
		regulardensity = sets->getSettings(regdens).toDouble();
		singulardensity = sets->getSettings(sindens).toDouble();
	}
	return (int)(regulardensity/singulardensity);
}

kinematic < real, 3, defaultInert > ParamTrajectory::getPosition
					(unsigned short int sat_history_id,
					 real t) const
{
	map<unsigned int,pair<unsigned int, set<unsigned int > > >::const_iterator
			itfr = frames.find(sat_history_id);
	if (itfr == frames.end())
	{
		((ParamTrajectory*)(this))->collectFrames();
		itfr = frames.find(sat_history_id);
	}
	if (itfr == frames.end())
		throw StrException("ParamTrajectory::getPosition",
						   "Координаты КА №"+Variant(sat_history_id).toString()+
				   " не загружены.");
	if (itfr->second.first == 0xffffffff)
		throw StrException("ParamTrajectory::getPosition",
				"Координаты КА №"+Variant(sat_history_id).toString()+
				   " не загружены.");

	int coord_frame_id = itfr->second.first;

	vector < int > coords = framest->getFrameCoordinates(coord_frame_id);
	unsigned int reqcoordcount = 3;
	if (framest->getFrameType(coord_frame_id) == Frames::FT_Elements)
		reqcoordcount = 6;

	vector < real > pos  (reqcoordcount);

	Tuple key0;
	key0<<(int)sat_history_id<<coords[0];
	for (unsigned int i=0; i<reqcoordcount; i++)
	{
		key0[1] = coords[i];
		pos[i] = getParameterValue(key0, t);
	}

	return framest->posInert(pos, coord_frame_id, t);
}

FrameHasNoAcceleration::FrameHasNoAcceleration(const string& frame)
	: StrException("FrameHasNoAcceleration",
				   "Для системы координат не определены компоненты ускорения: "
		+ frame )
{

}

FrameHasNoVelocity::FrameHasNoVelocity(const string& frame): 
	StrException("FrameHasNoVelocity",
		"Для системы координат не определены компоненты скорости: "
	+ frame)
{

}

kinematic < real,6,defaultInert > ParamTrajectory::getPositionVelocity
					(unsigned short int sat_history_id,
					 real t) const
{
	map<unsigned int,pair<unsigned int, set<unsigned int > > >::const_iterator
			itfr = frames.find(sat_history_id);
	if (itfr == frames.end())
	{
		((ParamTrajectory*)(this))->collectFrames();
		itfr = frames.find(sat_history_id);
	}
	if (itfr == frames.end())
		throw StrException("ParamTrajectory::getPositionVelocity",
				"Координаты КА №"+Variant(sat_history_id).toString()+
				   " не загружены.");
	if (itfr->second.first == 0xffffffff)
		throw StrException("ParamTrajectory::getPositionVelocity",
						   "Координаты КА №"+Variant(sat_history_id).toString()+
				   " не загружены.");

	int coord_frame_id = itfr->second.first;

	vector <int> coords = (framest->getFrameCoordinates(coord_frame_id));
	
	if (coords.size() < 6)
		throw FrameHasNoVelocity
			((*framest)[Tuple()<<coord_frame_id][1].toString());

	vector < real > pos;
	pos.resize(6);

	//Сначала взять координаты (они точно должны быть)
	for (unsigned int i=0; i<3; i++)
	{
		pos[i]=getParameterValue(Tuple()<<(int)(sat_history_id)<<coords[i],
					   t);
	}

	if (hasVelocity.at(sat_history_id) == false)
	{
		kinematic < real,3,defaultInert > nanvec(
						numeric_limits<real>::quiet_NaN());
		return framest->posInert(pos,coord_frame_id,t).concat(nanvec);
	}
	else
	{
		//Затем попытаться взять скорости
		try
		{
			for (unsigned int i=3; i<6; i++)
			{
				pos[i] = getParameterValue(Tuple()<<
						(int)(sat_history_id)<<coords[i], t);
			}

		}
		catch (KeyNotFoundException e)
		{
			kinematic < real,3,defaultInert > nanvec(
							numeric_limits<real>::quiet_NaN());
			return framest->posInert(pos,coord_frame_id,t).concat(nanvec);
		}
	}
	return framest->posVelInert(pos, coord_frame_id, t);
}

kinematic < real, 9, defaultInert > 
ParamTrajectory::getPositionVelocityAcceleration (int sat_history_id,
						 real t) const
{
	map<unsigned int,pair<unsigned int, set<unsigned int > > >::const_iterator
			itfr = frames.find(sat_history_id);
	if (itfr == frames.end())
	{
		((ParamTrajectory*)(this))->collectFrames();
		itfr = frames.find(sat_history_id);
	}
	if (itfr == frames.end())
		throw StrException("ParamTrajectory::getPositionVelocityAcceleration",
						   "Координаты КА №"+Variant(sat_history_id).toString()+
				   " не загружены.");
	if (itfr->second.first == 0xffffffff)
		throw StrException("ParamTrajectory::getPositionVelocityAcceleration",
						   "Координаты КА №"+Variant(sat_history_id).toString()+
				   " не загружены.");

	int coord_frame_id = itfr->second.first;

	vector <int> coords = (framest->getFrameCoordinates(coord_frame_id));
	
	//Проверить, что для системы координат есть понятие ускорения
	// (т.е. соответствующие типы координат загружены в coordinate_types.
	if (coords.size()<9)
		throw FrameHasNoAcceleration(
			(*framest)[Tuple()<<coord_frame_id][1].toString());

	vector < real > pos;
	pos.resize(9);

	//Сначала взять координаты (они точно должны быть)
	for (unsigned int i=0; i<3; i++)
	{
		pos[i]=getParameterValue(Tuple()<<(int)(sat_history_id)<<coords[i],
					   t);
	}

	if (hasVelocity.at(sat_history_id) == false)
	{
		kinematic < real,6,defaultInert > nanvec(
						numeric_limits<real>::quiet_NaN());
		return framest->posInert(pos,coord_frame_id,t).concat(nanvec);
	}
	else
	{
		//Затем попытаться взять скорости
		try
		{
			for (unsigned int i=3; i<6; i++)
			{
				pos[i] = getParameterValue(Tuple()<<
						(int)(sat_history_id)<<coords[i], t);
			}

		}
		catch (const KeyNotFoundException & e)
		{
			kinematic < real,6,defaultInert > nanvec(
							numeric_limits<real>::quiet_NaN());
			framest->posInert(pos,coord_frame_id,t).concat(nanvec);
		}
		catch (const ParameterApproximationException & e)
		{
			kinematic < real,6,defaultInert > nanvec(
							numeric_limits<real>::quiet_NaN());
			framest->posInert(pos,coord_frame_id,t).concat(nanvec);
		}

		//Затем попытаться взять ускорения
		try
		{
			for (unsigned int i=6; i<9; i++)
			{
				pos[i] = getParameterValue(Tuple()<<
						(int)(sat_history_id)<<coords[i], t);
			}

		}
		catch (const KeyNotFoundException & e)
		{
			kinematic < real,3,defaultInert > nanvec(
							numeric_limits<real>::quiet_NaN());
			return framest->posVelInert(pos,coord_frame_id,t).concat(nanvec);
		}
		catch (const ParameterApproximationException &e)
		{
			kinematic < real,3,defaultInert > nanvec(
							numeric_limits<real>::quiet_NaN());
			return framest->posVelInert(pos,coord_frame_id,t).concat(nanvec);
		}
		
	}
	return framest->posVelAccelInert(pos, coord_frame_id, t);
}

void ParamTrajectory::toInertial()
{
	collectFrames();
	vector < int > coordtypes = framest->getFrameCoordinates(
				framest->getCoordinateFrameID("GCRS"));
	ERPStorage * erp = (ERPStorage *)(base->getTable("ERP"));

	//Пройти по всем КА
	for (DBTable::DBConstIterator it0=begin(); it0!=const_end(); it0.inc(0))
	{
		//Взять номер КА
		unsigned short int sat_id = it0.keyColumnValue(0).toInt();

		//Проверить, что траектория данного КА уже не в GCRS
		int frame_id = frames[sat_id].first;
		if ((*framest)[Tuple()<<frame_id][0].toInt()==Frames::FT_ECIF)
			continue;

		vector < int > oldcoordtypes = framest->getFullCoordinateSet(
					it0.keyColumnValue(1).toInt());


		//Для моментов времени используется тип Variant, чтобы
		//исключить какие-либо преобразования.
		vector < Variant > epochs;
		for (DBTable::DBConstIterator it1=find(Tuple()<<sat_id);
		     it1!=const_end(); it1.subinc(2,1))
		{
			erp->calcERPMatrix(it1.keyColumnValue(2).toDouble());
			epochs.push_back(it1.keyColumnValue(2));
		}

		//Теперь вычислить координаты КА в эти моменты времени
		vector < kinematic < real, 9, defaultInert > > vec;
		vec.resize(epochs.size());

		for (unsigned int i=0; i<epochs.size(); i++)
		{
			if (oldcoordtypes.size() == 3)
				vec[i] = getPosition(sat_id, epochs[i].toDouble()).concat<6>
								(kinematic<real,6,defaultInert> 
									(numeric_limits<real>::quiet_NaN()));
			if (oldcoordtypes.size() == 6)
				vec[i] = getPositionVelocity(sat_id, epochs[i].toDouble())
					.concat<3>(kinematic<real,3,defaultInert> 
									(numeric_limits<real>::quiet_NaN()));;
			if (oldcoordtypes.size() == 9)
				vec[i] = getPositionVelocityAcceleration(sat_id,
														  epochs[i].toDouble());
		}

		//Удалить координаты данного КА
		for (unsigned int i=0; i<oldcoordtypes.size(); i++)
			deleteRows(Tuple()<<sat_id<<oldcoordtypes[i]);

		frames.erase(sat_id);
		hasAcceleration.erase(sat_id);
		hasVelocity.erase(sat_id);

		//Вставить полученные координаты в таблицу
		for (unsigned int j=0; j<epochs.size(); j++)
		{
			for (unsigned int i=0; i<coordtypes.size(); i++)
				if (!isnan(vec[j][i]))
					insertRow(Tuple()<<sat_id<<
						  coordtypes[i]<<epochs[j],
						  Tuple()<<vec[j][i]);
		}

		//Перенести разрывы из исходной системы координат в инерциальную
		for (unsigned int j=0;j<min(oldcoordtypes.size(),coordtypes.size());++j)
		{
			//Список разрывов в данной координате
			set<real> this_disc;
			for (DBConstIterator it=getDiscontinuitiesTable()->find(
				Tuple()<<sat_id<<oldcoordtypes[j]);!(it.isEnd());it.subinc(2,1))
				this_disc.insert(it.keyColumnValue(2).toDouble());

			//Перенести эти разрывы для нового идентификатора координаты
			deleteDiscontinuity(Tuple()<<sat_id<<oldcoordtypes[j]);
			for (set<real>::iterator it = this_disc.begin();
				 it!=this_disc.end(); ++it)
				addDiscontinuity(Tuple()<<sat_id<<coordtypes[j]<<*it);
		}


		//Обновить итератор по КА
		it0 = find(Tuple()<<sat_id);

	}

	framest = 0;
	frames.clear();
	((ParamTrajectory*)(this))->collectFrames();
}

Settings::Enumerator velocityApproxPoints ("Parameters_settings",
					   "trajectory",
					   "VelocityApproxPoints",
					   Variant::TYPE_INT,
					   "Число вершин для аппроксимации "
					   "скорости КА по его траектории",
					   11);

Settings::Enumerator velocityApproxOrder ("Parameters_settings",
					  "trajectory",
					  "VelocityApproxOrder",
					  Variant::TYPE_INT,
					  "Порядок аппроксимации траектории КА"
					  " для вычисления его скорости",
					  10);

void ParamTrajectory::calcVelocity()
{
	collectFrames();
	
	DBTable vel (keyColumns, valueColumns);

	//Пройти по всем КА
	for (DBTable::DBConstIterator it0=begin(); it0!=const_end(); it0.inc(0))
	{
		//Взять номер КА
		unsigned short int sat_id = it0.keyColumnValue(0).toInt();

		//Если скорость уже есть
		if (hasVelocity.at(sat_id))
			continue;

		//Определить тип системы координат
		//Если траектория КА не в декартовой системе координат,
		//процедура вычисления скоростей неприменима
		int frame_id = frames[sat_id].first;
		int ft = (*framest)[Tuple()<<frame_id][0].toInt();
		if ((ft!=Frames::FT_ECIF)&&(ft!=Frames::FT_ITRS))
			continue;

		//Взять набор номеров координат
		vector < int > coordset = framest->getFullCoordinateSet(
					it0.keyColumnValue(1).toInt());

		//Пройти по всем трём координатам
		for (unsigned int i=0; i<3; i++)
		{
			int coord_id = coordset[i];
			Tuple pkey;
			pkey<<sat_id<<coord_id;
			//Пройти по всем моментам времени
			for (DBTable::DBConstIterator it1=find(pkey);
				 !(it1.isEnd()); it1.subinc(2,1))
			{
				real t = it1.keyColumnValue(2).toDouble();
				real v;
				try
				{
					v = getParameterValueAndDerivs(pkey,t,1)[1];
				}
				catch (const ParameterApproximationException & apprerr)
				{
					continue;
				}

				vel.insertRow(Tuple()<<sat_id<<coordset[i+3]<<t,Tuple()<<v);
			}
			//Вставить все разрывы
			for (DBConstIterator it = getDiscontinuitiesTable()->find(
					 Tuple()<<sat_id<<coordset[i]); it.isEnd() == false;
						it.subinc(2,1))
			{
				Variant disc_t = it.keyColumnValue(2);
				addDiscontinuity(Tuple()<<sat_id<<coordset[i+3]<<disc_t);
			}
		}
	}

	copyFrom(vel.begin(), vel.end());

	framest = 0;
	frames.clear();
	((ParamTrajectory*)(this))->collectFrames();
}

void ParamTrajectory::dropVelocities()
{
	for (DBTable::DBConstIterator it = const_begin();
		 it.isEnd() == false; it.inc(0))
	{
		int sat_history_id = it.keyColumnValue(0).toInt();
		map<unsigned int,pair<unsigned int, set<unsigned int > > >::const_iterator
				itfr = frames.find(sat_history_id);
		if (itfr == frames.end())
		{
			((ParamTrajectory*)(this))->collectFrames();
			itfr = frames.find(sat_history_id);
		}
		if (itfr == frames.end())
			continue;
		if (itfr->second.first == 0xffffffff)
			continue;
		int coord_frame_id = itfr->second.first;
		vector < int > coords = framest->getFrameCoordinates(coord_frame_id);

		for (int i=3; i<6; ++i)
			if (i<coords.size())
				deleteRows(Tuple()<<sat_history_id<<coords[i]);

		it = find(sat_history_id);
		hasVelocity[sat_history_id]=false;
	}
}

void ParamTrajectory::insertRow(const Tuple &keyValue, const Tuple &values)
{
	//Обновить индекс систем координат, скоростей и ускорений
	int sat_his_id = keyValue[0].toInt();
	if (find(sat_his_id).isEnd())
	{
		hasVelocity.erase(sat_his_id);
		hasAcceleration.erase(sat_his_id);
		frames.erase(sat_his_id);
	}
	//Если скоростей не было, то пока считать, что их и не добавилось
	//(если добавляются скорости, то поправки вносятся ниже).
	if (hasVelocity.find(sat_his_id) == hasVelocity.end())
		hasVelocity[sat_his_id] = false;
	if (hasAcceleration.find(sat_his_id) == hasAcceleration.end())
		hasAcceleration[sat_his_id] = false;
	int coord_id = keyValue[1].toInt();
	if (framest == 0)
	{
		framest=(Frames*)(base->getTable("coordinate_frames"));
		coordtypes = (CoordinateTypes *)
			(base->getTable("coordinate_types"));
	}
	Tuple coorddetails = coordtypes->read(coord_id);
	int coord_num = coorddetails[1].toInt();
	int frame_id = coorddetails[0].toInt();
	Tuple framedetails = framest->read(frame_id);

	//Посмотреть, вносятся ли скорости или ускорения
	if (coord_num>=6)
		hasAcceleration[sat_his_id] = true;
	else
		if (coord_num >= 3)
			hasVelocity[sat_his_id] = true;
	if (framedetails[0].toInt() == Frames::FT_Fake)
	{
		if (frames.find(sat_his_id) == frames.end())
			frames[sat_his_id].first = 0xffffffff;
		frames[sat_his_id].second.insert(frame_id);
	}
	else
	{
		if (frames.find(sat_his_id) != frames.end())
		{
			if ((frames[sat_his_id].first!=frame_id)
					&&(frames[sat_his_id].first != 0xffffffff))
				throw StrException("ParamTrajectory::insertRow",
						"Допускается указывать "
					"координаты КА только в одной системе "
						"координат.");
		}
		else
			frames[sat_his_id].first = frame_id;
	}

	//Вставить сами данные
	ParameterStorage::insertRow(keyValue, values);
}

void ParamTrajectory::updateCell(const Tuple &keyValue, int colnumber,
						const Variant &value)
{
	int sat_history_id = keyValue[0].toInt();
	eclipsing.erase(sat_history_id);
	InterpolatedParameterStorage::updateCell(keyValue,colnumber,value);
}

void ParamTrajectory::mkeclipsinginfo(int sat_history_id)
{
	real T0 = getBeginTime(sat_history_id);
	real T1 = getEndTime(sat_history_id);
	//Сформировать информацию о заходе в тень
	for (real ts = T0; ts<T1 + ecldist; ts+=ecldist)
	{
		try
		{
			kinematic<real,3,defaultInert> pos =
					getPosition(sat_history_id,ts);
			eclipsing[sat_history_id][ts]=shadowFactor(ts, pos);
		}
		catch (ApproximationError & e)
		{
			if (ts > T1)
				break;
			else
				throw e;
		}
	}
}


double ParamTrajectory::getDensity ( const Tuple & k, real t )
{
	if (isnan(ecldist) || isnan(regulardensity) || isnan(singulardensity))
	{
		Settings*sets = (Settings*)(base->getTable("settings"));
		ecldist = sets->getSettings(shadowcheck).toDouble();
		regulardensity = sets->getSettings(regdens).toDouble();
		singulardensity = sets->getSettings(sindens).toDouble();
	}
	int sat_history_id = k[0].toInt();
	map<int,map<real,real> >::iterator it = eclipsing.find(sat_history_id);
	if (it == eclipsing.end())
	{
		mkeclipsinginfo(sat_history_id);
		it = eclipsing.find(sat_history_id);
	}
	if (it->second.size() < 2)
		StrException("ParamTrajectory::getDensity",
					"Не сформировано достаточно информации о входе НКА в тень");

	//Считается, что нужно понижать шаг, когда НКА входит в тень, или
	//выходит из неё, т.е. если в коэффициент освещённости слева и справа
	//отличаются
	bool ineclipse = false;
	map<real,real>::iterator itu = it->second.upper_bound(t);
	if (itu == it->second.end())
	{
		map<real,real>::reverse_iterator itf = it->second.rbegin();
		real ecl1 = itf->second;
		real ecl2;
		if (itf->first >= t)
			ecl2 = (++itf)->second;
		else
			ecl2 = shadowFactor(t, getPosition(sat_history_id,t));
		ineclipse = (ecl1!=ecl2);
	}
	else
	{
		real ecl1 = itu->second;
		real ecl2;
		if (itu == it->second.begin())
			ecl2 = shadowFactor(t, getPosition(sat_history_id,t));
		else
			ecl2 = (--itu)->second;
		ineclipse = (ecl1!=ecl2);
	}
	if (ineclipse == true)
		return 1.0l/singulardensity;
	else
		return 1.0l/regulardensity;

}

#ifdef WithQT
double ParamTrajectory:: getSatBeginTime (int sat_history_id ) const
{
	return getBeginTime(sat_history_id);
}
	
double ParamTrajectory::getSatEndTime (int sat_history_id ) const
{
	return getEndTime(sat_history_id);
}
	
	//! Вычислить координаты КА
QVariantList ParamTrajectory::getSatellitePosition (int sat_history_id,
													double t )
{
	kinematic < real, 3, defaultInert > pos = getPosition(sat_history_id, t);
	QVariantList vli;
	vli<<QVariant((double)pos[0])<<QVariant((double)pos[1])
									<<QVariant((double)pos[2]);
	return vli;
}
	
	//! Вычислить координаты и скорость КА
QVariantList ParamTrajectory::getSatellitePositionVelocity(int sat_history_id,
												double t )
{
	kinematic < real, 6, defaultInert > pos = getPositionVelocity(sat_history_id, t);
	QVariantList vli;
	vli<<QVariant((double)pos[0])<<QVariant((double)pos[1])
		<<QVariant((double)pos[2])<<QVariant((double)pos[3])
		<<QVariant((double)pos[4])<<QVariant((double)pos[5]);
	return vli;
}

QScriptValue addtrajectory(QScriptContext * ctx, QScriptEngine * eng)
{
	DBTableCollection * c = (DBTableCollection *)(ctx->argument(0).toQObject());
	ParamTrajectory * es = new ParamTrajectory (c);
	return QScriptValue();
}

BuiltIn addtrajectory_ ("addTrajectoryTable", 1, addtrajectory);
#endif

}

#include <vector>
#include <map>
#include <Types.h>

namespace libgnss
{

class DBTableCollection;
class ParamTrajectory;
class ClockBias;
class ITRFTranslation;
class ERPStorage;
class Frames;
class ParameterRadiationPressure;

/**
 * @brief Класс, принимающий оперативную информацию ГЛОНАСС
 *
 * Данный класс используется как абстрактный приёмник оперативной информации
 * ГЛОНАСС и GPS. Объект данного класса (или его наследника) передаётся функциям
 * чтения RINEX-файлов с навигационной информацией, C-кадров или любых
 * других источников.
 *
 * Стандартная функциональность заключается в размножении эфемерид и записи их
 * в таблицу траектории @ref ParamTrajectory. Кроме того, уход часов и скорость
 * ухода пишутся в таблицу ухода часов @ref ClockBias.
 *
 * При приёме оперативной информации на момент времени t происходит размножение
 * эфемерид и ухода часов на интервал [t; t+30минут].
 *
 * Функциональность может быть заменена путём перегрузки метода
 * loadGLONavData() и loadGPSNavData().
 *
 */
class NavDataLoader
{
public:
	/**
	 * @brief Алгоритмы размножения эфемерид ГЛОНАСС
	 *
	 * GLO_ICD: эфемериды размножаются согласно ИКД.
	 *
	 * GLO_Full: эфемериды размножаются с помощью интегрирования, как и в ИКД,
	 * но используется более полная модель правой части уравнения движения:
	 * модель ГПЗ EGM08, модель движения космических тел: JPL, коэффициенты РД
	 * берутся из таблицы, либо, если в таблице их нет, ускорение от РД
	 * направлено строго от Солнца и имеет величину 1e-10 км/с^2.
	 *
	 * GLO_Adams: использует интерполяционную формулу Адамса, которая принимает
	 * величину (координаты) и её производную (скорость) в нескольких
	 * (в нашем случае, в восьми) моментах времени и возвращает координаты в
	 * заданный момент времени.
	 */
	enum GLOExtrapolateMethod
	{
		GLO_ICD = 0,
		GLO_Full = 1,
		GLO_Adams = 2
	};
private:
	DBTableCollection * col;
	ParamTrajectory * traj;
	ClockBias * clk;
	GLOExtrapolateMethod meth;
	ITRFTranslation * itrft;
	Frames * frm;
	ERPStorage*erp;
	ParameterRadiationPressure * rp;
	real desiredStep;
	int pz90id;

	/**
	 * @brief Кинематические параметры НКА в предыдущие моменты времени
	 *
	 * Отображение: Идентификатор НКА ->Вектор пар (момент времени,
	 * набор кинематических параметров)
	 */
	std::map<int,std::vector<std::pair<real,real[9]> > > prev;

	//Максимальное количество точек, которые необходимо помнить
	int maxdatasize;

public:

	/**
	 * @brief Пустой конструктор
	 *
	 * Зануляет все указатели, делая использование объекта невозможным до
	 * указания коллекции таблиц.
	 */
	NavDataLoader();

	/**
	 * @brief Запоминает укзатель на коллекцию таблиц и находит нужные таблицы
	 * @param tc Указатель на коллекцию таблиц
	 */
	void setTableCollection(DBTableCollection * tc);

	inline DBTableCollection * getTableCollection()
	{
		return col;
	}
	\
	inline void setGLOExtrapolateMethod(GLOExtrapolateMethod method)
	{
		meth = method;
		if (meth == GLO_ICD)
			maxdatasize = 1;
		else
			maxdatasize = 8;
	}

	inline GLOExtrapolateMethod getGLOExtrapolateMethod()
	{
		return meth;
	}

	/**
	 * @brief Загрузка оперативной информации ГЛОНАСС
	 * @param sat_history_id Идентификатор НКА (@ref SatelliteHistory)
	 * @param toe Момент времени эфемерид, секунды от 12:00 01.01.2000 TAI
	 * @param kin Массив с координатами, скоростью и ускорением
	 * @param taun Уход часов
	 * @param gammak Относительный сдвиг частоты
	 * @param dL1_L2 Разность задержек в трактах на двух частотах
	 *
	 * Данный метод у базового класса выполняет действия:
	 *
	 * При переходе к новой эпохе размножает эфемериды НКА с заданным шагом.
	 * Полученные эфемериды передаются методу
	 * @ref acceptSatelliteKinematicData().
	 *
	 * Кроме того, методу @ref acceptClockBias() передаётся уход часов НКА,
	 * также размноженный по оперативной информации.
	 */
	virtual void loadGLONavData(int sat_history_id, real toe,real kin[9],
						real taun, real gammak, real dL1_L2);

	/**
	 * @brief Загрузка оперативной информации GPS
	 * @param sat_history_id Идентификатор НКА (@ref SatelliteHistory)
	 * @param toe Момент времени эфемерид, секунды от 12:00 01.01.2000 (TAI)
	 * @param toc Момент времени эфемерид, секунды от 12:00 01.01.2000 (TAI)
	 * @param m0 Mean Anomaly at Reference Time
	 * @param dn Mean Motion Difference From Computed Value
	 * @param e Eccentricity
	 * @param sqrta Square Root of the Semi-Major Axis
	 * @param omega0 Longitude of Ascending Node of Orbit Plane at Weekly Epoch
	 * @param i0 Inclination Angle at Reference Time
	 * @param omega Argument of Perigee
	 * @param omegadot Rate of Right Ascension
	 * @param idot Rate of Inclination Angle
	 * @param cuc Amplitude of the Cosine Correction Term to the Argument of
	 * Latitude
	 * @param cus Amplitude of the Sine Harmonic Correction Term to the Argument
	 * of Latitude
	 * @param cic Amplitude of the Cosine Harmonic Correction Term to the Orbit
	 * Radius
	 * @param cis Amplitude of the Sine Harmonic Correction Term to the Orbit
	 * Radius
	 * @param crc Amplitude of the Cosine Harmonic Correction Term to the Angle
	 * of Inclination
	 * @param crs Amplitude of the Sine Harmonic Correction Term to the Angle of
	 * Inclination
	 * @param af0 Значение ухода часов
	 * @param af1 Скорость ухода часов
	 * @param af2 Ускорение ухода часов
	 */
	virtual void loadGPSNavData(int sat_history_id, real toe, real toc,
		real m0, real dn, real e, real sqrta, real omega0, real i0,
		real omega, real omegadot, real idot, real cuc, real cus, real cic,
		real cis, real crc, real crs, real af0, real af1, real af2);


protected:

	/**
	 * @brief Принимает размноженные эфемериды НКА
	 * @param sat_history_id Идентификатор НКА
	 * @param posvelaccel Эфемериды НКА
	 *
	 * posvelaccel представляет собой вектор пар (момент времени,
	 * вектор кинематических параметров: [0,2]-координаты, [3,5]-скорость,
	 * [6-8]-ускорение). Если ускорения нет, передаются не больше шести
	 * параметров; если скорости нет, передаются не больше трех параметров.
	 */
	virtual void acceptSatelliteKinematicData( int sat_history_id,
				std::vector<std::pair<real,std::vector<real> > > & posvelaccel);

	/**
	 * @brief Принимает размноженный уход часов НКА
	 * @param sat_history_id Идентификатор НКА
	 * @param clkbias Размноженный уход часов
	 *
	 * clkbias представляет собой вектор пар (момент времени,
	 * вектор: уход часов, скорость ухода часов, ускорение ухода часов).
	 *
	 * Если ускорения нет, то передаётся уход часов и его скорость; если
	 * скорости нет, передаётся только уход часов.
	 */
	virtual void acceptClockBias(int sat_history_id,
				std::vector<std::pair<real,std::vector<real> > > & clkbias);
};

}

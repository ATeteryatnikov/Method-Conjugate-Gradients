#include <Types.h>
#include <NavDataLoader.h>
#include <ParameterStorage.h>
#include <StdTables.h>
#include <ParamTrajectory.h>
#include <TimeShift.h>
#include <ExtrapolateEphemeris.h>
#include <Integrate.h>
#include <RadPressure.h>
#include <integrate.hpp>
#include <ERPStorage.h>

namespace libgnss
{

NavDataLoader::NavDataLoader()
{
	col = 0;
	traj = 0;
	clk = 0;
	meth = GLO_ICD;
	desiredStep = 60.0l;
}

void NavDataLoader::setTableCollection(DBTableCollection *tc)
{
	col = tc;
	traj = (ParamTrajectory*)(tc->getTable("trajectory"));
	clk = (ClockBias*)(tc->getTable("time_shift"));
	itrft = (ITRFTranslation*)(tc->getTable("itrf_transformation"));
	frm = (Frames*)(tc->getTable("coordinate_frames"));
	erp = (ERPStorage*)(tc->getTable("ERP"));
	string rpname = ParameterRadiationPressure::getRPStorageName(*tc);
	rp = (ParameterRadiationPressure*)(tc->getTable(rpname));
	pz90id = frm->getCoordinateFrameID("ПЗ-90.02");
}

void NavDataLoader::loadGLONavData(int sat_history_id, real toe, real kin[9],
								   real taun, real gammak, real dL1_L2)
{
//	//--------  1) РАЗМНОЖИТЬ ЭФЕМЕРИДЫ ----------------------------------
//	std::vector<std::pair<real,real[9]> > & curdata=prev.at(sat_history_id);
//	int availabledata = curdata.size();
//	real prevtoe = curdata[availabledata-1].first;

//	//Если эти данные были ранее считаны, пропустить их
//	if (prevtoe == toe)
//		return;


//	//Признак того, что нужно размножать эфемериды на все предыдущие интервалы
//	bool allintervals = (availabledata < maxdatasize);


//	if (allintervals == false)
//	{
//		//Продвинуть окно
//		for (unsigned int i=0; i<availabledata-1; i++)
//			curdata[i] = curdata[i+1];
//		curdata[availabledata-1].first = toe;
//		memcpy(curdata[availabledata-1].second, kin, 9*sizeof(real));
//	}
//	else
//		//Если окно ещё не сформировано
//		curdata.push_back(pair<real,real[9]> (toe,kin) );

//	//Если предыдущих значений всё ещё недостаточно, дожидаться, когда будет
//	//достаточно.
//	if (curdata.size() < maxdatasize)
//		return;

//	int nsteps = 3600.0l/desiredStep;

//	//Координаты НКА в моменты времени t0, t0+D, ..., t0+nsteps*D = t0 + 3600.
//	vector<vector<real> > ephem;

//	if (meth==GLO_ICD)
//		ephem = extrapolateGLONASSEphemeris(
//					t0,t0+3600,nsteps,kin[0],kin[1],kin[2],kin[3],kin[4],
//				kin[5],kin[6],kin[7],kin[8]);
//	else if (meth==GLO_Full)
//	{
//		//Перевести в систему координат GCRS
//		vector<real> pvpz90(kin,kin+9);
//		kinematic<real,6,defaultInert> curpos = frm->posVelInert(pvpz90,
//																	pz90id,
//																	toe);
//		ForwardIntegrate fi(*col,sat_history_id);
//		kinematic<real,6,defaultInert> rhs = fi(toe,curpos);
//		ephem.push_back(vector<real>(kin,kin+9));
//		real curstep = 3600.0l/nsteps;
//		for (unsigned int i=0; i<nsteps; i++)
//		{
//			real curt = i*curstep+t0;
//			//Шаг интегрирования методом Рунге-Кутты
//			kinematic<real,6,defaultInert> nextpos;
//			kinematic<real,6,defaultInert> nextrhs;
//			Integrate::stepRungeKutta6(curt,curpos,rhs,fi,curstep,
//									   nextpos,nextrhs);
//			curpos = nextpos;
//			rhs = nextrhs;

//			//Перевести результат в ПЗ-90.02 и записать в массив
//			kinematic<real,6,defaultNonInert> curpos_ni =
//					erp->GCRStoITRF(curpos,curt);
//			curpos_ni = itrft->translateITRF(
//						curpos_ni,frm->defaultNonInertFrame(),
//						pz90id);
//			vector<real> curv;
//			for (unsigned int i=0 ; i<6; i++)
//				curv.push_back(curpos_ni[i]);
//			ephem.push_back(curv);
//		}
//	}
//	else if (meth==GLO_Adams)
//	{
//		//Длина интервала навигационной информации
//		real ephstep = curdata[1].first - curdata[0].first;

//	}


}

void NavDataLoader::loadGPSNavData(int sat_history_id, real toe, real toc,
								   real m0, real dn, real e, real sqrta,
								   real omega0, real i0, real omega,
								   real omegadot, real idot, real cuc, real cus,
								   real cic, real cis, real crc, real crs,
								   real af0, real af1, real af2)
{

}

void NavDataLoader::acceptSatelliteKinematicData(int sat_history_id,
				std::vector<std::pair<real, std::vector<real> > > &posvelaccel)
{

}

void NavDataLoader::acceptClockBias(int sat_history_id,
					std::vector<std::pair<real, std::vector<real> > > &clkbias)
{

}

//void extrapolateGLONASSEphemeris(DBTableCollection *collection, real step,
//								 GLOExtrapolateMethod method)
//{
//	ParamTrajectory*traj=(ParamTrajectory*)(collection->getTable("trajectory"));
//	SatelliteHistory*his=(SatelliteHistory*)
//			(collection->getTable("satellite_history"));
//	Frames*frm = (Frames*)(collection->getTable("coordinate_frames"));

//	for (DBTable::DBConstIterator it = traj->const_begin();
//		 !(it.isEnd()); it.inc(0))
//	{
//		//Пропускать все НКА, кроме ГЛОНАСС
//		int sat_history_id = it.keyColumnValue(0).toInt();
//		if (his->read(sat_history_id)[0].toChar() != 'R')
//			continue;

//		//Собрать все моменты времени
//		set<real> tmoments;
//		for (DBTable::DBConstIterator it2 = it; !(it2.isEnd()); it2.subinc(2,0))
//		{
//			int coord_id = it2.keyColumnValue(1).toInt();

//		}
//	}

//}
}

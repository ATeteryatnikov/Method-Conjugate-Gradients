#include <ExtrapolateEphemeris.h>
#include <DBError.h>
#include <integrate.hpp>
#include <StdTables.h>
#include <DBTableCollection.h>
#include <ephemeris.h>
#include <NewtonGravity.h>
#include <ERPStorage.h>
#include <Kinematic.h>
#include <Consts.h>
#include <RadPressureBerne.h>
#include <GravityPotential.h>
#include <LoadEGM08.h>
#include <Integrate.h>

namespace libgnss
{

class ExtrapolateForwardIntegrate : public ForwardIntegrate
{
public:

	ExtrapolateForwardIntegrate(
			GravityPotential * gp, ERPStorage * erp,
			ParameterRadiationPressure * rp,
			int sat_history_id, real regular_step, int maxDiv)
		: ForwardIntegrate(gp,erp,rp,sat_history_id,regular_step,maxDiv)
	{

	}

	virtual kinematic < real, 6, defaultInert > operator()
		(real t, const kinematic < real, 6, defaultInert > & x) const
	{
		ERPStorage * erp = getERPStorage();
		erp->calcERPMatrix(t);
		return ForwardIntegrate::operator ()(t,x);
	}

};

class ETblCollDeleter
{
public:

	~ETblCollDeleter()
	{
		DBTableCollection * c = getExtrapolateCollection();
		delete c->getTable("ERP");
		delete c->getTable("celestial_bodies");
		delete c->getTable("gravity_potential");
		delete c->getTable("solid_tides_semidiurnal");
		delete c->getTable("ocean_tides");
		delete c->getTable("ocean_pole_tides");
		delete c->getTable("solid_tides_longperiod");
		delete c->getTable("settings");
		delete c->getTable("rad_pressure_berne");
		delete c->getTable("solid_tides_diurnal");
		delete c;
	}
};

ETblCollDeleter etblcolldeleter;

DBTableCollection * getExtrapolateCollection()
{
	static DBTableCollection * dbcol = 0;
	if (dbcol==0)
	{
		dbcol = new DBTableCollection();
		new DiurnalSolidTides(dbcol);
		ERPStorage * erp = new ERPStorage(dbcol);
		ParameterRadPressureBerne * berne =
				new ParameterRadPressureBerne(dbcol);
		erp->ignoreERP();
		Settings * sets = new Settings(dbcol);
		new LongperiodSolidTides(dbcol);
		new OceanPoleTides(dbcol);
		new OceanTides(dbcol);
		new SemidiurnalSolidTides(dbcol);
		new GravityPotential(dbcol);
		CelestialBodies * cb = new CelestialBodies(dbcol);
		LoadEGM08(*dbcol, 5);
		cb->loadDefaultValues();
		berne->insertRow(Tuple()<<0<<0, Tuple()<<1e-10l);
		berne->resample(0,1);
		string settingsstr =
		"settings	Integration	Adams	Regular_step	300\n"
		"settings	Integration	Adams	Subdivide	6\n"
		"settings	Parameters_settings	Radiation_Pressure_Base	RP_Model	BERNE\n";
		istringstream setstr(settingsstr);
		ostringstream sout;
		dbcol->readFromStream(setstr, sout);
//		//Отключить приливы
//		sets->updateCell(
//					Tuple()
//					<<"Motion_model"
//					<<"Gravity_potential"
//					<<"useOceanPoleTides",0,"No");
//		sets->updateCell(
//					Tuple()
//					<<"Motion_model"
//					<<"Gravity_potential"
//					<<"useOceanTides",0,"No");
//		sets->updateCell(
//					Tuple()
//					<<"Motion_model"
//					<<"Gravity_potential"
//					<<"useSolTidesSD",0,"No");
//		sets->updateCell(
//					Tuple()
//					<<"Motion_model"
//					<<"Gravity_potential"
//					<<"useSolTidesD",0,"No");
//		sets->updateCell(
//					Tuple()
//					<<"Motion_model"
//					<<"Gravity_potential"
//					<<"useSolTidesLP",0,"No");

	}
	return dbcol;
}


std::vector < std::vector < real > > extrapolateGLONASSEphemeris(
		real t0, real t1, int numsteps, real x0, real y0, real z0,
		real vx0, real vy0, real vz0, real ax0, real ay0, real az0)
{
	const real omega = 0.7292115e-4;

	/**
	 * Переведём координаты в систему координат GCRS.
	 * Для нужной нам точности достаточно нулевых ПВЗ.
	 */

	kinematic<real,3,defaultNonInert> accel;
	accel[0] = ax0; accel[1] = ay0; accel[2] = az0;

	kinematic<real,3,defaultNonInert> vel;
	vel[0] = vx0; vel[1] = vy0; vel[2] = vz0;

	kinematic<real,3,defaultNonInert> pos;
	pos[0] = x0; pos[1] = y0; pos[2] = z0;

	vector<vector<real> > result(numsteps+1);
	double tf[3][3];
	double dtf[3][3];
	double ddtf[3][3];
	mkmatrix_cio(t0,0,0,0,0,0,0,0,0,tf,dtf,ddtf,2);
	kinematic<real,3,defaultInert> pos_inert = ITRFToGCRS(pos,tf);
	kinematic<real,3,defaultInert> vel_inert = ITRFToGCRS(vel,tf)+
			ITRFToGCRS(pos,dtf);

	DBTableCollection * tmp = getExtrapolateCollection();
	ParameterRadiationPressure * rp =
			(ParameterRadiationPressure*)
			(tmp->getTable(ParameterRadiationPressure::getRPStorageName(*tmp)));
	ERPStorage * erp = (ERPStorage*)(tmp->getTable("ERP"));
	GravityPotential * gp = (GravityPotential*)
			(tmp->getTable("gravity_potential"));


	ExtrapolateForwardIntegrate fi(gp,erp,rp, 0,300,5);


	kinematic<real,6,defaultInert> posvel = pos_inert.concat(vel_inert);
	kinematic<real,6,defaultInert> velaccel = fi(t0,posvel);
	real step = (t1-t0)/numsteps;

	for (unsigned int i=0; i<=numsteps; i++)
	{
		real t = t0 + i*step;
		if (t==t0)
		{
			result[i].push_back(x0);
			result[i].push_back(y0);
			result[i].push_back(z0);
			result[i].push_back(vx0);
			result[i].push_back(vy0);
			result[i].push_back(vz0);
			continue;
		}
		//Вычислить координаты, скорость и ускорение в следующий момент времени
		kinematic <real,6,defaultInert> nextposvel;
		kinematic <real,6,defaultInert> nextvelaccel;
		stepRungeKutta6
				(t,posvel,velaccel,fi,step,nextposvel,nextvelaccel);
		//Сохранить координаты
		posvel = nextposvel;
		velaccel = nextvelaccel;
		mkmatrix_cio(t,0,0,0,0,0,0,0,0,tf,dtf,0,1);
		kinematic<real,3,defaultNonInert> newpos =
				GCRSToITRF(posvel.subset<0,2>(),tf);
		kinematic<real,3,defaultNonInert> newvel =
				GCRSToITRF(posvel.subset<0,2>(),dtf)+
				GCRSToITRF(posvel.subset<3,5>(),tf);
		result[i].push_back(newpos[0]);
		result[i].push_back(newpos[1]);
		result[i].push_back(newpos[2]);
		result[i].push_back(newvel[0]);
		result[i].push_back(newvel[1]);
		result[i].push_back(newvel[2]);
	}
	return result;
}

std::vector < real > extrapolateGPSEphemeris(
		real deltat, real m0, real dn, real e, real sqrta, real omega0, real i0,
		real omega, real omegadot, real idot, real cuc, real cus, real cic,
		real cis, real crc, real crs )
{
	throw NotImplementedException("extrapolateGPSEphemeris");
}

}

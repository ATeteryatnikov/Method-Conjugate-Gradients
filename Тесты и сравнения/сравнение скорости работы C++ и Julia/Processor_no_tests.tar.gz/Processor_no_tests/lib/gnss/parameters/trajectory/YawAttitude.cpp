#include <YawAttitude.h>
#include <Frames.h>
#include <ephemeris.h>
#include <limits>
#include <cmath>
#include<iostream>
#include <BuiltIn.h>
#include <StdTables.h>

namespace libgnss
{

YawAttitudeRequiresVelocity::YawAttitudeRequiresVelocity(int sat_history_id)
	: StrException("YawAttitudeRequiresVelocity",
				   "Для НКА №" + Variant(sat_history_id).toString()+
				   " в таблице нет "
				   "скоростей, необходимых для вычисления ориентации.")
{

}

void nominalOrientation (const kinematic < real, 3, defaultInert > & pos,
						 const kinematic < real, 3, defaultInert > & sunpos,
						 kinematic < real, 3, defaultInert > * axis)
{
	//Ось Z
	axis[2] = real(-1)*(pos.normalize());

	//Ось Y
	axis[1] = (axis[2].crossProduct(sunpos-pos)).normalize();

	//Ось X
	axis[0] = axis[1].crossProduct(axis[2]);
}

void nominalOrientationDot (const kinematic < real, 6, defaultInert > & posvel,
							const kinematic < real, 3, defaultInert > & sunpos,
							kinematic < real, 3, defaultInert > * axisDot)
{
	kinematic < real, 3, defaultInert > axis[3];
	kinematic < real, 3, defaultInert > pos = posvel.subset<0,2>(),
			vel = posvel.subset<3,5>();
	nominalOrientation(pos,sunpos,&(axis[0]));
	real rm = pos.length<0,2>();
	real rmdot = pos*vel*(1/rm);
	real rmsq = rm*rm;
	axisDot[2] = ((real)(-1)/(rm*rmsq))*(vel*rmsq - rmdot*pos);
	kinematic < real, 3, defaultInert > sunsatn = (sunpos-pos).normalize();
	axisDot[1] = axisDot[2].crossProduct(sunsatn);
	axisDot[0] = axis[1].crossProduct(axisDot[2]) +
			axisDot[1].crossProduct(axis[2]);
}

CTypeSelect * OrientationModels()
{
	static CTypeSelect ormodels("sv_orientation_model",
								Tuple()<<"Nominal",0);
	return &ormodels;
}

Settings::Enumerator orientationmodel ("Other_models","SV_Orientation",
									   "Model", OrientationModels(),
									   "Модель ориентации НКА",
									   OrientationModels()->defaultValue()
									   );

Settings::Enumerator orientationregularstep ("Other_models","SV_Orientation",
									  "RegularStep", Variant::TYPE_DOUBLE,
			"Шаг интегрирования ориентации НКА на регулярных участках, сек.",
									  (real)(100));

Settings::Enumerator orientationsingularstep("Other_models","SV_Orientation",
									"SingularStep", Variant::TYPE_DOUBLE,
		"Шаг интегрирования ориентации НКА вблизи полудня и в тени, сек.",
										(real)10);

Settings::Enumerator orientationsingularangle("Other_models","SV_Orientation",
								   "SingularAngle", Variant::TYPE_DOUBLE,
		"Какой угол СОЗ считать приводящим к необходимости уменьшать шаг "
								   "интегрирования (рад.)", real(0.3));

void calcOrientation(DBTableCollection & tables, bool except)
{
	Settings * sets = (Settings *)(tables.getTable("settings"));
	ParamTrajectory * traj = (ParamTrajectory *)
			(tables.getTable("trajectory"));
	Frames * frames = (Frames*)(tables.getTable("coordinate_frames"));
	int frame_id = frames->getCoordinateFrameID("attitude");
	int yaw_coord_id = frames->getFrameCoordinates(frame_id)[0];
	real regularintegratestep =
			sets->getSettings(orientationregularstep).toDouble();
	real singularintegratestep =
			sets->getSettings(orientationsingularstep).toDouble();
	real singularangle =
			sets->getSettings(orientationsingularangle).toDouble();
	string orientation_model = sets->getSettings(orientationmodel).toString();

	if (orientation_model!= "Nominal")
		throw NotImplementedException("Модель ориентации "+orientation_model);

	// Пройти по всем НКА
	for (DBTable::DBConstIterator it0 = traj->const_begin();
		 it0!=traj->const_end(); it0.inc(0))
	{
		//Идентификатор НКА
		int sat_history_id = it0.keyColumnValue(0).toInt();
		if (traj->hasVelocity[sat_history_id] == false)
		{
			if (except == true)
				throw YawAttitudeRequiresVelocity(sat_history_id);
			else
				continue;
		}


		//Момент времени, с которого начинается траектория данного НКА
		real t0 = traj->getBeginTime(sat_history_id);
		//Момент времени, которым заканчивается траектория
		real t1 = traj->getEndTime(sat_history_id);
		//Найти начало траектории и выбрать начальный шаг
		kinematic<real,3,defaultInert> pos0 =
				traj->getPosition(sat_history_id,t0);
		real soeangle = angleSunEarthObject(pos0,t0);
		real step = regularintegratestep;
		if ((soeangle < singularangle) || (soeangle > 2*Pi - singularangle))
			step = singularintegratestep;
		real currentyaw = numeric_limits<real>::quiet_NaN();

		real t = t0;
		while (true)
		{
			//Угол между осью Y и скоростью.
			//Вычисление этого угла зависит от модели ориентации
			real angleYV;
			if (orientation_model == "Nominal")
			{
				kinematic < real, 6, defaultInert > posvel;
				//Номинальная модель
				bool haveposvel = true;
				try
				{
					posvel = traj->getPositionVelocity(sat_history_id,t);
				}
				catch (const ParameterApproximationException & e)
				{
					//Установить разрыв в непрерывной модели ориентации
					currentyaw = numeric_limits<real>::quiet_NaN();
					haveposvel = false;
				}
				if (haveposvel)
				{
					kinematic < real, 3, defaultInert > mposn =
									(real)(-1)*posvel.subset<0,2>().normalize();
					kinematic < real, 3, defaultInert > veln =posvel.subset<3,5>();
						veln = (veln - (veln*mposn) * mposn).normalize();
					kinematic < real, 3, defaultInert > binormal =
										mposn.crossProduct(veln);
					kinematic < real, 3, defaultInert > sun =
									getCelestialBodyEphemerides(11,t);
					kinematic < real, 3, defaultInert > axis[3];
					nominalOrientation(posvel.subset<0,2>(),sun,&(axis[0]));
					real COS = axis[1]*veln;
					real SIN = axis[1]*binormal;
					angleYV = atan2(SIN,COS);
					soeangle = angleSunEarthObject(posvel.subset<0,2>(),t);
					if ((soeangle < singularangle)||(soeangle > 2*Pi-singularangle))
						step = singularintegratestep;
					else
						step = regularintegratestep;
				}
//				cout<<t<<endl;//470018735
			}
			else
				throw NotImplementedException("Модель ориентации "
											  +orientation_model);

			//Определить текущий угол рыскания с учетом накопления
			if (isnan(currentyaw))
				currentyaw = angleYV;
			else
			{
				real r = round((currentyaw - angleYV)/(2*Pi));
				currentyaw = r*2*Pi + angleYV;
			}
			//Занести угол рыскания в таблицу
			try
			{
				traj->insertRow(Tuple()<<sat_history_id<<yaw_coord_id<<t,
								Tuple()<<currentyaw);
			}
			catch (const StrException & e)
			{
				if (except)
					throw e;
			}

			if (t==t1)
				break;
			else
			{
				if ((t + 1.25*step > t1) && (t + step<t1))
					t = (t+t1)/2.0l;
				else
					t+=step;

				if (t > t1)
					t = t1;
			}
		}
	}
}

void satelliteOrientation (int sat_history_id, real tai,
						   kinematic < real, 6, defaultInert > posvel,
							const ParamTrajectory & traj,
						   kinematic < real, 3, defaultInert > * axis,
						   real & yawangle)
{
	int yawcoordid = traj.framest->getFrameCoordinates(
				traj.framest->getCoordinateFrameID("attitude"))[0];
	axis[2] = (real)(-1)*posvel.subset<0,2>().normalize();
	kinematic < real, 3, defaultInert > veln =posvel.subset<3,5>();
	veln = (veln - (veln*axis[2]) * axis[2]).normalize();
	kinematic < real, 3, defaultInert > binormal =
						axis[2].crossProduct(veln);
	yawangle = traj.getParameterValue(Tuple()<<sat_history_id<<yawcoordid, tai);
	axis[1] = cos(yawangle)*veln.normalize() + sin(yawangle)*binormal;
	axis[0] = axis[1].crossProduct(axis[2]);
}

#ifdef WithQT
QScriptValue calcOrient(QScriptContext * ctx,
								   QScriptEngine * eng)
{
	try
	{
		DBTableCollection * tc = qobject_cast<DBTableCollection*>
				(ctx->argument(0).toQObject());
		calcOrientation(*tc);
		return QScriptValue();
	}
	catch(StrException & e)
	{
		returnError(eng, string("Не удалось вычислить ориентацию НКА: ")+
					e.what());
	}
}

BuiltIn calcorient("calculateSatelliteOrientation", 1, calcOrient);
#endif
}

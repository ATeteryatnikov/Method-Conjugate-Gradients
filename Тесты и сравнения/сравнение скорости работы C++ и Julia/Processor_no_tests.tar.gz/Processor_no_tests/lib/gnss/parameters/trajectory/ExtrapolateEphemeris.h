#ifndef EXTRAPOLATEEPHEMERIS_H
#define EXTRAPOLATEEPHEMERIS_H

#include <vector>
#include <Types.h>

namespace libgnss
{

class DBTableCollection;

/**
 * @brief Размножение оперативных эфемерид ГЛОНАСС согласно ИКД
 * @param t0 Момент времени, на который даны эфемериды
 * @param t1 Момент времени, до которого размножение эфемерид корректно
 * @param numsteps Число шагов интегрирования
 * @param x0 Координата X (ПЗ-90.02), км
 * @param y0 Координата Y (ПЗ-90.02), км
 * @param z0 Координата Z (ПЗ-90.02), км
 * @param vx0 Скорость X (ПЗ-90.02), км/c
 * @param vy0 Скорость Y (ПЗ-90.02), км/c
 * @param vz0 Скорость Z (ПЗ-90.02), км/c
 * @param ax0 Ускорение X от Луны и Солнца, км/с.
 * @param ay0 Ускорение Y от Луны и Солнца, км/с.
 * @param az0 Ускорение Z от Луны и Солнца, км/с.
 * @return Массив радиус-векторов НКА (ПЗ-90.02)
 *
 * В массиве-результате будут записаны координаты и скорости НКА в моменты
 * времени \$t_0+i\cdot \Delta\$, где \$\Delta=(t1-t0)/numsteps\$,
 * \$i=0,1,\ldots,numsteps\$. result[i][0-2] - координаты, result[i][3-5] -
 * скорости.
 */
std::vector < std::vector < real > > extrapolateGLONASSEphemeris(
		real t0, real t1, int numsteps, real x0, real y0, real z0,
		real vx0, real vy0, real vz0, real ax0, real ay0, real az0);


/**
 * @brief Размножение эфемерид GPS
 * @param deltat Разница требуемого момента времени и момента времени эфемерид
 * @param m0 Mean Anomaly at Reference Time
 * @param dn Mean Motion Difference From Computed Value
 * @param e Eccentricity
 * @param sqrta Square Root of the Semi-Major Axis
 * @param omega0 Longitude of Ascending Node of Orbit Plane at Weekly Epoch
 * @param i0 Inclination Angle at Reference Time
 * @param omega Argument of Perigee
 * @param omegadot Rate of Right Ascension
 * @param idot Rate of Inclination Angle
 * @param cuc Amplitude of the Cosine Harmonic Correction Term to the Argument of Latitude
 * @param cus Amplitude of the Sine Harmonic Correction Term to the Argument of Latitude
 * @param cic Amplitude of the Cosine Harmonic Correction Term to the Orbit Radius
 * @param cis Amplitude of the Sine Harmonic Correction Term to the Orbit Radius
 * @param crc Amplitude of the Cosine Harmonic Correction Term to the Angle of Inclination
 * @param crs Amplitude of the Sine Harmonic Correction Term to the Angle of Inclination
 * @return Координаты НКА в системе координат WGS-84
 */
std::vector < real > extrapolateGPSEphemeris(
		real deltat, real m0, real dn, real e, real sqrta, real omega0, real i0,
		real omega, real omegadot, real idot, real cuc, real cus, real cic,
		real cis, real crc, real crs );


DBTableCollection * getExtrapolateCollection();

}

#endif // EXTRAPOLATEEPHEMERIS_H

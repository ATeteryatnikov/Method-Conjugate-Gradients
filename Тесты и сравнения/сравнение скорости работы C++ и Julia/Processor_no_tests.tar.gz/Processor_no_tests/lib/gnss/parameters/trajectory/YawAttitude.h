#ifndef YAWATTITUDE_H_
#define YAWATTITUDE_H_

#include <Kinematic.h>
#include <Consts.h>
#include <Frames.h>
#include <ParamTrajectory.h>

namespace libgnss
{

class YawAttitudeRequiresVelocity : public StrException
{
public:
	YawAttitudeRequiresVelocity(int sat_history_id);
};

/** @file
 *
 * Модель ориентации НКА, основанная на угле рыскания.
 *
 * Под моделью ориентации НКА понимается алгоритм вычисления в любого момента
 * времени матрицы перехода между инерциальной системой координат GCRS и
 * системой координат, связанной с НКА.
 *
 * Для согласования с Antex-форматом принимается следующая спецификация системы
 * координат НКА (см. описание формата Antex):
 *
 * @li Ось z направлена к центру Земли
 * @li Ось y является осью вращения солнечных панелей сонаправлена векторному
 * произведению оси Z с вектором НКА-Солнце.
 * @li Ось x дополняет тройку до правой так, чтобы Z = [X, Y].
 *
 * Угол рыскания - это угол между вектором скорости и осью X, в пределах от
 * \f$-\pi \f$ до \f$pi \f$. В модели ориентации НКА, основанной на угле
 * рыскания, считается, что НКА выдерживает направление антенны в центр
 * Земли с достаточно высокой точностью.
 *
 * Для вычисления угла рыскания на всём промежутке
 *
 */


CTypeSelect * OrientationModels();

/**
 * @brief Вычисление номинальной ориентации НКА
 * @param pos Координаты НКА в системе координат GCRS
 * @param sunpos Координаты Солнца в системе координат GCRS
 * @param axis Единичные векторы X, Y, Z системы координат, связанной с НКА
 *
 * Направления X, Y, Z при их использовании для вычисления смещения фазового
 * центра антенны НКА иногда ещё называют Север, Восток, Вверх.
 */
void nominalOrientation (const kinematic < real, 3, defaultInert > & pos,
						 const kinematic < real, 3, defaultInert > & sunpos,
						 kinematic < real, 3, defaultInert > * axis);

/**
 * @brief Вычисление скорости изменения номинальной ориентации НКА
 * @param posvel Координаты и скорость НКА в системе координат GCRS
 * @param sunpos Координаты Солнца в системе координат GCRS
 * @param axisDot Скорость изменения векторов X, Y, Z, привязанных к НКА
 *
 * Координаты Солнца считаются постоянными, так как ориентация от них
 * зависит намного меньше, чем от координат НКА.
 *
 * Все вычисления проводятся по стандартным формулам дифференцирования:
 *
 * \f[ |pos|' = \frac{(pos,vel)}{|pos|},\qquad
  axisDot[2] = - \frac{|pos|*vel  - |pos|'pos}{|pos|^2} \f]
 *
 * \f[
 |sun-pos|' = -\frac{(vel,(sunpos-pos)}{|sunpos-pos|},\qquad
 \left(\frac{sunpos-pos}{|sunpos-pos|}\right)' =
\frac{-vel|sunpos-pos|-(sunpos-pos)|sunpos-pos|'}{|sunpos-pos|^2}
	\f]
 *
 * \f[ axisDot[1] = \left[axisDot[2], \frac{sunpos-pos}{|sunpos-pos|}\right] +
	\left[ axis[2], \left(\frac{sunpos-pos}{|sunpos-pos|}\right)'\right], \f]
 *
 * \f[ axisDot[0] = [axisDot[1],axis[2]] + [axis[1],axisDot[2]]. \f]
 */
void nominalOrientationDot (const kinematic < real, 6, defaultInert > & posvel,
							const kinematic < real, 3, defaultInert > & sunpos,
							kinematic < real, 3, defaultInert > * axisDot);

/**
 * @brief Вычисляет угол рыскания для всех НКА
 * @param tables Коллекция таблиц
 * @param except Флаг вызова исключения.
 *
 * Угол рыскания по модулю 2Pi равен углу между осью Y и вектором скорости НКА,
 * но продолжает накапливаться при вращении НКА.
 *
 * Данная процедура вычисляет и сохраняет в таблицу траектории НКА их ориентацию
 * (угол рыскания). Шаг, с которым вычисляется ориентация, задаётся независимыми
 * параметрами Other_models->SV_Orientation->RegularStep и Other_models->
 * SV_Orientation->RegularStep. Если на каком-то временнОм промежутке траектория
 * НКА отсутствует, то на этом промежутке не будет вычислена и ориентация.
 *
 * Если установлен флаг исключения, то при невозможности вычисления угла
 * рыскания будет вызвано исключение. В противном случае будет совершен переход
 * к следующему моменту времени или НКА.
 */
void calcOrientation (DBTableCollection &tables, bool except=true);

/**
 * @brief Процедура вычисляет ориентацию НКА
 * @param sat_history_id Идентификатор НКА: ключ в @ref SatelliteHistory
 * @param tai Момент времени, секунды TAI от J2000
 * @param vel Скорость НКА
 * @param traj Указатель на таблицу траекторий
 * @param axis Возвращаемые оси связанной с НКА системы координат
 * @param yaw Угол рыскания
 *
 * Угол рыскания по модулю 2Pi равен углу между осью Y и вектором скорости.
 * Когда угол доходит до 2Pi и НКА продолжает вращение, угол не обнуляется, а
 * продолжает накапливаться; аналогично, при приближении к нулю.
 */
void satelliteOrientation (int sat_history_id, real tai,
						   kinematic<real, 6, defaultInert> posvel,
							const ParamTrajectory & traj,
						   kinematic < real, 3, defaultInert > * axis,
						   real & yawangle);


}

#endif



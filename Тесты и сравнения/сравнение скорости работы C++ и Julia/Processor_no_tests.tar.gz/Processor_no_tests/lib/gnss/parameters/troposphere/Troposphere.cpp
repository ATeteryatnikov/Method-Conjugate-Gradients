#include <map>
#include <set>
#include <string>

using namespace std;

#include <Troposphere.h>

namespace libgnss
{

Settings::Enumerator tropodensity("Parameters_settings","troposphere",
								  "Sampling_density", Variant::TYPE_DOUBLE,
						"Плотность узлов интерполяции параметров тропосферы",
								  (real)(4.0)/(real)(86400));

TroposphereSettingsInconsistent::TroposphereSettingsInconsistent(
		const string &what)
	: StrException("TroposphereSettingsInconsistent",
				   "Несогласованные настройки модели тропосферной задержки"
				   + what)
{

}

ParamTroposphere :: ParamTroposphere(DBTableCollection *base)
	: InterpolatedParameterStorage(base, "troposphere", Columns()
								   <<Column(Variant::TYPE_INT, "marker_id")
								  <<Column(Variant::TYPE_INT, "type")
								 <<Column(Variant::TYPE_DOUBLE, "Time"))
{
	markers = 0;
	settings = 0;
	setInterpolateOrder(Tuple(),4);
}

int ParamTroposphere::getParameterType(const string &paramtype)
{
	static map < string, int > paramtypes;
	if (paramtypes.size() == 0)
	{
		int i=0;
		paramtypes["TROTOT"]=i++;
		paramtypes["TRODRY"]=i++;
		paramtypes["TROWET"]=i++;
		paramtypes["TGNTOT"]=i++;
		paramtypes["TGNDRY"]=i++;
		paramtypes["TGNWET"]=i++;
		paramtypes["TGETOT"]=i++;
		paramtypes["TGEDRY"]=i++;
		paramtypes["TGEWET"]=i++;
		paramtypes["PWV"   ]=i++;
		paramtypes["PRESS" ]=i++;
		paramtypes["TEMDRY"]=i++;
		paramtypes["HUMREL"]=i++;
	}
	try
	{
		return paramtypes.at(paramtype);
	}
	catch (exception e)
	{
		return -1;
	}
}

bool ParamTroposphere::isDelayINKm(int type)
{
	return (type<10);
}

CTypeSelect * troposettings ( int set_id )
{
	static map < int, CTypeSelect * > set_types;
	if (set_types.size() == 0)
	{
		set_types[0] = new CTypeSelect ("tropomodel",Tuple()
			<<string("Total_DryMF")
			<<string("Total_WetMF")
			<<string("DryAndWet"), 2);
		set_types[1] = new CTypeSelect ("tropomf",Tuple()
						<<string("GMF")<<string("NMF")<<string("CosZ"), 0);
	}
	return set_types[set_id];
}



Settings::Enumerator Tropomodel ("Delay_models",
								 "Tropospheric_delay",
								 "Model", troposettings(0),
			"Модель тропосферы", troposettings(0)->defaultValue().toString());

Settings::Enumerator UseTropoGradient ("Delay_models", "Tropospheric_delay",
								"tropo_gradients", CTypeSelect::yesOrNo(),
						"Использовать градиенты тропосферной задержки",
									   string("Yes"));

Settings::Enumerator MapFunc ("Delay_models", "Tropospheric_delay",
								"tropo_mf", troposettings(1),
									  "Отображающая функция для тропосферы",
								troposettings(1)->defaultValue().toString());


void ParamTroposphere::checkSettings()
{
	if ((markers == 0) || (settings == 0))
	{
		markers = (Markers*)(base->getTable("markers"));
		settings = (Settings*)(base->getTable("settings"));
		this->tropomodel = troposettings(0)->toInt(
					settings->getSettings(Tropomodel));
		this->usegradient = CTypeSelect::yesOrNo()->toInt(
					settings->getSettings(UseTropoGradient));
		this->mappingfunction = troposettings(1)->toInt(
					settings->getSettings(MapFunc));
	}
}



real ParamTroposphere::troposphereDelay(int marker_id,
			const kinematic < real, 3, defaultGeodetic > & markerpos,
			real sat_zenith, real sat_azimuth, real t)
{
	checkSettings();

	//Вычислить отображающую функцию и её производные
	double hmf; //Гидростатическая отображающая функция
	double wmf; //Влажная отображающая функция
	double dhmf; //Производная гидростатической функции по зенитному углу
	double dwmf; //Производная влажной отображающей функции по зенитному углу
	switch (mappingfunction)
	{
		case 0:
		{
			//Global mapping function
			double zd = (double)(sat_zenith);
			double lon = markerpos[0];
			double lat = markerpos[1];
			double hm = markerpos[2] * 1000;
			double mjdt = t / jsecondsPerDay + DJM00;
			gmf_(&mjdt,&lat,&lon,&hm,&zd,&hmf,&wmf,&dhmf,&dwmf);
			break;
		}
		case 1:
			throw NotImplementedException("Niel tropospheric mapping function");
		case 2:
			throw NotImplementedException("CosZ tropospheric mapping function");
	}

	//Необходимые параметры
	real p0_ztotal, p2_zwet, p1_zdry,
			p3_grad_n_total, p5_grad_n_wet, p4_grad_n_dry,
			p6_grad_e_total, p8_grad_e_wet, p7_grad_e_dry;

	if (tropomodel == 2)
	{
		p2_zwet = getParameterValue(Tuple()<<marker_id<<(int)2,t);
		p1_zdry = getParameterValue(Tuple()<<marker_id<<(int)1,t);
	}

	//1) Градиенты не используются
	if (usegradient == 0)
	{
		//Используется влажная и сухая задержки
		if (tropomodel == 2)
			return p2_zwet * wmf + p1_zdry * hmf;

		//Используется только полная задержка - с какой отображающей функцией?
		p0_ztotal = getParameterValue(Tuple()<<marker_id<<(int)0,t);
		//С сухой отображающей функцией
		if (tropomodel == 0)
			return hmf * p0_ztotal;

		//С влажной отображающей функцией
		if (tropomodel == 1)
			return wmf * p0_ztotal;
	}
	//2) Используются градиенты
	else
	{
		//Используется и сухая и влажная задержки
		if (tropomodel == 2)
		{
			p5_grad_n_wet = getParameterValue(Tuple()<<marker_id<<(int)5,t);
			p4_grad_n_dry = getParameterValue(Tuple()<<marker_id<<(int)4,t);
			p8_grad_e_wet = getParameterValue(Tuple()<<marker_id<<(int)8,t);
			p7_grad_e_dry = getParameterValue(Tuple()<<marker_id<<(int)7,t);
			real wetdelay = p2_zwet*wmf+dwmf*(p5_grad_n_wet*cos(sat_azimuth)+
												p8_grad_e_wet*sin(sat_azimuth));
			real drydelay = p1_zdry*hmf+dhmf*(p4_grad_n_dry*cos(sat_azimuth)+
												p7_grad_e_dry*sin(sat_azimuth));
			return wetdelay + drydelay;
		}

		//Используется полная задержка
		p0_ztotal = getParameterValue(Tuple()<<marker_id<<(int)0,t);
		p3_grad_n_total = getParameterValue(Tuple()<<marker_id<<(int)3,t);
		p6_grad_e_total = getParameterValue(Tuple()<<marker_id<<(int)6,t);
		if (tropomodel == 0)
			return p0_ztotal*hmf+dhmf*(p3_grad_n_total*cos(sat_azimuth)+
										p6_grad_e_total*sin(sat_azimuth));
		if (tropomodel == 1)
			return p0_ztotal*wmf+dwmf*(p3_grad_n_total*cos(sat_azimuth)+
										p6_grad_e_total*sin(sat_azimuth));
	}

	throw TroposphereSettingsInconsistent("Внутренняя ошибка.");
}


set < int > ParamTroposphere::getParametersSet(int tropomodel, int usegradient)
{
	set < int > tropotypes;

	// Сухая и влажная задержки уточняются раздельно
	if (tropomodel == 2)
	{
		tropotypes.insert((int)1); //Сухая зенитная задержка
		tropotypes.insert((int)2); //Влажная зенитная задержка
		if (usegradient != 0)
		{
			tropotypes.insert((int)4); //Градиент сухой задержки
			tropotypes.insert((int)7);

			tropotypes.insert((int)5); //Градиент влажной задержки
			tropotypes.insert((int)8);
		}
	}

	//Сухая и влажная задержка уточняются в сумме
	else
	{
		tropotypes.insert((int)0); //Полная зенитная задержка
		if (usegradient != 0)
		{
			tropotypes.insert((int)3); //Градиент полной задержки
			tropotypes.insert((int)6);
		}
	}

	return tropotypes;
}

void ParamTroposphere::resample (real t0, real t1, const Tuple &subkey)
{
	if (subkey.size() > 1)
		throw TroposphereSettingsInconsistent(
				"При перестройке узлов интерполяции параметров тропосферы "
				"для указания части хранилища в качестве параметра subkey "
				"можно использовать только номер БИС.");
	checkSettings();

	int need_marker_id = -1;
	if (subkey.size()==1)
		need_marker_id = subkey[0].toInt();

	//Удостовериться, что есть все БИСы, и для каждого БИС - необходимый
	//набор параметров тропосферы, а затем запустить resample для каждого
	//значения подключа.

	//Собрать набор уточняемых параметров тропосферы.
	set <int> tropotypes = getParametersSet(tropomodel, usegradient);

	DBTable * observables = base->getTable("observables");
	DBTable * obssrc = base->getTable("observation_source");
	for (DBTable::DBConstIterator it = observables->const_begin();
		 it!=observables->const_end(); it.inc(0))
	{
		int marker_id = (*obssrc)[it.keyColumnValue(0).toInt()][0].toInt();
		if ((need_marker_id>0) && (need_marker_id!=marker_id))
			continue;

		//Составить список типов параметров для данного маркера
		set<int> thistropotypes;
		for (DBTable::DBConstIterator it1 = find(marker_id); it1!=const_end();
			 it1.subinc(1,0))
			thistropotypes.insert(it1.keyColumnValue(1).toInt());

		//Удалить все параметры, которые не соответствуют указанной в
		//настройках модели
		for(set<int>::iterator it1=thistropotypes.begin();
			it1!=thistropotypes.end(); ++it1)
			if (tropotypes.find(*it1)==tropotypes.end())
				deleteRows(Tuple()<<marker_id<<(*it1));

		//Добавить недостающие параметры для данной модели
		for (set<int>::iterator it2=tropotypes.begin();
			 it2!=tropotypes.end(); ++it2)
			if (thistropotypes.find(*it2)==thistropotypes.end())
				if (find(Tuple()<<marker_id<<(*it2))==const_end())
					insertRow(Tuple()<<marker_id<<(*it2)<<t0,
							  Tuple()<<(real)(0.0l));

		thistropotypes.clear();
	}

	InterpolatedParameterStorage::resample(t0,t1,subkey);
}


real SaastamoinenDryZD(real pr, real td, real rh, real lat, real height)
{
	return 0.0000022768 * pr
				/ (1 - 0.00266 * cos(2*lat) - 0.00028 * height);
}

real SaastamoinenWetZD(real pr, real td, real rh, real lat, real height)
{
	real exp=7.5l*td/(td+237.3l);
	real humid = 6.11l * (rh/100.0l) * std::pow(10.0l,exp);

	return 0.0000022768 * humid * 1255/((td+ 273.15) + 0.05)
			/ (1 - 0.00266 * cos(2*lat) - 0.00028 * height);
}

void calcSaastamoinen(ParamTroposphere * trop, int obs_src_id,
					  const kinematic<real,3,defaultGeodetic> & pos,
					  real t0, real t1, real step)
{
	int tmp_t = trop->getParameterType("TEMDRY");
	int hum_t = trop->getParameterType("HUMREL");
	int prs_t = trop->getParameterType("PRESS");
	int zwd_t = trop->getParameterType("TROWET");
	int zdd_t = trop->getParameterType("TRODRY");

	//Если не задан, установить шаг
	if (isnan(step))
	{
		DBTableCollection * tcol = trop->getBase();
		Settings * sets = (Settings*)(tcol->getTable("settings"));
		step = 1.0l/sets->getSettings(tropodensity).toDouble();
	}

	//Если не заданы, установить моменты времени
	if (isnan(t1))
	{
		real t1_1 = trop->getMaxT(Tuple()<<obs_src_id<<tmp_t);
		real t1_2 = trop->getMaxT(Tuple()<<obs_src_id<<hum_t);
		real t1_3 = trop->getMaxT(Tuple()<<obs_src_id<<prs_t);
		t1 = min(t1_1, min(t1_2, t1_3));
		if (isnan(t1))
			return;
	}

	if (isnan(t0))
	{
		real t0_1 = trop->getMinT(Tuple()<<obs_src_id<<tmp_t);
		real t0_2 = trop->getMinT(Tuple()<<obs_src_id<<hum_t);
		real t0_3 = trop->getMinT(Tuple()<<obs_src_id<<prs_t);
		t0 = max(t0_1, max(t0_2, t0_3));
		if (isnan(t0))
			return;
	}

	if (t0>t1)
		return;

	real lat = pos[1];
	real height = pos[2];

	for (real t = t0; t<t1+step; t+=step)
	{
		if (t>t1)
			t=t1;
		real tmp = trop->getParameterValue(Tuple()<<obs_src_id<<tmp_t,t);
		real hum = trop->getParameterValue(Tuple()<<obs_src_id<<hum_t,t);
		real prs = trop->getParameterValue(Tuple()<<obs_src_id<<prs_t,t);
		real zwd = SaastamoinenWetZD(prs,tmp,hum,lat,height);
		real zdd = SaastamoinenDryZD(prs,tmp,hum,lat,height);
		Tuple zd;
		zd<<obs_src_id<<zwd_t<<t;

		//Если строки уже есть, переписать их.
		try
		{
			zd[1] = zwd_t;
			trop->insertRow(zd,Tuple()<<zwd);
		}
		catch(const DuplicateKeyException & e)
		{
			trop->updateCell(zd,0,zwd);
		}
		try
		{
			zd[1] = zdd_t;
			trop->insertRow(zd,Tuple()<<zdd);
		}
		catch (const DuplicateKeyException & e)
		{
			trop->updateCell(zd,0,zdd);
		}
	}

}

}

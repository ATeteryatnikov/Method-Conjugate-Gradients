/* ./gmf_hu.f -- translated by f2c (version 20100827).
   You must link the resulting object file with libf2c:
	on Microsoft Windows system, link with libf2c.lib;
	on Linux or Unix systems, link with .../path/to/libf2c.a -lm
	or, if you install libf2c.a in a standard place, with -lf2c -lm
	-- in that order, at the end of the command line, as in
		cc *.o -lf2c -lm
	Source for libf2c is in /netlib/f2c/libf2c.zip, e.g.,

		http://www.netlib.org/f2c/libf2c.zip
*/

#include <f2c.h>

/* Subroutine */ int gmf_(doublereal *dmjd, doublereal *dlat, doublereal *
	dlon, doublereal *dhgt, doublereal *zd, doublereal *gmfh, doublereal *
	gmfw, doublereal *dgmfh, doublereal *dgmfw)
{
    /* Initialized data */

    static doublereal ah_mean__[55] = { 125.17,.8503,.06936,-6.76,.1771,.0113,
	    .5963,.01808,.002801,-.001414,-1.212,.093,.003683,.001095,
	    4.671e-5,.3959,-.03867,.005413,-5.289e-4,3.229e-4,2.067e-5,.3,
	    .02031,.0059,4.573e-4,-7.619e-5,2.327e-6,3.845e-6,.1182,.01158,
	    .005445,6.219e-5,4.204e-6,-2.093e-6,1.54e-7,-4.28e-8,-.4751,
	    -.0349,.001758,4.019e-4,-2.799e-6,-1.287e-6,5.468e-7,7.58e-8,
	    -6.3e-9,-.116,.008301,8.771e-4,9.955e-5,-1.718e-6,-2.012e-6,
	    1.17e-8,1.79e-8,-1.3e-9,1e-10 };
    static doublereal bh_mean__[55] = { 0.,0.,.03249,0.,.03324,.0185,0.,
	    -.1115,.02519,.004923,0.,.02737,.01595,-7.332e-4,1.933e-4,0.,
	    -.04796,.006381,-1.599e-4,-3.685e-4,1.815e-5,0.,.07033,.002426,
	    -.001111,-1.357e-4,-7.828e-6,2.547e-6,0.,.005779,.003133,
	    -5.312e-4,-2.028e-5,2.323e-7,-9.1e-8,-1.65e-8,0.,.03688,-8.638e-4,
	    -8.514e-5,-2.828e-5,5.403e-7,4.39e-7,1.35e-8,1.8e-9,0.,-.02736,
	    -2.977e-4,8.113e-5,2.329e-7,8.451e-7,4.49e-8,-8.1e-9,-1.5e-9,
	    2e-10 };
    static doublereal ah_amp__[55] = { -.2738,-2.837,.01298,-.3588,.02413,
	    .03427,-.7624,.07272,.0216,-.003385,.4424,.03722,.02195,-.001503,
	    2.426e-4,.3013,.05762,.01019,-4.476e-4,6.79e-5,3.227e-5,.3123,
	    -.03535,.00484,3.025e-6,-4.363e-5,2.854e-7,-1.286e-6,-.6725,
	    -.0373,8.964e-4,1.399e-4,-3.99e-6,7.431e-6,-2.796e-7,-1.601e-7,
	    .04068,-.01352,7.282e-4,9.594e-5,2.07e-6,-9.62e-8,-2.742e-7,
	    -6.37e-8,-6.3e-9,.08625,-.005971,4.705e-4,2.335e-5,4.226e-6,
	    2.475e-7,-8.85e-8,-3.6e-8,-2.9e-9,0. };
    static doublereal bh_amp__[55] = { 0.,0.,-.1136,0.,-.1868,-.01399,0.,
	    -.1043,.01175,-.00224,0.,-.03222,.01333,-.002647,-2.316e-5,0.,
	    .05339,.01107,-.003116,-1.079e-4,-1.299e-5,0.,.004861,.008891,
	    -6.448e-4,-1.279e-5,6.358e-6,-1.417e-7,0.,.03041,.00115,-8.743e-4,
	    -2.781e-5,6.367e-7,-1.14e-8,-4.2e-8,0.,-.02982,-.003,1.394e-5,
	    -3.29e-5,-1.705e-7,7.44e-8,2.72e-8,-6.6e-9,0.,.01236,-9.981e-4,
	    -3.792e-5,-1.355e-5,1.162e-6,-1.789e-7,1.47e-8,-2.4e-9,-4e-10 };
    static doublereal aw_mean__[55] = { 56.4,1.555,-1.011,-3.975,.03171,.1065,
	    .6175,.1376,.04229,.003028,1.688,-.1692,.05478,.02473,6.059e-4,
	    2.278,.006614,-3.505e-4,-.006697,8.402e-4,7.033e-4,-3.236,.2184,
	    -.04611,-.01613,-.001604,5.42e-5,7.922e-5,-.2711,-.4406,-.03376,
	    -.002801,-4.09e-4,-2.056e-5,6.894e-6,2.317e-6,1.941,-.2562,.01598,
	    .005449,3.544e-4,1.148e-5,7.503e-6,-5.667e-7,-3.66e-8,.8683,
	    -.05931,-.001864,-1.277e-4,2.029e-4,1.269e-5,1.629e-6,9.66e-8,
	    -1.015e-7,-5e-10 };
    static doublereal bw_mean__[55] = { 0.,0.,.2592,0.,.02974,-.5471,0.,
	    -.5926,-.103,-.01567,0.,.171,.09025,.02689,.002243,0.,.3439,
	    .02402,.00541,.001601,9.669e-5,0.,.09502,-.03063,-.001055,
	    -1.067e-4,-1.13e-4,2.124e-5,0.,-.3129,.008463,2.253e-4,7.413e-5,
	    -9.376e-5,-1.606e-6,2.06e-6,0.,.2739,.001167,-2.246e-5,-1.287e-4,
	    -2.438e-5,-7.561e-7,1.158e-6,4.95e-8,0.,-.1344,.005342,3.775e-4,
	    -6.756e-5,-1.686e-6,-1.184e-6,2.768e-7,2.73e-8,5.7e-9 };
    static doublereal aw_amp__[55] = { .1023,-2.695,.3417,-.1405,.3175,.2116,
	    3.536,-.1505,-.0166,.02967,.3819,-.1695,-.07444,.007409,-.006262,
	    -1.836,-.01759,-.06256,-.002371,7.947e-4,1.501e-4,-.8603,-.136,
	    -.03629,-.003706,-2.976e-4,1.857e-5,3.021e-5,2.248,-.1178,.01255,
	    .001134,-2.161e-4,-5.817e-6,8.836e-7,-1.769e-7,.7313,-.1188,
	    .01145,.001011,1.083e-4,2.57e-6,-2.14e-6,-5.71e-8,2e-8,-1.632,
	    -.006948,-.003893,8.592e-4,7.577e-5,4.539e-6,-3.852e-7,-2.213e-7,
	    -1.37e-8,5.8e-9 };
    static doublereal bw_amp__[55] = { 0.,0.,-.08865,0.,-.4309,.0634,0.,.1162,
	    .06176,-.004234,0.,.253,.04017,-.006204,.004977,0.,-.1737,
	    -.005638,1.488e-4,4.857e-4,-1.809e-4,0.,-.1514,-.01685,.005333,
	    -7.611e-5,2.394e-5,8.195e-6,0.,.09326,-.01275,-3.071e-4,5.374e-5,
	    -3.391e-5,-7.436e-6,6.747e-7,0.,-.08637,-.003807,-6.833e-4,
	    -3.861e-5,-2.268e-5,1.454e-6,3.86e-7,-1.068e-7,0.,-.02658,
	    -.001947,7.131e-4,-3.506e-5,1.885e-7,5.792e-7,3.99e-8,2e-8,
	    -5.7e-9 };

    /* System generated locals */
    integer i__1, i__2;
    doublereal d__1, d__2;

    /* Builtin functions */
    double cos(doublereal), sin(doublereal);

    /* Local variables */
    static doublereal dht_corr__;
    static integer i__, m, n;
    static doublereal v[100]	/* was [10][10] */, w[100]	/* was [10][
	    10] */, x, y, z__, ah, bh, ch, aw, pi, bw, cw, c0h, aha, c10h, 
	    c11h, ahm, awa, phh, awm, doy, a_ht__, b_ht__, c_ht__, beta, sine;
    static integer mmax, nmax;
    static doublereal ht_corr_coef__, dbeta, gamma, hs_km__, dsine, 
	    dht_corr_coef__, dgamma, topcon, ht_corr__;

/*     This subroutine determines the Global Mapping Functions GMF */

/*     Reference: Boehm, J., A.E. Niell, P. Tregoning, H. Schuh (2006), */
/*     Global Mapping Functions (GMF): A new empirical mapping function based on numerical weather model data,
 */
/*     Geoph. Res. Letters, Vol. 33, L07304, doi:10.1029/2005GL025545. */

/*     input data */
/*     ---------- */
/*     dmjd: modified julian date */
/*     dlat: latitude in radians */
/*     dlon: longitude in radians */
/*     dhgt: height in m */
/*     zd:   zenith distance in radians */

/*     output data */
/*     ----------- */
/*     gmfh: hydrostatic mapping function */
/*     gmfw: wet mapping function */
/*     dgmfh:first derivative of hydrostatic mapping function as a function of zd */
/*     dgmfw:first derivative of wet mapping function as a function of zd */

/*     Johannes Boehm, 2005 August 30 */

/*     ref 2006 Aug. 14: recursions for Legendre polynomials (O. Montenbruck) */

    pi = 3.14159265359;
/*     reference day is 28 January */
/*     this is taken from Niell (1996) to be consistent */
    doy = *dmjd - 44239. - 27;
/*     degree n and order m */
    nmax = 9;
    mmax = 9;
/*     unit vector */
    x = cos(*dlat) * cos(*dlon);
    y = cos(*dlat) * sin(*dlon);
    z__ = sin(*dlat);
/* Legendre polynomials */
    v[0] = 1.;
    w[0] = 0.;
    v[1] = z__ * v[0];
    w[1] = 0.f;
    i__1 = nmax;
    for (n = 2; n <= i__1; ++n) {
	v[n] = (((n << 1) - 1) * z__ * v[n - 1] - (n - 1) * v[n - 2]) / n;
	w[n] = 0.;
    }
    i__1 = nmax;
    for (m = 1; m <= i__1; ++m) {
	v[m + 1 + (m + 1) * 10 - 11] = ((m << 1) - 1) * (x * v[m + m * 10 - 
		11] - y * w[m + m * 10 - 11]);
	w[m + 1 + (m + 1) * 10 - 11] = ((m << 1) - 1) * (x * w[m + m * 10 - 
		11] + y * v[m + m * 10 - 11]);
	if (m < nmax) {
	    v[m + 2 + (m + 1) * 10 - 11] = ((m << 1) + 1) * z__ * v[m + 1 + (
		    m + 1) * 10 - 11];
	    w[m + 2 + (m + 1) * 10 - 11] = ((m << 1) + 1) * z__ * w[m + 1 + (
		    m + 1) * 10 - 11];
	}
	i__2 = nmax;
	for (n = m + 2; n <= i__2; ++n) {
	    v[n + 1 + (m + 1) * 10 - 11] = (((n << 1) - 1) * z__ * v[n + (m + 
		    1) * 10 - 11] - (n + m - 1) * v[n - 1 + (m + 1) * 10 - 11]
		    ) / (n - m);
	    w[n + 1 + (m + 1) * 10 - 11] = (((n << 1) - 1) * z__ * w[n + (m + 
		    1) * 10 - 11] - (n + m - 1) * w[n - 1 + (m + 1) * 10 - 11]
		    ) / (n - m);
	}
    }
/*     hydrostatic */
    bh = .0029f;
    c0h = .062f;
    if (*dlat < 0.) {
/* southern hemisphere */
	phh = pi;
	c11h = .007f;
	c10h = .002f;
    } else {
/* northern hemisphere */
	phh = 0.;
	c11h = .005f;
	c10h = .001f;
    }
    ch = c0h + ((cos(doy / 365.25 * 2 * pi + phh) + 1) * c11h / 2 + c10h) * (
	    1 - cos(*dlat));
    ahm = 0.;
    aha = 0.;
    i__ = 0;
    i__1 = nmax;
    for (n = 0; n <= i__1; ++n) {
	i__2 = n;
	for (m = 0; m <= i__2; ++m) {
	    ++i__;
	    ahm += ah_mean__[i__ - 1] * v[n + 1 + (m + 1) * 10 - 11] + 
		    bh_mean__[i__ - 1] * w[n + 1 + (m + 1) * 10 - 11];
	    aha += ah_amp__[i__ - 1] * v[n + 1 + (m + 1) * 10 - 11] + 
		    bh_amp__[i__ - 1] * w[n + 1 + (m + 1) * 10 - 11];
	}
    }
    ah = (ahm + aha * cos(doy / 365.25 * 2. * pi)) * 1e-5;
    sine = sin(pi / 2 - *zd);
    dsine = -sin(*zd);
    beta = bh / (sine + ch);
/* Computing 2nd power */
    d__1 = sine + ch;
    dbeta = -bh * dsine / (d__1 * d__1);
    gamma = ah / (sine + beta);
/* Computing 2nd power */
    d__1 = sine + beta;
    dgamma = ah * (dsine + dbeta) / (d__1 * d__1);
    topcon = ah / (bh / (ch + 1.) + 1.) + 1.;
    *gmfh = topcon / (sine + gamma);
/* Computing 2nd power */
    d__1 = sine + gamma;
    *dgmfh = topcon * (dsine + dgamma) / (d__1 * d__1);
/*     height correction for hydrostatic mapping function from Niell (1996) */
    a_ht__ = 2.53e-5;
    b_ht__ = .00549;
    c_ht__ = .00114;
    hs_km__ = *dhgt / 1e3;

    beta = b_ht__ / (sine + c_ht__);
/* Computing 2nd power */
    d__1 = sine + c_ht__;
    dbeta = -b_ht__ * dsine / (d__1 * d__1);
    gamma = a_ht__ / (sine + beta);
/* Computing 2nd power */
    d__1 = sine + beta;
    dgamma = a_ht__ * (dsine + dbeta) / (d__1 * d__1);
    topcon = a_ht__ / (b_ht__ / (c_ht__ + 1.) + 1.) + 1.;
    ht_corr_coef__ = 1 / sine - topcon / (sine + gamma);
/* Computing 2nd power */
    d__1 = sine;
/* Computing 2nd power */
    d__2 = sine + gamma;
    dht_corr_coef__ = -dsine / (d__1 * d__1) + topcon * (dsine + dgamma) / (
	    d__2 * d__2);
    ht_corr__ = ht_corr_coef__ * hs_km__;
    dht_corr__ = dht_corr_coef__ * hs_km__;
    *gmfh += ht_corr__;
    *dgmfh += dht_corr__;
/*     wet */
    bw = .00146f;
    cw = .04391f;
    awm = 0.;
    awa = 0.;
    i__ = 0;
    i__1 = nmax;
    for (n = 0; n <= i__1; ++n) {
	i__2 = n;
	for (m = 0; m <= i__2; ++m) {
	    ++i__;
	    awm += aw_mean__[i__ - 1] * v[n + 1 + (m + 1) * 10 - 11] + 
		    bw_mean__[i__ - 1] * w[n + 1 + (m + 1) * 10 - 11];
	    awa += aw_amp__[i__ - 1] * v[n + 1 + (m + 1) * 10 - 11] + 
		    bw_amp__[i__ - 1] * w[n + 1 + (m + 1) * 10 - 11];
	}
    }
    aw = (awm + awa * cos(doy / 365.25 * 2 * pi)) * 1e-5;
    beta = bw / (sine + cw);
/* Computing 2nd power */
    d__1 = sine + cw;
    dbeta = -bw * dsine / (d__1 * d__1);
    gamma = aw / (sine + beta);
/* Computing 2nd power */
    d__1 = sine + beta;
    dgamma = aw * (dsine + dbeta) / (d__1 * d__1);
    topcon = aw / (bw / (cw + 1.) + 1.) + 1.;
    *gmfw = topcon / (sine + gamma);
/* Computing 2nd power */
    d__1 = sine + gamma;
    *dgmfw = topcon * (dsine + dgamma) / (d__1 * d__1);
    return 0;
} /* gmf_ */


#ifndef TROPOSPHERE_H_
#define TROPOSPHERE_H_

#include <StdTables.h>
#include <Consts.h>
#include <DBTableCollection.h>
#include <InterpolatedParameterStorage.h>
#include <Kinematic.h>

namespace libgnss
{


class TroposphereSettingsInconsistent : public StrException
{
public:
	TroposphereSettingsInconsistent(const string & what);
};

/**
 * @brief Функция, вычисляющая отображающую функцию тропосферы GMF
 * @param dmjd Модифицированная юлианская дата
 * @param dlat Широта, радианы
 * @param dlon Долгота, радианы
 * @param dhgt Высота, метры
 * @param zd Зенитный угол, радианы
 * @param gmfh Гидростатическая отображающая функция
 * @param gmfw Влажная отображающая функция
 * @param dgmfh Производная гидростатической функции по зенитному углу
 * @param dgmfw Производная влажной функции по зенитному углу
 *
 * Ссылка: Boehm, J., A.E. Niell, P. Tregoning, H. Schuh (2006),
 *    Global Mapping Functions (GMF): A new empirical mapping function based on
 *    numerical weather model data, Geoph. Res. Letters, Vol. 33, L07304,
 *    doi:10.1029/2005GL025545.
 */
extern "C" void gmf_(double * dmjd, double * dlat, double * dlon,
					 double * dhgt, double * zd,
					 double * gmfh, double * gmfw,
					 double * dgmfh, double * dgmfw);

/**
 * @brief Хранилище параметров тропосферы
 *
 * Ключ:
 * @li int marker_id - идентификатор маркера, соответствует полю autoinc в
 * таблице @ref Markers
 * @li int type - тип хранимой информации
 * @li double Time
 *
 * Значения: double value - значение параметра
 *
 * Типы данных о тропосфере взяты спецификации SINEX и SINEX-Tropo:
 * @li 0 = TROTOT - полная зенитная задержка, км
 * @li 1 = TRODRY - гидростатическая зенитная задержка, км
 * @li 2 = TROWET - влажная зенитная задержка, км
 * @li 3 = TGNTOT - градиент полной задержки в направлении Севера, км
 * @li 4 = TGNDRY - градиент гидростатической задержки в сторону Севера, км
 * @li 5 = TGNWET - градиент влажной задержки в сторону Севера, км
 * @li 6 = TGETOT - градиент полной задержки в направлении Востока, км
 * @li 7 = TGEDRY - градиент гидростатической задержки в сторону Востока, км
 * @li 8 = TGEWET - градиент влажной задержки в сторону Востока, км
 * @li 9 = PWV - оседающий водяной пар (?!!!), км
 * @li 10 = PRESS - давление, мБар
 * @li 11 = TEMDRY - гидростатическая температура, градусы Цельсия
 * @li 12 = HUMREL - отнzосительная влажность, %
 */
class ParamTroposphere : public InterpolatedParameterStorage
{
private:
	Markers * markers;
	Settings * settings;
	int tropomodel;
	int usegradient;
	int mappingfunction;

	void checkSettings();
public:
	ParamTroposphere (DBTableCollection * base);

	/**
	 * @brief Возвращает тип параметра по его SINEX-Tropo-обозначению
	 * @param paramtype Обозначение типа параметра в файлах SINEX-Tropo
	 * @return Тип параметра, используемый в колонке type данной таблицы
	 */
	static int getParameterType ( const string & paramtype );

	/**
	 * @brief Является ли данный параметр величиной задержки в км?
	 * @param i Тип параметра
	 * @return true, если параметр данного типа измеряется в километрах
	 *
	 * Данная процедура используется при чтении файлов с тропосферной
	 * информацией. Если данная величина измеряется в километрах, то при
	 * чтении её из файла необходимо приводить единицы измерения.
	 */
	static bool isDelayINKm ( int type );

	/**
	 * @brief Вычислить тропосферную задержку сигнала НКА
	 * @param marker_id Идентификатор маркера
	 * @param marker_pos Координаты маркера в инерциальной системе координат
	 * @param sv_pos Координаты НКА в инерциальной системе координат
	 * @param t Момент времени, секунды TAI от J2000
	 * @return Задержка сигнала при прохождении через тропосферу, км.
	 *
	 * Для вычисления задержки требуются:
	 * @li Момент времени для интерполяции параметров тропосферы
	 * @li Зенитный угол НКА по отношению к БИС. Поскольку координаты БИС и
	 * НКА в инерциальной системе координат в любом случае нужны для вычисления
	 * псевдодальности, лучше всего вычислить угол именно с их помощью.
	 * @li Геодезические координаты маркера для подстановки в отображающую
	 * функцию. Их можно запросить в таблице маркеров по номеру маркера.
	 *
	 * Тропосферная задержка в заданном направлении вычисляется с помощью
	 * отображающей функции, которая выбирается в настройках Delay_models,
	 * Tropospheric_delay,tropo_mf.
	 *
	 * См. также  Meindl M., Schaer S., Hugentobler U., Beutler G. Tropospheric
	 * Gradient Estimation at CODE: Results from Global Solutions //  Journal of
	 * the Meteorological Society of Japan, 82(1B):331 – 338.
	 */
	real troposphereDelay(int marker_id,
			const kinematic < real, 3, defaultGeodetic > & markerpos,
			real sat_zenith, real sat_azimuth, real t);

	/**
	 * @brief Перестройка хранилища тропосферных параметров
	 *
	 * Перераспределяются узлы интерполяции хранилища на интервале времени
	 * [t0; t1]. Параметр subkey может задавать только номер БИС. Если
	 * subkey содержит больше одного поля, будет сгенерировано исключение
	 * TroposphereSettingsInconsistent.
	 */
	virtual void resample (real t0, real t1, const Tuple & subkey= Tuple());

	inline int getTropoModel()
	{
		checkSettings();
		return tropomodel;
	}

	inline int useGradient()
	{
		checkSettings();
		return usegradient;
	}

	inline int getMappingFunctionType()
	{
		checkSettings();
		return mappingfunction;
	}

	static set < int > getParametersSet(int tropomodel, int usegradient);


};

real SaastamoinenDryZD(real pr, real td, real rh, real lat, real height);

real SaastamoinenWetZD(real pr, real td, real rh, real lat, real height);

/**
 * @brief Вычисление зенитных задержек по модели Саастамойнена
 * @param trop Таблица тропосферных параметров
 * @param obs_src_id Идентификатор БИС
 * @param pos Положение БИС в геодезической системе координат
 * @param t0 Начало временнОго интервала
 * @param t1 Конец временнОго интервала
 * @param step Желаемый шаг, с которым будут вычисляться задержки
 *
 * В результате работы функции в таблицу тропосферных параметров будут внесены
 * влажная и сухая тропосферные задержки на указанном временнОм интервале
 * с указанным шагом. Для того, чтобы улучшить обусловленность системы
 * уравнений при уточнении параметров, можно после вычисления задержек вызвать
 * метод resample().
 *
 * Если шаг не указан, он будет взят из настроек уточняемого параметра
 * тропосферы.
 *
 * Если не указаны границы интервала времени, будет выбрано пересечение
 * интервалов между наименьшим и наибольшим моментом времени, на котором есть
 * параметры температуры, влажности и давления.
 *
 * Если температура, влажность и давление не заданы ни для одного момента
 * времени одновременно, функция не выполнится.
 *
 * Если временнОй интервал задан, и в один из моментов времени не удалось
 * найти температуру, влажность, или давление, будет сгенерировано исключение.
 */
void calcSaastamoinen(ParamTroposphere *trop, int obs_src_id,
					  const kinematic<real,3,defaultGeodetic> & pos,
					  real t0 = numeric_limits<real>::quiet_NaN(),
					  real t1 = numeric_limits<real>::quiet_NaN(),
					  real step = numeric_limits<real>::quiet_NaN());

}

#endif

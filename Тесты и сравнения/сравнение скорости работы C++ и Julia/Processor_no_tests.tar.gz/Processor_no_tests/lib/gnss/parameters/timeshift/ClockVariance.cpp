#include <limits>

using namespace std;

#include <binomial.hpp>
#include <ClockVariance.h>
#include <DBInterpolate.h>
#include <StdTables.h>
#include <TimeShift.h>

namespace libgnss
{


NotContinuousClockInterval::NotContinuousClockInterval(real tbr)
	: StrException ("NotContinuousClockInterval",
		  "Интервал непрерывности работы часов бьётся в момент "
			"времени "+UTCDateTime::fromTAIJ2000(tbr).getUTCDateTimeString())
{
	this->timeBreak = tbr;
}


/*
 * @li int type Соответствует колонке type в @ref TimeShift
 * @li int id Соответствует колонке id в @ref TimeShift
 * @li double since Время изменения параметров часов (например, установка нвоых)

 */

ClockLinearResidue::ClockLinearResidue(DBTableCollection *base)
	: DBTable (Columns()
			   <<Column(Variant::TYPE_INT, "type")
				 <<Column(Variant::TYPE_INT, "id")
				   <<Column(Variant::TYPE_INT, "since"),
			   Columns()<<Column(Variant::TYPE_DOUBLE, "residue"))
{
	base->addTable("clock_linear_residue", this);
}

ClockVarBinomial::ClockVarBinomial(DBTableCollection *base)
	: DBTable(Columns()
			  <<Column(Variant::TYPE_INT, "comb")
			  <<Column(Variant::TYPE_INT, "type")
			 <<Column(Variant::TYPE_INT, "id")
			 <<Column(Variant::TYPE_DOUBLE, "since")
			 <<Column(Variant::TYPE_DOUBLE, "interval"),
			  Columns()
			  <<Column(Variant::TYPE_DOUBLE, "variance")
		   )
{
	base->addTable("clock_variance",this);
}

real ClockLinearResidue::clockVariance(int clock_type, int device_id,
										  real t0, real t1) const
{
	DBTable::DBConstIterator it = lower_bound(Tuple()<<clock_type
											  <<device_id<<t1);
	if (it == const_end())
		throw KeyNotFoundException(Tuple()<<clock_type<<device_id<<t1);
	real prevtm = it.keyColumnValue(2).toDouble();
	if (prevtm > t0)
		throw NotContinuousClockInterval(prevtm);
	return it[0].toDouble();

}

real ClockVarBinomial::clockVariance(int comb_id,int clock_type,
								int device_id,real t0, real interval)
const
{
	//1) Найти момент изменения параметров часов, непосредственно
	//предшествующий моменту времени t0
	DBTable::DBConstIterator it = lower_bound(Tuple()<<comb_id<<clock_type
											  <<device_id<<t0);
	if (it == const_end())
		throw KeyNotFoundException(Tuple()<<comb_id<<clock_type<<device_id<<t0);
	real prevtm = it.keyColumnValue(3).toDouble();

	//2) Интерполировать дисперсию по двум ближайшим значениям
	return interpolate(*this,0,Tuple()<<comb_id<<clock_type<<device_id<<prevtm,
					   interval,0,2);
}

void calcBinomVar(DBTableCollection *base, int comb_order, int step)
{
	const int minorder = 1;
	comb_order++;

	//Коэффициенты
	vector < vector < int > > binoms(comb_order);
	for (unsigned int i=1; i<comb_order; i++)
		binoms[i] = binomialCoefficientsAlt(i);

	ClockBias*ts=(ClockBias*)(base->getTable("time_shift"));
	ClockVarBinomial*var=(ClockVarBinomial*)
			(base->getTable("clock_variance"));

	//Пройти по всем БИС и НКА
	for (DBTable::DBConstIterator it = ts->const_begin();
		 it!=ts->const_end(); it.inc(2))
	{
		int cl_type = it.keyColumnValue(0).toInt();
		int id = it.keyColumnValue(1).toInt();
		int type = it.keyColumnValue(2).toInt();
		real est_time = it.keyColumnValue(3).toDouble();
		est_time-=1e-15*fabs(est_time);

		//Считать дисперсии только для ухода часов
		if (type!=0)
			continue;

		//stores[i][j] - j-й массив вершин для шаблона i-го порядка
		//После суммирования отдельно для каждого j затем суммируем по j и
		//получаем статистику по всевозможным шаблонам.
		vector<vector< vector < real > > > stores (comb_order);

		//sums[i][j].first - число накопленных слагаемых
		//sums[i][j].second.first - накопленная сумма квадратов элементов
		//sums[i][j].second.second - накопленная сумма элементов
		vector<vector<pair<int,pair<real,real> > > > sums (comb_order);

		for (unsigned int i=minorder; i<comb_order; i++)
		{
			stores[i]= vector < vector < real > > (
				i,vector < real> (i, numeric_limits<real>::quiet_NaN()));
			sums[i].resize(i);
		}

		int i = 0;

		real t0=numeric_limits<real>::quiet_NaN(),
				t1=numeric_limits<real>::quiet_NaN();

		for (DBTable::DBConstIterator it1 = it; it1!=ts->const_end();
			 it1.subinc(3,2))
		{
			t0 = t1;
			t1 = it1.keyColumnValue(3).toDouble();
			//j пробегает расчитываемые порядки линейных комбинаций
			for (unsigned int j = minorder; j < comb_order; j++)
			{
				//Выбрать номер окна
				int m = (j==1)?0:(i%step);
				//Продвинуть m-е окно
				for (unsigned int k = 1; k<j; k++)
					stores[j][m][k-1] = stores[j][m][k];
				stores[j][m][j-1] = it1[0].toDouble();

				if (isnan(stores[j][m][0]) == 0)
				{
					//Если накопилось достаточно вершин, нужно вычислить
					//линейную комбинацию
					real combination = 0;
					for (unsigned int k=0; k<j; k++)
						combination+=(binoms[j][k] * stores[j][m][k]);
					sums[j][m].first++;
					sums[j][m].second.second += combination;
					sums[j][m].second.first += (combination*combination);
				}
			}
			i++;
		}

		vector < pair < int ,pair < real, real > > > sums2 (comb_order,
					pair < int, pair < real, real > >(
								0,pair < real, real> (0.0l, 0.0l)
																	  ));
		real interval = (t1-t0)*step;

		for (int j = minorder; j<comb_order; j++)
		{
			for (int k = 0; k<j; k++)
			{
				sums2[j].first += sums[j][k].first;
				sums2[j].second.first += sums[j][k].second.first;
				sums2[j].second.second += sums[j][k].second.second;
			}

			//Теперь sums2[j].first содержит общее число n просуммированных
			//значений j-й комбинации, sums2[j].second.first содержит
			//сумму квадратов sq, sums2[j].second.second содержит сумму s.
			//Дисперсия = (sq - s/n)/(n-1).
			real variance = sums2[j].second.first / sums2[j].first;
			//(sums2[j].second.first -
			//(pow(sums2[j].second.second,2)/sums2[j].first))/
			//				(sums2[j].first-1);

			var->insertRow(Tuple()<<j<<cl_type<<id<<est_time<<interval,
						   Tuple()<<variance);
		}
	}
}

void calcLinearResidueVariance(DBTableCollection * base)
{
	ClockLinearResidue * lr = (ClockLinearResidue*)
			(base->getTable("clock_linear_residue"));
	ClockBias * cb = (ClockBias*)(base->getTable("time_shift"));

	//Пройти по всем часам
	for (DBTable::DBConstIterator it = cb->const_begin();
		 it!=cb->const_end(); it.inc(1))
	{
		int clktype = it.keyColumnValue(0).toInt();
		int device_id = it.keyColumnValue(1).toInt();

		real sumsqx = 0;
		real sumx = 0;
		real sumy = 0;
		real sumxy = 0;
		real count = 0;
		real t_estimate = numeric_limits<real>::quiet_NaN();

		//Построить линейную аппроксимацию ухода часов
		for (DBTable::DBConstIterator it1 = cb->find(
				 Tuple()<<clktype<<device_id<<0);
			 it1!=cb->const_end();
			 it1.subinc(3,2))
		{
			real t0 = it1.keyColumnValue(3).toDouble();
			if (isnan(t_estimate))
				t_estimate = t0;
			real dt = it1[0].toDouble();
			sumsqx += (t0 * t0);
			sumx += t0;
			sumy += dt;
			sumxy += dt*t0;
			count ++;
		}
		real determinant = count * sumsqx - (sumx*sumx);
		real c00 = count / determinant;
		real c01 = -sumx / determinant;
		real c10 = c01;
		real c11 = sumsqx / determinant;
		real a = c00 * sumxy + c01 * sumy;
		real b = c10 * sumxy + c11 * sumy;

		//Вычислить невязки
		real sumsqrres = 0;
		for (DBTable::DBConstIterator it1 = cb->find(
				 Tuple()<<clktype<<device_id<<0); it1!=cb->const_end();
			 it1.subinc(3,2))
		{
			real t0 = it1.keyColumnValue(3).toDouble();
			real dt = it1[0].toDouble();
			real residue = t0 * a + b - dt;
			sumsqrres += (residue * residue);
		}

		//Занести вычисленную СКО в таблицу
		lr->insertRow(Tuple()<<clktype<<device_id<<t_estimate,
					  Tuple()<<sqrt(sumsqrres/count));

	}
}

}

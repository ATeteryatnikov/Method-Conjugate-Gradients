#ifndef TIMESHIFT_H_
#define TIMESHIFT_H_

#include <InterpolatedParameterStorage.h>
#include <StdTables.h>

namespace libgnss
{


/**
 * @brief Таблица уходов часов НКА и БИС
 *
 * Название таблицы: time_shift
 *
 * Ключ:
 * @li int type 0 для БИС и 1 для НКА
 * @li int id = observation_source_id для БИС и satellite_history_id для НКА
 * @li int type Тип данных: 0 = уход часов, 1 = скорость ухода, 2 = ускорение
 * @li double t - момент времени, секунды TAI от J2000
 *
 * Значение: double value - уход часов относительно внутренней шкалы TAI, сек.
 *
 * Добавление данной таблицы в коллекцию также добавляет в эту же коллекцию
 * таблицу time_shift_order c колонками:
 *
 * Ключ:
 * @li int type 0 для БИС и 1 для НКА
 * @li int id = observation_source_id для БИС и satellite_history_id для НКА
 * @li int type Тип данных: 0 = уход часов, 1 = скорость ухода, 2 = ускорение
 *
 * Значение: int order - порядок аппроксимации ухода часов с данным подключом.
 *
 * Порядок аппроксимации ухода часов влияет на алгоритм, собственно,
 * аппроксимации ухода часов, а также на алгоритм создания уточняемых параметров
 * ухода часов (метод @ref resample() ).
 *
 * В случае, если order = 0 или 1, то считается, что модель ухода часов
 * стохастическая, и при выполнении метода @ref resample() новые параметры
 * создаются в каждый момент времени, в который есть псевдодальности.
 *
 * Если order = 2, то уход часов будет интерполироваться по двум точкам. При
 * выполнении метода @ref resample() такие точки создаются в начале и в конце
 * интервала обработки.
 *
 * Если order > 2, то вершины интерполяции ухода часов будут расставлены с
 * шагом согласно настройке Parameters_settings->time_shift->Sampling_density.
 */
class ClockBias : public InterpolatedParameterStorage
{
private:
	bool intorderset;
	void setIntOrder();
public:
	ClockBias (DBTableCollection * base);

	/**
	 * @brief Возвращает уход часов БИС
	 * @param observation_source_id Идентификатор "БИС"
	 * @param t Момент времени, секунды TAI от J2000
	 * @return Уход часов БИС относительно внутренней шкалы
	 */
	real stationTimeShift (int observation_source_id, real t) const;

	/**
	 * @brief satelliteTimeShift Возвращает уход часов НКА
	 * @param sat_history_id Идентификатор истории НКА в @ref SatelliteHistory
	 * @param t Момент времени, секунды TAI от J2000
	 * @return Уход часов НКА относительно внутрненней шкалы
	 */
	real satelliteTimeShift(int sat_history_id, real t) const;

	/**
	 * @brief Перестройка хранилища ухода часов
	 *
	 * При выполнении этого метода будут взяты все эпохи измерительных данных
	 * из таблицы Observables, и для каждой эпохи будут созданы параметры ухода
	 * часов НКА и БИС.
	 *
	 * В подключе subkey можно указать принадлежность ухода часов (БИС или НКА),
	 * идентификатор БИС или НКА и тип данных: уход часов, скорость или
	 * ускорение.
	 */
	virtual void resample(real t0, real t1, const Tuple &subkey = Tuple());
};

}

#endif

#include <TimeShift.h>
#include <fit.hpp>
#include <basis.h>

namespace libgnss
{


Settings::Enumerator clockmodel ("Parameters_settings", "TimeShift", "Order",
			Variant::TYPE_INT, "Число узлов интерполяции ухода часов",
								 string("1"));

Settings::Enumerator clockdensity("Parameters_settings","time_shift",
								  "Sampling_density", Variant::TYPE_DOUBLE,
						"Плотность узлов параметра ухода часов",
								  (real)(1.0)/(real)(300));


ClockBias::ClockBias(DBTableCollection *base)
	: InterpolatedParameterStorage(base, "time_shift", Columns()
								   <<Column(Variant::TYPE_INT, "type")
								  <<Column(Variant::TYPE_INT, "id")
								 <<Column(Variant::TYPE_INT, "type")
								 <<Column(Variant::TYPE_DOUBLE, "Time"))
{
//	(*base)["time_shift_order"] = InterpolateOrders;

	setExtrapolationLimit(Tuple(), -1);

	// Установить интерполяцию ухода часов по соседним узлам
	setInterpolateOrder(Tuple(), 1);

	intorderset = false;
}

void ClockBias::setIntOrder()
{
	if (intorderset == false)
	{
		Settings * sets = (Settings*)(base->getTable("settings"));
		int iord = sets->getSettings(clockmodel).toInt();
		setInterpolateOrder(Tuple(),iord);
		intorderset = true;
	}
}

real ClockBias::stationTimeShift(int observation_source_id, real t)
const
{
	//((ClockBias*)(this))->setIntOrder();
	return getParameterValue(Tuple()<<int(0)<<observation_source_id<<int(0), t);
}

real ClockBias::satelliteTimeShift(int sat_history_id, real t) const
{
	//((ClockBias*)(this))->setIntOrder();
	return getParameterValue(Tuple()<<int(1)<<sat_history_id<<int(0), t);
}


void ClockBias::resample(real t0, real t1, const Tuple & subkey)
{
	int M = subkey.size();
	int N = getKeyColumns().size();
	int need_clk_type = -1;
	int need_clk_id = -1;
	int need_clk_data_type = -1;
	if (M > 3)
		throw StrException("ClockBias::resample",
						   "Указано слишком много ключевых полей.");
	if (M > 0)
		need_clk_type = subkey[0].toInt();
	if (M > 1)
		need_clk_id = subkey[1].toInt();
	if (M>2)
		need_clk_data_type = subkey[2].toInt();

	//Пройти сначала по всем часам, для которых отдельный порядок модели
	//восстановления ухода часов.
	DBTable newts(getKeyColumns(), getValueColumns());

	DBTable * obs = base->getTable("observables");
	for (DBTable::DBConstIterator it = obs->const_begin();
		 it!=obs->const_end(); it.inc(2))
	{
		int obs_src_id = it.keyColumnValue(0).toInt();
		real tai = it.keyColumnValue(1).toDouble();
		int sat_history_id = it.keyColumnValue(2).toInt();
//		int sat_order = getInterpolateOrder(Tuple()<<1<<sat_history_id<<0);
//		int obs_order = getInterpolateOrder(Tuple()<<0<<obs_src_id<<0);
		Tuple t1 = Tuple()<<0<<obs_src_id<<0<<tai,
				t2 = Tuple()<<1<<sat_history_id<<0<<tai;
		if ((need_clk_type == 0) && (need_clk_id!=-1)
				&&(need_clk_id!=obs_src_id))
			continue;
		if ((need_clk_type == 1) && (need_clk_id!=-1)
				&&(need_clk_id!=sat_history_id))
			continue;
		if (need_clk_data_type > 0)
			continue;

		if ((newts.find(t1) == newts.const_end()) && (need_clk_type!=1))
		{
			real recclk;
			try
			{
				recclk = getParameterValue(Tuple()<<0<<obs_src_id<<0, tai);
			}
			catch (...)
			{
				recclk = 0.0l;
			}
			newts.insertRow(t1, Tuple()<<recclk);
		}

		if ((newts.find(t2) == newts.const_end()) && (need_clk_type!=0))
		{
			real satclk;
			try
			{
				satclk = getParameterValue(Tuple()<<1<<sat_history_id<<0, tai);
			}
			catch (...)
			{
				satclk = 0.0l;
			}
			newts.insertRow(t2, Tuple()<<satclk);
		}
	}
	deleteRows(subkey);
	for (DBTable::DBConstIterator it = newts.const_begin();
		 it!= newts.const_end(); ++it)
		insertRow(it.subkey(), *it);
}

}

#ifndef RADPRESSURE_H_
#define RADPRESSURE_H_

//! @file

#include <ParameterStorage.h>
#include <DBTableCollection.h>
#include <Kinematic.h>
#include <Types.h>
#include <Frames.h>
#include <StdTables.h>

namespace libgnss
{


/** @brief Абстрактный класс уточняемых параметров радиационного давления
  *
  * Параметры модели ускорения от радиационного давления на КА есть
  * конечный набор коэффициентов для каждого КА.
  *
  * Хранилище параметров радиационного давления представляет собой
  * таблицу, для которой ключ есть пара (Идентификатор КА, Номер коэффициента).
  *
  * Помимо определение абстрактного интерфейса, у данного класса есть ещё
  * одна функция - создание списка моделей РД для автоматического вызова
  * нужной модели. Каждый новый класс модели РД должен при инициализации
  * библиотеки вызвать метод addRadPressureType() для того, чтобы затем
  * можно было автоматически вызвать статический метод acceleration(), который
  * передаст управление методу calcAcceleration() нужного класса.
  *
  * Ключ:
  * @li int sat_history_id Идентификатор НКА (ключ к @ref SatelliteHistory)
  * @li int coefficient_id Идентификатор коэффициента (зависит от модели РД)
  */
class ParameterRadiationPressure : public ParameterStorage
{
private:
	static CTypeSelect * p_rptypeenum;
	static Settings::Enumerator * p_radpressuretype;
	static map < string, string > * p_typeDescrTblname;

public:
	/** @brief Конструктор, создающий таблицу
	  *
	  * @param base Коллекция, в которой создаётся таблица коэффициентов
	  * @param myname Имя создаваемой таблицы
	  *
	  */
	inline ParameterRadiationPressure (DBTableCollection * base,
					   const string & myname )
		: ParameterStorage (base, myname, Columns()<<
				Column(Variant::TYPE_INT, "sat_history_id")<<
                Column(Variant::TYPE_INT, "coefficient_id"))
	{

	}

	/** Метод, вычисляющий ускорение от радиационного давления на КА
	  *
	  * @param sat_history_id Идентификатор КА
	  * @param posvel Положение и скорости КА
	  * @param TAI Эпоха, TAI
	  * @param lambda Коэффициент освещённости КА Солнцем
	  *
	  */
	virtual kinematic < real, 3, defaultInert > calcAcceleration
		(int sat_history_id,
		 const kinematic < real, 6, defaultInert > & posvel,
		 real TAI,
		 real lambda) const = 0;


	/** @brief Метод, добавляющий новую модель РД в список известных
	  *
	  * @param typeString Имя модели, которое будет отображаться в GUI
	  * @param tablename Имя таблицы с коэффициентами
	  */
	static void addRadPressureType (const string & typeString,
					const string & tablename);

	/**
	 * @brief Вернуть указатель на таблицу с параметрами РД
	 * @param data Коллекция таблиц
	 * @return Имя таблицы с параметрами РД
	 */
	static string getRPStorageName(const DBTableCollection & data);


	/** @brief Определить используемую модель РД и вычислить ускорение
	  * @param data Коллекция таблиц
	  * @param sat_historyid Идентификатор КА (ключ в @ref SatelliteHistory)
	  * @param posvel Положение и скорости КА
	  * @param TAI Эпоха, TAI
	  */
	static  kinematic < real, 3, defaultInert > acceleration
			(const DBTableCollection & data,
			 int sat_history_id,
			 const kinematic < real, 6, defaultInert > & posvel,
			 real TAI);
			
};

/** @brief Метод, вычисляющий коэффициент освещённости КА Солнцем
  *
  * @param data Коллекция таблиц
  * @param TAI Эпоха, TAI
  * @param r_satellite Положение КА
  * @return Значение от 0.0 (полная тень) до 1.0 (полная освещённость)
  */
real shadowFactor(real TAI,
			kinematic<real,3,defaultInert> r_satellite);

}

#endif

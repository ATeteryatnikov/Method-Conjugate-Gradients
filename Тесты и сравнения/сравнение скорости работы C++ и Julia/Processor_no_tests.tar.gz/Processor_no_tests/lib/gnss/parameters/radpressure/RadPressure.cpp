#include <map>
#include <string>

using namespace std;

//! @file

#include <RadPressure.h>
#include <StdTables.h>
#include <Kinematic.h>
#include <BuiltIn.h>

namespace libgnss
{


//! @todo Проверить порядок инициализации глобальных переменных!
CTypeSelect * ParameterRadiationPressure::p_rptypeenum;
Settings::Enumerator * ParameterRadiationPressure::p_radpressuretype;
map < string, string > * ParameterRadiationPressure::p_typeDescrTblname;

void ParameterRadiationPressure::addRadPressureType (const string & typeString,
				const string & tablename)
{
	static CTypeSelect rptypeenum ("RadPressureTypeEnumerator",
					   Tuple()<<string("Zero_RadPressure"),0);
	static Settings::Enumerator radpressuretype ("Parameters_settings",
						"Radiation_Pressure_Base",
						"RP_Model",
						&rptypeenum,
						"Модель ускорения от РД",
		string("Zero_RadPressure"));
	static map < string,string > typeDescrTblname;
	p_rptypeenum = &rptypeenum;
	p_radpressuretype = &radpressuretype;
	p_typeDescrTblname = &typeDescrTblname;

	p_rptypeenum->addOption(typeString);
	typeDescrTblname[typeString] = tablename;
}


string ParameterRadiationPressure::getRPStorageName
(const DBTableCollection &data)
{
	Settings * sets = (Settings *)(data.getTable("settings"));
	string RPModel = sets->getSettings(*p_radpressuretype).toString();
	return (*p_typeDescrTblname)[RPModel];
}

kinematic < real, 3, defaultInert > ParameterRadiationPressure::acceleration
(const DBTableCollection & data,
		 int sat_history_id,
		 const kinematic < real, 6, defaultInert > & posvel,
		 real TAI)
{
	string RPTable = getRPStorageName(data);
	ParameterRadiationPressure * rpm = (ParameterRadiationPressure *)
			(data.getTable(RPTable));
	real lambda = shadowFactor(TAI,posvel.subset<0,2>());
	return rpm->calcAcceleration(sat_history_id,posvel,TAI,lambda);
}

#ifdef WithQT

QScriptValue rpacceleration (QScriptContext * ctx, QScriptEngine * eng)
{
	DBTableCollection * c = (DBTableCollection *)(ctx->argument(0).toQObject());
	int sat_id = ctx->argument(1).toInt32();
	QVariantList posvel_ = ctx->argument(2).toVariant().toList();
	kinematic < real, 6, defaultInert > posvel;
	posvel[0] = posvel_[0].toDouble();
	posvel[1] = posvel_[1].toDouble();
	posvel[2] = posvel_[2].toDouble();
	posvel[3] = posvel_[3].toDouble();
	posvel[4] = posvel_[4].toDouble();
	posvel[5] = posvel_[5].toDouble();
	real tai = ctx->argument(3).toNumber();
	kinematic < real, 3, defaultInert > result=
				ParameterRadiationPressure::acceleration(*c,sat_id,posvel,tai);
	QVariantList result_;
	result_<<QVariant((double)result[0])<<QVariant((double)result[1])
										<<QVariant((double)result[2]);
	return eng->toScriptValue<QVariantList>(result_);
}

BuiltIn rpaccel("radPressureAcceleration",4,rpacceleration);

QScriptValue shadowFactor (QScriptContext * ctx, QScriptEngine *eng)
{
	DBTableCollection * c = (DBTableCollection *)(ctx->argument(0).toQObject());
	double TAI = ctx->argument(1).toNumber();
	QVariantList posvel_ = ctx->argument(2).toVariant().toList();
	kinematic < real, 3, defaultInert > posvel;
	posvel[0] = posvel_[0].toDouble();
	posvel[1] = posvel_[1].toDouble();
	posvel[2] = posvel_[2].toDouble();
	return eng->toScriptValue<double>(shadowFactor (TAI, posvel));
}

BuiltIn shadowfact ("shadowFactor", 3, shadowFactor);
#endif

}

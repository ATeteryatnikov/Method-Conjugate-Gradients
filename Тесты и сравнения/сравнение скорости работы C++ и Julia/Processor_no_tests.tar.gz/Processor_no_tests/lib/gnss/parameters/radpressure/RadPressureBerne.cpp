//! @file

#include <RadPressureBerne.h>
#include <ephemeris.h>
#include <Consts.h>
#include <BuiltIn.h>

namespace libgnss
{

ParameterRadPressureBerne::InitBerne ParameterRadPressureBerne::initBerne;

kinematic<real,3,defaultInert>ParameterRadPressureBerne::calcAcceleration
		(int sat_history_id,
		 const kinematic < real, 6, defaultInert > & posvel,
		 real tai,
		 real lambda) const
{

	kinematic<real,3,defaultInert>SatPosInert=posvel.subset<0,2>();
	kinematic<real,3,defaultInert>SatVelInert=posvel.subset<3,5>();

	kinematic<real,3,defaultInert> sun_sat = SatPosInert-
					getCelestialBodyEphemerides(11, tai);

	real sundist = sun_sat.length<0,2>();
	real intensity_coeff = (astrounit*astrounit)/(sundist*sundist);
	real distfct = intensity_coeff;

	Tuple key0;
	key0<<sat_history_id<<(int)(0);


	//Извлечь значения параметров РД

	key0[1] = BERNE_DRAD;
	real DRAD = read(key0)[0].toDouble();

	key0[1] = BERNE_YRAD;
	real YRAD = read(key0)[0].toDouble();

	key0[1] = BERNE_BRAD;
	real BRAD = read(key0)[0].toDouble();

	key0[1] = BERNE_DCOS;
	real DCOS = read(key0)[0].toDouble();

	key0[1] = BERNE_DSIN;
	real DSIN = read(key0)[0].toDouble();

	key0[1] = BERNE_YCOS;
	real YCOS = read(key0)[0].toDouble();

	key0[1] = BERNE_YSIN;
	real YSIN = read(key0)[0].toDouble();

	key0[1] = BERNE_BCOS;
	real BCOS = read(key0)[0].toDouble();

	key0[1] = BERNE_BSIN;
	real BSIN = read(key0)[0].toDouble();

	//Вычислить требуемые вектора RVEC, SVEC, YVEC, BVEC

	//RVEC - единичный вектор направления на КА
	kinematic<real,3,defaultInert> RVEC = SatPosInert*
						(1/SatPosInert.length<0,2>());

	//SVEC = SatPotInert-SunPosInert
	kinematic<real,3,defaultInert> SVEC = sun_sat*(1/sundist);

	//YVEC = RVEC x SVEC
	kinematic<real,3,defaultInert> YVEC =
					(RVEC.crossProduct(SVEC)).normalize();

	//BVEC = YVECxSVEC
	kinematic<real,3,defaultInert> BVEC =
					(YVEC.crossProduct(SVEC)).normalize();

	//Найдём угол СОЗ
	real phi = angleSunEarthObject(SatPosInert, tai);

	//Найдём долготу восходящего узла
	kinematic<real,3,defaultInert> VVEC =
				SatVelInert*(1/SatVelInert.length<0,2>());
	kinematic<real,3,defaultInert> HVEC =
				(RVEC.crossProduct(VVEC)).normalize();
	kinematic<real,3,defaultInert> ZAXIS; ZAXIS[2] = 1.0;
	kinematic<real,3,defaultInert> NVEC =
				(ZAXIS.crossProduct(HVEC));

	real sinu, cosu;
	//! @bug Что делать с долготой восходящего узла, когда орбита экваториальная
	if (NVEC.length<0,2>()==0)
	{
		sinu = 0;
		cosu = 1.0;
	}
	else
	{
		NVEC=NVEC.normalize();
		cosu = NVEC*RVEC;
		kinematic<real,3,defaultInert> NRVEC = NVEC.crossProduct(RVEC);
		real signsinu = NRVEC*HVEC;
		sinu = (signsinu>=0)?(NRVEC.length<0,2>()):
							(-(NRVEC.length<0,2>()));
	}
	real dt = 0;
	real yt = 0;
	real bt = 0;

	kinematic<real,3,defaultInert> result =
			distfct*(SVEC*(lambda * (DRAD+dt) + DCOS*cosu + DSIN*sinu)+
			YVEC*(YRAD+YCOS*cosu+YSIN*sinu+yt)+
			BVEC*(BRAD+BCOS*cosu+BSIN*sinu+bt));

	return result;
}

void ParameterRadPressureBerne::resample(real t0, real t1, const Tuple &subkey)
{
	if (subkey.size() > 1)
		throw StrException("ParameterRadPressureBerne::resample",
			"При перестройке хранилища параметров РД по модели BERNE "
			"в качестве подключа subkey допустимо указывать только "
			"идентификатор НКА.");

	set < int > sat_ids;
	if (subkey.size() > 0)
		sat_ids.insert(subkey[0].toInt());
	else
		for (DBConstIterator it0 = const_begin(); it0!=const_end(); ++it0)
			sat_ids.insert(it0.keyColumnValue(0).toInt());

	//Убедиться, что для каждого КА доступно 9 коэффициентов
	for (set<int>::iterator it0=sat_ids.begin(); it0!=sat_ids.end(); ++it0)
	{
		if (find(Tuple()<<(*it0)<<BERNE_DRAD)==const_end())
			insertRow(Tuple()<<(*it0)<<BERNE_DRAD, Tuple()<<0);
		if (find(Tuple()<<(*it0)<<BERNE_YRAD)==const_end())
			insertRow(Tuple()<<(*it0)<<BERNE_YRAD, Tuple()<<0);
		if (find(Tuple()<<(*it0)<<BERNE_BRAD)==const_end())
			insertRow(Tuple()<<(*it0)<<BERNE_BRAD, Tuple()<<0);
		if (find(Tuple()<<(*it0)<<BERNE_DCOS)==const_end())
			insertRow(Tuple()<<(*it0)<<BERNE_DCOS, Tuple()<<0);
		if (find(Tuple()<<(*it0)<<BERNE_YCOS)==const_end())
			insertRow(Tuple()<<(*it0)<<BERNE_YCOS, Tuple()<<0);
		if (find(Tuple()<<(*it0)<<BERNE_BCOS)==const_end())
			insertRow(Tuple()<<(*it0)<<BERNE_BCOS, Tuple()<<0);
		if (find(Tuple()<<(*it0)<<BERNE_DSIN)==const_end())
			insertRow(Tuple()<<(*it0)<<BERNE_DSIN, Tuple()<<0);
		if (find(Tuple()<<(*it0)<<BERNE_YSIN)==const_end())
			insertRow(Tuple()<<(*it0)<<BERNE_YSIN, Tuple()<<0);
		if (find(Tuple()<<(*it0)<<BERNE_BSIN)==const_end())
			insertRow(Tuple()<<(*it0)<<BERNE_BSIN, Tuple()<<0);
	}
}

#ifdef WithQT
QScriptValue addBerne(QScriptContext * ctx, QScriptEngine * eng)
{
	DBTableCollection * c = (DBTableCollection *)(ctx->argument(0).toQObject());
	ParameterRadPressureBerne * es = new ParameterRadPressureBerne (c);
	return QScriptValue();
}

BuiltIn addBerne_ ("addRadPressureBerneTable", 1, addBerne);
#endif
}

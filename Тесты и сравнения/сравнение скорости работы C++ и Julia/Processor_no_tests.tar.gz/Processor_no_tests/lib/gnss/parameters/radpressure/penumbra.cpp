//Enable UTF-8 encoding to read russian comments
//Файл относится к проекту "Имитатор"

/** @file
* @brief Файл содержит метод shadowFactor класса RightHandSide, находящий коэффициент затенения Солнца.
*/

#include <cmath>

using namespace std;

#include <DBTableCollection.h>
#include <ephemeris.h>
#include <StdTables.h>
#include <precmath.h>

namespace libgnss
{

/** @brief Функция нахождения площади пересечения двух кругов.
*
* @param a Радиус первого круга.
* @param b Радиус второго круга.
* @param c Расстояние между центрами кругов.
* @return Площадь пересечения кругов.
*
* До вызова функции необходимо проверить, что круги пересекаются.
*/
inline real TwoCirclesIntersectionArea ( real a, real b, real c )
{
	real x, y;
	x = 0.5 * ( c * c + a * a - b * b ) / c;
	y = sqrt ( fabs ( a * a - x * x ) ); //На случай ошибки округления вставляем модуль от подкоренного выражения

	return a*a*arccos ( x / a ) + b*b*arccos ( ( c - x ) / b ) - c*y;
}

real shadowFactor(real TAI, kinematic<real,3,defaultInert> r_satellite)
{
	real t = TAI;

	//!	Степень затенения Солнца вычисляется через угловое расстояние и диаметры тел (Солнце, Земля, Луна). Угловые расстояния проецируются на плоскость и находится площадь пересечения дисков.
	kinematic<real,3,defaultInert> r_earth = getCelestialBodyEphemerides(3, t);
	kinematic<real,3,defaultInert> r_sun = getCelestialBodyEphemerides(11, t);
	kinematic<real,3,defaultInert> r_moon = getCelestialBodyEphemerides(10, t);

	//! 1. Оценивается расположение Солнца и Земли, Солнца и Луны по отношению к КА. Это является быстрой проверкой на затенённость Солнца.

	//! @todo Быстрая проверка в данном случае излишня, т.к. её осуществляет метод stepDiv перед вызовом текущего метода, однако для независимой работы функции эта проверка нужна. Подумать, что делать с частично дублирующейся проверкой.
	//Оценка расположения Солнца и Земли и Солнца и Луны по отношению к спутнику.
	//Если они далеко - нет смысла проверять на пересечение
	real r_satellite_sun[3], r_satellite_earth[3], r_satellite_moon[3]; //Вектора, соединяющие два тела
	int i;
	for ( i=0; i<3;++i )
	{
		r_satellite_sun[i]=r_sun[i]-r_satellite[i];
		r_satellite_earth[i]=r_earth[i]-r_satellite[i];
		r_satellite_moon[i]=r_moon[i]-r_satellite[i];
	}

	//Для проверки вычисляется скалярное произведение векторов
	real scal_es=0, scal_ms=0;
	for ( i=0; i<3;++i )
	{
		scal_es+=r_satellite_earth[i]*r_satellite_sun[i];//Земля и Солнце.
		scal_ms+=r_satellite_moon[i]*r_satellite_sun[i];	//Луна и Солнце.
	}


	//Расстояние от спутника до Солнца, Луны и Земли
	real distance_satellite_sun=0, distance_satellite_moon=0, distance_satellite_earth=0;
	//Видимый со спутника радиус (угол) Солнца, Земли и Луны.
	//Видимое расстояние (угол) между центрами Земли и Солнца, Луны и Солнца, Земли и Луны.
	real apparent_r_sun, apparent_r_earth, apparent_r_moon,
	apparent_separation_earth_sun, apparent_separation_moon_sun, apparent_separation_earth_moon;

	//=======================================
	//Если Земля дальше от Солнца, чем спутник
	if ( scal_es<=0 )
	{
		if ( scal_ms<=0 )
		{
			//cout<<"Земля дальше от Солнца, Луна дальше от Солнца, чем спутник"<<endl;
			return 1; //Луна дальше от солнца, чем спутник (при этом Земля тоже дальше)
		}

		//Иначе Луна ближе к солнцу (при этом Земля дальше), чем спутник, поэтому необходимо проверить,
		//не закрывает ли она его.
		//Вычисляем угол (видимый радиус),  под которым Луна и Солнце видны со спутника, находим угловое
		//расстояние (видимое расстояние) между центрами Луны и Солнца.
		for ( i=0; i<3; ++i )
		{
			distance_satellite_sun+=r_satellite_sun[i]*r_satellite_sun[i];
			distance_satellite_moon+=r_satellite_moon[i]*r_satellite_moon[i];
		}
		distance_satellite_sun=sqrt ( distance_satellite_sun );
		distance_satellite_moon=sqrt ( distance_satellite_moon );


		apparent_r_sun = asin ( R_sun/distance_satellite_sun );
		apparent_r_moon=asin ( R_moon/distance_satellite_moon );
		apparent_separation_moon_sun=0;
		for ( i=0; i<3;++i )
			apparent_separation_moon_sun+=r_satellite_moon[i]*r_satellite_sun[i];
		apparent_separation_moon_sun/=distance_satellite_sun*distance_satellite_moon;
		apparent_separation_moon_sun=arccos ( apparent_separation_moon_sun );


		//Проверяем, пересекаются ли тела по выполнению условия |r1-r2|<separation<r1+r2
		//Если не выполнено  separation<r1+r2, то тела далеко
		//Если не выполнено |r1-r2|<separation, то одно тело вложено в другое
		if ( apparent_separation_moon_sun>=apparent_r_sun+apparent_r_moon )
		{
			//cout<<"Земля дальше от Солнца, а Луна не пересекает Солнце"<<endl;
			return 1;
		}

		//Если тела (Солнце и Луна) вложены.
		if ( fabs ( apparent_r_sun-apparent_r_moon ) >=apparent_separation_moon_sun )
		{
			//Видимый радиус Солнца меньше радиуса Луны
			if ( apparent_r_sun<=apparent_r_moon )
			{
				//cout<<"Земля дальше от Солнца, а Солнце полностью закрыто Луной"<<endl;
				return 0;
			}

			//Видимый радиус Солнца больше радиуса Луны.
			//cout<<"Земля дальше от Солнца, а Луна меньше Солнца и вложена в него"<<endl;
			return 1.- ( apparent_r_moon*apparent_r_moon ) / ( apparent_r_sun*apparent_r_sun );
		}

		//Если выполнено условие пересечения тел
		//cout<<"Земля дальше от солнца, а Луна частично закрывает Солнце"<<endl;
		return 1.-TwoCirclesIntersectionArea ( apparent_r_sun,apparent_r_moon, apparent_separation_moon_sun ) / ( Pi*apparent_r_sun*apparent_r_sun );
	}

	//======================================
	//Если Земля ближе к Солнцу, чем спутник
	if ( scal_ms<=0 )   //Луна дальше от солнца, чем спутник, поэтому Солнце может закрыть только Земля
	{

		/*
		Вычисляем угол (видимый радиус),  под которым Земля, Солнце видны со спутника, находим угловое
		расстояние (видимое расстояние) между центрами Земли и Солнца.
		 */
		for ( i=0; i<3; ++i )
		{
			distance_satellite_sun+=r_satellite_sun[i]*r_satellite_sun[i];
			distance_satellite_earth+=r_satellite_earth[i]*r_satellite_earth[i];
		}
		distance_satellite_sun=sqrt ( distance_satellite_sun );
		distance_satellite_earth=sqrt ( distance_satellite_earth );

		apparent_r_sun = asin ( R_sun/distance_satellite_sun );
		apparent_r_earth=asin ( R_earth/distance_satellite_earth );

		apparent_separation_earth_sun=0;
		for ( i=0; i<3;++i )
		{
			apparent_separation_earth_sun+=r_satellite_earth[i]*r_satellite_sun[i];
		}
		apparent_separation_earth_sun/=distance_satellite_sun*distance_satellite_earth;
		apparent_separation_earth_sun=arccos ( apparent_separation_earth_sun );

		//Проверяем, пересекаются ли тела по выполнению условия |r1-r2|<separation<r1+r2
		//Если не выполнено  separation<r1+r2, то тела далеко
		//Если не выполнено |r1-r2|<separation, то одно тело вложено в другое
		if ( apparent_separation_earth_sun>=apparent_r_sun+apparent_r_earth )
		{
			//cout<<"Земля не закрывает Солнце, Луна дальше от Солнца"<<endl;
			return 1;
		}

		//Если Солнце полностью закрыто Землёй
		if ( fabs ( apparent_r_sun-apparent_r_earth ) >=apparent_separation_earth_sun )
		{
						//cout<<"Земля полностью закрывает Солнце, Луна дальше от Солнца"<<endl;
			return 0;
		}

				//Выполнено условие пересечения двух тел
		//cout<<"Земля частично закрывает Солнце, а Луна дальше от Солнца"<<endl;
		return 1.-TwoCirclesIntersectionArea ( apparent_r_sun,apparent_r_earth, apparent_separation_earth_sun ) / ( Pi*apparent_r_sun*apparent_r_sun );

	}

	//===========================================================================================================
	/**	2. Если Земля и Луна ближе к Солнцу, чем КА, то рассматриваются все возможные варианты расположения и перекрытия Солнца дисками Земли и Луны:
	*	<UL>
	*		<LI> Солнце не затенено. Функция возвращает \f$\nu=1\f$.
	*		<LI> Солнце полностью закрыто одним из тел. Функция возвращает \f$\nu=0\f$.
	*		<LI> Одно из тел затеняет Солнце. Функция возвращает \f$\nu\f$ равное доли незатенённого участка Солнца.
	*		<LI> Оба тела частично затеняют Солнце. Функция возвращает \f$\nu\f$ равное доли незатенённого участка Солнца.
	*	</UL>
	*/

	/*
	Вычисляем угол (видимый радиус), под которым Земля Луна и Солнце видны со спутника,
	находим угловое расстояние (видимое расстояние) между центрами (Земли и Солнца), (Луны и Солнца).
	 */
	for ( i=0; i<3; ++i )
	{
		distance_satellite_sun+=r_satellite_sun[i]*r_satellite_sun[i];
		distance_satellite_earth+=r_satellite_earth[i]*r_satellite_earth[i];
		distance_satellite_moon+=r_satellite_moon[i]*r_satellite_moon[i];
	}
	distance_satellite_sun=sqrt ( distance_satellite_sun );
	distance_satellite_earth=sqrt ( distance_satellite_earth );
	distance_satellite_moon=sqrt ( distance_satellite_moon );

	apparent_r_sun = asin ( R_sun/distance_satellite_sun );
	apparent_r_earth=asin ( R_earth/distance_satellite_earth );
	apparent_r_moon=asin ( R_moon/distance_satellite_moon );

	apparent_separation_earth_sun=0;
	apparent_separation_moon_sun=0;
	for ( i=0; i<3;++i )
	{
		apparent_separation_earth_sun+=r_satellite_earth[i]*r_satellite_sun[i];
		apparent_separation_moon_sun+=r_satellite_moon[i]*r_satellite_sun[i];
	}
	apparent_separation_earth_sun/=distance_satellite_sun*distance_satellite_earth;
	apparent_separation_earth_sun=arccos ( apparent_separation_earth_sun );

	apparent_separation_moon_sun/=distance_satellite_sun*distance_satellite_moon;
	apparent_separation_moon_sun=arccos ( apparent_separation_moon_sun );

	/*Проверяем, пересекаются ли тела по выполнению условия |r1-r2|<separation<r1+r2
	Если не выполнено  separation<r1+r2, то тела далеко
	Если не выполнено |r1-r2|<separation, то одно тело вложено в другое*/

	//Если Земля не закрывает солнце

	if ( apparent_separation_earth_sun >= apparent_r_sun + apparent_r_earth )
	{

		//Если Луна не закрывает Солнце
		if ( apparent_separation_moon_sun >= apparent_r_sun + apparent_r_moon )
		{
			//cout << "Земля не закрывает Солнце, Луна не закрывает Солнце" << endl;
			return 1;
		}

		//Если тела (Солнце и Луна) вложены.
		if ( fabs ( apparent_r_sun -apparent_r_moon ) >= apparent_separation_moon_sun )
		{
			//Видимый радиус Солнца меньше радиуса Луны
			if ( apparent_r_sun <= apparent_r_moon )
			{
				//cout << "Земля не закрывает Солнце, Солнце полностью закрыто Луной" << endl;
				return 0;
			}

			//Видимый радиус Солнца больше радиуса Луны.
			//cout << "Земля не закрывает Солнце, Луна меньше Солнца и вложена в него" << endl;
			return 1. - ( apparent_r_moon*apparent_r_moon ) / ( apparent_r_sun*apparent_r_sun );
		}

		//Если выполнено условие пересечения тел (Луны и Солнца)
		//cout << "Земля не закрывает Солнце, Луна частично закрывает Солнце" << endl;
		return 1. - TwoCirclesIntersectionArea ( apparent_r_sun, apparent_r_moon, apparent_separation_moon_sun )
		       / ( Pi*apparent_r_sun*apparent_r_sun );

	}

	//Если Солнце полностью закрыто Землёй
	if ( fabs ( apparent_r_sun - apparent_r_earth ) >= apparent_separation_earth_sun )
	{
		//cout << "Земля полностью закрывает Солнце, положение Луны не важно." << endl;
		return 0;
	}

	//Если выполнено условие пересечения тел (Земли и Солнца)
	//Если Луна не закрывает Солнце
	if ( apparent_separation_moon_sun >= apparent_r_sun + apparent_r_moon )
	{
		//cout << "Земля частично закрывает Солнце, Луна не закрывает Солнце" << endl;
		return 1. - TwoCirclesIntersectionArea ( apparent_r_sun, apparent_r_earth, apparent_separation_earth_sun )
		       / ( Pi*apparent_r_sun*apparent_r_sun );
	}

	//Находим угловое расстояние (видимое расстояние) между центрами Земли и Луны.
	apparent_separation_earth_moon=0;
	for ( i=0; i<3;++i )
	{
		apparent_separation_earth_moon+=r_satellite_earth[i]*r_satellite_moon[i];
	}
	apparent_separation_earth_moon/=distance_satellite_moon*distance_satellite_earth;
	apparent_separation_earth_moon=arccos ( apparent_separation_earth_moon );


	//Если Земля закрывает Луну
	if ( fabs ( apparent_r_earth - apparent_r_moon ) >= apparent_separation_earth_moon )  //В этом случае есть избыток в проверках
	{
		//cout << "Земля частично закрывает Солнце, Луна вложена в Землю" << endl;
		return 1. - TwoCirclesIntersectionArea ( apparent_r_sun, apparent_r_earth, apparent_separation_earth_sun )
		       / ( Pi*apparent_r_sun*apparent_r_sun );
	}

	//Если тела (Солнце и Луна) вложены.
	if ( fabs ( apparent_r_sun - apparent_r_moon ) >= apparent_separation_moon_sun )
	{
		//Видимый радиус Солнца меньше радиуса Луны
		if ( apparent_r_sun <= apparent_r_moon )   //В этом случае есть избыток в проверках, однако его вероятность очень мала
		{
			//cout << "Земля частично закрывает Солнце, Солнце полностью закрыто Луной" << endl;
			return 0;
		}

		//Видимый радиус Солнца больше радиуса Луны.
		//Земля не закрывает Луну
		if ( apparent_separation_earth_moon >= apparent_r_earth + apparent_r_moon )
		{
			//cout << "Земля частично закрывает Солнце, Луна вложена в Солнце и не пересекает Землю" << endl;
			return 1. - ( TwoCirclesIntersectionArea ( apparent_r_sun, apparent_r_earth, apparent_separation_earth_sun )
				      + Pi*apparent_r_moon*apparent_r_moon ) / ( Pi*apparent_r_sun*apparent_r_sun );
		}

		//Если выполнено условие пересечения тел (Луны и Земли)
		//cout << "Земля частично закрывает Солнце, Луна меньше Солнца, вложена в него и частично пересекает Землю" << endl;
		return 1. - ( TwoCirclesIntersectionArea ( apparent_r_sun, apparent_r_earth, apparent_separation_earth_sun )
			      - TwoCirclesIntersectionArea ( apparent_r_moon, apparent_r_earth, apparent_separation_earth_moon )
			      + Pi*apparent_r_moon*apparent_r_moon ) / ( Pi*apparent_r_sun*apparent_r_sun );
	}

	//Если выполнено условие пересечения тел (Луны и Солнца)
	//Земля не закрывает Луну
	if ( apparent_separation_earth_moon >= apparent_r_earth + apparent_r_moon )
	{
		//cout << "Земля частично закрывает Солнце, Луна частично закрывает Солнце и не пересекает Землю" << endl;
		return 1. - ( TwoCirclesIntersectionArea ( apparent_r_sun, apparent_r_earth, apparent_separation_earth_sun )
			      + TwoCirclesIntersectionArea ( apparent_r_sun, apparent_r_moon, apparent_separation_moon_sun ) )
		       / ( Pi*apparent_r_sun*apparent_r_sun );
	}

	//Выполнено условие пересечения трёх тел: Солнца, Земли и Луны.

	//Перенумеруем тела, так чтобы они располагались в порядке уменьшения радиуса
	//ri - радиусы, dij - расстояния между центрами тел i и j.
	real r1, r2, r3;

	real d12, d13, d23;

	r1 = apparent_r_earth;

	if ( apparent_r_sun > apparent_r_moon )
	{
		r2 = apparent_r_sun;
		r3 = apparent_r_moon;
		d12 = apparent_separation_earth_sun;
		d13 = apparent_separation_earth_moon;
	}
	else
	{
		r2 = apparent_r_moon;
		r3 = apparent_r_sun;
		d12 = apparent_separation_earth_moon;
		d13 = apparent_separation_earth_sun;
	}

	d23 = apparent_separation_moon_sun;

	//Вспомогательные значения.
	real x12, y12;
	real cos_theta_p, cos_theta_pp,
	sin_theta_p, sin_theta_pp;
	x12 = 0.5 * ( r1 * r1 - r2 * r2 + d12 * d12 ) / d12;
	y12 = 0.5 * sqrt ( fabs ( 2 * d12 * d12 * ( r1 * r1 + r2 * r2 ) - ( r1 * r1 - r2 * r2 ) * ( r1 * r1 - r2 * r2 ) - d12 * d12 * d12 * d12 ) ) / d12;
	cos_theta_p = 0.5 * ( d12 * d12 + d13 * d13 - d23 * d23 ) / ( d12 * d13 );
	sin_theta_p = sqrt ( fabs ( 1 - cos_theta_p * cos_theta_p ) );
	cos_theta_pp = -0.5 * ( d12 * d12 + d23 * d23 - d13 * d13 ) / ( d12 * d23 );
	sin_theta_pp = sqrt ( fabs ( 1 - cos_theta_pp * cos_theta_pp ) );

	real x13, y13, x13_p, y13_p, x23, y23, x23_pp, y23_pp;
	x13_p = 0.5 * ( r1 * r1 - r3 * r3 + d13 * d13 ) / d13;
	y13_p = -0.5 * sqrt ( fabs ( 2 * d13 * d13 * ( r1 * r1 + r3 * r3 ) - ( r1 * r1 - r3 * r3 ) * ( r1 * r1 - r3 * r3 ) - d13 * d13 * d13 * d13 ) ) / d13;
	x13 = x13_p * cos_theta_p - y13_p * sin_theta_p;
	y13 = x13_p * sin_theta_p + y13_p * cos_theta_p;
	x23_pp = 0.5 * ( r2 * r2 - r3 * r3 + d23 * d23 ) / d23;
	y23_pp = 0.5 * sqrt ( fabs ( 2 * d23 * d23 * ( r2 * r2 + r3 * r3 ) - ( r2 * r2 - r3 * r3 ) * ( r2 * r2 - r3 * r3 ) - d23 * d23 * d23 * d23 ) ) / d23;
	x23 = x23_pp * cos_theta_pp - y23_pp * sin_theta_pp + d12;
	y23 = x23_pp * sin_theta_pp + y23_pp * cos_theta_pp;

	/*Проверяем какой тип пересечения трёх тел в данном случае
	И находим площадь совместного пересечения*/
	real Area_3_body_intersection;

	real t1 = ( x12 - d13 * cos_theta_p ) * ( x12 - d13 * cos_theta_p );

	if ( t1 + ( y12 - d13*sin_theta_p ) * ( y12 - d13*sin_theta_p ) < r3*r3 )
	{
		//Если два (из трёх) тела пересекаются и область пересечения полностью внутри третьего тела (#3.3)
		if ( t1 + ( y12 + d13*sin_theta_p ) * ( y12 + d13*sin_theta_p ) <= r3*r3 )
		{
			Area_3_body_intersection = TwoCirclesIntersectionArea ( r1, r2, d12 );
		}

		//Если выполнены условия существования круглого треугольника пересечения трёх тел (#1)
		//хорды для нахождения площади круглого треугольника
		else
		{
			real c1, c2, c3;
			c1 = sqrt ( ( x12 - x13 ) * ( x12 - x13 ) + ( y12 - y13 ) * ( y12 - y13 ) );
			c2 = sqrt ( ( x12 - x23 ) * ( x12 - x23 ) + ( y12 - y23 ) * ( y12 - y23 ) );
			c3 = sqrt ( ( x13 - x23 ) * ( x13 - x23 ) + ( y13 - y23 ) * ( y13 - y23 ) );

			t1 = 0.25 * c3 * sqrt ( fabs ( 4.0 * r3 * r3 - c3 * c3 ) );

			if ( d13*sin_theta_p >= y13 + ( y23 - y13 ) / ( x23 - x13 ) * ( d13*cos_theta_p - x13 ) )
			{
				t1 *= -1;
			}

			Area_3_body_intersection = 0.25 * sqrt ( fabs ( ( c1 + c2 + c3 ) * ( c2 + c3 - c1 ) * ( c1 + c3 - c2 ) * ( c1 + c2 - c3 ) ) )

									   + r1 * r1 * arcsin ( 0.5 * c1 / r1 ) + r2 * r2 * arcsin ( 0.5 * c2 / r2 ) + r3 * r3 * arcsin ( 0.5 * c3 / r3 )
									   - 0.25 * ( c1 * sqrt ( fabs ( 4.0 * r1 * r1 - c1 * c1 ) ) + c2 * sqrt ( fabs ( 4.0 * r2 * r2 - c2 * c2 ) ) ) + t1;
		}
	}
	else
	{
		if ( x23*x23 + y23*y23 < r1*r1 )
		{
			//Область тройного пересечения - круглый четырехугольник #2
			//Его площадь считать - бессмысленно
			if ( ( x13 - d12 ) * ( x13 - d12 ) + y13*y13 < r2*r2 )
			{
				//Если меньшее вложенное тело Солнце
				if ( apparent_r_sun < apparent_r_moon )
				{
					//cout << "Земля и Луна перекрывают друг друга и полностью закрывают Солнце" << endl;
					return 0;
				}

				//Если меньшее вложенное тело Луна
				//cout << "Земля и Луна перекрывают друг друга и частично закрывают Солнце" << endl;

				return 1. - ( Pi*apparent_r_moon*apparent_r_moon
					      - TwoCirclesIntersectionArea ( apparent_r_moon, apparent_r_earth, apparent_separation_earth_moon )
					      + TwoCirclesIntersectionArea ( apparent_r_sun, apparent_r_earth, apparent_separation_earth_sun ) )
				       / ( Pi*apparent_r_sun*apparent_r_sun );
			}

			//#3.1
			else
			{
				return 1.0 - TwoCirclesIntersectionArea ( apparent_r_sun, apparent_r_earth, apparent_separation_earth_sun ) / ( Pi*apparent_r_sun*apparent_r_sun );
			}
		}
		else
		{
			//#3.2
			if ( ( x13 - d12 ) * ( x13 - d12 ) + y13*y13 < r2*r2 )
			{
				Area_3_body_intersection = TwoCirclesIntersectionArea ( r1, r3, d13 );
			}

			//#4
			else
			{
				Area_3_body_intersection = 0;
			}
		}
	}

//cout << "Земля частично закрывает Солнце, Луна частично закрывает в Солнце, Луна частично перекрывает Землю (или Земля Луну)" << endl;

	return 1. - ( TwoCirclesIntersectionArea ( apparent_r_sun, apparent_r_earth, apparent_separation_earth_sun )
		      + TwoCirclesIntersectionArea ( apparent_r_sun, apparent_r_moon, apparent_separation_moon_sun )
		      - Area_3_body_intersection ) / ( Pi*apparent_r_sun*apparent_r_sun );


}

}

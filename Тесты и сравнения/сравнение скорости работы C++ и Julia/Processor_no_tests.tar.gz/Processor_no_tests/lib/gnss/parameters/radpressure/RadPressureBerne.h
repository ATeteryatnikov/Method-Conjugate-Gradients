#ifndef RADPRESSUREBERNE_H_
#define RADPRESSUREBERNE_H_

//! @file

#include <RadPressure.h>
#include <Types.h>

namespace libgnss
{


class ParameterRadPressureBerne : public ParameterRadiationPressure
{
public:

	static class InitBerne
	{
	public:
		InitBerne()
		{
			ParameterRadiationPressure::addRadPressureType("BERNE",
							"rad_pressure_berne");
		}
	}	initBerne;

	enum Berne_Coefficients
	{
		BERNE_DRAD = 0,
		BERNE_YRAD = 1,
		BERNE_BRAD = 2,
		BERNE_DCOS = 3,
		BERNE_DSIN = 4,
		BERNE_YCOS = 5,
		BERNE_YSIN = 6,
		BERNE_BCOS = 7,
		BERNE_BSIN = 8
	};

	inline ParameterRadPressureBerne (DBTableCollection * base)
		: ParameterRadiationPressure(base,"rad_pressure_berne")
	{

	}


	virtual kinematic < real, 3, defaultInert > calcAcceleration
		(int sat_history_id,
		 const kinematic < real, 6, defaultInert > & posvel,
		 real TAI,
		 real lambda) const;

	/**
	 * @brief Перестройка хранилища уточняемых параметров РД на НКА
	 *
	 * Здесь моменты времени t0, t1 роли не играют; в качестве subkey можно
	 * указывать только идентификатор НКА.
	 */
	virtual void resample(real t0, real t1, const Tuple & subkey = Tuple());
};

}

#endif

#ifndef PHASEAMBIGUITY_H_
#define PHASEAMBIGUITY_H_

#include <InterpolatedParameterStorage.h>
#include <DBTableCollection.h>

namespace libgnss
{

/**
 * @brief Поправка еоднозначности фазовых измерений
 *
 * Ключ:
 * @li int observation_source_id Идентификатор БИС
 * @li int sat_history_id Идентификатор истории НКА
 * @li int freqn Номер частоты
 * @li double Time Секунды TAI от J2000 (в шкале БИС)
 *
 * Значение: double value Значение параметра
 *
 * Данный параметр хранит разность реального фазового измерения и "фазовой
 * дальности" (суммы моделируемой псевдодальности и поправки докрутки фазы).
 * На интервалах непрерывности фазы данный параметр не меняется; он меняется
 * на целое число циклов или полуциклов при разрыве фазы.
 */
class ParamPhaseAmbiguity : public InterpolatedParameterStorage
{
public:
	ParamPhaseAmbiguity(DBTableCollection * base);

	/**
	 * @brief Перестройка параметра фазовой неоднозначности
	 *
	 * Перед перестройкой все существовавшие до этого параметры фазовой
	 * неоднозначности будут удалены (для заданной подключем части хранилища),
	 * поскольку они теряют смысл при изменении моментов времени.
	 *
	 * В качестве подключа можно указывать любое количество полей, от 0 до 3.
	 */
	virtual void resample(real t0, real t1, const Tuple & subkey = Tuple());
};

}

#endif

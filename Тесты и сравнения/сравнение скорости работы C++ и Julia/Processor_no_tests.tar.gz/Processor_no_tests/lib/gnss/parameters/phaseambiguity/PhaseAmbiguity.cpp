//#include <iostream>
#include <set>

using namespace std;

#include <PhaseAmbiguity.h>
#include <observables.h>

namespace libgnss
{


ParamPhaseAmbiguity :: ParamPhaseAmbiguity(DBTableCollection *base)
	: InterpolatedParameterStorage(base, "phase_ambiguity", Columns()
					<<Column(Variant::TYPE_INT, "observation_source_id")
				   <<Column(Variant::TYPE_INT, "sat_history_id")
				  <<Column(Variant::TYPE_INT, "freqn")
				 <<Column(Variant::TYPE_DOUBLE, "Time"))
{
	//Значение параметра на заданный момент времени равно значению
	//параметра в ближайший предшествующий известный момент времени
	//(установить порядок интерполяции 0).
	setInterpolateOrder(Tuple(), 0);
}

void ParamPhaseAmbiguity::resample(real t0, real t1, const Tuple &subkey)
{
	if (subkey.size() > 3)
		throw StrException("ParamPhaseAmbiguity::resample",
						   "Подключ имеет слишком много полей.");
	//Удалить все имеющиеся параметры
	deleteRows(subkey);

	//И заново просмотреть таблицу измерительных данных
	Observables * obs = (Observables *)
			(base->getTable("observables"));
	ObservableTypes * types = (ObservableTypes *)
			(base->getTable("observable_types"));

	int need_obs_src_id = -1;
	int need_sat_history_id = -1;
	int need_freq_id = -1;
	if (subkey.size()>0)
		need_obs_src_id = subkey[0].toInt();
	if (subkey.size()>1)
		need_sat_history_id = subkey[1].toInt();
	if (subkey.size()>2)
		need_freq_id = subkey[2].toInt();

	//Пройти по всем БИС
	for (DBTable::DBConstIterator it = obs->const_begin();
		 it!=obs->const_end(); it.inc(0))
	{
		int obs_src_id = it.keyColumnValue(0).toInt();
		if ((need_obs_src_id !=-1) && (obs_src_id!=need_obs_src_id))
			continue;
		//sat_history_id->freqn->Был ли уже сигнал НКА
		//Первое измерение дальности при появлении НКА из-за горизонта
		//будет помечено БИСом как разрыв фазы. Однако если к моменту начала
		//измерений НКА уже наблюдался, то флаг не будет поставлен. Поэтому
		//необходимо отслеживать, когда НКА появляется в первый раз.
		map < int, set <int > > initsat;

		for(DBTable::DBConstIterator it1 = it; it1!=obs->const_end();
			it1.subinc(3,0))
		{
			//Получить подробности: номер БИС, НКА, характеристики измерения
			real t = it1.keyColumnValue(1).toDouble();
			int sat_history_id = it1.keyColumnValue(2).toInt();
			if ((need_sat_history_id != -1)
					&& (sat_history_id!=need_sat_history_id))
				continue;
			int obstype_id = it1.keyColumnValue(3).toInt();
			Tuple obsdetail = types->read(obstype_id);
			int freqn = obsdetail[2].toInt();
			if ((need_freq_id!= -1) && (freqn!=need_freq_id))
				continue;
			int flag = it1[1].toInt();
			int lli = (flag&(255*65536))/65536;

			//Работать только с фазовыми дальностями
			if (obsdetail[3].toInt()!=ObservableTypes::MTYPE_L)
				continue;


			//Если данный НКА уже наблюдается, и разрыв не отмечен,
			//перейти к следующему измерению
			if ((lli%2 == 0) && (initsat[sat_history_id].find(freqn) !=
					initsat[sat_history_id].end()))
				continue;

			initsat[sat_history_id].insert(freqn);

			//Добавить параметр фазовой неоднозначности
			insertRow(Tuple()<<obs_src_id<<sat_history_id<<freqn<<t,
					  Tuple()<<(real)0);
			//cout<<"Параметр!"<<endl;
		}
	}
}

}

#include <dcb.h>

namespace libgnss
{

ParamDCB::ParamDCB(DBTableCollection *base)
	: InterpolatedParameterStorage(base, "dcb", Columns()
						<<Column(Variant::TYPE_INT, "observation_source_id")
						<<Column(Variant::TYPE_INT, "freq_slot")
						<<Column(Variant::TYPE_INT, "freq")
						<<Column(Variant::TYPE_DOUBLE, "Time"))
{
	//Интерполяция по двум точкам
	setInterpolateOrder(Tuple(),2);
}
}

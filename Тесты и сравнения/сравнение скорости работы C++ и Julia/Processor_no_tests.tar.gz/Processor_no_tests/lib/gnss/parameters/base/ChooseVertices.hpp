#ifndef CHOOSEVERTICES_HPP_
#define CHOOSEVERTICES_HPP_

//! @file

#include <cmath>
#include <vector>

namespace libgnss
{

/** @brief Выбрать на отрезке узлы в соответствии с функцией плотности
 *
 * Функция располагает на отрезке узлы для будущей интерполяции в соответствии
 * с функцией плотности, указатель на которую передаётся в виде аргумента.
 *
 * @tparam ArgPrec Тип чисел с плавающей точкой
 * @tparam DensityFunctionType Тип, для которого определён оператор()(ArgPrec t)
 *
 * @param t0 Начало отрезка
 * @param t1 Конец отрезка
 * @param f Функция плотности
 * @param intdiv Коэффициент, определяющий шаг интегрирования функции плотности
 *
 * Узлы \$\tau_i,\ \tau_0 = t_0,\ \tau_N = t_1\$, располагаются так, чтобы
 * \f[\int\limits_{\tau_i}^{\tau_{i+1}} f(t)\ dt \approx 1.\f]
 *
 * Интегрирование производится численно, а шаг интегрирования равен текущему
 * шагу между выбираемыми узлами, делённому на коэффициент intdiv.
 *
 * Соответственно должна быть определена и функция плотности.
 *
 * Функция плотности f а должна быть определена на интервале [t0; t1+Delta], где
 * интеграл f(t) от t1 до t1+Delta равен 1.
 *
 * Все узлы, кроме, может быть, последнего, располагаются на отрезке [t0;t1].
 * Последний узел может располагаться за пределами интервала, но выбирается,
 * всё равно, с помощью функции плотности.
 *
 */
template < typename ArgPrec, typename DensityFunctionType >
vector < ArgPrec > chooseVertices ( ArgPrec t0, ArgPrec t1,
					const DensityFunctionType & f, int intdiv = 100)
{
	vector < ArgPrec > result;

	ArgPrec curT = t0;
	while (true)
	{
		if (curT > t1)
		{
			curT = t1;
			if (result.size() >= 2)
			{
				int N = result.size();
				result[N-1] = (result[N-2] + curT)*0.5l;
			}
		}
		ArgPrec curDensity = (ArgPrec)f(curT);
		if (curDensity == 0)
			return result;

		result.push_back(curT);

		if (curT>=t1)
			break;

		ArgPrec step = (1/curDensity)/intdiv;

		double densityIntegral = 0;
		while (densityIntegral<1.0)
		{
			densityIntegral += step * f(curT);
			curT += step;
			step = (1/curDensity)/intdiv;
			if (curT >= t1)
				break;
		}
	}

	return result;
}

}

#endif

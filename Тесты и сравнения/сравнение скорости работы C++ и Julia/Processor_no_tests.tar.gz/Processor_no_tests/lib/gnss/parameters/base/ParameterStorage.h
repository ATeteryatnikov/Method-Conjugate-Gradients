#ifndef PARAMETERSTORAGE_H_
#define PARAMETERSTORAGE_H_

#include <string>
//! @file

#include <DBTable.h>
#include <DBTableCollection.h>
#include <Types.h>

namespace libgnss
{

class AParameter;

/** @brief Класс хранилища уточняемых параметров
  *
  * Класс хранилища управляет хранением и доступом к уточняемым параметрам.
  * Для доступа к хранилищу удобно использовать итератор по хранилищу,
  * класс AParameter.
  *
  * Каждый отдельный уточняемый параметр представляет собой скалярную величину.
  * Для выбора конкретной скалярной величины из хранилища используется набор
  * ключевых полей. Таким образом, хранилище представляет собой таблицу, имеющую
  * некоторый (произвольный) набор ключевых полей и одно поле данных, хранящее
  * значения уточняемых параметров.
  *
  * Для объявления нового класса уточняемых параметров необходимо перегрузить
  * методы, на которые возложена основная функциональность хранилища:
  *
  * @li Конструктор: необходимо определить имя хранилища (соответствует типу
  * уточняемых параметров), набор ключевых полей.
  *
  * @li Методы isSatelliteDependent() и isStationDependent(), определяющие,
  * являются ли идентификаторы КА и БИС элементами ключа для доступа к значениям
  * УП, т.е. привязан ли каждый уточняемый параметр данного типа к своему КА
  * или БИС.
  *
  * @li Если каждый Уточняемый параметр данного типа привязан к КА и/или БИС,
  * то необходимо перегрузить методы getSatelliteID() и/или getStationID(),
  * возвращающие ключу параметра (т.е. по соответствующему объекту класса
  * AParameter) номер КА и/или БИС, к которым привязан данный УП.
  *
  */
class ParameterStorage : public DBTable
{
	Q_OBJECT
protected:
	string myname;
	DBTableCollection * base;
public:

	/** @brief Конструктор базового класса хранилища УП
	  *
	  * Конструктор создаёт таблицу, в которой будут храниться значения УП,
	  * и добавляет её в коллекцию таблиц (DBTableCollection). Для этого
	  * необходимо указать:
	  *
	  * @param Base указатель на коллекцию таблиц
	  * @param MyName имя создаваемого хранилища
	  * @param keyColumns набор ключевых полей для индексации УП
	  */
	ParameterStorage (DBTableCollection * Base,const std::string & MyName,
			const Columns & keyColumns)
		:DBTable (keyColumns, Columns()<<Column(Variant::TYPE_DOUBLE,
							"value"))
	{
		Base->addTable(MyName, this);
		base = Base;
		myname = MyName;
	}

	inline DBTableCollection * getBase() const
	{
		return base;
	}

	//! Метод возвращает имя хранилища УП
	inline const string & getName() const
	{
		return myname;
	}

	virtual string describeParameter (const AParameter & a);

	/** @brief Перестройка хранилища
	  *
	  * Данный метод перестраивает хранилище уточняемых параметров для
	  * улучшения обусловленности задачи вычисления и уточнения параметров.
	  *
	  * Для каждого типа параметра условия такого улучшения определяются
	  * индивидуально. Например, для интерполируемых по времени параметров,
	  * таких, как координаты НКА, требуется выставить узлы интерполяции на
	  * оптимальном расстоянии друг от друга.
	  *
	  * Для перестроения хранилища может быть важна информация: временнОй
	  * интервал, на котором предполагается решать задачу, и подключ,
	  * определяющий, какую часть хранилища нужно перестроить.
	  *
	  * @param t0 Начальный момент времени
	  * @param t1 Конечный момент времени
	  * @param subkey Подключ, задающий часть хранилища
	  */
	virtual void resample(real t0, real t1, const Tuple & subkey = Tuple()) = 0;

#ifdef WithQT
public slots:
	QString getMyName() const;
	void resampleMe ( double t0, double t1 );
#endif

};

/** @brief Класс уточняемого параметра
  *
  * При моделировании измерительных данных учитывается некоторый конечный набор
  * величин. Некоторые из этих величин (например, шаги интегрирования) заданы
  * жестко, изменение других величин допустимо.
  *
  * Данный класс представляет описание и доступ к одной скалярной величине,
  * влияющей на процесс моделирования измерительных данных, и допускающих
  * вариацию.
  *
  * Уточняемые параметры содержатся в хранилищах уточняемых параметров
  * ParameterStorage, объекты данного класса являются итераторами по хранилищам.
  */
class AParameter : public DBTable ::DBIterator
{
public:
	AParameter ( const DBTable::DBIterator & it )
		:DBTable::DBIterator (it)
	{

	}

	inline real getValue() const
	{
		Variant x = (*((DBConstIterator*)(this)))[0];
		return x.toDouble();
	}

	inline void setValue ( real x )
	{
		updateCell(0,x);
		//(*this)[0] = (maxprec)(x);
	}

	inline string describeMe ()
	{
		return ((ParameterStorage * )parent)->describeParameter(*this);
	}
};

}

#endif

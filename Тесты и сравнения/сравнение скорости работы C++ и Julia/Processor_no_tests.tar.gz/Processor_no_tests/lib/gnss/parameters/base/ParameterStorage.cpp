#include <sstream>

using namespace std;

//! @file

#include <ParameterStorage.h>

namespace libgnss
{

string ParameterStorage::describeParameter(const AParameter &a)
{
	stringstream info;
	info<<"Параметр: "
		<<getName()<<" ";

	for (unsigned int i=0; i<getKeyColumns().size(); i++)
	{
		info<<getKeyColumns()[i].second<<": "
		   <<a.keyColumnValue(i).toString()<<" ";
	}
	return info.str();
}

#ifdef WithQT
QString ParameterStorage::getMyName() const
{
	return QString::fromStdString(getName());
}

void ParameterStorage::resampleMe ( double t0, double t1 )
{
	resample(t0, t1);
}
#endif

}

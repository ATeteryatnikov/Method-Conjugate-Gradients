//! @file

#include <InterpolatedParameterStorage.h>
#include <DBInterpolate.h>
#include <ChooseVertices.hpp>
#include <StdTables.h>

namespace libgnss
{


ParameterApproximationException::ParameterApproximationException
(const string& paramname, real t0, const Tuple& subkey,
 const InterpolatedParameterStorage* s, const string &what)

	: StrException("ParameterApproximationException",
		  "При вычислении параметра '"+paramname +"' в момент времени "
		+Variant(t0).toString()+" для значения подключа: "
		+ s->tuplePrettyPrint(subkey,Tuple()) + " возникла ошибка: "+what)
{

}

InterpolatedParameterStorage:: InterpolatedParameterStorage
			(DBTableCollection * Base,
			const std::string & MyName,
			const Columns & keyColumns
			)
	: ParameterStorage (Base, MyName, keyColumns)
{
	interpolateorder = 0;
	extrlimit = -1;
	maxinterplimit = -1;

	// Создать таблицу для порядков интерполяционного многочлена
	Columns subkey = keyColumns;
	subkey.pop_back();
	InterpolateOrders = new DBTable(subkey,Columns()<<
				       Column(Variant::TYPE_INT, "order"));
	Base->addTable(MyName+"_interpolate_orders",InterpolateOrders);
	ExtrLimits = new DBTable(subkey, Columns()<<Column(Variant::TYPE_DOUBLE,
														 "limit"));
	Base->addTable(MyName+"_extrapolation_limit", ExtrLimits);
	MaxVerticesSteps =new DBTable(subkey,Columns()<<Column(Variant::TYPE_DOUBLE,
														   "limit"));
	Base->addTable(MyName+"_vertices_steps",MaxVerticesSteps);
	Discontinuities = new DBTable(keyColumns, Columns());
	Base->addTable(MyName+"_discontinuities",Discontinuities);

	if ((keyColumns[keyColumns.size()-1].first != Variant::TYPE_DOUBLE) ||
			(keyColumns[keyColumns.size()-1].second != "Time"))
		throw TableInappropriateForInterpolation(
				"последняя колонка таблицы должна "
				"соответствовать времени.");

	stddensity = 0;
}

InterpolatedParameterStorage::~InterpolatedParameterStorage()
{
	base->deleteTable(getName()+"_interpolate_orders");
	base->deleteTable(getName()+"_extrapolation_limit");
	base->deleteTable(getName()+"_vertices_steps");
	base->deleteTable(getName()+"_discontinuities");
	delete InterpolateOrders;
	delete ExtrLimits;
	delete MaxVerticesSteps;
	delete Discontinuities;
}

real InterpolatedParameterStorage::getParameterValue(const Tuple &k,
							real t) const
{
	int interpOrder = getInterpolateOrder(k);
	real approxlimit = getExtrapolationLimit (k);
	real maxintstep = getMaxVerticesStep( k);
	try
	{
		return interpolate(*this,Discontinuities,k,t,0,interpOrder,approxlimit,
						   maxintstep);
	}
	catch (const ApproximationError & e)
	{
		throw ParameterApproximationException(getName(), t, k, this,
											  e.what());
	}
}

vector<real> InterpolatedParameterStorage::getParameterValueAndDerivs
(const Tuple & k, real t, int derivscount) const
{
	if (derivscount == 0)
		return vector<real>(1,getParameterValue(k,t));
	int interpOrder = getInterpolateOrder(k);
	real approxlimit = getExtrapolationLimit (k);
	real maxintstep = getMaxVerticesStep (k);
	try
	{
		return approximate(*this, Discontinuities, k, t, 0, interpolateorder,
			interpOrder-1,derivscount,approxlimit,maxintstep);
	}
	catch (const ApproximationError  & e)
	{
		throw ParameterApproximationException(getName(), t, k, this,
											  e.what());
	}
}


double InterpolatedParameterStorage::getDensity(const Tuple &k, real t)
{
	//Если данный стандартный метод уже был вызван ранее,
	//вернуть его прежний результат, так как алгоритм метода не предполагает
	//изменения этого результата.
	if (stddensity != 0)
		return stddensity;

	//Проверить, загружена ли таблица настроек
	Settings * sets;
	try
	{
		sets = (Settings *)(base->getTable("settings"));
	}
	catch (exception e)
	{
		return 0;
	}

	//Проверить, есть ли в таблице настроек нужная настройка
	real result;
	try
	{
		result = sets->getSettings(
		"Parameters_settings",myname,"Sampling_density").toDouble();
		stddensity = result;
		return result;
	}
	catch(SettingsNotDefinedException e)
	{
		return 0;
	}
}

class DensityFunctor
{
private:
	InterpolatedParameterStorage * storage;
	Tuple key0;
public:
	DensityFunctor(InterpolatedParameterStorage * s,
		       Tuple k0)
	{
		storage = s;
		key0 = k0;
	}

	double operator() (real t) const
	{
		return storage->getDensity(key0, t);
	}
};

int InterpolatedParameterStorage::getVStepDiv(const Tuple & subkey)
{
	return 100;
}

real InterpolatedParameterStorage::getMaxT(const Tuple &k)
{
	Tuple sk = k;
	sk << numeric_limits<real>::infinity();
	DBConstIterator it = lower_bound(sk);
	if (it.isEnd())
		return numeric_limits<real>::quiet_NaN();
	return it.keyColumnValue(getKeyColumnsCount()-1).toDouble();
}

real InterpolatedParameterStorage::getMinT(const Tuple &k)
{
	Tuple sk = k;
	sk << (-numeric_limits<real>::infinity());
	DBConstIterator it = upper_bound(sk);
	if (it.isEnd())
		return numeric_limits<real>::quiet_NaN();
	return it.keyColumnValue(getKeyColumnsCount()-1).toDouble();
}

void InterpolatedParameterStorage::resample(real t0, real t1,
											const Tuple &subkey)
{
	//Пройти по всем значениям подключа
	int M = subkey.size();
	if (M==getKeyColumns().size())
		return;
	int N = getKeyColumns().size()-1;
	for (DBConstIterator it0 = find(subkey); it0!=const_end();
		 it0.subinc(N-1,M-1))
	{
		real approxrestr = getExtrapolationLimit(it0.subkey(N));
		real t0_this = t0;
		real t1_this = t1;
		if (approxrestr >= 0)
		{
			t0_this = it0.keyColumnValue(N).toDouble()-approxrestr;
			DBConstIterator it1 = it0;
			it1.inc(N-1);
			it1--;
			t1_this = it1.keyColumnValue(N).toDouble()+approxrestr;
			if (t1_this > t1)
				t1_this = t1;
			if (t0_this < t0)
				t0_this = t0;
		}

		//Выбрать моменты времени с использованием функции плотности
		Tuple key0 = it0.subkey(N);
		vector < real > epochs = chooseVertices(t0_this,t1_this,
						DensityFunctor(this, key0), getVStepDiv(key0));

		//Вычислить значения параметра в выбранные моменты времени
		vector < double > values(epochs.size());
		for (unsigned int i=0; i<epochs.size(); i++)
			values[i] = getParameterValue(key0, epochs[i]);

		//Удалить старые узлы интерполяции
		deleteRows(key0);

		key0<<Variant();

		//Скопировать новые узлы
		for (unsigned int i=0; i<epochs.size(); i++)
		{
			key0[N] = (real)((real)(epochs[i]));
			insertRow(key0,Tuple()<<(real)(values[i]));
		}

		//После удаления итератор it0 может стать некорректным.
		//Восстановить его по имеющемуся ключу
		it0 = find(key0);
	}
}

void InterpolatedParameterStorage::setExtrapolationLimit
(const Tuple& k, real limit)
{
	if (k.size() == 0)
		extrlimit = limit;
	else
	{
		if (ExtrLimits->find(k) == ExtrLimits->const_end())
			ExtrLimits->insertRow(k,Tuple()<<limit);
		else
			ExtrLimits->updateCell(k,0,limit);
	}
}


void InterpolatedParameterStorage::setInterpolateOrder(const Tuple &k,
						       int order)
{
	if (k.size() == 0)
		interpolateorder = order;
	else
	{
		if (InterpolateOrders->find(k) == InterpolateOrders->const_end())
			InterpolateOrders->insertRow(k,Tuple()<<order);
		else
			InterpolateOrders->updateCell(k,0,order);
	}
}

void InterpolatedParameterStorage::setMaxVerticesStep(const Tuple &k,
													 real limit)
{
	if (k.size() == 0)
		maxinterplimit = limit;
	else
	{
		if (MaxVerticesSteps->find(k) == MaxVerticesSteps->const_end())
			MaxVerticesSteps->insertRow(k, Tuple()<<limit);
		else
			MaxVerticesSteps->updateCell(k,0,limit);
	}
}

#ifdef WithQT
double InterpolatedParameterStorage::getParameterValue (QVariantList & k, 
														double t) const
{
	return getParameterValue(variantListToTuple(k),t);
}

//-----------Скриптовые обертки ------//

double InterpolatedParameterStorage::getParameterValue (const QVariantList & k,
														double t) const
{
	return getParameterValue(variantListToTuple(k), t);
}

QVariantList InterpolatedParameterStorage::getParameterValueAndDerivs(
		const QVariantList & k, double t, int derivscount) const
{
	vector < real > result_ = getParameterValueAndDerivs(
				variantListToTuple(k), t, derivscount);
	QVariantList result;
	for (unsigned int i=0; i<result_.size(); i++)
		result.push_back((double)result_[i]);
	return result;
}

void InterpolatedParameterStorage::setInterpolateOrder ( const QVariantList & k,
														 int order)
{
	setInterpolateOrder(variantListToTuple(k),order);
}

void InterpolatedParameterStorage::setExtrapolationLimit(const QVariantList & k,
														 double limit)
{
	setExtrapolationLimit(variantListToTuple(k), limit);
}

void InterpolatedParameterStorage::setMaxVerticesStep(const QVariantList & k,
													  double limit)
{
	setMaxVerticesStep(variantListToTuple(k), limit);
}

double InterpolatedParameterStorage::getExtrapolationLimit(const QVariantList&k)
const
{
	return getExtrapolationLimit(variantListToTuple(k));
}

int InterpolatedParameterStorage::getInterpolateOrder(const QVariantList & k)
const
{
	return getInterpolateOrder(variantListToTuple(k));
}

double InterpolatedParameterStorage::getMaxVerticesStep(const QVariantList & k)
const
{
	return getMaxVerticesStep(variantListToTuple(k));
}

void InterpolatedParameterStorage::addDiscontinuity(const QVariantList & k)
{
	addDiscontinuity(variantListToTuple(k));
}

QScriptValue InterpolatedParameterStorage::discontinuitiesTable ()
{
	return engine->newQObject((QObject*)(getDiscontinuitiesTable()),
							  QScriptEngine::QtOwnership);
}
#endif

}

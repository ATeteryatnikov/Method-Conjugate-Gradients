#ifndef INTERPOLATEPARAMETERSTORAGE_H_
#define INTERPOLATEPARAMETERSTORAGE_H_

//! @file

#include <set>
#include <ParameterStorage.h>

namespace libgnss
{

class InterpolatedParameterStorage;

class ParameterApproximationException : public StrException
{
public:

	ParameterApproximationException(const string & paramname, real t0,
		const Tuple & subkey, const InterpolatedParameterStorage * s,
									const string & what);
};

/** @brief Класс, представляющий линейно интерполируемый по времени параметр
  *
  * Пусть значения какого-либо параметра зависят от некоторого набора ключевых
  * полей, последним из которых является время, причем для каждого
  * фиксированного набора значений всех ключевых полей, кроме времени,
  * параметр представляет собой непрерывную функцию. Будем считать все
  * значения параметра в разные моменты времени при фиксированных значениях
  * всех ключевых полей, кроме времени, узлами интерполяции. Тогда помимо
  * моментов времени, в которые значение параметра известно, можно вычислять
  * значения данного параметра в любой момент времени.
  *
  * Для правильной работы необходимо указать количество узлов интерполяции.
  *
  * Хранилище допускает существование разрывов в параметре. Разрывы добавляются
  * методом @ref addDiscontinuity().
  *
  * Если существует разрыв, по времени не совпадающий ни с одним из узлов
  * интерполяции, то при интерполяции значений слева будут задействованы только
  * левые узлы, а справа - только правые; в точке разрыва значение не будет
  * определено. Если разрыв приходится на узел интерполяции, это означает, что
  * разрыв не в параметре, а в скорости его изменения; таким образом, узел,
  * совпадающий по времени с моментом разрыва, будет использован для
  * интерполяции значений и слева и справа.
  */
class InterpolatedParameterStorage : public ParameterStorage
{
	Q_OBJECT
protected:
	int interpolateorder;
	DBTable * InterpolateOrders;
	real extrlimit;
	DBTable * ExtrLimits;
	real maxinterplimit;
	DBTable * MaxVerticesSteps;
	DBTable * Discontinuities;
	Tuple keyPrefix;
	double stddensity;

	/**
	 * @brief Метод, определяющий точность расстановки узлов интерполяции
	 * @param subkey Подключ
	 *
	 * Расстановка узлов интерполяции делается путем интегрирования функции
	 * плотности. Интегрирование производится численно, причем его шаг равен
	 * текущему шагу между узлами (1/плотность), делёному на коэффициент.
	 * Данный метод возвращает как раз этот коэффициент.
	 *
	 * Коэффициент можно определить отдельно для каждого значения подключа
	 * (т.е. ключа, за исключением поля Time).
	 *
	 * @return Коэффициент, задающий шаг интегрирования функции плотности узлов
	 */
	virtual int getVStepDiv(const Tuple & subkey);
public:

	/** @brief Конструктор хранилища
	  *
	  * @param Base Коллекция таблиц, в котороую добавится хранилище
	  * @param MyName Имя создаваемого хранилища
	  * @param keyColumns Список ключевых полей
	  * @param interpolateOrder Порядок интерполяции
	  */
	InterpolatedParameterStorage (DBTableCollection * Base,
				      const std::string & MyName,
				      const Columns & keyColumns
				      );

	~InterpolatedParameterStorage();

	virtual real getParameterValue (const Tuple & k, real t) const;
	
	vector<real> getParameterValueAndDerivs (const Tuple & k, real t,
		int derivscount) const;

	/** @brief Метод, перестраивающий хранилище интерполируемого УП
	  *
	  * @param t0 Начальный момент времени
	  * @param t1
	  * @param subkey
	  *
	  * При работе данного метода выбираются новые узлы интерполяции,
	  * а значения в них вычисляются с использованием старых узлов
	  * интерполяции. После того, как новые узлы вычислены, старые узлы
	  * удаляются.
	  *
	  * Для правильной работы метода resample() требуется задать функцию
	  * плотности getDensity().
	  *
	  * Метод предназначен для вызова при уже имеющемся табличном задании
	  * параметров.
	  */
	virtual void resample(real t0, real t1, const Tuple & subkey=Tuple());

	/** @brief Метод, возвращающий требуемую плотность расположения узлов
	  * интерполяции после перестройки
	  *
	  * Для перевыбора узлов интерполяции при перестройке хранилища
	  * требуется задать требуемую плотность расположения узлов после
	  * перестройки хранилища. Данный метод должен возвращать в результате
	  * число, равное требуемому количеству узлов на 1 секунду.
	  *
	  * В стандартной реализации он лишь пытается получить это количество
	  * узлов из таблицы настроек. Если это не удаётся, возвращается 0,
	  * и метод resample() завершает работу с ошибкой "Невозможно прочитать
	  * параметры перестройки хранилища".
	  *
	  * Значения плотности функция будет читать из таблицы Settings с
	  * ключами:
	  *
	  * Group = "Parameters_settings"
	  * Module = <MyName> (имя параметра)
	  * Key = "Sampling_density"
	  *
	  * Значение поля Value будет восприниматься как число с плавающей
	  * точкой, и будет возвращено как результат работы данного метода.
	  */
	virtual double getDensity ( const Tuple & k, real t );

	/** @brief Установить число узлов интерполяции
	  *
	 * Ключ должен быть либо пустым, либо содержать все ключевые поля таблицы,
	 * кроме момента времени.
	  *
	  * @param k Значения подключа, для которого задаётся степень многочлена
	  * @param order Число узлов интерполяции
	  */
	void setInterpolateOrder ( const Tuple & k, int order );

	/**
	 * @brief Возвращает наибольший момент времени с данным значением подключа
	 * @param k Подключ (ключ без поля времени)
	 * @return Метка времени, секунды от 12:00 01.01.2000 TAI
	 */
	real getMaxT( const Tuple & k);

	/**
	 * @brief Возвращает наименьший момент времени с данным значением подключа
	 * @param k Подключ (ключ без поля времени)
	 * @return Метка времени, секунды от 12:00 01.01.2000 TAI
	 */
	real getMinT( const Tuple & k);

	/**
	 * @brief Установить ограничение экстраполяции
	 * @param k Подключ
	 * @param limit Ограничение экстраполяции
	 *
	 * Для каждого значения подключа (ключа, за исключением последнего поля,
	 * времени) можно установить своё ограничение на экстраполяцию параметра.
	 * При указании пустого ключа ограничение устанавливается для всех значений
	 * подключа.
	 *
	 * Его влияние на выбор узлов аппроксимации см. в @ref getNeighbourhood().
	 */
	void setExtrapolationLimit ( const Tuple & k, real limit);

	/**
	 * @brief Задать максимальное расстояние между соседними узлами интерполяции
	 * @param k Подключ
	 * @param limit Максимально допустимое расстояние между узлами интерполяции
	 *
	 * Для каждого значения подключа (ключа, за исключением последнего поля,
	 * времени) можно установить своё ограничение на экстраполяцию параметра.
	 * Подключ должен быть или пустым, либо содержать все ключевые поля таблицы,
	 * кроме момента времени. Если он пустой, то ограничение устанавливается для
	 * всех подключей.
	 *
	 * Его влияние на выбор узлов аппроксимации см. в @ref getNeighbourhood().
	 */
	void setMaxVerticesStep ( const Tuple & k, real limit );

	inline real getExtrapolationLimit ( const Tuple & k ) const
	{
		if (ExtrLimits->count() == 0)
			return extrlimit;
		DBTable::DBConstIterator it = ExtrLimits->find(k);
		if (it==ExtrLimits->const_end())
			return extrlimit;
		else
			return it[0].toDouble();
	}
	
	inline int getInterpolateOrder ( const Tuple & subkey ) const
	{
		if (InterpolateOrders->count() == 0)
			return interpolateorder;
		DBTable::DBConstIterator it = InterpolateOrders->find(subkey);
		if (it == InterpolateOrders->const_end())
			return interpolateorder;
		else
			return it[0].toInt();
	}

	inline real getMaxVerticesStep ( const Tuple & subkey ) const
	{
		if (MaxVerticesSteps->count() == 0)
			return maxinterplimit;
		DBTable::DBConstIterator it = MaxVerticesSteps->find(subkey);
		if (it == MaxVerticesSteps->const_end())
			return maxinterplimit;
		else
			return it[0].toDouble();
	}

	/**
	 * @brief Добавить разрыв
	 * @param discontinuity Ключ разрыва
	 */
	inline void addDiscontinuity (const Tuple & discontinuity)
	{
		//Попробовать вставить разрыв - если он есть, вставлять ничего не надо
		//Если произошла другая ошибка - не ловить её.
		try
		{
			Discontinuities->insertRow(discontinuity, Tuple());
		}
		catch (const DuplicateKeyException & e)
		{

		}
	}

	/** @brief Удалить разрывы
	 * @param discontinuity Ключ разрыва или нескольких разрывов
	  */
	inline void deleteDiscontinuity(const Tuple & discontinuity)
	{
		Discontinuities->deleteRows(discontinuity);
	}

	//! Возвращает константную ссылку на таблицу разрывов
	inline const DBTable * getDiscontinuitiesTable ()
	{
		return Discontinuities;
	}

#ifdef WithQT
public slots:
	double getParameterValue (QVariantList & k, double t) const;
//---
	double getParameterValue (const QVariantList & k, double t) const;
	QVariantList getParameterValueAndDerivs(const QVariantList & k,
											double t, int derivscount) const;
	void setInterpolateOrder ( const QVariantList & k, int order);
	void setExtrapolationLimit(const QVariantList & k, double limit);
	void setMaxVerticesStep(const QVariantList & k, double limit);
	double getExtrapolationLimit(const QVariantList & k) const;
	int getInterpolateOrder(const QVariantList & k) const;
	double getMaxVerticesStep(const QVariantList & k) const;
	void addDiscontinuity(const QVariantList & k);
	QScriptValue discontinuitiesTable ();
#endif
};

}

#endif

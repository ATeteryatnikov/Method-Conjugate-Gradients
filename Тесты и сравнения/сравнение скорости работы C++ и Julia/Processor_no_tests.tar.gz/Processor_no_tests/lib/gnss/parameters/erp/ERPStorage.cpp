
using namespace std;

//! @file

#include <ERPStorage.h>
// !!! В ЭТОМ ФАЙЛЕ РЕАЛИЗАЦИИ ТОЛЬКО НЕПАРАЛЛЕЛЬНЫХ МЕТОДОВ! !!!

#include <Distribute.hpp>
#include <Consts.h>
#include <StdTables.h>
#include <BuiltIn.h>
#include <sofa.h>


namespace libgnss
{

NoERPException::NoERPException(real t)
	: StrException("NoERPException","Не удалось считать ПВЗ на момент времени "+
				   UTCDateTime::fromTAIJ2000(t).getUTCDateTimeString())
{

}

void mkmatrix_cio(double tai, double pmx, double pmy, double tai_ut1,
				  double dx, double dy, double dpmx, double dpmy, double dtai_ut1, double matrix [3][3],
				  double  dmatrix[3][3], double ddmatrix[3][3], int ddm)
{
	double tt = (tai+32.184) / jsecondsPerDay;
	double dx06 = dx * AS2R / 1000;
	double dy06 = dy * AS2R / 1000;
	double x, y;
	iauXy06( DJ00, tt, &x, &y);
	double s = iauS06(DJ00, tt, x, y );
	x = x + dx06;
	y = y + dy06;
	double rc2i0 [3][3];
	iauC2ixys(x, y, s, rc2i0);

	//Вычислим матрицу вращения Земли и её производные
	double ut1=(tai-tai_ut1) / jsecondsPerDay; // Время UT1 в юлианских сутках
	double era = iauEra00( DJ00, ut1 ); // Вычисляем угол вращения Земли.

	//Матрица поворота
	double rt[3][3];
	iauIr(rt);
	iauRz(era,rt);

	//Матрица движения полюсов
	double rpom[3][3];
	iauPom00(pmx*AS2R, pmy*AS2R, iauSp00(DJ00,tt), rpom);

	//Вычисляем матрицу перехода ITRF->GCRS и её производные
	// matrix = RPOM0 * RT * RC2I
	iauRxr(rt, rc2i0, matrix);
	iauRxr(rpom,matrix,matrix);

	if (ddm>0)
	{

		double rc2i1[7][3][3];

		for (int i=-3; i<=3; i++)
		{
			if ((i==0) && (ddm==1))
				continue;
			double x1, y1;
			iauXy06(DJ00,tt+i/(86400.0l), &x1, &y1);
			double s1 = iauS06(DJ00, tt+i/(86400.0l), x1, y1);
			x1 = x1 + dx06;
			y1 = y1 + dy06;
			iauC2ixys(x1,y1,s1,rc2i1[i+3]);
		}

		//Производные от матрицы небесного полюса
		double drc2i[3][3], ddrc2i[3][3];

		for (unsigned int i=0; i<3; i++)
			for (unsigned int j = 0; j<3; j++)
			{
				drc2i[i][j] = (45*(rc2i1[4][i][j]/*+1*/-rc2i1[2][i][j]/*-1*/)
						+9*(rc2i1[1][i][j]/*-2*/-rc2i1[5][i][j]/*+2*/)
						+ rc2i1[6][i][j]/*+3*/-rc2i1[0][i][j]/*-3*/) / 60.0l;

				ddrc2i[i][j] = (270*(rc2i1[4][i][j]+rc2i1[2][i][j]/*-1*/)
						-27*(rc2i1[1][i][j]/*-2*/+rc2i1[5][i][j]/*+2*/)
						+2*(rc2i1[0][i][j]/*-3*/+rc2i1[6][i][j]/*+3*/)
						-490*rc2i1[3][i][j]/*0*/)/180.0l;
			}

		double dmatrix1[3][3];

		iauRxr(rt,drc2i, dmatrix1);
		iauRxr(rpom, dmatrix1, dmatrix1);

		//Производная от матрицы вращения Земли вокруг своей оси
		double drt[3][3];
		double rpi2[3][3];
		iauIr(rpi2);
		iauRz(Pi/2.0l,rpi2);
		iauIr(drt);
		drt[2][2] = 0.0l;
		double omega = 0.000072921151467069794; //Оборотов в сутки
		double rpi2rt[3][3];
		iauRxr(rpi2, rt, rpi2rt);
		for (int i=0; i<2; i++)
			for (int j=0; j<2; j++)
				drt[i][j] = omega * (1-dtai_ut1) * rpi2rt[i][j];

		//Производная RPOM
		double rpom1[7][3][3];
		double drpom[3][3];
		double ddrpom[3][3];
		for (int i=-3; i<=3; i++)
			iauPom00((pmx+(i*dpmx))*AS2R,(pmy+(i*dpmy))*AS2R,
					 iauSp00(DJ00,tt+i/86400.0l), rpom1[i+3]);

		for (unsigned int i=0; i<3; i++)
			for (unsigned int j = 0; j<3; j++)
			{
				drpom[i][j] = (45*(rpom1[4][i][j]/*+1*/-rpom1[2][i][j]/*-1*/)
						+9*(rpom1[1][i][j]/*-2*/-rpom1[5][i][j]/*+2*/)
						+ rpom1[6][i][j]/*+3*/-rpom1[0][i][j]/*-3*/) / 60.0l;

				ddrpom[i][j] = (270*(rpom1[4][i][j]+rpom1[2][i][j]/*-1*/)
						-27*(rpom1[1][i][j]/*-2*/+rpom1[5][i][j]/*+2*/)
						+2*(rpom1[0][i][j]/*-3*/+rpom1[6][i][j]/*+3*/)
						-490*rpom1[3][i][j]/*0*/)/180.0l;
			}

		double dmatrix2[3][3];
		iauRxr(rt, rc2i0, dmatrix2);
		iauRxr(drpom, dmatrix2, dmatrix2);

		//Считаем все остальные матрицы не меняющимися по времени
		iauRxr(drt, rc2i0, dmatrix);
		iauRxr(rpom, dmatrix, dmatrix);
		for (unsigned int i=0; i<3; i++)
			for (unsigned int j=0; j<3; j++)
				dmatrix[i][j]+=(dmatrix1[i][j]+dmatrix2[i][j]);

		//Вычисление второй производной
		if (ddm > 1)
		{
			//Вторая производная от матрицы вращения вокруг оси
			double ddrt[3][3];

			double rpi2drt[3][3];
			iauRxr(rpi2, drt, rpi2drt);

			iauIr(ddrt);
			ddrt[2][2]=0.0l;
			for (unsigned int i=0; i<2; i++)
				for (unsigned int j=0; j<2; j++)
					ddrt[i][j] = omega * rpi2drt[i][j]/* * (1-ddtai_ut1)*/;
							//- omega * tai_ut1 * rpi2rt[i][j];

			double rpom_drt_drc2i[3][3];
			iauRxr(drt,drc2i,rpom_drt_drc2i);
			iauRxr(rpom,rpom_drt_drc2i,rpom_drt_drc2i);

			double rpom_ddrt_rc2i[3][3];
			iauRxr(ddrt,rc2i0,rpom_ddrt_rc2i);
			iauRxr(rpom, rpom_ddrt_rc2i,rpom_ddrt_rc2i);

			//rpom_rt_ddrc2i
			iauRxr(rt,ddrc2i,ddmatrix);
			iauRxr(rpom,ddmatrix,ddmatrix);

			for (unsigned int i=0; i<3; i++)
				for (unsigned int j=0; j<3; j++)
					ddmatrix[i][j]+=(rpom_drt_drc2i[i][j]+rpom_ddrt_rc2i[i][j]);
		}
	}
}


Settings::Enumerator pmdens ("Parameters_settings","ERP","PM_Sampling",
			     Variant::TYPE_DOUBLE,
			     "Плотность узлов интерполяции параметров "
			     "смещения полюсов",
			     Variant((real)(1.0/86400.0)));

Settings::Enumerator ut1dens ("Parameters_settings","ERP","TAI_UT1_Sampling",
			     Variant::TYPE_DOUBLE,
			     "Плотность узлов интерполяции параметра "
			     "неравномерности вращения Земли",
			     Variant((real)(1.0/86400.0)));

Settings::Enumerator erporder("Parameters_settings","ERP","InterpolateOrder",
					Variant::TYPE_INT,
				"Порядок интерполяции параметров вращения Земли",
				Variant(4));

ERPStorage::ERPStorage(DBTableCollection *base)
	: InterpolatedParameterStorage(
		  base,
		  "ERP",
		  Columns()<<Column(Variant::TYPE_INT, "Component")
			  <<Column(Variant::TYPE_DOUBLE, "Time"))
{
	//setInterpolateOrder(Tuple(),4);
	setExtrapolationLimit(Tuple(),43200.5);
	interporderset = false;
	storage.resize(0);
	storageIndex.clear();
	pm_density = 0;
	tai_ut1_density = 0;
}

void ERPStorage::ignoreERP()
{
	setExtrapolationLimit(Tuple(), -1.0l);
	setMaxVerticesStep(Tuple(), -1.0l);
	deleteRows(Tuple());
	insertRow(Tuple()<<ERP_PM_X<<0.0l, Tuple()<<0);
	insertRow(Tuple()<<ERP_PM_Y<<0.0l, Tuple()<<0);
	insertRow(Tuple()<<ERP_TAI_UT1<<0.0l, Tuple()<<0);
	insertRow(Tuple()<<ERP_DX<<0.0l, Tuple()<<0);
	insertRow(Tuple()<<ERP_DY<<0.0l, Tuple()<<0);
}

void ERPStorage::calcERPMatrix(real epoch, bool derivs)
{
	bool exist = true;
	//Вдруг матрица уже вычислена?
	map<real, unsigned int>::iterator it = storageIndex.find(epoch);
	if (it == storageIndex.end())
		exist = false;
	else
		if ((storage[it->second].derivs == false) && (derivs == true))
			exist = false;

	if (exist)
		return;

	//Вычислить новый набор ПВЗ+матрица
	ERPMATRIXSTORAGE ls;
	getERP(ls.pm_x, ls.pm_y, ls.tai_ut1, ls.dx, ls.dy, ls.dpm_x,
		   ls.dpm_y, ls.dtai_ut1, epoch);
	double t = epoch;
	mkmatrix_cio(t,ls.pm_x,ls.pm_y,ls.tai_ut1,ls.dx,ls.dy,ls.dpm_x,
				 ls.dpm_y, ls.dtai_ut1,ls.matrix, ls.dmatrix,ls.ddmatrix,
				 derivs?2:0);
	ls.derivs = derivs;
	if (it == storageIndex.end())
	{
		storage.push_back(ls);
		storageIndex[epoch] = storage.size()-1;
	}
	else
		storage[it->second] = ls;
}

void ERPStorage::clearERPMatrixStorage()
{
	storage.clear();
	storageIndex.clear();
}


void ERPStorage::getERP(double &pm_x, double &pm_y, double &tai_ut1, double &dx,
			double &dy, double &dpmx, double &dpmy, double &dtai_ut1, real tai)
const
{
	if (interporderset == false)
	{
		((ERPStorage*)this)->interporderset = true;
		Settings * sets = (Settings*)(base->getTable("settings"));
		((ERPStorage*)this)->setInterpolateOrder(Tuple(),
										sets->getSettings(erporder).toInt());
	}
	map < real, unsigned int > ::const_iterator it0 =
						storageIndex.find(tai);
	if (it0 == storageIndex.end())
	{
		//Вычислить ПВЗ с поправками
		//Считать ПВЗ из таблицы
		try
		{
			dx=getParameterValue(Tuple()<<ERP_DX,tai);
			dy=getParameterValue(Tuple()<<ERP_DY,tai);
			pm_x=getParameterValue(Tuple()<<ERP_PM_X,tai);
			pm_y=getParameterValue(Tuple()<<ERP_PM_Y,tai);
			tai_ut1=getParameterValue(Tuple()<<ERP_TAI_UT1,tai);
		}
		catch (const StrException & e)
		{
			throw NoERPException(tai);
		}

		double mjd_utc = ( (tai-UTCDateTime::getLeapSeconds(tai)) /
						jsecondsPerDay + DJM00 );
		double cor_x, cor_y, cor_ut1, cor_lod;
		pmut1_oceans_ (&mjd_utc, &cor_x, &cor_y, & cor_ut1, &cor_lod);
		//CALL PMUT1_OCEANS (rjd_int,cor_x,cor_y,cor_ut1,cor_lod)
		pm_x+=cor_x;
		pm_y+=cor_y;
		tai_ut1-=cor_ut1;
		pm_gravi_( & mjd_utc, & cor_x, & cor_y );
		//CALL PM_GRAVI (rjd_int,cor_x,cor_y)
		pm_x+=cor_x;
		pm_y+=cor_y;
		utlibr_ (&mjd_utc, &cor_ut1, &cor_lod);
		tai_ut1-=cor_ut1/1000000;

		//Вычислить производные с помощью разности вперёд
		double pm_x_1=getParameterValue(Tuple()<<ERP_PM_X,tai+10.0l);
		double pm_y_1=getParameterValue(Tuple()<<ERP_PM_Y,tai+10.0l);
		double tai_ut1_1=getParameterValue(Tuple()<<ERP_TAI_UT1,tai+10.0l);
		double mjd_utc_1 = ( (tai+10.0l-UTCDateTime::getLeapSeconds(tai)) /
						jsecondsPerDay + DJM00 );
		pmut1_oceans_ (&mjd_utc_1, &cor_x, &cor_y, & cor_ut1, &cor_lod);
		//CALL PMUT1_OCEANS (rjd_int,cor_x,cor_y,cor_ut1,cor_lod)
		pm_x_1+=cor_x;
		pm_y_1+=cor_y;
		tai_ut1_1-=cor_ut1;
		pm_gravi_( & mjd_utc_1, & cor_x, & cor_y );
		//CALL PM_GRAVI (rjd_int,cor_x,cor_y)
		pm_x_1+=cor_x;
		pm_y_1+=cor_y;
		utlibr_ (&mjd_utc_1, &cor_ut1, &cor_lod);
		tai_ut1_1-=cor_ut1/1000000;
		dpmx = (pm_x_1 - pm_x)/10.0;
		dpmy = (pm_y_1 - pm_y)/10.0;
		dtai_ut1 = (tai_ut1_1 - tai_ut1)/10.0;
	}
	else
	{
		int idx = it0->second;
		pm_x = storage[idx].pm_x;
		pm_y = storage[idx].pm_y;
		tai_ut1 = storage[idx].tai_ut1;
		dx = storage[idx].dx;
		dy = storage[idx].dy;
		dpmx = storage[idx].dpm_x;
		dpmy = storage[idx].dpm_y;
		dtai_ut1 = storage[idx].dtai_ut1;
	}
}


void ERPStorage::getERPMatrix (real tai, double mat[3][3], double dmat[3][3],
							   double ddmat[3][3]) const
{
	bool requirederivs = (dmat!=0) || (ddmat!=0);
	double t = tai;
	map <real,unsigned int>::const_iterator it=storageIndex.find(tai);
	bool exist = true;
	if (it==storageIndex.end())
		exist = false;
	else
		if ((storage.at(it->second).derivs == false) && (requirederivs))
			exist = false;
	if (exist == false)
	{
//		char Method = ((ERPStorage*)(this))->getMatrixMethod();
		double pm_x;
		double pm_y;
		double tai_ut1;
		double dx;
		double dy;
		double dpmx;
		double dpmy;
		double dtaiut1;

		getERP(pm_x, pm_y, tai_ut1, dx, dy, dpmx, dpmy, dtaiut1, t);
		int ddm;
		if ((dmat != 0) && (ddmat != 0))
			ddm = 2;
		else if (dmat  != 0)
			ddm = 1;
		else
			ddm = 0;
		mkmatrix_cio(t, pm_x, pm_y, tai_ut1, dx, dy, dpmx, dpmy, dtaiut1, mat,
					 dmat, ddmat, ddm);
	}
	else
	{
		const double*m = &(storage[it->second].matrix[0][0]);
		const double*dm = &(storage[it->second].dmatrix[0][0]);
		const double*ddm = &(storage[it->second].ddmatrix[0][0]);
		memcpy(mat,m,9*sizeof(double));
		if (dmat!=0)
			memcpy(dmat,dm,9*sizeof(double));
		if (ddmat!=0)
			memcpy(ddmat,ddm,9*sizeof(double));
	}
}

#ifdef UseMPI
void ERPStorage::prepareMatrices( vector < real > epochs, bool derivs,
				  MPI_Comm mpicomm )
#else
void ERPStorage::prepareMatrices( vector < real > epochs, bool derivs )
#endif
{
	int comm_size = 1;
	int comm_rank = 0;
#ifdef UseMPI
	MPI_Comm_size (mpicomm, &comm_size);
	MPI_Comm_rank (mpicomm, &comm_rank);
#endif
	//Простой случай - ничего не надо копировать и синхронизировать.
	if (comm_size == 1)
	{
		for (unsigned int i=0; i<epochs.size();i++)
			calcERPMatrix(epochs[i], derivs);
		return;
	}
#ifdef UseMPI
	//Распределить работу между потоками
	pair < unsigned int, unsigned int > task =
		pair <unsigned int, unsigned int>(0,epochs.size()-1);
	task = distribute(0,epochs.size()-1,comm_size,comm_rank);

	//Вычислить или прочитать все требуемые матрицы своей части
	vector < ERPMATRIXSTORAGE > localstorage(task.second-task.first +1);
	for (unsigned int i=task.first; i<=task.second; ++i)
	{
		//Проверить, что в данном потоке матрица на требуемый момент времени
		//вычислена.
		calcERPMatrix(epochs[i], derivs);
		//Подготовить её для отдачи другим потокам
		localstorage[i-task.first] = storage[storageIndex[epochs[i]]];
	}

	//Синхронизировать матрицы между процессами
	for (unsigned int i=0; i<comm_size; i++)
	{
		//Какую часть работы должен был выполнить i-й процесс
		task = distribute(0,epochs.size()-1,comm_size,i);
		vector < ERPMATRIXSTORAGE > localstorage1(task.second-task.first +1);
		MPI_Bcast(
			(i==comm_rank)?localstorage.data():localstorage1.data(),//buffer
			sizeof(ERPMATRIXSTORAGE)*(task.second-task.first +1),//count
			MPI_BYTE, //datatype
			i, //root
			mpicomm//comm
					);
		if (i == comm_rank)
			continue;
		//Забрать необходимые матрицы в своё хранилище
		for (unsigned int j = 0; j<localstorage1.size(); j++)
		{
			real epoch1 = epochs[j+task.first];
			map<real,unsigned int>::iterator fm = storageIndex.find(epoch1);
			if (fm == storageIndex.end()) //Либо записать новую матрицы
			{
				storage.push_back(localstorage1[j]);
				storageIndex[epoch1] = storage.size() - 1;
			}
			else //Либо переписать существующую
				storage[fm->second] = localstorage1[j];
		}
	}
#endif
}


kinematic < real, 3, defaultInert > ERPStorage::ITRFtoGCRS
	( const kinematic < real, 3, defaultNonInert > & pos,
	  real t) const
{
	double tf[3][3];
	getERPMatrix(t, tf,0,0);
	return ITRFToGCRS(pos,tf);
//	kinematic<real,3,defaultInert> result;
//	result[0] = tf[0][0]*pos[0] + tf[1][0]*pos[1] + tf[2][0]*pos[2];
//	result[1] = tf[0][1]*pos[0] + tf[1][1]*pos[1] + tf[2][1]*pos[2];
//	result[2] = tf[0][2]*pos[0] + tf[1][2]*pos[1] + tf[2][2]*pos[2];
//	return result;
}

kinematic < real, 3, defaultNonInert > ERPStorage::GCRStoITRF
	( const kinematic < real, 3, defaultInert > & pos,
	  real t) const
{
	double tf[3][3];
	getERPMatrix(t, tf,0,0);
	return GCRSToITRF(pos,tf);
//	kinematic<real,3,defaultNonInert> result;
//	result[0] = tf[0][0]*pos[0] + tf[0][1]*pos[1] + tf[0][2]*pos[2];
//	result[1] = tf[1][0]*pos[0] + tf[1][1]*pos[1] + tf[1][2]*pos[2];
//	result[2] = tf[2][0]*pos[0] + tf[2][1]*pos[1] + tf[2][2]*pos[2];
//	return result;
}



kinematic < real, 6, defaultInert > ERPStorage::ITRFtoGCRS
	( const kinematic < real, 6, defaultNonInert > & pos,
	  real t) const
{
	double tf[3][3], dtf[3][3];
	getERPMatrix(t, tf, dtf, 0);
#define X pos.subset<0,2>()
#define V pos.subset<3,5>()
	return ITRFToGCRS(X,tf).concat(ITRFToGCRS(V,tf)+ITRFToGCRS(X,dtf));
//	kinematic < real, 3, defaultInert > resultpos;
//	kinematic < real, 3, defaultInert > resultvel;
//	resultvel[0] = tf[0][0]*pos[3] + tf[1][0]*pos[4] + tf[2][0]*pos[5]
//				+ dtf[0][0]*pos[0] +dtf[1][0]*pos[1] +dtf[2][0]*pos[2];
//	resultvel[1] = tf[0][1]*pos[3] + tf[1][1]*pos[4] + tf[2][1]*pos[5]
//				+ dtf[0][1]*pos[0] +dtf[1][1]*pos[1] +dtf[2][1]*pos[2];
//	resultvel[2] = tf[0][2]*pos[3] + tf[1][2]*pos[4] + tf[2][2]*pos[5]
//				+ dtf[0][2]*pos[0] +dtf[1][2]*pos[1] +dtf[2][2]*pos[2];
//	resultpos[0] = tf[0][0]*pos[0] + tf[1][0]*pos[1] + tf[2][0]*pos[2];
//	resultpos[1] = tf[0][1]*pos[0] + tf[1][1]*pos[1] + tf[2][1]*pos[2];
//	resultpos[2] = tf[0][2]*pos[0] + tf[1][2]*pos[1] + tf[2][2]*pos[2];

//	return resultpos.concat(resultvel);
}

kinematic< real, 9, defaultInert > ERPStorage::ITRFtoGCRS
(const kinematic< real, 9, defaultNonInert >& pos, real tai) const
{
	double tf[3][3], dtf[3][3], ddtf[3][3];
	getERPMatrix(tai, tf, dtf, ddtf);
#define X pos.subset<0,2>()
#define V pos.subset<3,5>()
#define A pos.subset<6,8>()
	return ITRFToGCRS(X,tf).concat(ITRFToGCRS(V,tf)+ITRFToGCRS(X,dtf))
		.concat(ITRFToGCRS(A,tf)+(real)2*ITRFToGCRS(V,dtf)+ITRFToGCRS(X,ddtf));


//	kinematic < real, 3, defaultInert > resultpos;
//	kinematic < real, 3, defaultInert > resultvel;
//	kinematic < real, 3, defaultInert > resultacc;

//	resultacc[0] = tf[0][0]*pos[6] + tf[1][0]*pos[7] + tf[2][0]*pos[8]
//				+ dtf[0][0]*pos[3] +dtf[1][0]*pos[4] +dtf[2][0]*pos[5]
//				+ddtf[0][0]*pos[0]+ddtf[1][0]*pos[1]+ddtf[2][0]*pos[2];
//	resultacc[1] = tf[0][1]*pos[6] + tf[1][1]*pos[7] + tf[2][1]*pos[8]
//				+ dtf[0][1]*pos[3] +dtf[1][1]*pos[4] +dtf[2][1]*pos[5]
//				+ddtf[0][1]*pos[0]+ddtf[1][1]*pos[1]+ddtf[2][1]*pos[2];
//	resultacc[2] = tf[0][2]*pos[6] + tf[1][2]*pos[7] + tf[2][2]*pos[8]
//				+ dtf[0][2]*pos[3] +dtf[1][2]*pos[4] +dtf[2][2]*pos[5]
//				+ddtf[0][2]*pos[0]+ddtf[1][2]*pos[1]+ddtf[2][2]*pos[2];
//	resultvel[0] = tf[0][0]*pos[3] + tf[1][0]*pos[4] + tf[2][0]*pos[5]
//				+ dtf[0][0]*pos[0] +dtf[1][0]*pos[1] +dtf[2][0]*pos[2];
//	resultvel[1] = tf[0][1]*pos[3] + tf[1][1]*pos[4] + tf[2][1]*pos[5]
//				+ dtf[0][1]*pos[0] +dtf[1][1]*pos[1] +dtf[2][1]*pos[2];
//	resultvel[2] = tf[0][2]*pos[3] + tf[1][2]*pos[4] + tf[2][2]*pos[5]
//				+ dtf[0][2]*pos[0] +dtf[1][2]*pos[1] +dtf[2][2]*pos[2];
//	resultpos[0] = tf[0][0]*pos[0] + tf[1][0]*pos[1] + tf[2][0]*pos[2];
//	resultpos[1] = tf[0][1]*pos[0] + tf[1][1]*pos[1] + tf[2][1]*pos[2];
//	resultpos[2] = tf[0][2]*pos[0] + tf[1][2]*pos[1] + tf[2][2]*pos[2];

//	return resultpos.concat(resultvel).concat(resultpos);

}


kinematic < real, 6, defaultNonInert > ERPStorage::GCRStoITRF
	( const kinematic < real, 6, defaultInert > & pos,
	  real t) const
{
	double tf[3][3], dtf[3][3];
	getERPMatrix(t, tf, dtf, 0);
#define X pos.subset<0,2>()
#define V pos.subset<3,5>()
	return GCRSToITRF(X,tf).concat(GCRSToITRF(V,tf)+GCRSToITRF(X,dtf));


//	kinematic < real, 3, defaultNonInert > resultpos;
//	kinematic < real, 3, defaultNonInert > resultvel;
//	resultvel[0] = tf[0][0]*pos[3] + tf[0][1]*pos[4] + tf[0][2]*pos[5]
//			+ dtf[0][0]*pos[0] +dtf[0][1]*pos[1] +dtf[0][2]*pos[2];
//	resultvel[1] = tf[1][0]*pos[3] + tf[1][1]*pos[4] + tf[1][2]*pos[5]
//			+ dtf[1][0]*pos[0] +dtf[1][1]*pos[1] +dtf[1][2]*pos[2];
//	resultvel[2] = tf[2][0]*pos[3] + tf[2][1]*pos[4] + tf[2][2]*pos[5]
//			+ dtf[2][0]*pos[0] +dtf[2][1]*pos[1] +dtf[2][2]*pos[2];
//	resultpos[0] = tf[0][0]*pos[0] + tf[0][1]*pos[1] + tf[0][2]*pos[2];
//	resultpos[1] = tf[1][0]*pos[0] + tf[1][1]*pos[1] + tf[1][2]*pos[2];
//	resultpos[2] = tf[2][0]*pos[0] + tf[2][1]*pos[1] + tf[2][2]*pos[2];
//	return resultpos.concat(resultvel);
}

double ERPStorage::getDensity(const Tuple &k, real t)
{
	//Если плотность уже выбрана из таблиц настроек, вернуть её
	if (k[0] == ERP_TAI_UT1)
	{
		if (tai_ut1_density != 0)
			return tai_ut1_density;
	}
	else
		if (pm_density != 0)
			return pm_density;

	//В противном случае, скопировать её из настроек
	map < string, DBTable * > :: iterator sets = base->find("settings");
	if (sets == base->end())
		return 0;
	pm_density = ((Settings*)(sets->second))->getSettings(pmdens).toDouble();
	tai_ut1_density = ((Settings*)(sets->second))->
						getSettings(ut1dens).toDouble();
	if (k[0] == ERP_TAI_UT1)
		return tai_ut1_density;
	else
		return pm_density;
}

#ifdef WithQT
#ifdef UseMPI
void ERPStorage::prepareMatrices ( const QVariantList & tm, bool derivs,
								   const QMPICommunicator & comm)
{
	vector < real > tmv;
	for (QVariantList::const_iterator it = tm.begin(); it!=tm.end(); ++it)
		tmv.push_back(it->toDouble());
	prepareMatrices(tmv, derivs, comm.currentCommunicator());
}
#endif

QVariantList ERPStorage::GCRStoITRF ( const QVariantList& src, double t ) const
{
	if (src.size() == 3)
	{
		kinematic < real, 3, defaultInert > gcrs_;
		for (unsigned int i=0; i<3; i++)
			gcrs_[i] = src[i].toDouble();
		kinematic < real, 3, defaultNonInert > dst_ = GCRStoITRF(gcrs_, t);
		QVariantList dst;
		for (unsigned int i=0; i<3; i++)
			dst.push_back(QVariant((double)(dst_[i])));
		return dst;
	}
	else
	{
		kinematic < real, 6, defaultInert > gcrs_;
		for (unsigned int i=0; i<6; i++)
			gcrs_[i] = src[i].toDouble();
		kinematic < real, 6, defaultNonInert > dst_ = GCRStoITRF(gcrs_, t);
		QVariantList dst;
		for (unsigned int i=0; i<6; i++)
			dst.push_back(QVariant((double)(dst_[i])));
		return dst;
	}
}

QVariantList ERPStorage::ITRFtoGCRS ( const QVariantList& src, double t ) const
{
		if (src.size() == 3)
	{
		kinematic < real, 3, defaultNonInert > src_;
		for (unsigned int i=0; i<3; i++)
			src_[i] = src[i].toDouble();
		kinematic < real, 3, defaultInert > dst_ = ITRFtoGCRS(src_, t);
		QVariantList dst;
		for (unsigned int i=0; i<3; i++)
			dst.push_back(QVariant((double)(dst_[i])));
		return dst;
	}
	else
	{
		kinematic < real, 6, defaultNonInert > src_;
		for (unsigned int i=0; i<6; i++)
			src_[i] = src[i].toDouble();
		kinematic < real, 6, defaultInert > dst_ = ITRFtoGCRS(src_, t);
		QVariantList dst;
		for (unsigned int i=0; i<6; i++)
			dst.push_back(QVariant((double)(dst_[i])));
		return dst;
	}
}

QVariantList ERPStorage::getEOPMatrix ( double t ) const
{
	double tf[3][3];
	getERPMatrix(t, tf,0,0);
	QVariantList result;
	QVariantList line;
	for (unsigned int i=0; i<3; i++)
	{
		line.clear();
		for (unsigned int j=0; j<3; j++)
			line.push_back(tf[i][j]);
		result.push_back(QVariant(line));
	}
	return result;
}

QVariantList ERPStorage::getEOP ( double t ) const
{
	double pm_x;
	double pm_y;
	double tai_ut1;
	double dx;
	double dy;
	double dpm_x;
	double dpm_y;
	double dtai_ut1;
	getERP(pm_x, pm_y, tai_ut1, dx, dy, dpm_x, dpm_y, dtai_ut1, t);
	QVariantList result;
	result<<pm_x<<pm_y<<tai_ut1<<dx<<dy;
	return result;
}

void ERPStorage::calculateERPMatrix(double t, bool derivs)
{
	calcERPMatrix(t, derivs);
}


QScriptValue addERP(QScriptContext * ctx, QScriptEngine * eng)
{
	DBTableCollection * c = (DBTableCollection *)(ctx->argument(0).toQObject());
	ERPStorage * es = new ERPStorage (c);
	return QScriptValue();
}

BuiltIn adderp_ ("addERPTable", 1, addERP);
#endif
}

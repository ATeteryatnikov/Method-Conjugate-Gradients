#ifndef ERPSTORAGE_H_
#define ERPSTORAGE_H_

#include <gnssconfig.h>

#ifdef UseMPI
#include <mpi.h>
#endif

#include <vector>
#include <map>
#include <cmath>
#include <cstring>


//! @file

#include <ScriptShell.h>
#include <Types.h>
#include <StdTables.h>
#include <Frames.h>
#include <DBTableCollection.h>
#include <InterpolatedParameterStorage.h>
#include <Distribute.hpp>
#include <Kinematic.h>

namespace libgnss
{

class NoERPException : public StrException
{
public:
	NoERPException (real t);
};

extern Settings::Enumerator eomethod;
 
/** @file
 * 
 */

/**
 * @brief Функция вычисляет матрицу ориентации Земли и её производные
 * @param tai Момент времени, секунды TAI от 12:00 1 января 2000
 * @param pmx Координата X земного полюса
 * @param pmy Координата Y земного полюса
 * @param tai_ut1 Разность шкал времени TAI и UT1
 * @param dx Координата X небесного полюса
 * @param dy Координата Y небесного полюса
 * @param dpmx Скорость изменения координата X земного полюса, угловые сеунды/с
 * @param dpmy Скорость изменения координата Y земного полюса, угловые сеунды/с
 * @param dtai_ut1 Скорость ухода шкалы TAI относительно UT1, секунды/с
 * @param[out] matrix Вычисляемая матрица
 * @param[out] dmatrix Вычисляемая первая производная
 * @param[out] ddmatrix Вычисляемая вторая производная
 * @param ddm Число производных, которые нужно вычислять (0/1/2)
 *
 * Матрица вычисляется по формуле: \f$ EOM = RPoM \cdot R \cdot RC2I,\f$ где
 * \f$ RPoM \f$ - матрица смещения Земного полюса, \f$ R \f$ - матрица вращения
 * Земли вокруг своей оси, \f$ RC2I \f$ - матрица прецесси и нутации.
 *
 * Производные от матрицы \f$ RC2I \f$ вычисляются численно по семи точкам.
 * Производная от матрицы \f$ RPOM \f$ вычисляется численно по пяти точкам.
 *
 * По экспериментальным подсчетам, это даёт точность элементов производных от
 * этих матриц до \f$ 10^{-14} \f$, что необходимо для обеспечения точности
 * перевода ускорений в \f$ 10^{-10}\f$ км/с^2.
 *
 * Производная от матрицы вращения \f$ R \f$ должна быть вычислена явно в связи
 * с высокой скоростью её изменения.
 *
 * Имеем:
 *
 * \f[ R(t) = \left(\begin{array}{lll} cos(\varphi_0 + \omega(t-taiut1)) &
 * -sin(\varphi_0 + \omega(t-taiut1)) & 0 \\
 * sin(\varphi_0 + \omega(t-taiut1)) & cos(\varphi_0 + \omega(t-taiut1)) & 0
 * \\ 0 & 0 & 1
 * \end{array}\right) \f]
 *
 * Здесь \f$ \varphi_0 \f$ --- угол поворота Земли в эпоху J2000,
 * \f$ \omega = 0.000072921151467069794 \f$ - скорость вращения Земли
 * относительно временной шкалы UT1,
 * \f$ t \f$ - момент времени, число секунд TAI от J2000.
 * \f$ taiut1 \f$ - разность шкал времени TAI-UT1.
 *
 * Нетрудно проверить равенства:
 * \f$ R'(t) = \omega (1-taiut1')\cdot R\cdot R(t), \f$
 * \f$ R''(t)=\omega(1-taiut1')\cdot R \cdot R'(t)-\omega taiut1'' R R(t),\f$
 * где \f$ R \f$ получается из матрицы поворота вокруг оси Z на угол
 * \f$ \pi / 2 \f$ занулением нижнего правого элемента.
 *
 * Для вычисления этих матриц сначала вычисляется матрица \f$ R(t) \f$
 * (переменная RT), затем матрица \f$ R \f$ (переменна RPI2), затем матрица
 * \f$ R\cdot R(t) \f$ (переменная RPI2RT), затем матрица \f$ R'(t) \f$
 * (переменная DRT), затем \f$ R\cdot R'(t) \f$ (переменная RPI2), и, наконец,
 * \f$ R''(t) \f$ (переменная DDRT).
 *
 * Дальнейшие расчеты происходят по формулам дифференцирования произведений.
 *
 */
void mkmatrix_cio(double tai, double pmx, double pmy, double tai_ut1,
				  double dx, double dy, double dpmx, double dpmy,
				  double dtai_ut1, double matrix [3][3], double  dmatrix[3][3],
				  double ddmatrix[3][3], int ddm);



/**
 * @brief Процедура, моделирующая влияние дневных приливов на ПВЗ
 *
 *
 *
 * @param mjd_int Модифицированная юлианская дата
 * @param cor_x Поправка к координате X земного полюса (возвращаемое значение)
 * @param cor_y Поправка к координате Y земного полюса (возвращаемое значение)
 * @param cor_ut1 Поправка к разнице шкал UT1 и UTC (возвращаемое значение)
 * @param cor_lod Поправка к длительности суток (возвращаемое значение)
 **/
extern "C" void pmut1_oceans_ ( double * mjd_int, double * cor_x,
			double * cor_y, double * cor_ut1, double * cor_lod );


/**
 * @brief Процедура, моделирующая влияние гравитации Луны и Солнца на ПВЗ
 *
 *
 *
 * @param mjd_int Модифицированная юлианская дата
 * @param cor_x Поправка к координате X земного полюса (возвращаемое значение)
 * @param cor_y Поправка к координате Y земного полюса (возвращаемое значение)
 **/
extern "C" void pm_gravi_ ( double * mjd_int, double * cor_x, double * cor_y );

/** @brief Процедура, моделирующая влияние либрации Луны на длительность суток
  *
  * @param mjd_int Модифицированная юлианская дата
  * @param dut1 Поправка к разнице шкал UT1 и UTC (возвращаемое значение)
  * @param dlod Поправка к длительности суток (возвращаемое значение)
  */
extern "C" void utlibr_ ( double * mjd_int, double * dut1, double * dlod );


/**
 * @brief Перевод из ITRS-системы координат в инерциальную систему координат
 * @param v Вектор в неинерциальной системе координат
 * @param tf Матрица переход, генерируемая функцией формирования матрицы
 * @return Вектор в инерциальной системе координат
 */
inline kinematic<real,3,defaultInert> ITRFToGCRS(
		const kinematic<real,3,defaultNonInert> & v,
		const double tf[3][3])
{
	return mulVM<real, 3, 3, defaultNonInert, defaultInert>(v,tf);
}

/**
 * @brief Перевод из инерциальной системы координат в ITRS-систему координат
 * @param v Вектор в инерциальной системе координат
 * @param tf Матрица переход, генерируемая функцией формирования матрицы
 * @return Вектор в неинерциальной системе координат
 */
inline kinematic<real,3,defaultNonInert> GCRSToITRF(
		const kinematic<real,3,defaultInert> & v,
		const double tf[3][3])
{
	return mulMV<real,3,3,defaultInert,defaultNonInert>(tf,v);
}

/** @brief Хранилище уточняемых параметров вращения Земли
  *
  * Параметрами вращения Земли являются:
  * @li Координаты небесного полюса, указывающие направление оси вращения Земли
  * @li Поправка неравномерности вращения Земли
  * @li Смещение Земного полюса
  *
  * Чаще всего, параметры вращения Земли указываются с шагом 1 сутки, а
  * моделируемые колебания с частотой меньше суток, возникающие из-за приливов и
  * др., вычисляются отдельно.
  *
  * В результате, вычисление параметров вращения Земли в нужный момент времени
  * занимает много вычислительных ресурсов, и логично подготовить значения ПВЗ
  * в нужные моменты времени заранее, чтобы затем обращаться к ним несколько
  * раз. Также, экономия может быть достигнута за счет предвычисления матриц
  * перехода ITRF<->GCRS. Эта подготовка и является основной функцие данного
  * класса, наряду с хранением и предоставлением произвольного доступа.
  */
class ERPStorage : public InterpolatedParameterStorage
{
	Q_OBJECT
public:
	enum COMPONENT
	{
		ERP_PM_X = 0,
		ERP_PM_Y = 1,
		ERP_TAI_UT1 = 2,
		ERP_DX = 3,
		ERP_DY = 4
	};
private:

	double pm_density;
	double tai_ut1_density;

	/** @brief Структура, подготавливаемая для каждого момента времени
	  *
	  * @li Параметры вращения Земли и их производные
	  * @li Матрица перехода GCRS<->ITRF и её две производные
	  */
	struct ERPMATRIXSTORAGE
	{
		double pm_x;
		double pm_y;
		double tai_ut1;
		double dx;
		double dy;
		double dpm_x;
		double dpm_y;
		double dtai_ut1;
		double matrix[3][3];
		double dmatrix[3][3];
		double ddmatrix[3][3];
		bool derivs;
		inline ERPMATRIXSTORAGE ()
		{
			memset(this,0,sizeof(ERPMATRIXSTORAGE));
		}
	};

	//----------ХРАНИЛИЩЕ ПРЕДВЫЧИСЛЕННЫХ МАТРИЦ ПЕРЕХОДА---------------//

	//! Множество матриц и значений ПВЗ
	vector <ERPMATRIXSTORAGE> storage;

	//! Индекс хранилища матриц и значений ПВЗ
	map < real, unsigned int > storageIndex;
	
	bool interporderset;

public:

	/** @brief Вычисляет ПВЗ для заданного в TAI от J2000 момента времени
	 * 
	 * Параметры вращения Земли интерполируются по числу точек, указанных
	 * в настройке Parameters_settings->ERP->InterpolateOrder
	 * (см. @ref Settings).
	 * @param[out] pm_x Координата X земного полюса
	 * @param[out] pm_y Координата Y земного полюса
	 * @param[out] tai_ut1 Разность шкал времени TAI и UT1
	 * @param[out] dx Координата X небесного полюса
	 * @param[out] dy Координата Y небесного полюса
	 * @param[out] dpmx Производная координаты X земного полюса
	 * @param[out] dpmy Производная координаты Y земного полюса
	 * @param[out] dtai_ut1 Скорость ухода шкалы TAI относительно UT1
	 * @param tai Момент времени, секунды TAI от 12:00 01.01.2000
	 */
	void getERP ( double & pm_x, double & pm_y, double & tai_ut1,
				 double & dx, double & dy, double & dpmx, double & dpmy,
				  double & dtai_ut1, real tai) const;

	/**
	 * @brief Возвращает матрицу перехода ITRF<->GCRS и её производные
	 * @param t Момент времени, секунды TAI от 12:00 01.01.2000
	 * @param[out] mat Матрица перехода
	 * @param[out] dmat Первая производная матрицы перехода
	 * @param[out] ddmat Вторая производная матрицы перехода
	 *
	 * Чтобы не заставлять метод выполнять ненужную работу, если производные
	 * не нужны, следует передать вместо них нуль.
	 *
	 * Если матрица (и её производные, если требуются) имеются в хранилище
	 * матриц на данный момент времени, она (и производные) будут возвращены
	 * сразу. В противном случае, вычисление будет выполнено заново.
	 *
	 * @warning Метод не сохраняет вычисленную матрицу перехода в хранилище,
	 * если её там не было. Чтобы вычисленная матрица перехода осталась в
	 * хранилище, нужно сначала вызвать метод @ref calcMatrix(), указав
	 * в ему вычислить и производные, если они потребуются.
	 */
	void getERPMatrix (real t, double mat[3][3], double dmat[3][3],
						double ddmat[3][3])const;


	ERPStorage (DBTableCollection * base);

	/**
	 * @brief Просчитывает матрицу поворотов и сохраняет её в хранилище
	 * @param epoch Секунды TAI от J2000
	 * @param derivs true, если необходимо вычислить производные
	 *
	 * Метод вычисляет матрицу перехода ITRF<->GCRS на заданный момент времени,
	 * и её первую и вторую производную, если указано. Вычисленные матрицы
	 * будут сохранены в хранилище и затем могут быть быстро использованы
	 * любым методом, запрашивающим матрицы (@ref ITRFtoGCRS(),
	 * @ref GCRStoITRF() ).
	 *
	 * Если какому-либо методу потребуется матрица вместе с производной, а
	 * данный метод был вызван на этот момент времени для вычисления только
	 * матрицы без производных, то и матрица, и производные будут вычислены
	 * заново и не будут сохранены в хранилище.
	 *
	 * Если известно большое количество моментов времени, для которых могут
	 * понадобиться матрицы, то эти матрицы могут быть вычислены многопоточно
	 * с помощью метода @ref prepareMatricesParallel().
	 */
	void calcERPMatrix(real epoch, bool derivs = false);

	//! Удаляет все вычисленные матрицы перехода
	void clearERPMatrixStorage();

#ifdef UseMPI
	/** @brief Функция подготовки матриц перехода ITRF<->GCRS
	  *
	  * Данная функция заранее вычисляет матрицы перехода между
	  * инерциальной и неинерциальной системами координат ITRF и GCRS в
	  * заданные моменты времени. Для вычисления может быть использовано
	  * несколько MPI-процессов
	  * @param epochs Моменты времени, в которые будут нужны матрицы
	  * @param mpicomm Коммутатор MPI, ресурсы которого можно задействовать
	  * @param derivs true, если необходимо вычислять производные матриц
	  */
	void prepareMatrices( vector < real > epochs, bool derivs,
					  MPI_Comm mpicomm );
#else
	void prepareMatrices( vector < real > epochs, bool derivs );
#endif

	/** @brief Перевести координаты из системы ITRF в систему GCRS
	  *
	  * Параметры вращения Земли запрашиваются методом @ref getERP().
	  * 
	  * @param pos Радиус-вектор в системе координат ITRF
	  * @param tai Момент времени, секунды от J2000 в шкале TAI
	  * @return Радиус-вектор в системе координат GCRS
	  */
	kinematic < real, 3, defaultInert > ITRFtoGCRS
		( const kinematic < real, 3, defaultNonInert > & pos,
		  real tai) const;

	/** @brief Перевести координаты и скорости из системы ITRF в GCRS
	  *
	  * См. документацию к методу, переводящему координаты, скорость и
	  * ускорение.
	  *
	  * @param pos Радиус-вектор и скорость в системе координат ITRF
	  * @param tai Момент времени, секунды от J2000 в шкале TAI
	  * @return Радиус-вектор и скорость в системе координат GCRS
	  */
	kinematic < real, 6, defaultInert > ITRFtoGCRS
		( const kinematic < real, 6, defaultNonInert > & pos,
		  real tai) const;
		  
	/** @brief Перевести координаты и скорости из системы ITRF в GCRS
	 *
 * Перевод координат выполняется по формуле:
 *
 * \f[(cx,cy,cz)_{GCRS}=(cx,cy,cz)_{ITRF}\cdot EOM,\f]
 *
 * где EOM - матрица ориентации Земли.
 *
 * Для перевода скоростей и ускорений нужно продифференцировать это равенство.
 *
 * \f[ (vx,vy,vz)_{GCRS}= (vx,vy,vz)_{ITRF}\cdot EOM + (cx,cy,cz)_{ITRF}\cdot
 *  EOM', \f]
 *
 * \f[ (ax,ay,az)_{GCRS}= (ax,ay,az)_{ITRF}\cdot EOM +
 * 2(vx,vy,vz)_{ITRF}\cdot EOM' +(cx,cy,cz)_{ITRF}\cdot EOM''.\f]
 *
	  * @param pos Радиус-вектор, скорость и ускорение в системе координат ITRF
	  * @param tai Момент времени, секунды от J2000 в шкале TAI
	  * @return Радиус-вектор, скорость и ускорение в системе координат GCRS
	  */
	kinematic < real, 9, defaultInert > ITRFtoGCRS
		( const kinematic < real, 9, defaultNonInert > & pos,
		  real tai) const;
		  

	/** @brief Перевести координаты из системы GCRS в систему ITRF
	  *
	  * @param pos Радиус-вектор в системе координат GCRS
	  * @param tai Момент времени, секунды от J2000 в шкале TAI
	  * @return Радиус-вектор в системе координат ITRF
	  */
	kinematic < real, 3, defaultNonInert > GCRStoITRF
		( const kinematic < real, 3, defaultInert > & pos,
		  real tai) const;

	/** @brief Перевести координаты и скорости из системы GCRS в ITRF
	  *
	  * @param pos Радиус-вектор и скорость в системе координат GCRS
	  * @param tai Момент времени, секунды от J2000 в шкале TAI
	  * @return Радиус-вектор и скорость в системе координат ITRF
	  */
	kinematic < real, 6, defaultNonInert > GCRStoITRF
		( const kinematic < real, 6, defaultInert > & pos,
		  real tai) const;

	virtual double getDensity ( const Tuple & k, real tai );

	/**
	 * @brief Указать игнорировать ПВЗ.
	 *
	 * Таблица будет очищена и заполенна нулями, будет установлено разрешение
	 * любой экстраполяции и аппроксимации.
	 *
	 * Данный метод нужно вызвать, когда параметры вращения Земли взять
	 * неоткуда, и когда ошибка, вызванная их отсутствием, будет в допустимых
	 * пределах.
	 */
	void ignoreERP();
	
	
#ifdef WithQT
	//-----------------------------Скриптовые обёртки-------------------------//
public slots:

#ifdef UseMPI
	/** Непараллельное вычисление матриц перехода
	 *  @todo Параллельная версия функции подготовки матриц для скриптов!
	 */
	void prepareMatrices (const QVariantList & tm , bool derivs,
						  const QMPICommunicator & comm);
#endif

	//! Преобразование GCRS->ITRF
	QVariantList GCRStoITRF ( const QVariantList & gcrs, double t ) const;
	
	//! Преобразование ITRF->GCRS
	QVariantList ITRFtoGCRS ( const QVariantList & itrf, double t ) const;
	
	//! Получить матрицу перехода
	QVariantList getEOPMatrix ( double t ) const;
	
	//! Получить массив ПВЗ
	QVariantList getEOP ( double t ) const;

	//! Вычислить матрицу вращения Земли
	void calculateERPMatrix(double t, bool derivs);
#endif

};

#ifdef WithQT
QScriptValue prepareMatrices(QScriptContext * ctx, QScriptEngine * eng);
#endif

}

#endif

#ifndef SITEDISPLACEMENT_H_
#define SITEDISPLACEMENT_H_

/** @file
 *
 * @brief Модуль вычисления положения опорной точки антенны БИС
 *
 * Координаты фазового центра антенны находятся по следующему алгоритму:
 * @li Исходные данные - средние координаты маркера (например, из SINEX).
 * Эти координаты хранятся в таблице @ref MarkerPosition.
 * @li К ним прибавляются детерминированные поправки за счет приливных
 * деформаций Земной коры. Они вычисляются функцией @ref getCrustShift().
 * @li К ним прибавляется смещение опорной точки антенны относительно
 * положения маркера (таблица @ref MarkerEccentricity).
 * @li Далее прибавляется поправка, приводящая к среднему положению фазового
 * центра (таблица @ref PhaseCentreOffsetFrequency), а затем - вариация
 * фазового центра, зависящая от угла азимута и зенитного угла (таблица
 * @ref PhaseCentreVariationGrid).
 */

#include <map>
#include <InterpolatedParameterStorage.h>
#include <Kinematic.h>
#include <Frames.h>
#include <StdTables.h>

namespace libgnss
{

/**
 * @brief Вычисление детерминированных приливных поправок к положению объекта
 * @param nominal Номинальное положение объекта на поверхности Земли
 * @param t Момент времени
 * @param ps Коллекция таблиц
 * @return Смещение земной коры в заданной точке в заданный момент времени
 */
kinematic < real, 3, defaultNonInert> getCrustShift(
		const kinematic < real, 3, defaultNonInert> & nominal,
		real t,
		const DBTableCollection *ps
		);

class NoEccentricityAvailable : public StrException
{
public:
	NoEccentricityAvailable(const string & marker_name, real t);
};

/**
 * @brief Таблица смещений антенны БИС относительно положения маркера
 *
 * Ключ:
 * @li int marker_id - идентификатор маркера (совпадает со значением поля
 *		autoinc в @ref Markers)
 * @li double since_tai - момент установки антенны (секунды TAI от J2000)
 *
 * Значение:
 * @li int coord_type - тип координат, задающих смещение.
 * @li double dx
 * @li double dy
 * @li double dz
 * @li double until - момент демонтажа данной антенны (секунды TAI от J2000)
 *
 * Тип координат, задающих смещение: 0 - в локальной системе координат с осями
 * "Вверх", "На север", "На восток", 1 - в системе координат, идентификатор
 * которой задаётся настройкой "Coordinate_Systems", "Frame_Converter",
 * "Default_TRS".
 *
 * Система координат по умолчанию может меняться, но на поправку к положению
 * БИС эта смена оказывает слишком малое влияние, чтобы его учитывать.
 */
class MarkerEccentricity : public DBTable
{
private:
	Markers * markers;
	DBTableCollection * Base;
	void NoEccentricity(int marker_id, real tai) const;
public:
	MarkerEccentricity(DBTableCollection * base);
	pair < int, kinematic < real, 3, otherCoordSys > > getEccentricity
			(int marker_id, real tai) const;
};

/**
 * @brief Хранилище координат БИС
 *
 * Хранит положение БИС в системе координат, которая в настройках отмечена
 * как неинерциальная система координат по умолчанию.
 *
 * Если происходит считывание положений БИС в другой системе координат, то
 * её необходимо перевести в систему координат по умолчанию.
 *
 * Ключ:
 * @li int marker_id - идентификатор маркера (соответствует полю autoinc в
 *      таблице @ref Markers)
 * @li int coord_number - номер координаты (0 = X, 1 = Y, 2 = Z)
 * @li double time - момент времени, секунды TAI (J2000).
 *
 * Значение:
 * @li double value - значение координаты
 */
class MarkerPosition : public InterpolatedParameterStorage
{
private:
	Markers * markers;
public:
	MarkerPosition ( DBTableCollection * base );

	/**
	 * @brief Получить координаты маркера без учета приливных движений
	 * @param marker_id Идентификатор маркера
	 * @param t Момент времени
	 * @return Координаты маркера
	 *
	 * Если координаты не были введены в таблицу, то функция обращается к
	 * методу @ref Markers::getMarkerApproxPosition().
	 */
	kinematic < real, 3, defaultNonInert > getZeroTideMarkerPosition(
			int marker_id, real t) const;


	/**
	 * @brief Вычисление положения БИС с учетом движений Земной коры
	 * @param marker_id Идентификатор маркера
	 * @param t Момент времени
	 * @return  Положение требуемого маркера в нужный момент времени
	 */
	kinematic < real, 3, defaultNonInert > getMarkerPosition(
			int marker_id, real t) const;

	/**
	 * @brief Перестройка хранилища координат маркера
	 *
	 * В качестве параметра subkey разрешается указывать только идентификатор
	 * маркера.
	 */
	virtual void resample(real t0, real t1, const Tuple & subkey = Tuple());
};

class MarkerNotInReferenceFrame : public StrException
{
public:
	MarkerNotInReferenceFrame(const string & framename,
							  const string & markername);
	static void throwMe(DBTableCollection * base,int frame_id,int  marker_id);
};


/**
 * @brief Таблица с заданием системы координат
 *
 * Ключ:
 * @li frame_id Идентификатор системы координат
 * @li marker_id Идентификатор маркера
 * @li coord_number Номер координаты
 *
 * Значение
 * @li value Значение координаты
 * @li epoch Момент времени
 * @li stddev Среднеквадратическое отклонение
 *
 * Название таблицы: reference_frames
 * Нумерация координат: [0,1,2,3,4,5]=[STAX,STAY,STAZ,VELX,VELY,VELZ]
 *
 * Каждая система координат задаётся координатами в ней базовых БИС и их
 * среднеквадратическими отклонениеми. Это позволяет при уточнении положений
 * БИС регуляризовать неопределённости путем добавления уравнений вида
 * "Координата БИС - Исходная Координата БИС = 0", умноженных на нужный
 * коэффициент. Это делается для того, чтобы
 *
 * @li Немоделируемые вращения Земли не давали вклад в координаты БИС, а
 * уходили в параметры вращения Земли.
 * @li Исключить поворот всей системы БИСов одновременно со спутниками.
 *
 */
class ReferenceFrames : public DBTable
{
private:
	DBTableCollection * base;
public:
	ReferenceFrames(DBTableCollection * base);

	/** @brief Возвращает координаты, скорость БИС и их СКО
	  *
	  * @param frame_id Идентификатор системы координат
	  * @param marker_id Идентификатор маркера
	  * @param t0 Момент времени
	  *
	  * @return .first  - координаты и скоротсь, .second - соответствующее СКО
	  */
	pair<kinematic<real,6,defaultNonInert>,kinematic<real,6,defaultNonInert> >
	getPositionVelocity (int frame_id, int marker_id, real t0) const;
};


}

#endif

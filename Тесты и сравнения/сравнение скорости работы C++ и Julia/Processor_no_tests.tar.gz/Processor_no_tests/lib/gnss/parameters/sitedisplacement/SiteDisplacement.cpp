//! @file

#include <DBTableCollection.h>
#include <InterpolatedParameterStorage.h>
#include <SiteDisplacement.h>
#include <ERPStorage.h>
#include <ephemeris.h>


namespace libgnss
{

MarkerEccentricity::MarkerEccentricity(DBTableCollection *base)
	: DBTable(Columns()
			  <<Column(Variant::TYPE_INT, "marker_id")
			   <<Column(Variant::TYPE_DOUBLE, "since_tai"),
			  Columns()
			  <<Column(Variant::TYPE_INT, "coord_type")
			  <<Column(Variant::TYPE_DOUBLE, "dx")
				<<Column(Variant::TYPE_DOUBLE, "dy")
				  <<Column(Variant::TYPE_DOUBLE, "dz")
			 <<Column(Variant::TYPE_DOUBLE, "until"))
{
	base->addTable("marker_eccentricity", this);
	markers = 0;
	Base = base;
}

Settings::Enumerator mposdensity("Parameters_settings","marker_position",
								 "Sampling_density", Variant::TYPE_DOUBLE,
								 "Плотность узлов интерполяции координат БИС",
								 (real)(1)/(real)(86400));

NoEccentricityAvailable::NoEccentricityAvailable(const string &marker_name,
												 real t)
	: StrException("NoEccentricityAvailable",
				   "Неизвестно смещение опорной точки антенны относительно "
				   "положения маркера "+marker_name+" в момент времени "
				   +UTCDateTime::fromTAIJ2000(t).getUTCDateTimeString())
{
}

void MarkerEccentricity::NoEccentricity(int marker_id, real tai) const
{
	if (markers == 0)
		((MarkerEccentricity*)(this))->markers = (Markers*)
			(Base->getTable("markers"));
	string markername = markers->read(marker_id)[0].toString();
	throw NoEccentricityAvailable(markername, tai);
}

pair < int, kinematic < real, 3, otherCoordSys > > MarkerEccentricity::
getEccentricity(int marker_id, real tai) const
{
	DBTable::DBConstIterator it0 = lower_bound(Tuple()<<marker_id<<tai);
	if (it0 == const_end())
		NoEccentricity(marker_id, tai);
	if (it0[4].toDouble() < tai)
		NoEccentricity(marker_id, tai);
	pair < int, kinematic < real, 3, otherCoordSys > > result;
	result.first = it0[0].toInt();
	result.second[0] = it0[1].toDouble();
	result.second[1] = it0[2].toDouble();
	result.second[2] = it0[3].toDouble();
	return result;
}


MarkerPosition::MarkerPosition(DBTableCollection *base)
	: InterpolatedParameterStorage (base, "marker_position",Columns()
							<<Column(Variant::TYPE_INT, "marker_id")
						   <<Column(Variant::TYPE_INT, "coordinate_id")
						  <<Column(Variant::TYPE_DOUBLE, "Time"))
{
	setInterpolateOrder(Tuple(),2);
	markers = (Markers*)(base->getTable("markers"));
}

/** @brief Вычисление сдвига точки земной коры при приливной деформации коры
  *
  * @param xsta Указатель на массив номинальных координат точки;
  * @param yr Год
  * @param mn Месяц в году
  * @param day День в месяце
  * @param fhr Час в сутках (дробное число)
  * @param xsun Координаты Солнца
  * @param xmoon Координаты Луны
  * @param xtide Сдвиг точки под действием приливных деформаций земной коры
  *
  * @todo Здесь должна быть документация к модулю dehanttideinel!
  */
extern "C" void dehanttideinel_ (double * xsta, int * yr, int * mn, int * day,
								 double * fhr, double * xsun, double * xmoon,
								 double * xtide
								 );


kinematic < real, 3, defaultNonInert> getCrustShift(
		const kinematic < real, 3, defaultNonInert> & nominal,
		real t, const DBTableCollection *ps)
{
	double stationCoordinates [3];
	stationCoordinates[0] = nominal[0];
	stationCoordinates[1] = nominal[1];
	stationCoordinates[2] = nominal[2];

	// Вычисление координат небесных тел
	// 10 - Луна,
	// 11 - Солнце,
	//Координаты Луны в инерциальной системе
	kinematic<real,3,defaultInert> moonPosInert =
							getCelestialBodyEphemerides(10, t);
	//Координаты Солнца в инерциальной системе
	kinematic<real,3,defaultInert> sunPosInert =
							getCelestialBodyEphemerides(11, t);
	//Получение ПВЗ для перехода в неинерциальную систему координат
	ERPStorage * erps = (ERPStorage*)(ps->getTable("ERP"));
	kinematic<real, 3, defaultNonInert> MoonPosNonInert=
			erps->GCRStoITRF(moonPosInert, t);
	kinematic<real, 3, defaultNonInert> SunPosNonInert=
			erps->GCRStoITRF(sunPosInert, t);

	double moonCoordinates [3]={MoonPosNonInert[0],MoonPosNonInert[1],
								MoonPosNonInert[2] };
	double sunCoordinates [3]={SunPosNonInert[0],SunPosNonInert[1],
							   SunPosNonInert[2]};

	// Перевести всё в метры
	for (unsigned int i=0; i<3; i++)
	{
		stationCoordinates[i] *= 1000;
		moonCoordinates[i] *= 1000;
		sunCoordinates[i] *= 1000;
	}

	// Перевод текущего времени в дату и час в сутках
	double TaiDays = t/86400.0;
	double utc1, utc2;
	double ag1 = 2451545.0;
	int status;
	iauTaiutc(ag1,TaiDays,&utc1,&utc2);
//	libsofa::iau_taiutc_(&ag1,&TaiDays,&utc1, &utc2, &status);
	int y, m, d;
	double hms;
	iauJd2cal(utc1,utc2,&y,&m,&d,&hms);
//	libsofa::iau_jd2cal_(&utc1,&utc2,&y,&m,&d,&hms, &status);
	//Преобразовать дробное количество суток в дробное количество часов
	hms*=24.0;

	// Место под результат
	double shift [3];

	// Вычислить сдвиг положения БИС при деформации земной коры под
	//действием приливов от Луны и Солнца
	dehanttideinel_( &(stationCoordinates[0]), &y, &m, &d, &hms,
					 &(sunCoordinates[0]), &(moonCoordinates[0]), &(shift[0]) );

	// Вернуть смещение в километры
	kinematic < real, 3, defaultNonInert> result;
	result[0] = 0.001 * shift[0];
	result[1] = 0.001 * shift[1];
	result[2] = 0.001 * shift[2];

	return result;
}

kinematic < real, 3, defaultNonInert > MarkerPosition::getMarkerPosition(
		int marker_id, real t) const
{
	kinematic < real, 3, defaultNonInert > result =
			getZeroTideMarkerPosition(marker_id,t);
	if (result.length<0,2>() != 0.0)
		result += getCrustShift(result,t,base);
	return result;
}

kinematic < real, 3, defaultNonInert > MarkerPosition::
getZeroTideMarkerPosition(int marker_id, real t) const
{
	kinematic < real, 3, defaultNonInert > result;
	try
	{
		for (unsigned int i=0; i<3; i++)
			result[i] = getParameterValue(Tuple()<<marker_id<<(int)i, t);
	}
	catch (exception e)
	{
		return markers->getMarkerApproxPosition(marker_id);
	}

	return result;

}

void MarkerPosition::resample(real t0, real t1, const Tuple &subkey)
{
	if (subkey.size() > 1)
		throw StrException("MarkerPosition::resample",
						   "При перестройке хранилища координат маркера в "
						   "качестве параметра subkey допустимо указывать "
						   "только идентификатор маркера.");
	int need_marker_id = -1;
	if (subkey.size() == 1)
		need_marker_id = subkey[0].toInt();
	DBTable * obs = base->getTableIfExists("observables");
	DBTable * obssrc = base->getTableIfExists("observation_source");
	Markers * mrk = (Markers*)(base->getTable("markers"));
	//Нужно задать координаты каждого БИС, участвующего в МНК
	if ((obs == 0) || (obssrc == 0))
	{
		InterpolatedParameterStorage::resample(t0,t1);
		return;
	}
	//Проверить, что каждая БИС, участвующая в МНК, есть в таблице.
	for (DBTable::DBConstIterator it = obs->const_begin();
		 it!=obs->const_end(); it.inc(0))
	{
		int obs_src_id = it.keyColumnValue(0).toInt();
		int marker_id = obssrc->read(obs_src_id)[0].toInt();
		if ((need_marker_id != -1) && (marker_id != need_marker_id))
			continue;
		bool posexists = true;
		for (int i=0; i<3; i++)
			//Пройти по всем моментам времени данного БИС и убедиться, что
			//координаты БИС доступны в каждый из этих моментов времени.
			for (DBTable::DBConstIterator it1 = it; it1!=obs->const_end();
				 it1.subinc(1,0))
			{
				real t = it1.keyColumnValue(1).toDouble();
				try
				{
					getParameterValue(Tuple()<<marker_id<<i, t);
				}
				catch (...)
				{
					posexists = false;
				}
			}
		if (posexists == true)
			continue;
		//В противном случае, добавить.
		//Попробовать точные координаты в таблице ReferenceFrames.
		kinematic < real, 6, defaultNonInert > posvelrf;
		bool isreference = true;
		try
		{
			Frames * frm = (Frames*)(base->getTable("coordinate_frames"));
			ReferenceFrames * rfrm = (ReferenceFrames *)
					(base->getTable("reference_frames"));
			int rframe = frm->defaultNonInertFrame();
			posvelrf = rfrm->getPositionVelocity(rframe,marker_id,t0).first;
		}
		catch(...)
		{
			isreference = false;
		}
		if (isreference)
		{
			//Достаточно вставить координаты в начале и в конце интервала
			for (int i=0; i<3; i++)
			{
				real vstep = getMaxVerticesStep(Tuple()<<marker_id<<i);
				if (vstep<=0)
					vstep = t1-t0;
				int steps = floor((t1-t0)/vstep);
				if (vstep * steps < (t1-t0))
					steps++;
				vstep = (t1-t0)/(steps);
				for (int j=0; j<=steps; j++)
				{
					real t = t0 + j*vstep;
					real year = (t-t0)/(365.25*86400);
					insertRow(Tuple()<<marker_id<<i<<t,
							  Tuple()<<(posvelrf[i] + posvelrf[i+3]*year));
				}
			}
			continue;
		}
		//Если станция не референсная, взять из грубых координат маркера
		kinematic<real,3,defaultNonInert> posapprox=
				mrk->getMarkerApproxPosition(marker_id);
		for (int i=0; i<3; i++)
		{
			real vstep = getMaxVerticesStep(Tuple()<<marker_id<<i);
			if (vstep<=0)
				vstep = t1-t0;
			int steps = floor((t1-t0)/vstep);
			if (vstep * steps < (t1-t0))
				steps++;
			vstep = (t1-t0)/(steps);
			for (int j=0; j<=steps; j++)
			{
				real t = t0 + j*vstep;
				real year = (t-t0)/(365.25*86400);
				insertRow(Tuple()<<marker_id<<i<<t,
						  Tuple()<<posapprox[i]);
			}
		}
	}//Цикл по маркерам, участвующим в МНК
	InterpolatedParameterStorage::resample(t0,t1, subkey);
}

//-------------ReferenceFrames--------------------------------------------//

MarkerNotInReferenceFrame::MarkerNotInReferenceFrame(const string & framename,
						  const string & markername)
	: StrException("MarkerNotInReferenceFrame", "Маркер "+markername+
		  " не является базовым в системе отсчета "+framename)
{

}

void MarkerNotInReferenceFrame::throwMe
(DBTableCollection * base, int frame_id,int  marker_id)
{
	DBTable *fr = base->getTableIfExists("coordinate_frames");
	DBTable * mr = base->getTableIfExists("markers");
	string framename = fr->read(frame_id)[1].toString();
	string markername = mr->read(marker_id)[0].toString();
	throw MarkerNotInReferenceFrame(framename, markername);
}


ReferenceFrames::ReferenceFrames(DBTableCollection *base)
	: DBTable(Columns()
			  <<Column(Variant::TYPE_INT, "frame_id")
				<<Column(Variant::TYPE_INT, "marker_id")
				  <<Column(Variant::TYPE_INT, "coord_number"),
			  Columns()
			  <<Column(Variant::TYPE_DOUBLE, "value")
				<<Column(Variant::TYPE_DOUBLE, "epoch")
				<<Column(Variant::TYPE_DOUBLE, "stddev"))
{
	base->addTable("reference_frames", this);
	this->base = base;
}

pair<kinematic<real,6,defaultNonInert>,kinematic<real,6,defaultNonInert> >
ReferenceFrames::getPositionVelocity(int frame_id, int marker_id, real t0)
const
{
	int i=0;
	pair<kinematic<real,6,defaultNonInert>,kinematic<real,6,defaultNonInert> >
			result;
	real timemoments[3];
	for (DBTable::DBConstIterator it = find(Tuple()<<frame_id
		  <<marker_id); it!=const_end(); it.subinc(2,1))
	{
		if (i==6)
			break;
		if (i!=it.keyColumnValue(2).toInt())
			break;
		result.first[i] = it[0].toDouble();
		result.second[i] = it[2].toDouble();
		if (i<3)
			timemoments[i] = it[1].toDouble();
		i++;
	}
	if (i<6)
		MarkerNotInReferenceFrame::throwMe(base,frame_id,marker_id);
	for(unsigned int i=0; i<3; i++)
	{
		real years = (t0 - timemoments[i])/(365.25l*86400.0l);
		result.first[i] += (result.first[i+3] * years);
		result.second[i] += (result.second[i+3] * years);
	}
	return result;
}

}

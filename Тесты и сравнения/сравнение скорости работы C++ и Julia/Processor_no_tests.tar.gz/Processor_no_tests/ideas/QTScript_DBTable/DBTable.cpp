#include <map>
#include <cmath>

using namespace std;

//! @file

#include <QDateTime>
#include <DBTable.h>
#include <DBVariant.h>
#include <DBError.h>

DuplicateKeyException::DuplicateKeyException(const Tuple &keyValues)
	: StrException ("Попытка добавления строки с уже существующим"
			" значением ключа: ("+
			keyValues.join(";")+")")
{

}

IndexUniquenessException::IndexUniquenessException(const Tuple &keyvalues,
							const Tuple &values, const string &idxname)
	: StrException ("Добавление строки ("+keyvalues.join(";")+")->"
					"("+values.join(";")+") нарушает уникальность в "
					"индексе "+idxname)
{

}

string DBMap::tuplePrettyPrint(const Tuple& k, const Tuple& v) const
{
	stringstream s0;
	s0<<"(";
	if (k.size()>0)
		for (unsigned int i=0; (i<k.size())&&(i<keyColumns.size()); i++)
			s0<<keyColumns[i].second<<"="<<k[i].toString()<<" ";
	if (v.size()>0)
		for (unsigned int i=0; (i<v.size())&&(i<valueColumns.size()); i++)
			s0<<valueColumns[i].second<<"="<<v[i].toString()<<" ";
	s0<<")";
	return s0.str();
}


//-------------------------------DBMap--------------------------------------//

DBMap::DBMap(const DBMap &another)
	:QObject()
{
	for (DBMap::DBConstIterator it0 = another.const_begin();
	it0!=another.const_end(); ++it0)
		insertRow(it0.subkey(),it0.values());
}

DBMap::DBMap(const Columns& key, const Columns& value)
{
	//Запомнить список ключевых полей и полей данных
	keyColumns = key;
	valueColumns = value;
	rowsCount = 0;

	//Проверить, что таблица обладает ключом
	if (key.size() == 0)
		throw StrException("Указан пустой ключ таблицы.");

	//Проверить, что выбран ключ допустимого типа
	for (unsigned int i=0; i<key.size(); ++i)
		if ((key[i].first != Variant::TYPE_INT)
			&& (key[i].first != Variant::TYPE_DOUBLE)
			&& (key[i].first != Variant::TYPE_CHAR)
			&& (key[i].first != Variant::TYPE_STRING)
			&& (key[i].first != Variant::TYPE_DATETIME)
		)
			throw StrException("В качестве ключа в таблице DBMap"
	"был использован тип, отличный от int, double, char, string, datetime.");

	//Создать корневой элемент таблицы
	map < Variant, vector < Variant > * > * tblroot =
						new map < Variant, vector < Variant > * >;

	tableRoot = tblroot;


}

void DBMap::cleanNode (void* node, unsigned int level, Tuple key)
{
	if (level == keyColumns.size())
	{
		//processChanges();
		rowsCount--;
		delete ((vector < Variant > *)(node));
		return;
	}

	//Пока не удалены все дочерние узлы
	while (!(((map < Variant, void * >*)(node))->empty()))
	{
		map < Variant, void * >::iterator it =
				((map < Variant, void * >*)(node))->begin();
		key.push_back(it->first);
		cleanNode(it->second,level+1, key);
		((map < Variant, void * >*)(node))->erase(it);

		key.pop_back();

	}

	//Удалить дочерние узлы таблицы
//	for ( map < Variant, void * >::iterator it =
//		  ((map < Variant, void * >*)(node))->begin();
//		  it!=((map < Variant, void * >*)(node))->end(); ++it)
//	{
//		key.push_back(it->first);
//		cleanNode(it->second,level+1, key);

//		processChanges();
//		key.pop_back();
//	}

	//Очистить связи текущего узла таблицы
	((map < Variant, void * >*)(node))->clear();

	//Удалить текущий узел таблицы
	delete ((map < Variant, void * >*)(node));
}

DBMap::~DBMap()
{
	cleanNode(this->tableRoot, 0);
}

const Tuple & DBMap::operator[] ( const Tuple& keyValue ) const
{

	if (keyValue.size() < keyColumns.size())
		throw StrException("Указано недостаточно ключевых полей.");

	// Пройти докуда возможно по значениям ключа.
	unsigned int i = 0;
	void * cur = tableRoot;

	//Пройти по всем полям ключа
	for (;i<keyColumns.size(); ++i)
	{

		//Поиск в подиндексе
		map < Variant, void * >::iterator found =
			((map < Variant, void * > *)(cur))->find(keyValue[i]);

		//Если элемент подиндекса не найден
		if (found == (( map < Variant, void * > * )(cur))->end())
			//В константом варианте данного метода запрещено
			//добавлять новые строки в таблицу.
			throw KeyNotFoundException
				(keyValue);
		else
			cur = found->second;
	}

	return   *((Tuple *)(cur));
}

DBMap::DBConstIterator DBMap::const_begin() const
{
	if (count() == 0)
		return const_end();
	
	//Выделить память под результат
	DBMap::DBConstIterator result;

	//Указать, что итератор относится к данной таблицу
	result.parent = this;

	//Указать, что итератор указывает не на конец таблицы
	result.isEnd = false;

	//Начать с корня дерева
	map <Variant, void * > * cur = (map <Variant,void * > *)this->tableRoot;

	//Для каждого ключевого элемента
	for (unsigned int i=0; i<keyColumns.size(); ++i)
	{
		//Выбрать наименьшее значение этого ключевого элемента
		result.tableIterator.push_back(cur->begin());

		//Если этот ключевой элемент не принимает никаких значений,
		//положить
		if (cur->begin() == cur->end())
		{
			result.isEnd = true;
			return result;
		}
		cur = (map <Variant, void * > *)(cur->begin()->second);
	}
	return result;
}

DBMap::DBConstIterator DBMap::const_end() const
{
	DBMap::DBConstIterator result;
	result.parent = this;
	result.isEnd = true;
	return result;
}

DBMap::DBIterator DBMap::begin()
{
	return DBIterator (const_begin());
}

DBMap::DBIterator DBMap::end()
{
	return DBIterator (const_end());
}

DBMap::DBConstIterator DBMap::find(const Tuple &keyValue) const
{
	DBMap::DBConstIterator result;
	result.isEnd = false;
	result.parent = this;
	result.tableIterator.resize(keyColumns.size());
	map <Variant, void * > * cur = (map <Variant,void * > *)this->tableRoot;
	//Произвести поиск по значениям заданных ключевых полей
	for (unsigned int i=0; i<keyValue.size(); ++i)
	{
		result.tableIterator[i]=cur->find(keyValue[i]);
		//result.tableIterator.push_back(cur->find(keyValue[i]));
		if (result.tableIterator[i] == cur->end())
		{
			result.isEnd = true;
			return result;
		}
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}

	//Установить наименьшие значения оставшихся ключевых полей
	for (unsigned int i=keyValue.size(); i<keyColumns.size(); ++i)
	{
		result.tableIterator[i] = cur->begin();
		//result.tableIterator.push_back(cur->begin());
		if (result.tableIterator[i] == cur->end())
		{
			result.isEnd = true;
			return result;
		}
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}
	return result;
}

DBMap::DBIterator DBMap::find (const Tuple &keyValue)
{
	return DBMap::DBIterator (((const DBMap*)(this))->find(keyValue));
}

DBConstIterator DBMap::find ( const Variant & keyValue ) const;
{
	return find (Tuple()<<keyValue);
}

void DBMap::insertRow(const Tuple &keyValue, const Tuple &values)
{

	if (keyValue.size() < keyColumns.size())
		throw StrException ("Указано недостаточно ключевых полей.");
	
	if (values.size() < valueColumns.size())
		throw StrException ("Указано недостаточно полей данных.");
	
	map < Variant, void * > * cur = (map < Variant, void * > *) tableRoot;
	
	for (unsigned int i = 0; i<keyColumns.size(); ++i)
	{
		//Поиск в подиндексе
		map < Variant, void * >::iterator found = cur->find(keyValue[i]);
		
		//Если подиндекс не найден, создать поддерево
		if (found == cur->end())
		{
			//Если это последний элемент индекса,
			//записать требуемую строку данных
			if (i == keyColumns.size()-1)
			{
				vector < Variant > * newv = new vector < Variant > (values);
				(*cur)[keyValue[i]] = newv;
				rowsCount++;
				
				Tuple oldvals;
				oldvals.resize(valueColumns.size());
				
				//Вставка завершена
				return;
			}
			//В противном случае - создат поддерево
			else
			{
				map < Variant, void*> * newsubtree = new map <Variant, void*>;
				(*cur)[keyValue[i]] = newsubtree;
				cur = newsubtree;
			}
				
		}
		else
			cur = (map<Variant, void*>*)(found->second);
	}
	
	//Если выполнение дошло до этого места, это означает, что строка с таким
	//ключом уже существует.
	throw DuplicateKeyException (keyValue);

}

void DBMap::updateCell(const Tuple &keyValue, int colnumber,
					   const Variant &value)
{

	if (keyValue.size() < keyColumns.size())
		throw StrException("Указано недостаточно ключевых полей.");

	// Пройти докуда возможно по значениям ключа.
	unsigned int i = 0;
	void * cur = tableRoot;

	//Пройти по всем полям ключа
	for (;i<keyColumns.size(); ++i)
	{

		//Поиск в подиндексе
		map < Variant, void * >::iterator found =
			((map < Variant, void * > *)(cur))->find(keyValue[i]);

		//Если элемент подиндекса не найден
		if (found == (( map < Variant, void * > * )(cur))->end())
			//В константом варианте данного метода запрещено
			//добавлять новые строки в таблицу.
			throw KeyNotFoundException
				(keyValue);
		else
			cur = found->second;
	}

	Tuple * values = (Tuple *)cur;
	(*values)[colnumber] = value;

	//return   *((Tuple *)(cur));
}

DBMap::DBConstIterator DBMap::upper_bound(const Tuple &keyValue) const
{
	DBMap::DBConstIterator result;
	result.isEnd = false;
	result.parent = this;
	map <Variant, void * > * cur = (map <Variant,void * > *)this->tableRoot;
	int N = keyValue.size()-1;

	//result.tableIterator.resize(keyColumns.size());
	//Произвести поиск по значениям заданных ключевых полей
	Tuple foundt;
	for (int i=0; i<N; ++i)
	{
		foundt.push_back(keyValue[i]);
		map < Variant, void * > :: iterator curit = cur->find(keyValue[i]);
		if (curit == cur->end())
			return const_end();
		result.tableIterator.push_back(curit);
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}

	//n-е ключевое поле выбрать командой lower_bound
	result.tableIterator.push_back(cur->lower_bound(keyValue[N]));
	//result.tableIterator[N] = cur->lower_bound(keyValue[N]);
	if (result.tableIterator[N] == cur->end())
		return const_end();
	cur = (map <Variant, void* >*)(result.tableIterator[N]->second);

	//Установить наименьшие значения оставшихся ключевых полей
	for (unsigned int i=keyValue.size(); i<keyColumns.size(); ++i)
	{
		//result.tableIterator[i] =cur->begin();
		result.tableIterator.push_back(cur->begin());
		if (result.tableIterator[i] == cur->end())
			return const_end();
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}
	return result;
}

DBMap::DBConstIterator DBMap::lower_bound(const Tuple &keyValue) const
{
	DBMap::DBConstIterator result;
	result.isEnd = false;
	result.parent = this;
	map <Variant, void * > * cur = (map <Variant,void * > *)this->tableRoot;
	int N = keyValue.size()-1;

	//result.tableIterator.resize(keyColumns.size());

	//Произвести поиск по значениям заданных ключевых полей
	for (int i=0; i<N; ++i)
	{
		//result.tableIterator[i] = cur->find(keyValue[i]);
		result.tableIterator.push_back(cur->find(keyValue[i]));
		if (result.tableIterator[i] == cur->end())
			return const_end();
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}

	//Выбрать верхнюю грань и уменьшать поле, пока не получим нижнюю грань

	//n-е ключевое поле выбрать командой lower_bound
	map < Variant, void * > :: iterator it0 = cur->lower_bound(keyValue[N]);

	//Если не удалось выбрать lower_bound(), попробовать начать поиск с
	//максимального значения ключа
	if (it0 == cur->end())
	{
		it0 = cur->find(cur->rbegin()->first);
		if (it0 == cur->end())
		{
			result.isEnd = true;
			return result;
		}
	}

	while (it0->first > keyValue[N])
	{
		if (it0 == cur->begin())
		{
			result.isEnd = true;
			return result;
		}
		it0--;
	}

	//result.tableIterator[N] = it0;
	result.tableIterator.push_back(it0);
	if (result.tableIterator[N] == cur->end())
	{
		result.isEnd = true;
		return result;
	}

	cur = (map <Variant, void* >*)(result.tableIterator[N]->second);

	//Установить наименьшие значения оставшихся ключевых полей
	for (unsigned int i=keyValue.size(); i<keyColumns.size(); ++i)
	{
		//result.tableIterator[i] = cur->begin();
		result.tableIterator.push_back(cur->begin());
		if (result.tableIterator[i] == cur->end())
		{
			result.isEnd = true;
			return result;
		}
		cur = (map <Variant, void* >*)(result.tableIterator[i]->second);
	}
	return result;
}

void DBMap::deleteRows( const Tuple & keyValue )
{
	int N = keyValue.size()-1;
	vector < map < Variant, void * > * > maps;
	maps.resize(N+1);
	void * cur = tableRoot;

	//С помощью ключа выбрать поддерево, которое необходимо удалить
	for (int i=0; i<=N; i++)
	{
		maps[i] = (map < Variant, void * > *) (cur);
		map < Variant, void * > :: iterator it0 =
			((map < Variant, void * > *)cur)->find(keyValue[i]);
		//Если удалять нечего, ничего не удалять.
		if (it0 == ((map < Variant, void * > *)cur)->end())
			return;
		cur=it0->second;
	}

	//Удалить поддерево
	cleanNode (cur, N+1, keyValue);

	//Удалить ссылку на поддерево из родительского дерева
	if (N>=0)
		maps[N]->erase(keyValue[N]);

	//Удалить все пустые поддеревья
	for (int i=N-1; i>0; i--)
		if (maps[i]->size() == 0)
		{
			//Удалить опустевшее поддерево
			delete maps[i];

			//Удалить ссылку на только что удаленное поддерево
			maps[i-1]->erase(keyValue[i-1]);
		}

}

unsigned int DBMap::getValueColumnIndex(const std::string &valueColumnName)
const
{
	for (unsigned int i=0; i<valueColumns.size(); ++i)
		if (valueColumns[i].second == valueColumnName)
			return i;
	throw NoSuchFieldWithName(valueColumnName);
}

unsigned int DBMap::getKeyColumnIndex(const std::string &keyColumnName)
const
{
	for (unsigned int i=0; i<keyColumns.size(); ++i)
		if (keyColumns[i].second == keyColumnName)
			return i;
	throw NoSuchFieldWithName(keyColumnName);
}

//------------Переводы между QVariant и Variant-------------------------------//

Variant qvToV(const QVariant & qv)
{
	if ((qv.type() == QVariant::Int)||(qv.type() == QVariant::UInt)||
							(QVariant::ULongLong))
		return Variant(qv.toInt());
	if (qv.type() == QVariant::Double)
		return Variant((maxprec)(qv.toDouble()));
	if (qv.type() == QVariant::Invalid)
		return Variant();
	if (qv.type() == QVariant::Char)
		return Variant(qv.toChar().toAscii());
	if ((qv.type() == QVariant::Date)||(qv.type() == QVariant::DateTime))
	{
		QDateTime dt = qv.toDateTime();
		return Variant(UTCDateTime::fromUTCDateTime(dt.date().year(),
		dt.date().month(), dt.date().day(),dt.time().hour(),dt.time().minute(),
			dt.time().second()+0.001*dt.time().msec()));
	}
	if (qv.type() == QVariant::String)
		return Variant(qv.toString().toStdString());

	throw TypeMismatchException("QVariant", "DBVariant");
}

QVariant vToQV(const Variant & v)
{
	if (v.getType() == Variant::TYPE_CHAR)
		return QVariant((char)(v.toChar()));
	if (v.getType() == Variant::TYPE_DATETIME)
	{
		UTCDateTime dt = v.toUTCDateTime();
		int sec = floor(dt.getSecond());
		int msec = floor(1000*(dt.getSecond()-sec));
		return QVariant(QDateTime(QDate(dt.getYear(),dt.getMonth(),dt.getDay()),
				QTime(dt.getHour(),dt.getMinute(),sec,msec)));
	}
	if (v.getType() == Variant::TYPE_DOUBLE)
		return QVariant((double)(v.toDouble()));
	if (v.getType() == Variant::TYPE_INT)
		return QVariant((int)(v.toInt()));
	if (v.getType() == Variant::TYPE_STRING)
		return QVariant(QString::fromStdString(v.toString()));
	return QVariant(QVariant::Invalid);
}

Tuple variantListToTuple(const QVariantList & list)
{
	Tuple result;
	for (QVariantList::const_iterator it0=list.begin(); it0!=list.end(); ++it0)
		result<<qvToV(*it0);
	return result;
}

QVariantList tupleToVariantList (const Tuple & tuple)
{
	QVariantList result;
	for (int i=0; i<tuple.size(); i++)
		result.push_back(tuple[i]);
	return result;
}


//------------------Скриптовые обёртки DBMap--------------------------------//
int DBMap::count() const
{
	return rowsCount;
}

QString DBMap::Dump ( const QString & tablename ) const
{
	std::ostringstream str;
	Dump(str,tablename.toStdString());
	return QString::fromStdString(str.str());
}

void DBMap::InsertRow ( const QVariantList & key, const QVariantList & value)
{
	insertRow(variantListToTuple(key), variantListToTuple(value));
}

void DBMap::DeleteRows(const QVariantList & key)
{
	this->deleteRows(variantListToTuple(key));
}

int DBMap::getKeyColumnsCount() const
{
	return this->getKeyColumns().size();
}

int DBMap::getValueColumnsCount() const
{
	return this->getValueColumns().size();
}

QString DBMap::getKeyColumnName(int k) const
{
	return QString::fromStdString(keyColumns[k].second);
}

QString DBMap::getValueColumnName(int k) const
{
	return QString::fromStdString(valueColumns[k].second);
}

int DBMap::getKeyColumnByName(const QString & name) const
{
	return getKeyColumnIndex(name.toStdString());
}

int DBMap::getValueColumnByName(const QString & name) const
{
	return getValueColumnIndex(name.toStdString());
}

//------------------------DBConstIterator-------------------------------------//

DBConstIterator::DBConstIterator ( const DBConstIterator & other )
	: QObject(0)
{
	parent = other.parent;
	tableIterator = other.tableIterator;
	isEnd = other.isEnd;
}

const Variant & DBMap::DBConstIterator::operator[]
	( const unsigned int & valueColumnIndex ) const
{
	if (valueColumnIndex > parent->valueColumns.size())
		throw NoSuchFieldWithNumber (valueColumnIndex);
	if (this->isEnd)
		throw EndIteratorException();
	return ((Tuple*)(tableIterator[tableIterator.size()-1]->second))->
			operator [](valueColumnIndex);
}

const Variant & DBMap::DBConstIterator::operator[]
	( const std::string & valueColumnName ) const
{
	if (this->isEnd)
		throw EndIteratorException();
	return ((Tuple*)(tableIterator[tableIterator.size()-1]->second))->
			operator [](
				parent->getValueColumnIndex(valueColumnName)
				);
}

const Variant & DBMap::DBConstIterator::keyColumnValue
(const unsigned int &keyColumnIndex) const
{
	if (keyColumnIndex > parent->keyColumns.size())
		throw NoSuchFieldWithNumber (keyColumnIndex);
	if (this->isEnd)
		throw EndIteratorException();
	return tableIterator[keyColumnIndex]->first;
}

const Variant & DBMap::DBConstIterator::keyColumnValue
(const std::string &keyColumnName) const
{
	if (this->isEnd)
		throw EndIteratorException();
	return tableIterator[
			parent->getKeyColumnIndex(keyColumnName)
			]->first;
}

bool DBMap::DBConstIterator::operator ==(
		const DBMap::DBConstIterator & second ) const
{
	bool isend1 = isEnd;
	bool isend2 = second.isEnd;
	if (isend1&&isend2)
		return true;
	if (isend1||isend2)
		return false;

	if (second.parent != parent)
		return false;
	for (unsigned int i=0; i<parent->keyColumns.size(); ++i)
		if (tableIterator[i]!=second.tableIterator[i])
			return false;
	return true;
}

DBMap::DBConstIterator & DBMap::DBConstIterator::subinc
(const int colnumber, const int fixcolnumber, const int incriment)
{

	if (incriment <= 0)
		return (*this);

	//Свести задачу к увеличению на единицу
	subinc (colnumber, fixcolnumber, incriment-1);

	if (isEnd)
		throw OutOfBoundException();

	//Инкримент
	++(tableIterator[colnumber]);

	//Если требовался инкримент по нулевому полю, но оно уже дошло до конца
	//тогда установить итератор в состояние end()
	if ((colnumber == 0) && (tableIterator[0] ==
	((map<Variant, void*>*)(parent->tableRoot))->end()))
	{
		isEnd = true;
		return (*this);
	}

	if ((colnumber>0) && (colnumber<= fixcolnumber + 1) &&
		(tableIterator[colnumber] ==
		((map<Variant, void*>*)(tableIterator[colnumber-1]->second))->
		end()))
	{
		isEnd = true;
		return (*this);
	}

	//Если требовался инкримент по i-му полю, но оно уже дошло до последнего
	//возможного значения, совершить инкримент предыдущего поля.
	if (colnumber>fixcolnumber+1)
		if (tableIterator[colnumber] ==
		((map<Variant, void*>*)(tableIterator[colnumber-1]->second))->
			end())
			return subinc(colnumber-1,fixcolnumber, 1);

	//Теперь установить все последующие ключевые поля на наименьшие
	//значения
	for (unsigned int j = colnumber+1; j<tableIterator.size(); ++j)
		tableIterator[j] =
		((map<Variant, void*>*)(tableIterator[j-1]->second))->begin();

	return (*this);
}

DBMap::DBConstIterator & DBMap::DBConstIterator::inc
(const int colnumber, const int incriment)
{
	return subinc(colnumber, -1, incriment);
}

DBMap::DBConstIterator & DBMap::DBConstIterator::subdec
(const int colnumber, const int fixcolnumber, const int decriment)
{
	int fieldscount = parent->keyColumns.size();

	if (decriment <= 0)
		return (*this);

	//Свести задачу к декременту на единицу
	subdec (colnumber, fixcolnumber, decriment-1);

	//Если указывает на конец, перейти к последнему элементу.
	if (isEnd)
	{
		//Если число записей равно нулю, то последнего элемента также нет
		if (parent->count() == 0)
			return *this;

		//Выделить нужное число map::iterator'ов
		if (fieldscount>tableIterator.size())
			tableIterator.resize(fieldscount);
		
		map<Variant, void*>* cur = ((map<Variant, void*>*)(parent->tableRoot));
		
		//Установить самое большое допустимое значение для нулевого поля
		map<Variant,void*>::reverse_iterator itr = cur->rbegin();
		if (itr == cur->rend())
			return (*this);
		
		//Теперь заполнить все оставшиеся поля
		tableIterator[0] = cur->find(itr->first);
		for (unsigned int i=1; i<fieldscount; i++)
		{
			cur = (map<Variant, void*>*)(tableIterator[i-1]->second);
			itr = cur->rbegin();
			tableIterator[i] = cur->find(itr->first);
		}
		this->isEnd = false;
		return (*this);

	}

	//Если декремент невозможен
	if ((colnumber == 0) && (tableIterator[0] ==
			((map<Variant, void*>*)(parent->tableRoot))->begin()))
		throw OutOfBoundException();

	if ((colnumber>0)&&(colnumber<=fixcolnumber+1))
		if
		(tableIterator[colnumber] ==
		 ((map<Variant, void*>*)(tableIterator[colnumber-1]->second))
		 ->begin())
			throw OutOfBoundException();

	//Если требовался декримент по i-му полю, но оно уже установлено в
	//наименьшее значение, совершить декремент предыдущего поля
	if (colnumber > fixcolnumber + 1)
		if (tableIterator[colnumber] ==
		((map<Variant, void*>*)(tableIterator[colnumber-1]->second))->
			begin())
			return subdec (colnumber-1, 1);

	//Декремент
	--tableIterator[colnumber] ;

	//Установить все последующие колонки в end-1
	//Для этого используются обратный итератор
	for (unsigned int j = colnumber+1; j<tableIterator.size(); ++j)
		tableIterator[j] =
			((map<Variant, void*>*)(tableIterator[j-1]->second))->
				find(
			((map<Variant, void*>*)(tableIterator[j-1]->second))->
					rbegin()->first
					);

	return (*this);
}

DBMap::DBConstIterator & DBMap::DBConstIterator::dec
(const int colnumber, const int decriment)
{
	return subdec(colnumber, -1, decriment);
}

//------------------Скриптовые обертки вокруг итератора---------------------//

void DBMap::DBConstIterator::Inc (int column, int step = 1)
{
	inc(column, step);
}

void DBMap::DBConstIterator::Dec (int column, int step = 1)
{
	dec(column, step);
}

void DBMap::DBConstIterator::SubInc (int column, int fixcolumn, int step = 1)
{
	subinc(column, fixcolumn, step);
}

void DBMap::DBConstIterator::SubDec (int column, int fixcolumn, int step = 1)
{
	subdec(column,fixcolumn, step);
}

QVariantList DBMap::DBConstIterator::Values ()
{
	return tupleToVariantList(values());
}

QVariant DBMap::DBConstIterator::Value (int column)
{
	return vToQV((*this)[column]);
}

QVariantList DBMap::DBConstIterator::KeyValues ()
{
	return tupleToVariantList(subkey());
}

QVariant DBMap::DBConstIterator::KeyValue (int column)
{
	return vToQV(keyColumnValue(column));
}

void DBMap::DBIterator::UpdateCell(int colnumber, const QVariant &newvalue)
{
	updateCell(colnumber, qvToV(newvalue));
}

QScriptValue DBMap::registerIterator(const DBConstIterator *it)
{
	return myengine->newQObject(it, QScriptEngine::ScriptOwnership);
}

QScriptValue DBMap::Begin() const
{
	return registerIterator(new DBIterator(begin()));
}

QScriptValue DBMap::Last() const
{
	DBIterator * result = new DBIterator (end());
	result->operator --();
	return registerIterator(result);
}

bool DBMap::IsEnd (const QScriptValue & iterator)
{
	DBIterator * thisiterator = (DBIterator * )iterator.toQObject();
	return thisiterator->isEnd;
}

QScriptValue DBMap::Find(const QVariantList & keyvalue)
{
	return registerIterator(new DBIterator (find(qvToV(keyvalue))));
}

QScriptValue DBMap::LowerBound (const QVariantList & keyvalue)
{
	return registerIterator(new DBIterator (lower_bound(qvToV(keyvalue))));
}

QScriptValue DBMap::UpperBound (const QVariantList & keyvalue)
{
	return registerIterator(new DBIterator (upper_bound(qvToV(keyvalue))));
}

void DBMap::UpdateCell (const QVariantList&key, int column, const QVariant&v)
{
	updateCell(variantListToTuple(key), column, qvToV(v));
}

//-------------------------------ИСКЛЮЧЕНИЯ---------------------------------//

KeyNotFoundException::KeyNotFoundException(const Tuple &keyValues)
	: StrException ("Не удалось найти строку по элементам"
			" ключа: ("+
			keyValues.join(";")+")")
{

}

OutOfBoundException::OutOfBoundException()
	: StrException("Выход за границу массива")
{

}

EndIteratorException::EndIteratorException()
	: StrException("Обращение к данным по итератору, указывающему за "
		       "пределы таблицы.")
{

}

IndexAlreadyExistsException::IndexAlreadyExistsException(string indexname)
	: StrException("Таблица уже имеет индекс '"+indexname+"'.")
{

}

NoSuchFieldWithName::NoSuchFieldWithName(const string &name)
	: StrException("Обращение к полю по несуществующему имени поля: "+
				   name)
{

}

NoSuchFieldWithNumber::NoSuchFieldWithNumber(int number)
	: StrException ("Обращение к полю по номеру, превышающему число "
					"полей: " + Variant(number).toString())
{

}

void DBMap::Dump(ostream & output, const string & name) const
{
	for (DBConstIterator it0=const_begin(); it0!=const_end(); ++it0)
	{
		output<<name;
		for (unsigned int i = 0; i<getKeyColumns().size(); i++)
		{
			string kv = it0.keyColumnValue(i).toString();
			output<<'\t'<<kv;
		}
		for (unsigned int i=0; i<getValueColumns().size(); i++)
		{
			string dv = it0[i].toString();
			output<<'\t'<<dv;
		}
		output<<endl;
	}

}

//-----------------DBTable------------------------------------------------//

Tuple DBTable::idx_key(string idxname, const Tuple &key, const Tuple &value)
{
	Tuple result;
	result.resize(indices[idxname].first.size());
	for (unsigned int i=0; i<indices[idxname].first.size(); i++)
	{
		if (indices[idxname].first[i].first=='K')
			result[i] = key[indices[idxname].first[i].second];
		else
			result[i] = value[indices[idxname].first[i].second];
	}
	return result;
}

void DBTable::addToIndices(const Tuple &keyValue, const Tuple &values)
{
	for (map < string, pair < vector < pair<char, int> >,DBMap*> >::iterator
		 it0 = indices.begin(); it0!=indices.end(); ++it0)
	{
		Tuple idxkey = idx_key(it0->first, keyValue, values);
		try
		{
			it0->second.second->insertRow(idxkey,keyValue);
		}
		catch (DuplicateKeyException e)
		{
			//В случае нарушения уникальности в индексе, откатить уже
			//добавленные индексы и вернуть исключение
			while (true)
			{
				--it0;
				Tuple idxdelkey = idx_key(it0->first, keyValue, values);
				it0->second.second->deleteRows(idxdelkey);
				if (it0==indices.begin())
					break;
			}
			throw IndexUniquenessException (keyValue, values, it0->first);
		}
	}
}

void DBTable::removeFromIndices(const Tuple &keyValue, const Tuple &values)
{
	for (map < string, pair < vector < pair<char, int> >,DBMap*> >::iterator
		 it0 = indices.begin(); it0!=indices.end(); ++it0)
	{
		Tuple idxkey = idx_key(it0->first, keyValue, values);
		it0->second.second->deleteRows(idxkey);
	}
}

void DBTable::insertRow(const Tuple &keyValue, const Tuple &values)
{
	//1) Сначала попробовать вставить во все индексы. Если возникло исключение,
	// не обрабатывать его, но выйти из процедуры
	addToIndices(keyValue,values);

	//2) Теперь попробовать вставить в основной индекс
	try
	{
		DBMap::insertRow(keyValue, values);
	}
	catch (DuplicateKeyException e)
	{
		//3) Если не удалось вставить в таблицу, удалить из всех индексов
		removeFromIndices(keyValue,values);
		throw e;
	}
}

void DBTable::deleteRows(const Tuple &keyValue)
{
	if (indices.size()>0)
		//Обойти всё поддерево и стереть его из индексов
		for (DBTable::DBConstIterator it0 = find(keyValue); it0!=const_end();
			 it0.subinc(keyColumns.size()-1,keyValue.size()-1))
		{
			Tuple key = it0.subkey();
			removeFromIndices(key,*it0);
		}
	DBMap::deleteRows(keyValue);
}

void DBTable::updateCell(const Tuple &keyValue, int colnumber,
						 const Variant &value)
{
	Tuple oldValues = read(keyValue);
	Tuple newValue = oldValues;
	newValue[colnumber] = value;

	//Удалить из индексов эту строку
	removeFromIndices(keyValue,oldValues);

	//Добавить в индексы новую строку
	try
	{
		addToIndices(keyValue, newValue);
	}
	catch (IndexUniquenessException e)
	{
		//Если не получилось, то задержать вызов исключения до того, как
		//строка будет возвращена во все индексы
		addToIndices(keyValue, oldValues);
		throw e;
	}

	//После этого можно спокойно внести изменения в таблицу
	DBMap::updateCell(keyValue, colnumber, value);

}


void DBTable::createIndex (const string&name,
						   const OperatorPushableVector < string > & fields)
{
	//Поиск поля по названию среди полей основного ключа и значений
	vector < pair < char, int > > indexfields;
	Columns keycolumns;
	for (unsigned int i=0; i<fields.size(); i++)
	{
		for (unsigned int j=0; j<keyColumns.size(); j++)
			if (keyColumns[j].second == fields[i])
			{
				indexfields.push_back(pair<char, int>('K',j));
				keycolumns.push_back(Column(keyColumns[j].first,fields[i]));
			}
		for (unsigned int j=0; j<valueColumns.size(); j++)
			if (valueColumns[j].second == fields[i])
			{
				indexfields.push_back(pair<char, int>('V',j));
				keycolumns.push_back(Column(valueColumns[j].first,fields[i]));
			}
	}

	//Добавление нового индекса
	DBMap * dbm = new DBMap (keycolumns, keyColumns);

	indices[name] = pair < vector < pair<char, int> >, DBMap * >
			(indexfields, dbm);
//	indices[name] =


	//Создание нового индекса
	for (DBMap::DBConstIterator it0 = const_begin(); it0!=const_end(); ++it0)
	{
		Tuple keyvals;
		keyvals.resize(indexfields.size());
		for (unsigned int i=0; i<indexfields.size(); i++)
		{
			if (indexfields[i].first=='K')
				keyvals[i]=it0.keyColumnValue(indexfields[i].second);
			else
				keyvals[i]=it0[indexfields[i].second];
		}
		dbm->insertRow(keyvals, it0.subkey());
	}
}

void DBTable::dropIndex ( const string & name)
{
	indices.erase(name);
}

const Tuple & DBTable::mainKey ( const string & name, const Tuple & idx_key )
const
{
	return indices.at(name).second->read(idx_key);
}

DBMap::DBConstIterator DBTable::idx_upper_bound(const string & name,
												const Tuple &keyValue) const
{
	DBTable::DBConstIterator it0=indices.at(name).second->upper_bound(keyValue);
	if (it0 == indices.at(name).second->const_end())
		return const_end();
	else
		return find(*it0);
}

DBMap::DBConstIterator DBTable::idx_lower_bound(const string & name,
												const Tuple &keyValue) const
{
	DBTable::DBConstIterator it0=indices.at(name).second->lower_bound(keyValue);
	if (it0 == indices.at(name).second->const_end())
		return const_end();
	else
		return find(*it0);
}

DBMap::DBConstIterator DBTable::idx_find(const string &name,
										 const Tuple &idx_key) const
{
	DBMap::DBConstIterator it1 = indices.at(name).second->find(idx_key);
	if (it1 == indices.at(name).second->const_end())
		return const_end();
	else
		return find(it1.values());
}

//-----------Скриптовые обертки к дополнительным индексам ---------------//
void DBTable::CreateIndex (const QString & name, const QStringList & fields)
{
	vector < string > stl_fields;
	for (QStringList::iterator it = fields.begin(); it!=fields.end(); ++it)
		stl_fields.push_back(it->toStdString());
	createIndex(name.toStdString(), stl_fields);
}

void DBTable::DropIndex (const QString & name)
{
	dropIndex(name.toStdString());
}

QVariantList DBTable::MainKey (const QString & name, const QVariantList & key)
{
	return tupleToVariantList(mainKey(name.toStdString(),
									  variantListToTuple(key)));
}

QScriptValue DBTable::Idx_Find (const QString & name, const QVariantList & key)
{
	return registerIterator(idx_find(name.toStdString(),
									 variantListToTuple(key)));
}

QScriptValue DBTable::Idx_LowerBound(const QString&name, const QVariantList&key)
{
	return registerIterator(idx_lower_bound(name.toStdString(),
									 variantListToTuple(key)));
}

QScriptValue DBTable::Idx_UpperBound(const QString&name, const QVariantList&key)
{
	return registerIterator(idx_upper_bound(name.toStdString(),
									 variantListToTuple(key)));
}

//------------------------NUMERATEDTABLE-----------------------------//

int NumeratedTable::insertRow(const Tuple &values)
{
	int newkeyvalue;
	if (count() == 0)
		newkeyvalue = 0;
	else
	{
		//Перейти к последнему элементу
		DBTable::DBConstIterator it = const_end();
		it.dec(0);

		//Новое значение ключа на 1 больше предыдущего
		newkeyvalue = it.keyColumnValue(0).toInt() + 1;
	}
	DBTable::insertRow(Tuple()<<newkeyvalue, values);

	return newkeyvalue;
}

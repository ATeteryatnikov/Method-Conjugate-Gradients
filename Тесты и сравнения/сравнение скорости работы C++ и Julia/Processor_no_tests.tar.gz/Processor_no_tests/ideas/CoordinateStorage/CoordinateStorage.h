#ifndef COORDINATESTORAGE_H_
#define COORDINATESTORAGE_H_

#include <map>
#include <string>

using namespace std;

#include <InterpolatedParameterStorage.h>
#include <DBTableCollection.h>
#include <StdTables.h>
#include <Frames.h>

class CoordinatSystemMismatch : public StrException
{
public:
	CoordinatSystemMismatch (string frame0, string frame1)
		: StrException ("Невозможно задать координаты объекта в системе "
						"координат " + frame1, " поскольку координаты этого "
						"объекта уже хранятся в системе координат "+frame0)
	{

	}
};

class NoCoordinatesForObject : public StrException
{
public:
	NoCoordinatesForObject(int id)
		: StrException("Для объекта с id="+Variant(id).toString()+
					   " нет координат.")
	{

	}
};

class FrameHasNoVelocity : public StrException
{
public:
	FrameHasNoVelocity(const string & frame);
};

class FrameHasNoAcceleration : public StrException
{
public:
	FrameHasNoAcceleration(const string& frame);
};


/**
 * @brief Хранилище координат каких-либо объектов
 *
 * Класс предназначен для хранения координат каких-либо объектов, например,
 * НКА или БИС.
 *
 * Ключ:
 * @li int object_id - идентификатор объекта
 * @li int coordinate_id - идентификатор координаты (соответствует
 * coordinate_id в таблице @ref CoordinateTypes
 * @li double t - момент времени (секунды TAI от J2000)
 *
 * Координаты объектов могут храниться в разных системах коордиат.
 * Система координат должна быть задана в таблице @ref CoordinateFrames,
 * а типы всех хранимых координат должны быть заданы в таблице
 * @ref CoordinateTypes. Каждой компоненте (например, X, Y, Z) вектора
 * положения объекта и скорости объекта соответствует отдельная строка в
 * таблице. Например, если заданы координаты и скорость объекта в какой-либо
 * момент времени, то они соответствуют шести строкам в таблице.
 *
 * Координаты каждого отдельного объекта хранятся в одной системе координат.
 * Для отслеживания соблюдения этого правила в классе перегружены методы
 * редактирования таблицы.
 *
 * @note В данном классе не задаются пределы экстраполяции и аппроксимации
 * (т.е. насколько далеко искомая точка может находиться от крайней точки
 * сетки аппроксимации, и если она находится внутри сетки, то насколько
 * большой шаг допустим между узлами аппроксимации). Их задание необходимо
 * делать в конструкторе наследующего класса.
 *
 */
class CoordinateStorage : public InterpolatedParameterStorage
{
private:

	/** Отображение Номер объекта -> Пара:
	 * Пара (Номер системы координат, её тип),
	 * список её координат в порядке номера координаты (поле coordinate_number
	 * таблицы @ref CoordinateTypes).
	 */
	map < int, pair < pair <int, int>, vector < int > > > coordSystem;

	Frames * frames;
	CoordinateTypes * ctypes;

	/**
	 * @brief Получить имеющиеся координаты (не фиктивные) объекта
	 * @param obj_id Идентификатор объекта
	 * @param t Момент времени, секунды TAI от J2000
	 * @param pos Возвращаемое положение объекта
	 * @param coord_ids Идентификаторы требуемых координат
	 * @return Число полученных координат (3, 6, 9)
	 *
	 * Требуемое число координат задаётся размером массива pos, под который
	 * уже должна быть выделена память.
	 *
	 * В массиве coord_ids должны быть соответствующие идентификаторы.
	 */
	int extractCoordinates (int obj_id, timeMoment t, vector < coord > & pos,
							const vector < int > & coord_ids);

public:

	CoordinateStorage(DBTableCollection * base, string storageName);

	//! Метод перегружен для отслеживания согласования координат объектов
	virtual void insertRow(const Tuple &keyValue, const Tuple &values);

	//! Метод перегружен для отслеживания согласования координат объектов
	virtual void deleteRows(const Tuple &keyValue);

	virtual kinematic < coord, 3, defaultInert > getPosition
						(unsigned short int obj_id,
						 timeMoment t) const;

	virtual kinematic < coord, 6, defaultInert > getPositionVelocity
						(unsigned short int obj_id,
						 timeMoment t) const;

	//! Найти положение, скорость и ускорение НКА в данный момент времени
	virtual kinematic < coord, 9, defaultInert > getPositionVelocityAcceleration
						(unsigned short int obj_id,
						 timeMoment t) const;

	//! Конечный момент времени
	virtual timeMoment getBeginTime(unsigned short int obj_id) const;

	//! Начальный момент времени
	virtual timeMoment getEndTime(unsigned short int obj_id) const;

	//! @brief Перевести все координаты в инерциальную систему координат
	void toInertial();

	//! @brief Вычислить скорости, если их нет
	void calcVelocity();
};


#endif

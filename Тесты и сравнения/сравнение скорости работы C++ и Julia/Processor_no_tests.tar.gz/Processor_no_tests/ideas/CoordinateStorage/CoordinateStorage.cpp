#include <CoordinateStorage.h>

FrameHasNoAcceleration::FrameHasNoAcceleration(const string& frame)
	: StrException("Для системы координат не определены компоненты ускорения: "
		+ frame )
{

}

FrameHasNoVelocity::FrameHasNoVelocity(const string& frame):
	StrException("Для системы координат не определены компоненты скорости: "
	+ frame)
{

}


CoordinateStorage::CoordinateStorage(DBTableCollection * base,
									 string storageName)
	: InterpolatedParameterStorage(base, storageName, Columns()
								   <<Column(Variant::TYPE_INT, "id")
								  <<Column(Variant::TYPE_INT, "coordinate_id")
								 <<Column(Variant::TYPE_DOUBLE, "time"))
{
	frames = (Frames *)(base->getEssentialTable("coordinate_frames"));
	ctypes = (CoordinateTypes *)(base->getEssentialTable("coordinate_types"));
}

int CoordinateStorage::extractCoordinates(int obj_id, timeMoment t,
							vector<coord> &pos, const vector<int> &coord_ids)
{
	int req_count = pos.size();

	Tuple key0;

	//Попытаться извлечь координаты
	key0<<obj_id<<coord_ids[0];
	for (unsigned int i=0; i<3; i++)
	{
		key0[i] = coord_ids[i];
		pos[i] = getParameterValue(key0, t);
	}

	if (req_count == 3)
		return 3;

	//Попытаться извлечь скорость
	try
	{
		for (unsigned int i=3; i<6; i++)
		{
			key0[i] = coord_ids[i];
			pos[i] = getParameterValue(key0, t);
		}
	}
	catch (StrException e)
	{
		return 3;
	}

	if (req_count == 6)
		return 6;

	//Попытатьсся извлечь ускорения
	try
	{
		for (unsigned int i=6; i<9; i++)
		{
			key0[i] = coord_ids[i];
			pos[i] = getParameterValue(key0, t);
		}
	}
	catch (StrException e)
	{
		return 6;
	}
	return 9;
}

void CoordinateStorage::insertRow(const Tuple &keyValue,
										  const Tuple &values)
{
	int obj_id = keyValue[0].toInt();
	int coord_id = keyValue[1].toInt();
	int frame_id = ctypes->getCoordinateFrame(coord_id);

	//Если информации о системе координат для данного объекта нет,
	//
	if (coordSystem.find(obj_id)==coordSystem.end())
		coordSystem[obj_id] = pair <pair <int, int> ,vector <int> > (
					pair < int, int > (frame_id, frames->getFrameType(frame_id),
									 frames->getFrameCoordinates(frame_id) );

	// Если информация есть, проверить, что система координат не изменилась
	else
		if (frame_id != coordSystem[obj_id].first.first)
			throw CoordinatSystemMismatch(
				frames[Tuple()<<coordSystem[obj_id].first.first][1].toString(),
				frames[Tuple()<<frame_id][1].toString());

	//Занести информацию.
	InterpolatedParameterStorage::insertRow(keyValue,values);
}

void CoordinateStorage::deleteRows(const Tuple &keyValue)
{
	InterpolatedParameterStorage::deleteRows(keyValue);

	//После удаления проверить, что для данного объекта остались ещё
	//другие координаты. Если их не осталось, можно стереть запись в структуре
	//coordSystem, чтобы разрешить занести координаты этого объекта в другой
	//системе координат
	if (keyValue.size() == 0)
		coordSystem.clear();
	else
	{
		int obj_id = keyValue[0].toInt();
		if (find(Tuple()<<obj_id) == const_end())
			coordSystem.erase(obj_id);
	}
}



kinematic < coord, 3, defaultInert > CoordinateStorage::getPosition
					(unsigned short int obj_id,
					 timeMoment t) const
{
	//Найти, в какой системе координат заданы координаты объекта
	map < int, pair < pair < int, int >, vector < int > > >::iterator it0 =
			coordSystem.find(sat_id);

	//Если ни в какой, вернуть ошибку
	if (it0 == coordSystem.end())
		throw NoCoordinatesForObject(sat);

	//Для всех систем координат положение задаётся тремя компонентами
	int reqCoordinatesCount = 3;

	//Кроме элементов орбиты, где положение смешано со скоростью, и
	//всё вместе задаётся шестью элементами
	Frames::FrameType ft = it0->first.second;
	if (ft==Frames::FT_Elements)
		reqCoordinatesCount = 6;

	vector < coord > pos;
	pos.resize(reqCoordinatesCount);
	extractCoordinates(obj_id, t, pos, it0->second);

	//И передать модулю frames для вычисления координат в системе GCRS
	return frames->posInert(pos,it0->first.first,t);
}

kinematic < coord, 6, defaultInert > CoordinateStorage::getPositionVelocity
					(unsigned short int obj_id,
					 timeMoment t) const
{
	//Найти, в какой системе координат заданы координаты объекта
	//Найти, в какой системе координат заданы координаты объекта
	map < int, pair < pair < int, int >, vector < int > > >::iterator it0 =
			coordSystem.find(obj_id);

	//Если ни в какой, вернуть ошибку
	if (it0 == coordSystem.end())
		throw NoCoordinatesForObject(sat);

	//Известны ли для данной системы координат номера координат скорости?
	if (it0->second.size()<6)
		throw FrameHasNoVelocity(
				frames[Tuple()<<it0->first.first][1].toString());

	//Число компонент, нужных для вычисления координат. 3 для всех типов
	//систем координат, кроме элементов орбиты
	int reqCoordinatesCount = 3;

	//Кроме элементов орбиты, где положение смешано со скоростью, и
	//всё вместе задаётся шестью элементами
	Frames::FrameType ft = it0->first.second;
	if (ft==Frames::FT_Elements)
		reqCoordinatesCount = 6;

	vector < coord > pos;
	pos.resize(6);
	int extr = extractCoordinates(obj_id,t,pos,it0->second);
	if (extr == 6)
		return frames->posVelInert(pos,it0->first.first,t);
	else
		return frames->posInert(pos,it0->first.first,t).concat(
					kinematic < coord, 3, defaultInert > (
						numeric_limits<coord>::quiet_NaN())
}

kinematic < coord, 9, defaultInert > CoordinateStorage::
getPositionVelocityAcceleration
					(unsigned short int obj_id,
					 timeMoment t) const
{
	//Найти, в какой системе координат заданы координаты объекта
	//Найти, в какой системе координат заданы координаты объекта
	map < int, pair < pair < int, int >, vector < int > > >::iterator it0 =
			coordSystem.find(obj_id);

	//Если ни в какой, вернуть ошибку
	if (it0 == coordSystem.end())
		throw NoCoordinatesForObject(sat);

	//Известны ли для данной системы координат номера координат скорости?
	if (it0->second.size()<9)
		throw FrameHasNoAcceleration(
				frames[Tuple()<<it0->first.first][1].toString());

	//Число компонент, нужных для вычисления координат. 3 для всех типов
	//систем координат, кроме элементов орбиты
	int reqCoordinatesCount = 3;

	//Кроме элементов орбиты, где положение смешано со скоростью, и
	//всё вместе задаётся шестью элементами
	Frames::FrameType ft = it0->first.second;
	if (ft==Frames::FT_Elements)
		reqCoordinatesCount = 6;

	vector < coord > pos;
	pos.resize(9);
	int extr = extractCoordinates(obj_id,t,pos,it0->second);
	if (extr == 9)
		return frames->posVelAccelInert(pos,it0->first.first, t);
	if (extr == 6)
		return frames->posVelInert(pos,it0->first.first, t).concat(
					kinematic < coord, 3, defaultInert > (
						numeric_limits<coord>::quiet_NaN())
					);
	return frames->posInert(pos,it0->first.first,t).concat(
					kinematic < coord, 6, defaultInert > (
						numeric_limits<coord>::quiet_NaN()));
}

timeMoment CoordinateStorage::getBeginTime(unsigned short int obj_id) const
{
	DBConstIterator c = find(Tuple()<<(int)obj_id);
	return c.keyColumnValue(2).toDouble();
}

timeMoment CoordinateStorage::getEndTime(unsigned short int obj_id) const
{
	DBConstIterator c1 = lower_bound(Tuple()<<obj_id
					<<coordSystem[obj_id].first.first
					 <<numeric_limits<maxprec>::infinity());
	return c1.keyColumnValue(2).toDouble();
}

void CoordinateStorage::toInertial()
{
	vector < int > coordtypes = framest->getFrameCoordinates(
				framest->getCoordinateFrameID("GCRS"));

	//Пройти по всем объектам
	for (DBTable::DBConstIterator it0=begin(); it0!=const_end(); it0.inc(0))
	{
		//Взять номер объекта
		unsigned short int obj_id = it0.keyColumnValue(0).toInt();

		//Проверить, что координаты объекта уже не в GCRS
		if (coordSystem[obj_id].first.second==Frames::FT_ECIF)
			continue;

		//Для моментов времени используется тип Variant, чтобы
		//исключить какие-либо преобразования.
		vector < Variant > epochs;
		for (DBTable::DBConstIterator it1=find(Tuple()<<obj_id);
			 it1!=const_end(); it1.subinc(2,1))
			epochs.push_back(it1.keyColumnValue(2));

		//Теперь вычислить координаты в эти моменты времени
		vector < kinematic < coord, 9, defaultInert > > vec;
		vec.resize(epochs.size());

		vector < int > oldcoordtypes = coordSystem[obj_id].second;

		for (unsigned int i=0; i<epochs.size(); i++)
		{
			if (oldcoordtypes.size() == 3)
				vec[i] = getPosition(obj_id, epochs[i].toDouble()).concat<6>
								(kinematic<coord,6,defaultInert>
									(numeric_limits<coord>::quiet_NaN()));
			if (oldcoordtypes.size() == 6)
				vec[i] = getPositionVelocity(obj_id, epochs[i].toDouble())
					.concat<3>(kinematic<coord,3,defaultInert>
									(numeric_limits<coord>::quiet_NaN()));;
			if (oldcoordtypes.size() == 9)
				vec[i] = getPositionVelocityAcceleration(obj_id,
														  epochs[i].toDouble());
		}

		//Удалить имеющиеся координаты
		for (unsigned int i=0; i<oldcoordtypes.size(); i++)
			deleteRows(Tuple()<<obj_id<<oldcoordtypes[i]);

		//Вставить полученные координаты в таблицу
		for (unsigned int j=0; j<epochs.size(); j++)
		{
			for (unsigned int i=0; i<coordtypes.size(); i++)
				if (!isnan(vec[j][i]))
					insertRow(Tuple()<<obj_id<<
						  coordtypes[i]<<epochs[j],
						  Tuple()<<vec[j][i]);
		}
	}
}

void CoordinateStorage::calcVelocity()
{

}
